# Dyad GetRate API Documentation

## Overview

The Dyad GetRate API endpoint provides insurance rate quotes for commercial package policies. This endpoint accepts detailed policy information including property, liability, and coverage details, then returns pricing and coverage options.

## Endpoint

```
POST /api/dyed/getrate
```

## Authentication

This endpoint uses the wrapper's automatic authentication. The wrapper will:
1. Fetch a JWT token from the Dyad authentication service
2. Cache the token for reuse
3. Automatically refresh the token before expiry
4. Include the Bearer token in all API calls

No manual authentication is required from the client.

## Request Model

The request uses the strongly-typed `DyadGetRateRequest` model with the following structure:

### Root Object

```csharp
public class DyadGetRateRequest
{
    public SignonRequest SignonRq { get; set; }
    public InsuranceServiceRequest InsuranceSvcRq { get; set; }
}
```

### Key Request Fields

#### SignonRq (Sign-on Request)
- **CustLoginId**: Customer login identifier (e.g., "SLBGROUP")

#### InsuranceSvcRq (Insurance Service Request)
- **RqUID**: Unique request identifier (GUID format) - **Required**
- **IRH_QuoteNo**: Your system's quote number
- **IRH_Application_Name**: Your application name
- **IRH_Application_Type**: Application type (e.g., "QRB")
- **IRH_Request_Type**: Request type (e.g., "QUOTE")

#### Carrier Information
- **comIRH_CarrierRequestExt.comIRH_CarrierInfoExt**: Array of carriers to quote
  - IRH_CarrierName: Carrier name (e.g., "ACI", "USLI")
  - IRH_AdmittedStatus: Admitted status ("N" for non-admitted)

#### Policy Information
- **CommlPkgPolicyQuoteInqRq**: Commercial package policy quote request
  - **FormsRequestedCd**: Forms requested (e.g., "BOTH")
  - **SaveIndicationCd**: Save indication (e.g., "Yes")
  - **Producer**: Array of producer information
  - **InsuredOrPrincipal**: Insured party information
  - **Policy**: Policy details including effective dates
  - **Location**: Array of property locations
  - **CommlGeneralLiabilityLineBusiness**: General liability coverage
  - **CommlPropertyLineBusiness**: Property coverage
  - **PriorLoss**: Prior loss history

## Request Example

See the complete example in `/Examples/DyadGetRateRequest-Example.json`

### Minimal Request Example

```json
{
  "SignonRq": {
    "SignonPswd": {
      "CustId": {
        "CustLoginId": "SLBGROUP"
      }
    }
  },
  "InsuranceSvcRq": {
    "RqUID": "{{guid}}",
    "IRH_QuoteNo": "Q123456",
    "IRH_Application_Name": "My Application",
    "IRH_Application_Type": "QRB",
    "IRH_Request_Type": "QUOTE",
    "comIRH_CarrierRequestExt": {
      "comIRH_CarrierInfoExt": [
        {
          "IRH_CarrierName": "USLI",
          "IRH_AdmittedStatus": "N"
        }
      ]
    },
    "CommlPkgPolicyQuoteInqRq": {
      "FormsRequestedCd": "BOTH",
      "SaveIndicationCd": "Yes",
      "Policy": {
        "LOBCd": "CPKGE",
        "ContractTerm": {
          "EffectiveDt": "2025-09-15T00:00:00Z",
          "ExpirationDt": "2026-09-15T00:00:00Z"
        }
      },
      "BusinessPurposeTypeCd": "NBS",
      "TransactionRequestDt": "2025-09-15T00:00:00Z"
    }
  }
}
```

## Response Model

The response is an array containing one or more `DyadGetRateResponse` objects:

```csharp
public class DyadGetRateResponse
{
    public SignonResponse SignonRs { get; set; }
    public InsuranceServiceResponse InsuranceSvcRs { get; set; }
}
```

### Key Response Fields

#### InsuranceSvcRs
- **RqUID**: Request unique identifier (echoed from request)
- **IRH_QuoteNo**: Quote number
- **IRH_Rating_StatusCd**: Rating status ("Success", "Error", etc.)
- **MsgStatus**: Array of status messages
  - MsgStatusCd: Status code
  - MsgStatusDesc: Status description
- **CommlPkgPolicyQuoteInqRs**: Commercial package policy quote response
  - Producer: Producer information
  - InsuredOrPrincipal: Insured information
  - Policy: Policy details
  - Location: Location information
  - CommlGeneralLiabilityLineBusiness: GL coverage details
  - CommlPropertyLineBusiness: Property coverage details
  - BrokerageCommissionInfo: Commission information

## Response Example

### Success Response

```json
[
  {
    "SignonRs": {
      "SignonPswd": {
        "CustId": {
          "CustLoginId": "SLBGROUP",
          "SPName": ""
        }
      }
    },
    "InsuranceSvcRs": {
      "RqUID": "4ac5e506-a9b0-40d8-a7be-45a2800f4878",
      "IRH_QuoteNo": "Q123456",
      "CommlPkgPolicyQuoteInqRs": {
        "IRH_Rating_StatusCd": "Success",
        "MsgStatus": [
          {
            "MsgStatusCd": "Success",
            "MsgStatusDesc": "Quote successfully generated"
          }
        ],
        "BrokerageCommissionInfo": {
          "CommissionRatePct": 15.0,
          "CommissionAmt": 1500.00
        }
      }
    }
  }
]
```

### Error Response

```json
[
  {
    "InsuranceSvcRs": {
      "CommlPkgPolicyQuoteInqRs": {
        "IRH_Rating_StatusCd": "Error",
        "MsgStatus": [
          {
            "MsgStatusCd": "Error",
            "MsgErrorCd": "AUTH_ERROR",
            "MsgStatusDesc": "You are not authorized to rate this carrier-coverage combination."
          }
        ]
      }
    }
  }
]
```

## HTTP Status Codes

| Status Code | Description |
|------------|-------------|
| 200 | Success - Quote generated successfully |
| 400 | Bad Request - Invalid request format or missing required fields |
| 401 | Unauthorized - Authentication failed |
| 500 | Internal Server Error - Server-side error occurred |

## Common Error Scenarios

### Missing RqUID
```json
{
  "error": "RqUID is required"
}
```

### Authentication Failure
```json
{
  "error": "Internal server error",
  "message": "Failed to authenticate with Dyed service"
}
```

### Carrier Authorization Error
The response will include error details in the MsgStatus array:
```json
{
  "MsgStatusCd": "Error",
  "MsgStatusDesc": "You are not authorized to rate this carrier-coverage combination."
}
```

## Testing with cURL

```bash
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

## Testing with PowerShell

```powershell
$requestBody = Get-Content -Path "Examples/DyadGetRateRequest-Example.json" -Raw

$response = Invoke-RestMethod `
    -Uri "https://localhost:5001/api/dyed/getrate" `
    -Method POST `
    -Body $requestBody `
    -ContentType "application/json"

$response | ConvertTo-Json -Depth 20
```

## Testing with Postman

1. **Method**: POST
2. **URL**: `https://localhost:5001/api/dyed/getrate`
3. **Headers**: 
   - Content-Type: `application/json`
4. **Body**: 
   - Select "raw" and "JSON"
   - Paste the content from `Examples/DyadGetRateRequest-Example.json`
5. **Click "Send"**

## Field Descriptions

### Producer Information
- **ProducerRoleCd**: Role code (e.g., "LoggedInUser", "UN")
- **CommercialName**: Business name
- **EmailAddr**: Contact email
- **PhoneNumber**: Contact phone
- **Addr1**: Street address
- **City**: City name
- **StateProvCd**: State code (e.g., "AR", "IN")
- **PostalCode**: ZIP code

### Insured Information
- **CommercialName**: Business name of insured
- **PersonName**: Individual name (if applicable)
  - Surname: Last name
  - GivenName: First name
- **Addr**: Business address
- **PhysicalAddr**: Physical location (if different)

### Policy Information
- **PolicyNumber**: Policy number (if renewal)
- **LOBCd**: Line of business code (e.g., "CPKGE" for commercial package)
- **EffectiveDt**: Policy effective date (ISO 8601 format)
- **ExpirationDt**: Policy expiration date (ISO 8601 format)

### Location Information
- **LocationRef**: Location reference number
- **LocationType**: Type of location
- **SubLocation**: Array of building/sublocation details
  - ConstructionCd: Construction type code
  - YearBuilt: Year building was constructed
  - SquareFootage: Building square footage
  - NumStories: Number of stories
  - IRH_ProtectionClass: Fire protection class

### General Liability Coverage
- **Coverage**: Array of coverage details
  - CoverageCd: Coverage code (e.g., "BIPD" for Bodily Injury/Property Damage)
  - Limit: Coverage limits
- **CommlGLClassification**: Classification codes and exposure
  - ClassCd: Classification code
  - ClassCdDesc: Classification description
  - Exposure: Exposure amount
  - PremiumBasisCd: Premium basis (e.g., "Unit", "PAYRL")

### Property Coverage
- **CommlPropertyInfo**: Property information array
  - ClassCd: Property class code
  - Coverage: Array of property coverages
    - CoverageCd: Coverage code (e.g., "BLDG" for Building, "BPP" for Business Personal Property)
    - Limit: Coverage limit
    - Deductible: Deductible information
    - ValuationCd: Valuation method (e.g., "ACV" for Actual Cash Value)

## Important Notes

1. **GUID Generation**: The `RqUID` field must be a valid GUID. Generate a new GUID for each request.
   
2. **Date Format**: All dates must be in ISO 8601 format: `YYYY-MM-DDTHH:mm:ssZ`

3. **Carrier Names**: Valid carrier names depend on your authorization. Common carriers include:
   - "ACI"
   - "USLI"
   - Contact your administrator for the complete list

4. **State Codes**: Use standard US state abbreviations (e.g., "CA", "NY", "TX")

5. **Classification Codes**: Classification codes vary by carrier and line of business. Refer to the carrier's classification manual.

6. **Response is Array**: Note that the API returns an **array** of response objects, even for a single quote request.

## Troubleshooting

### Issue: "RqUID is required" error
**Solution**: Ensure the `InsuranceSvcRq.RqUID` field is populated with a valid GUID.

### Issue: "You are not authorized" error
**Solution**: Check that:
- Your credentials in `appsettings.json` are correct
- You have authorization for the specified carrier
- The carrier name is spelled correctly

### Issue: 401 Unauthorized
**Solution**: 
- Verify credentials in `appsettings.json`
- Check that the token endpoint is accessible
- Review authentication service logs

### Issue: Null or empty response
**Solution**:
- Check that all required fields are populated
- Verify date formats are correct
- Ensure classification codes are valid
- Review API logs for detailed error messages

## Support

For additional support or questions about the Dyad GetRate API:
1. Review the Swagger documentation at `https://localhost:5001/swagger`
2. Check application logs for detailed error messages
3. Contact your Dyad API administrator
