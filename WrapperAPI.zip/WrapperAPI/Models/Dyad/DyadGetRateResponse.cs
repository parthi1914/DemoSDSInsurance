using System.Text.Json.Serialization;

namespace WrapperAPI.Models.Dyad
{
    // Root Response Model - Note: API returns an array
    public class DyadGetRateResponse
    {
        [JsonPropertyName("SignonRs")]
        public SignonResponse? SignonRs { get; set; }

        [JsonPropertyName("InsuranceSvcRs")]
        public InsuranceServiceResponse? InsuranceSvcRs { get; set; }
    }

    // Signon Response Models
    public class SignonResponse
    {
        [JsonPropertyName("SignonPswd")]
        public SignonPasswordResponse? SignonPswd { get; set; }
    }

    public class SignonPasswordResponse
    {
        [JsonPropertyName("CustId")]
        public CustomerIdentityResponse? CustId { get; set; }

        [JsonPropertyName("CustPswd")]
        public CustomerPasswordResponse? CustPswd { get; set; }
    }

    public class CustomerIdentityResponse
    {
        [JsonPropertyName("CustLoginId")]
        public string CustLoginId { get; set; } = string.Empty;

        [JsonPropertyName("SPName")]
        public string SPName { get; set; } = string.Empty;
    }

    public class CustomerPasswordResponse
    {
        [JsonPropertyName("Pswd")]
        public string? Pswd { get; set; }
    }

    // Insurance Service Response Models
    public class InsuranceServiceResponse
    {
        [JsonPropertyName("RqUID")]
        public string RqUID { get; set; } = string.Empty;

        [JsonPropertyName("IRH_QuoteNo")]
        public string IRH_QuoteNo { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Application_Type")]
        public string IRH_Application_Type { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Application_Name")]
        public string IRH_Application_Name { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Request_Type")]
        public string IRH_Request_Type { get; set; } = string.Empty;

        [JsonPropertyName("comIRH_CarrierRequestExt")]
        public CarrierRequestExtensionResponse? comIRH_CarrierRequestExt { get; set; }

        [JsonPropertyName("CommlGeneralLiabilityPolicyQuoteInqRs")]
        public object? CommlGeneralLiabilityPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("CommlPropertyPolicyQuoteInqRs")]
        public object? CommlPropertyPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("EPLIPolicyQuoteInqRs")]
        public object? EPLIPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("CommlPkgPolicyQuoteInqRs")]
        public CommercialPackagePolicyQuoteResponse? CommlPkgPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("CyberLiabilityPolicyQuoteInqRs")]
        public object? CyberLiabilityPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("CommlUmbrellaPolicyQuoteInqRs")]
        public object? CommlUmbrellaPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("DocumentPolicyQuoteInqRs")]
        public object? DocumentPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("HomeownerPolicyQuoteInqRs")]
        public object? HomeownerPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("BindQuoteInqRs")]
        public object? BindQuoteInqRs { get; set; }

        [JsonPropertyName("CancelQuoteRs")]
        public object? CancelQuoteRs { get; set; }

        [JsonPropertyName("ReinstateQuoteInqRs")]
        public object? ReinstateQuoteInqRs { get; set; }

        [JsonPropertyName("RevokeQuoteInqRs")]
        public object? RevokeQuoteInqRs { get; set; }

        [JsonPropertyName("ExcessFloodPolicyQuoteInqRs")]
        public object? ExcessFloodPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("WorkCompPolicyQuoteInqRs")]
        public object? WorkCompPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("DocumentTypePolicyQuoteInqRs")]
        public object? DocumentTypePolicyQuoteInqRs { get; set; }

        [JsonPropertyName("ProfessionalLiabilityPolicyQuoteInqRs")]
        public object? ProfessionalLiabilityPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("OptionalAdditionalCoverageInqRs")]
        public object? OptionalAdditionalCoverageInqRs { get; set; }

        [JsonPropertyName("CommlDeductibelbuyBackQuoteInqRs")]
        public object? CommlDeductibelbuyBackQuoteInqRs { get; set; }

        [JsonPropertyName("ExcessAutoLiabilityQuoteInqRs")]
        public object? ExcessAutoLiabilityQuoteInqRs { get; set; }

        [JsonPropertyName("ReviveQuoteInqRs")]
        public object? ReviveQuoteInqRs { get; set; }

        [JsonPropertyName("CommlTerrorismQuoteInqRs")]
        public object? CommlTerrorismQuoteInqRs { get; set; }

        [JsonPropertyName("MotorTruckCargoQuoteInqRs")]
        public object? MotorTruckCargoQuoteInqRs { get; set; }

        [JsonPropertyName("EligibilityRs")]
        public object? EligibilityRs { get; set; }

        [JsonPropertyName("AlliedHealthFacilitiesPolicyQuoteInqRs")]
        public object? AlliedHealthFacilitiesPolicyQuoteInqRs { get; set; }

        [JsonPropertyName("FloodPolicyQuoteInqRs")]
        public object? FloodPolicyQuoteInqRs { get; set; }
    }

    public class CarrierRequestExtensionResponse
    {
        [JsonPropertyName("comIRH_CarrierInfoExt")]
        public List<CarrierInfoResponse>? comIRH_CarrierInfoExt { get; set; }
    }

    public class CarrierInfoResponse
    {
        [JsonPropertyName("IRH_CarrierName")]
        public string IRH_CarrierName { get; set; } = string.Empty;

        [JsonPropertyName("IRH_ReRateRqUID")]
        public string IRH_ReRateRqUID { get; set; } = string.Empty;

        [JsonPropertyName("IRH_AdmittedStatus")]
        public string IRH_AdmittedStatus { get; set; } = string.Empty;

        [JsonPropertyName("IRH_TimeTaken")]
        public string? IRH_TimeTaken { get; set; }

        [JsonPropertyName("IRH_OfficeCd")]
        public string IRH_OfficeCd { get; set; } = string.Empty;

        [JsonPropertyName("IRH_NAICCd")]
        public string? IRH_NAICCd { get; set; }

        [JsonPropertyName("IRH_BusinessPurposeTypecd")]
        public string IRH_BusinessPurposeTypecd { get; set; } = string.Empty;

        [JsonPropertyName("CarrierAgencyID")]
        public string CarrierAgencyID { get; set; } = string.Empty;
    }

    // Commercial Package Policy Quote Response
    public class CommercialPackagePolicyQuoteResponse
    {
        [JsonPropertyName("IRH_Rating_StatusCd")]
        public string IRH_Rating_StatusCd { get; set; } = string.Empty;

        [JsonPropertyName("MsgStatus")]
        public List<MessageStatus>? MsgStatus { get; set; }

        [JsonPropertyName("FormsRequestedCd")]
        public string FormsRequestedCd { get; set; } = string.Empty;

        [JsonPropertyName("SaveIndicationCd")]
        public string SaveIndicationCd { get; set; } = string.Empty;

        [JsonPropertyName("Producer")]
        public List<ProducerResponse>? Producer { get; set; }

        [JsonPropertyName("InsuredOrPrincipal")]
        public InsuredOrPrincipalResponse? InsuredOrPrincipal { get; set; }

        [JsonPropertyName("Policy")]
        public PolicyResponse? Policy { get; set; }

        [JsonPropertyName("BusinessPurposeTypeCd")]
        public string BusinessPurposeTypeCd { get; set; } = string.Empty;

        [JsonPropertyName("TransactionRequestDt")]
        public DateTime TransactionRequestDt { get; set; }

        [JsonPropertyName("comIRH_GoverningStateExt")]
        public string comIRH_GoverningStateExt { get; set; } = string.Empty;

        [JsonPropertyName("Location")]
        public List<LocationResponse>? Location { get; set; }

        [JsonPropertyName("CommlGeneralLiabilityLineBusiness")]
        public GeneralLiabilityLineBusinessResponse? CommlGeneralLiabilityLineBusiness { get; set; }

        [JsonPropertyName("CommlPropertyLineBusiness")]
        public PropertyLineBusinessResponse? CommlPropertyLineBusiness { get; set; }

        [JsonPropertyName("CyberLiabilityLineBusiness")]
        public object? CyberLiabilityLineBusiness { get; set; }

        [JsonPropertyName("CommlUmbrellaLineBusiness")]
        public object? CommlUmbrellaLineBusiness { get; set; }

        [JsonPropertyName("EPLILineBusiness")]
        public object? EPLILineBusiness { get; set; }

        [JsonPropertyName("JurisdictionTaxFee")]
        public JurisdictionTaxFee? JurisdictionTaxFee { get; set; }

        [JsonPropertyName("CompanyReferenceNumber")]
        public string CompanyReferenceNumber { get; set; } = string.Empty;

        [JsonPropertyName("BrokerageCommissionInfo")]
        public BrokerageCommissionInfo? BrokerageCommissionInfo { get; set; }

        [JsonPropertyName("HomeownerLineBusiness")]
        public object? HomeownerLineBusiness { get; set; }

        [JsonPropertyName("BindRiskInformation")]
        public object? BindRiskInformation { get; set; }

        [JsonPropertyName("ExcessFloodLineBusiness")]
        public object? ExcessFloodLineBusiness { get; set; }

        [JsonPropertyName("WorkCompLineBusiness")]
        public object? WorkCompLineBusiness { get; set; }

        [JsonPropertyName("DirectorsAndOfficersLineBusiness")]
        public object? DirectorsAndOfficersLineBusiness { get; set; }

        [JsonPropertyName("FiduciaryLiabilityLineBusiness")]
        public object? FiduciaryLiabilityLineBusiness { get; set; }

        [JsonPropertyName("CrimeLineBusiness")]
        public object? CrimeLineBusiness { get; set; }

        [JsonPropertyName("EPLLineBusiness")]
        public object? EPLLineBusiness { get; set; }

        [JsonPropertyName("AdditionalQuestionList")]
        public AdditionalQuestionList? AdditionalQuestionList { get; set; }

        [JsonPropertyName("KettleReAggLimitBreached")]
        public object? KettleReAggLimitBreached { get; set; }

        [JsonPropertyName("PriorLoss")]
        public PriorLossResponse? PriorLoss { get; set; }

        [JsonPropertyName("KidnapAndRansomLineBusiness")]
        public object? KidnapAndRansomLineBusiness { get; set; }

        [JsonPropertyName("DeductibelbuyBackLineBusiness")]
        public object? DeductibelbuyBackLineBusiness { get; set; }

        [JsonPropertyName("ExcessAutoLiabilityBusiness")]
        public object? ExcessAutoLiabilityBusiness { get; set; }

        [JsonPropertyName("OtherOrPriorPolicy")]
        public object? OtherOrPriorPolicy { get; set; }

        [JsonPropertyName("TerrorismLineBusiness")]
        public object? TerrorismLineBusiness { get; set; }

        [JsonPropertyName("MotorTruckCargoLineBusiness")]
        public object? MotorTruckCargoLineBusiness { get; set; }

        [JsonPropertyName("AlliedHealthFacilitiesLineBusiness")]
        public object? AlliedHealthFacilitiesLineBusiness { get; set; }

        [JsonPropertyName("PriorLossInfo")]
        public PriorLossInfo? PriorLossInfo { get; set; }

        [JsonPropertyName("PremiumDistributionList")]
        public PremiumDistributionList? PremiumDistributionList { get; set; }

        [JsonPropertyName("FloodLineBusiness")]
        public object? FloodLineBusiness { get; set; }

        [JsonPropertyName("PriorCarrierInfo")]
        public PriorCarrierInfo? PriorCarrierInfo { get; set; }
    }

    public class MessageStatus
    {
        [JsonPropertyName("MsgStatusCd")]
        public string MsgStatusCd { get; set; } = string.Empty;

        [JsonPropertyName("MsgErrorCd")]
        public string MsgErrorCd { get; set; } = string.Empty;

        [JsonPropertyName("MsgStatusDesc")]
        public string MsgStatusDesc { get; set; } = string.Empty;

        [JsonPropertyName("ChangeStatus")]
        public ChangeStatus? ChangeStatus { get; set; }
    }

    public class ChangeStatus
    {
        [JsonPropertyName("ActionCd")]
        public string? ActionCd { get; set; }

        [JsonPropertyName("ChangeDesc")]
        public string? ChangeDesc { get; set; }
    }

    public class ProducerResponse
    {
        [JsonPropertyName("GeneralPartyInfo")]
        public GeneralPartyInfoResponse? GeneralPartyInfo { get; set; }

        [JsonPropertyName("ProducerInfo")]
        public ProducerInfoResponse? ProducerInfo { get; set; }
    }

    public class ProducerInfoResponse
    {
        [JsonPropertyName("ProducerRoleCd")]
        public string ProducerRoleCd { get; set; } = string.Empty;

        [JsonPropertyName("ContractNumber")]
        public string ContractNumber { get; set; } = string.Empty;
    }

    public class GeneralPartyInfoResponse
    {
        [JsonPropertyName("NameInfo")]
        public NameInfoResponse? NameInfo { get; set; }

        [JsonPropertyName("Communications")]
        public CommunicationsResponse? Communications { get; set; }

        [JsonPropertyName("Addr")]
        public AddressResponse? Addr { get; set; }

        [JsonPropertyName("PhysicalAddr")]
        public AddressResponse? PhysicalAddr { get; set; }

        [JsonPropertyName("PersonInfo")]
        public PersonInfoResponse? PersonInfo { get; set; }

        [JsonPropertyName("OperationsDesc")]
        public string OperationsDesc { get; set; } = string.Empty;
    }

    public class NameInfoResponse
    {
        [JsonPropertyName("CommlName")]
        public CommercialNameResponse? CommlName { get; set; }

        [JsonPropertyName("PersonName")]
        public PersonNameResponse? PersonName { get; set; }

        [JsonPropertyName("SupplementaryNameInfo")]
        public SupplementaryNameInfoResponse? SupplementaryNameInfo { get; set; }

        [JsonPropertyName("IRH_ReferenceInsuredID")]
        public string IRH_ReferenceInsuredID { get; set; } = string.Empty;

        [JsonPropertyName("LegalEntityCd")]
        public string? LegalEntityCd { get; set; }
    }

    public class CommercialNameResponse
    {
        [JsonPropertyName("CommercialName")]
        public string CommercialName { get; set; } = string.Empty;
    }

    public class PersonNameResponse
    {
        [JsonPropertyName("Surname")]
        public string Surname { get; set; } = string.Empty;

        [JsonPropertyName("GivenName")]
        public string GivenName { get; set; } = string.Empty;

        [JsonPropertyName("MiddleName")]
        public string MiddleName { get; set; } = string.Empty;
    }

    public class SupplementaryNameInfoResponse
    {
        [JsonPropertyName("SupplementaryName")]
        public string SupplementaryName { get; set; } = string.Empty;

        [JsonPropertyName("SupplementaryNameCd")]
        public string SupplementaryNameCd { get; set; } = string.Empty;
    }

    public class CommunicationsResponse
    {
        [JsonPropertyName("EmailInfo")]
        public EmailInfoResponse? EmailInfo { get; set; }

        [JsonPropertyName("WebsiteInfo")]
        public WebsiteInfoResponse? WebsiteInfo { get; set; }

        [JsonPropertyName("PhoneInfo")]
        public PhoneInfoResponse? PhoneInfo { get; set; }
    }

    public class EmailInfoResponse
    {
        [JsonPropertyName("CommunicationUseCd")]
        public string CommunicationUseCd { get; set; } = string.Empty;

        [JsonPropertyName("EmailAddr")]
        public string EmailAddr { get; set; } = string.Empty;
    }

    public class WebsiteInfoResponse
    {
        [JsonPropertyName("WebsiteURL")]
        public string WebsiteURL { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Insured_WebsiteURL")]
        public string? IRH_Insured_WebsiteURL { get; set; }
    }

    public class PhoneInfoResponse
    {
        [JsonPropertyName("PhoneNumber")]
        public string PhoneNumber { get; set; } = string.Empty;

        [JsonPropertyName("Fax")]
        public string Fax { get; set; } = string.Empty;
    }

    public class AddressResponse
    {
        [JsonPropertyName("Addr1")]
        public string Addr1 { get; set; } = string.Empty;

        [JsonPropertyName("Addr2")]
        public string Addr2 { get; set; } = string.Empty;

        [JsonPropertyName("City")]
        public string City { get; set; } = string.Empty;

        [JsonPropertyName("StateProvCd")]
        public string StateProvCd { get; set; } = string.Empty;

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; } = string.Empty;

        [JsonPropertyName("Latitude")]
        public string Latitude { get; set; } = string.Empty;

        [JsonPropertyName("Longitude")]
        public string Longitude { get; set; } = string.Empty;

        [JsonPropertyName("County")]
        public string County { get; set; } = string.Empty;

        [JsonPropertyName("TerritoryCd")]
        public string TerritoryCd { get; set; } = string.Empty;

        [JsonPropertyName("HouseNumber")]
        public string? HouseNumber { get; set; }

        [JsonPropertyName("StreetNumber")]
        public string StreetNumber { get; set; } = string.Empty;
    }

    public class PersonInfoResponse
    {
        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; } = string.Empty;

        [JsonPropertyName("MiddleName")]
        public string MiddleName { get; set; } = string.Empty;

        [JsonPropertyName("LastName")]
        public string LastName { get; set; } = string.Empty;

        [JsonPropertyName("BirthDt")]
        public DateTime BirthDt { get; set; }

        [JsonPropertyName("OccupationClassCd")]
        public string OccupationClassCd { get; set; } = string.Empty;

        [JsonPropertyName("TaxIdentity")]
        public List<object>? TaxIdentity { get; set; }

        [JsonPropertyName("CarrierUserName")]
        public string CarrierUserName { get; set; } = string.Empty;
    }

    public class InsuredOrPrincipalResponse
    {
        [JsonPropertyName("GeneralPartyInfo")]
        public GeneralPartyInfoResponse? GeneralPartyInfo { get; set; }

        [JsonPropertyName("InsuredOrPrincipalInfo")]
        public InsuredOrPrincipalInfoResponse? InsuredOrPrincipalInfo { get; set; }
    }

    public class InsuredOrPrincipalInfoResponse
    {
        [JsonPropertyName("InsuredOrPrincipalRoleCd")]
        public string InsuredOrPrincipalRoleCd { get; set; } = string.Empty;
    }

    public class PolicyResponse
    {
        [JsonPropertyName("PolicyNumber")]
        public string PolicyNumber { get; set; } = string.Empty;

        [JsonPropertyName("LOBCd")]
        public string LOBCd { get; set; } = string.Empty;

        [JsonPropertyName("NAICCd")]
        public string NAICCd { get; set; } = string.Empty;

        [JsonPropertyName("ContractTerm")]
        public ContractTermResponse? ContractTerm { get; set; }

        [JsonPropertyName("Form")]
        public List<object>? Form { get; set; }

        [JsonPropertyName("IRH_LossFreeYears")]
        public int? IRH_LossFreeYears { get; set; }

        [JsonPropertyName("IRH_YrsInBus")]
        public int? IRH_YrsInBus { get; set; }

        [JsonPropertyName("NumYrsInBusiness")]
        public int? NumYrsInBusiness { get; set; }
    }

    public class ContractTermResponse
    {
        [JsonPropertyName("EffectiveDt")]
        public DateTime EffectiveDt { get; set; }

        [JsonPropertyName("ExpirationDt")]
        public DateTime ExpirationDt { get; set; }

        [JsonPropertyName("OriginalPolicyInceptionDt")]
        public DateTime OriginalPolicyInceptionDt { get; set; }
    }

    public class LocationResponse
    {
        [JsonPropertyName("Addr")]
        public AddressResponse? Addr { get; set; }

        [JsonPropertyName("IRH_NumAccidentsThreeYrs")]
        public int IRH_NumAccidentsThreeYrs { get; set; }

        [JsonPropertyName("IRH_NumClaimsThreeYrs")]
        public int IRH_NumClaimsThreeYrs { get; set; }

        [JsonPropertyName("IRH_TotalIncurredAmtThreeYrs")]
        public int IRH_TotalIncurredAmtThreeYrs { get; set; }

        [JsonPropertyName("LocationRef")]
        public string LocationRef { get; set; } = string.Empty;

        [JsonPropertyName("LocationType")]
        public string LocationType { get; set; } = string.Empty;

        [JsonPropertyName("SubLocation")]
        public List<object>? SubLocation { get; set; }
    }

    public class GeneralLiabilityLineBusinessResponse
    {
        [JsonPropertyName("Coverage")]
        public List<object>? Coverage { get; set; }

        [JsonPropertyName("CommlGLClassification")]
        public List<object>? CommlGLClassification { get; set; }

        [JsonPropertyName("GLCarrierSpecified")]
        public object? GLCarrierSpecified { get; set; }

        [JsonPropertyName("Deductible")]
        public List<object>? Deductible { get; set; }

        [JsonPropertyName("OptionalCoverageList")]
        public object? OptionalCoverageList { get; set; }

        [JsonPropertyName("AdditionalInsuredList")]
        public object? AdditionalInsuredList { get; set; }
    }

    public class PropertyLineBusinessResponse
    {
        [JsonPropertyName("PropertyInfo")]
        public object? PropertyInfo { get; set; }
    }

    public class JurisdictionTaxFee
    {
        [JsonPropertyName("JurisdictionTaxFeeInfo")]
        public JurisdictionTaxFeeInfo? JurisdictionTaxFeeInfo { get; set; }
    }

    public class JurisdictionTaxFeeInfo
    {
        [JsonPropertyName("TaxFee")]
        public List<object>? TaxFee { get; set; }
    }

    public class BrokerageCommissionInfo
    {
        [JsonPropertyName("CommissionRatePct")]
        public decimal CommissionRatePct { get; set; }

        [JsonPropertyName("CommissionAmt")]
        public decimal CommissionAmt { get; set; }
    }

    public class AdditionalQuestionList
    {
        [JsonPropertyName("QuestionDetails")]
        public List<object>? QuestionDetails { get; set; }
    }

    public class PriorLossResponse
    {
        [JsonPropertyName("LossYearInfo")]
        public List<object>? LossYearInfo { get; set; }

        [JsonPropertyName("PriorLossHistoryInfo")]
        public List<object>? PriorLossHistoryInfo { get; set; }
    }

    public class PriorLossInfo
    {
        [JsonPropertyName("LossTypeCd")]
        public string LossTypeCd { get; set; } = string.Empty;

        [JsonPropertyName("LossDescription")]
        public string LossDescription { get; set; } = string.Empty;

        [JsonPropertyName("IsClaimSettled")]
        public bool IsClaimSettled { get; set; }

        [JsonPropertyName("IsClaimFullyRepaired")]
        public bool IsClaimFullyRepaired { get; set; }

        [JsonPropertyName("LossDate")]
        public string LossDate { get; set; } = string.Empty;

        [JsonPropertyName("LossValue")]
        public decimal LossValue { get; set; }

        [JsonPropertyName("IsClaimAtThisLocation")]
        public bool IsClaimAtThisLocation { get; set; }

        [JsonPropertyName("LossTypeOther")]
        public string LossTypeOther { get; set; } = string.Empty;

        [JsonPropertyName("IsCatLoss")]
        public string IsCatLoss { get; set; } = string.Empty;

        [JsonPropertyName("IsChargeable")]
        public bool? IsChargeable { get; set; }

        [JsonPropertyName("LOBCd")]
        public string LOBCd { get; set; } = string.Empty;

        [JsonPropertyName("ClaimStatus")]
        public string ClaimStatus { get; set; } = string.Empty;

        [JsonPropertyName("ClaimDate")]
        public string ClaimDate { get; set; } = string.Empty;
    }

    public class PremiumDistributionList
    {
        [JsonPropertyName("PremiumDistribution")]
        public List<object>? PremiumDistribution { get; set; }
    }

    public class PriorCarrierInfo
    {
        [JsonPropertyName("PriorCarrierDetail")]
        public List<object>? PriorCarrierDetail { get; set; }
    }
}
