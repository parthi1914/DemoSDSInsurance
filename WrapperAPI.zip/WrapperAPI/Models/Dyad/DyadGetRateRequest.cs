using System.Text.Json.Serialization;

namespace WrapperAPI.Models.Dyad
{
    // Root Request Model
    public class DyadGetRateRequest
    {
        [JsonPropertyName("SignonRq")]
        public SignonRequest SignonRq { get; set; } = new();

        [JsonPropertyName("InsuranceSvcRq")]
        public InsuranceServiceRequest InsuranceSvcRq { get; set; } = new();
    }

    // Signon Models
    public class SignonRequest
    {
        [JsonPropertyName("SignonPswd")]
        public SignonPassword SignonPswd { get; set; } = new();
    }

    public class SignonPassword
    {
        [JsonPropertyName("CustId")]
        public CustomerIdentity CustId { get; set; } = new();

        [JsonPropertyName("CustPswd")]
        public CustomerPassword? CustPswd { get; set; }
    }

    public class CustomerIdentity
    {
        [JsonPropertyName("CustLoginId")]
        public string CustLoginId { get; set; } = string.Empty;
    }

    public class CustomerPassword
    {
        [JsonPropertyName("Pswd")]
        public string? Pswd { get; set; }
    }

    // Insurance Service Request Models
    public class InsuranceServiceRequest
    {
        [JsonPropertyName("RqUID")]
        public string RqUID { get; set; } = string.Empty;

        [JsonPropertyName("IRH_QuoteNo")]
        public string IRH_QuoteNo { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Application_Name")]
        public string IRH_Application_Name { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Application_Type")]
        public string IRH_Application_Type { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Request_Type")]
        public string IRH_Request_Type { get; set; } = string.Empty;

        [JsonPropertyName("comIRH_CarrierRequestExt")]
        public CarrierRequestExtension? comIRH_CarrierRequestExt { get; set; }

        [JsonPropertyName("comIRH_AdditionalQueRequireExt")]
        public object? comIRH_AdditionalQueRequireExt { get; set; }

        [JsonPropertyName("comIRH_AdditionalQueTypeExt")]
        public object? comIRH_AdditionalQueTypeExt { get; set; }

        [JsonPropertyName("CommlPkgPolicyQuoteInqRq")]
        public CommercialPackagePolicyQuoteRequest? CommlPkgPolicyQuoteInqRq { get; set; }
    }

    public class CarrierRequestExtension
    {
        [JsonPropertyName("comIRH_CarrierInfoExt")]
        public List<CarrierInfo>? comIRH_CarrierInfoExt { get; set; }
    }

    public class CarrierInfo
    {
        [JsonPropertyName("IRH_CarrierName")]
        public string IRH_CarrierName { get; set; } = string.Empty;

        [JsonPropertyName("IRH_ReRateRqUID")]
        public string IRH_ReRateRqUID { get; set; } = string.Empty;

        [JsonPropertyName("IRH_AdmittedStatus")]
        public string IRH_AdmittedStatus { get; set; } = string.Empty;

        [JsonPropertyName("IRH_TimeTaken")]
        public string? IRH_TimeTaken { get; set; }

        [JsonPropertyName("IRH_OfficeCd")]
        public string IRH_OfficeCd { get; set; } = string.Empty;
    }

    // Commercial Package Policy Quote Request
    public class CommercialPackagePolicyQuoteRequest
    {
        [JsonPropertyName("FormsRequestedCd")]
        public string FormsRequestedCd { get; set; } = string.Empty;

        [JsonPropertyName("SaveIndicationCd")]
        public string SaveIndicationCd { get; set; } = string.Empty;

        [JsonPropertyName("Producer")]
        public List<Producer>? Producer { get; set; }

        [JsonPropertyName("InsuredOrPrincipal")]
        public InsuredOrPrincipal? InsuredOrPrincipal { get; set; }

        [JsonPropertyName("Policy")]
        public Policy? Policy { get; set; }

        [JsonPropertyName("BusinessPurposeTypeCd")]
        public string BusinessPurposeTypeCd { get; set; } = string.Empty;

        [JsonPropertyName("TransactionRequestDt")]
        public DateTime TransactionRequestDt { get; set; }

        [JsonPropertyName("comIRH_GoverningStateExt")]
        public string comIRH_GoverningStateExt { get; set; } = string.Empty;

        [JsonPropertyName("Location")]
        public List<Location>? Location { get; set; }

        [JsonPropertyName("CommlGeneralLiabilityLineBusiness")]
        public GeneralLiabilityLineBusiness? CommlGeneralLiabilityLineBusiness { get; set; }

        [JsonPropertyName("CommlPropertyLineBusiness")]
        public PropertyLineBusiness? CommlPropertyLineBusiness { get; set; }

        [JsonPropertyName("PriorLoss")]
        public PriorLoss? PriorLoss { get; set; }
    }

    // Producer Models
    public class Producer
    {
        [JsonPropertyName("GeneralPartyInfo")]
        public GeneralPartyInfo? GeneralPartyInfo { get; set; }

        [JsonPropertyName("ProducerInfo")]
        public ProducerInfo? ProducerInfo { get; set; }
    }

    public class ProducerInfo
    {
        [JsonPropertyName("ProducerRoleCd")]
        public string ProducerRoleCd { get; set; } = string.Empty;

        [JsonPropertyName("ContractNumber")]
        public string ContractNumber { get; set; } = string.Empty;
    }

    // General Party Info Models
    public class GeneralPartyInfo
    {
        [JsonPropertyName("NameInfo")]
        public NameInfo? NameInfo { get; set; }

        [JsonPropertyName("Communications")]
        public Communications? Communications { get; set; }

        [JsonPropertyName("Addr")]
        public Address? Addr { get; set; }

        [JsonPropertyName("PhysicalAddr")]
        public Address? PhysicalAddr { get; set; }

        [JsonPropertyName("PersonInfo")]
        public PersonInfo? PersonInfo { get; set; }

        [JsonPropertyName("OperationsDesc")]
        public string OperationsDesc { get; set; } = string.Empty;
    }

    public class NameInfo
    {
        [JsonPropertyName("CommlName")]
        public CommercialName? CommlName { get; set; }

        [JsonPropertyName("PersonName")]
        public PersonName? PersonName { get; set; }

        [JsonPropertyName("SupplementaryNameInfo")]
        public SupplementaryNameInfo? SupplementaryNameInfo { get; set; }

        [JsonPropertyName("IRH_ReferenceInsuredID")]
        public string IRH_ReferenceInsuredID { get; set; } = string.Empty;

        [JsonPropertyName("LegalEntityCd")]
        public string? LegalEntityCd { get; set; }
    }

    public class CommercialName
    {
        [JsonPropertyName("CommercialName")]
        public string CommercialName { get; set; } = string.Empty;
    }

    public class PersonName
    {
        [JsonPropertyName("Surname")]
        public string Surname { get; set; } = string.Empty;

        [JsonPropertyName("GivenName")]
        public string GivenName { get; set; } = string.Empty;

        [JsonPropertyName("MiddleName")]
        public string MiddleName { get; set; } = string.Empty;
    }

    public class SupplementaryNameInfo
    {
        [JsonPropertyName("SupplementaryName")]
        public string SupplementaryName { get; set; } = string.Empty;

        [JsonPropertyName("SupplementaryNameCd")]
        public string SupplementaryNameCd { get; set; } = string.Empty;
    }

    public class Communications
    {
        [JsonPropertyName("EmailInfo")]
        public EmailInfo? EmailInfo { get; set; }

        [JsonPropertyName("WebsiteInfo")]
        public WebsiteInfo? WebsiteInfo { get; set; }

        [JsonPropertyName("PhoneInfo")]
        public PhoneInfo? PhoneInfo { get; set; }
    }

    public class EmailInfo
    {
        [JsonPropertyName("CommunicationUseCd")]
        public string CommunicationUseCd { get; set; } = string.Empty;

        [JsonPropertyName("EmailAddr")]
        public string EmailAddr { get; set; } = string.Empty;
    }

    public class WebsiteInfo
    {
        [JsonPropertyName("WebsiteURL")]
        public string WebsiteURL { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Insured_WebsiteURL")]
        public string? IRH_Insured_WebsiteURL { get; set; }
    }

    public class PhoneInfo
    {
        [JsonPropertyName("PhoneNumber")]
        public string PhoneNumber { get; set; } = string.Empty;

        [JsonPropertyName("Fax")]
        public string Fax { get; set; } = string.Empty;
    }

    public class Address
    {
        [JsonPropertyName("Addr1")]
        public string Addr1 { get; set; } = string.Empty;

        [JsonPropertyName("Addr2")]
        public string Addr2 { get; set; } = string.Empty;

        [JsonPropertyName("City")]
        public string City { get; set; } = string.Empty;

        [JsonPropertyName("StateProvCd")]
        public string StateProvCd { get; set; } = string.Empty;

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; } = string.Empty;

        [JsonPropertyName("Latitude")]
        public string? Latitude { get; set; }

        [JsonPropertyName("Longitude")]
        public string? Longitude { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; } = string.Empty;

        [JsonPropertyName("TerritoryCd")]
        public string TerritoryCd { get; set; } = string.Empty;

        [JsonPropertyName("HouseNumber")]
        public string? HouseNumber { get; set; }

        [JsonPropertyName("StreetNumber")]
        public string StreetNumber { get; set; } = string.Empty;
    }

    public class PersonInfo
    {
        [JsonPropertyName("BirthDt")]
        public DateTime BirthDt { get; set; }

        [JsonPropertyName("OccupationClassCd")]
        public string OccupationClassCd { get; set; } = string.Empty;

        [JsonPropertyName("TaxIdentity")]
        public List<object>? TaxIdentity { get; set; }
    }

    // Insured or Principal
    public class InsuredOrPrincipal
    {
        [JsonPropertyName("GeneralPartyInfo")]
        public GeneralPartyInfo? GeneralPartyInfo { get; set; }

        [JsonPropertyName("InsuredOrPrincipalInfo")]
        public InsuredOrPrincipalInfo? InsuredOrPrincipalInfo { get; set; }
    }

    public class InsuredOrPrincipalInfo
    {
        [JsonPropertyName("InsuredOrPrincipalRoleCd")]
        public string InsuredOrPrincipalRoleCd { get; set; } = string.Empty;
    }

    // Policy Models
    public class Policy
    {
        [JsonPropertyName("PolicyNumber")]
        public string PolicyNumber { get; set; } = string.Empty;

        [JsonPropertyName("LOBCd")]
        public string LOBCd { get; set; } = string.Empty;

        [JsonPropertyName("NAICCd")]
        public string NAICCd { get; set; } = string.Empty;

        [JsonPropertyName("ContractTerm")]
        public ContractTerm? ContractTerm { get; set; }

        [JsonPropertyName("Form")]
        public List<object>? Form { get; set; }

        [JsonPropertyName("IRH_LossFreeYears")]
        public int? IRH_LossFreeYears { get; set; }

        [JsonPropertyName("IRH_YrsInBus")]
        public int? IRH_YrsInBus { get; set; }

        [JsonPropertyName("NumYrsInBusiness")]
        public int? NumYrsInBusiness { get; set; }
    }

    public class ContractTerm
    {
        [JsonPropertyName("EffectiveDt")]
        public DateTime EffectiveDt { get; set; }

        [JsonPropertyName("ExpirationDt")]
        public DateTime ExpirationDt { get; set; }

        [JsonPropertyName("OriginalPolicyInceptionDt")]
        public DateTime OriginalPolicyInceptionDt { get; set; }
    }

    // Location Models
    public class Location
    {
        [JsonPropertyName("Addr")]
        public Address? Addr { get; set; }

        [JsonPropertyName("IRH_NumAccidentsThreeYrs")]
        public int IRH_NumAccidentsThreeYrs { get; set; }

        [JsonPropertyName("IRH_NumClaimsThreeYrs")]
        public int IRH_NumClaimsThreeYrs { get; set; }

        [JsonPropertyName("IRH_TotalIncurredAmtThreeYrs")]
        public int IRH_TotalIncurredAmtThreeYrs { get; set; }

        [JsonPropertyName("LocationRef")]
        public string LocationRef { get; set; } = string.Empty;

        [JsonPropertyName("LocationType")]
        public string LocationType { get; set; } = string.Empty;

        [JsonPropertyName("SubLocation")]
        public List<SubLocation>? SubLocation { get; set; }
    }

    public class SubLocation
    {
        [JsonPropertyName("ItemIdInfo")]
        public ItemIdInfo? ItemIdInfo { get; set; }

        [JsonPropertyName("Occupancy")]
        public string Occupancy { get; set; } = string.Empty;

        [JsonPropertyName("LocationType")]
        public string LocationType { get; set; } = string.Empty;

        [JsonPropertyName("SubLocationRef")]
        public string SubLocationRef { get; set; } = string.Empty;

        [JsonPropertyName("ConstructionCd")]
        public string ConstructionCd { get; set; } = string.Empty;

        [JsonPropertyName("IRH_ProtectionClass")]
        public string IRH_ProtectionClass { get; set; } = string.Empty;

        [JsonPropertyName("SquareFootage")]
        public int SquareFootage { get; set; }

        [JsonPropertyName("YearBuilt")]
        public int YearBuilt { get; set; }

        [JsonPropertyName("NumStories")]
        public int NumStories { get; set; }

        [JsonPropertyName("Basement")]
        public Basement? Basement { get; set; }

        [JsonPropertyName("IRH_Dwelling_PrimaryHeating")]
        public string IRH_Dwelling_PrimaryHeating { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Wiring_Type")]
        public string IRH_Wiring_Type { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Roofing")]
        public string IRH_Roofing { get; set; } = string.Empty;

        [JsonPropertyName("IRH_Sprinkler")]
        public SprinklerInfo? IRH_Sprinkler { get; set; }
    }

    public class ItemIdInfo
    {
        [JsonPropertyName("InsurerId")]
        public string InsurerId { get; set; } = string.Empty;
    }

    public class Basement
    {
        [JsonPropertyName("UnfinishedPct")]
        public int UnfinishedPct { get; set; }

        [JsonPropertyName("FinishedPct")]
        public int FinishedPct { get; set; }
    }

    public class SprinklerInfo
    {
        [JsonPropertyName("IRH_SprinklerPresence")]
        public bool IRH_SprinklerPresence { get; set; }

        [JsonPropertyName("IRH_TypeOfSystem")]
        public string IRH_TypeOfSystem { get; set; } = string.Empty;

        [JsonPropertyName("IRH_PercentageSprinklered")]
        public int IRH_PercentageSprinklered { get; set; }
    }

    // General Liability Line Business
    public class GeneralLiabilityLineBusiness
    {
        [JsonPropertyName("Coverage")]
        public List<LiabilityCoverage>? Coverage { get; set; }

        [JsonPropertyName("CommlGLClassification")]
        public List<GLClassification>? CommlGLClassification { get; set; }

        [JsonPropertyName("GLCarrierSpecified")]
        public GLCarrierSpecified? GLCarrierSpecified { get; set; }

        [JsonPropertyName("Deductible")]
        public List<Deductible>? Deductible { get; set; }

        [JsonPropertyName("OptionalCoverageList")]
        public OptionalCoverageList? OptionalCoverageList { get; set; }

        [JsonPropertyName("AdditionalInsuredList")]
        public AdditionalInsuredList? AdditionalInsuredList { get; set; }
    }

    public class LiabilityCoverage
    {
        [JsonPropertyName("CoverageCd")]
        public string CoverageCd { get; set; } = string.Empty;

        [JsonPropertyName("Limit")]
        public List<CoverageLimit>? Limit { get; set; }

        [JsonPropertyName("CoverageDesc")]
        public string CoverageDesc { get; set; } = string.Empty;
    }

    public class CoverageLimit
    {
        [JsonPropertyName("FormatCurrencyAmt")]
        public FormatCurrencyAmount? FormatCurrencyAmt { get; set; }

        [JsonPropertyName("LimitAppliesToCd")]
        public string LimitAppliesToCd { get; set; } = string.Empty;
    }

    public class FormatCurrencyAmount
    {
        [JsonPropertyName("Amt")]
        public string Amt { get; set; } = string.Empty;
    }

    public class GLClassification
    {
        [JsonPropertyName("Coverage")]
        public List<LiabilityCoverage>? Coverage { get; set; }

        [JsonPropertyName("ClassCd")]
        public string ClassCd { get; set; } = string.Empty;

        [JsonPropertyName("ClassCdDesc")]
        public string ClassCdDesc { get; set; } = string.Empty;

        [JsonPropertyName("IRH_SubClassCd")]
        public string IRH_SubClassCd { get; set; } = string.Empty;

        [JsonPropertyName("IRH_SubClassCdDesc")]
        public string IRH_SubClassCdDesc { get; set; } = string.Empty;

        [JsonPropertyName("IRH_DaggerClass")]
        public string IRH_DaggerClass { get; set; } = string.Empty;

        [JsonPropertyName("Exposure")]
        public decimal Exposure { get; set; }

        [JsonPropertyName("NumEmployeesPartTime")]
        public int NumEmployeesPartTime { get; set; }

        [JsonPropertyName("NumEmployeesFullTime")]
        public int NumEmployeesFullTime { get; set; }

        [JsonPropertyName("comIRH_IsCalculateStatePayroll")]
        public bool comIRH_IsCalculateStatePayroll { get; set; }

        [JsonPropertyName("IRH_PayrollType")]
        public string? IRH_PayrollType { get; set; }

        [JsonPropertyName("comIRH_NoOfOwners")]
        public int comIRH_NoOfOwners { get; set; }

        [JsonPropertyName("comIRH_PayrollPercentage")]
        public decimal comIRH_PayrollPercentage { get; set; }

        [JsonPropertyName("comIRH_EmployeePayroll")]
        public decimal comIRH_EmployeePayroll { get; set; }

        [JsonPropertyName("PremiumBasisCd")]
        public string PremiumBasisCd { get; set; } = string.Empty;

        [JsonPropertyName("PremiumBasisDesc")]
        public string PremiumBasisDesc { get; set; } = string.Empty;

        [JsonPropertyName("IfAnyRatingBasisInd")]
        public string IfAnyRatingBasisInd { get; set; } = string.Empty;

        [JsonPropertyName("CreditOrSurcharge")]
        public decimal CreditOrSurcharge { get; set; }

        [JsonPropertyName("LocationRef")]
        public string LocationRef { get; set; } = string.Empty;

        [JsonPropertyName("IRH_IsMaxRevenueGoverningClass")]
        public bool IRH_IsMaxRevenueGoverningClass { get; set; }
    }

    public class GLCarrierSpecified
    {
        [JsonPropertyName("IsOwnSecurityProvided")]
        public string IsOwnSecurityProvided { get; set; } = string.Empty;

        [JsonPropertyName("IsSnowShovelingContractedOut")]
        public string IsSnowShovelingContractedOut { get; set; } = string.Empty;

        [JsonPropertyName("IsAssaultAndBatteryExclusion")]
        public string IsAssaultAndBatteryExclusion { get; set; } = string.Empty;

        [JsonPropertyName("IsTotalFirearmExclusion")]
        public string IsTotalFirearmExclusion { get; set; } = string.Empty;
    }

    public class Deductible
    {
        [JsonPropertyName("FormatInteger")]
        public int FormatInteger { get; set; }

        [JsonPropertyName("FormatPct")]
        public decimal FormatPct { get; set; }

        [JsonPropertyName("DeductibleTypeCd")]
        public string DeductibleTypeCd { get; set; } = string.Empty;

        [JsonPropertyName("DeductibleAppliesToCd")]
        public string DeductibleAppliesToCd { get; set; } = string.Empty;
    }

    public class OptionalCoverageList
    {
        [JsonPropertyName("CoverageDetail")]
        public List<object>? CoverageDetail { get; set; }
    }

    public class AdditionalInsuredList
    {
        [JsonPropertyName("CoverageDetail")]
        public List<object>? CoverageDetail { get; set; }
    }

    // Property Line Business
    public class PropertyLineBusiness
    {
        [JsonPropertyName("PropertyInfo")]
        public PropertyInfo? PropertyInfo { get; set; }
    }

    public class PropertyInfo
    {
        [JsonPropertyName("CreditOrSurcharge")]
        public decimal CreditOrSurcharge { get; set; }

        [JsonPropertyName("CommlPropertyInfo")]
        public List<CommercialPropertyInfo>? CommlPropertyInfo { get; set; }

        [JsonPropertyName("PropCarrierSpecifiedPolicyInfo")]
        public PropCarrierSpecifiedPolicyInfo? PropCarrierSpecifiedPolicyInfo { get; set; }
    }

    public class CommercialPropertyInfo
    {
        [JsonPropertyName("ClassCd")]
        public string ClassCd { get; set; } = string.Empty;

        [JsonPropertyName("ClassCdDesc")]
        public string ClassCdDesc { get; set; } = string.Empty;

        [JsonPropertyName("comIRH_CSPCdExt")]
        public string? comIRH_CSPCdExt { get; set; }

        [JsonPropertyName("Coverage")]
        public List<PropertyCoverage>? Coverage { get; set; }

        [JsonPropertyName("Rate")]
        public decimal Rate { get; set; }

        [JsonPropertyName("CurrentTermAmt")]
        public CurrentTermAmount? CurrentTermAmt { get; set; }

        [JsonPropertyName("IRH_RatedPremium")]
        public decimal IRH_RatedPremium { get; set; }

        [JsonPropertyName("LocationRef")]
        public int LocationRef { get; set; }

        [JsonPropertyName("SubLocationRef")]
        public int SubLocationRef { get; set; }

        [JsonPropertyName("PropCarrierSpecified")]
        public PropCarrierSpecified? PropCarrierSpecified { get; set; }

        [JsonPropertyName("RiskAppetiteCd")]
        public string? RiskAppetiteCd { get; set; }
    }

    public class PropertyCoverage
    {
        [JsonPropertyName("CoverageCd")]
        public string CoverageCd { get; set; } = string.Empty;

        [JsonPropertyName("CoverageDesc")]
        public string CoverageDesc { get; set; } = string.Empty;

        [JsonPropertyName("Limit")]
        public List<CoverageLimit>? Limit { get; set; }

        [JsonPropertyName("Deductible")]
        public List<Deductible>? Deductible { get; set; }

        [JsonPropertyName("CommlCoverageSupplement")]
        public CommercialCoverageSupplement? CommlCoverageSupplement { get; set; }

        [JsonPropertyName("CurrentTermAmt")]
        public CurrentTermAmount? CurrentTermAmt { get; set; }

        [JsonPropertyName("Option")]
        public List<CoverageOption>? Option { get; set; }

        [JsonPropertyName("CreditOrSurcharge")]
        public CreditOrSurcharge? CreditOrSurcharge { get; set; }

        [JsonPropertyName("Rate")]
        public string Rate { get; set; } = string.Empty;

        [JsonPropertyName("MinPremAmt")]
        public MinPremiumAmount? MinPremAmt { get; set; }

        [JsonPropertyName("AddlCoverage")]
        public List<object>? AddlCoverage { get; set; }

        [JsonPropertyName("CreditOrSurchargeInfo")]
        public List<object>? CreditOrSurchargeInfo { get; set; }
    }

    public class CommercialCoverageSupplement
    {
        [JsonPropertyName("CoverageSubCd")]
        public string CoverageSubCd { get; set; } = string.Empty;

        [JsonPropertyName("CoinsurancePct")]
        public string CoinsurancePct { get; set; } = string.Empty;

        [JsonPropertyName("ClaimMadeInfo")]
        public ClaimMadeInfo? ClaimMadeInfo { get; set; }
    }

    public class ClaimMadeInfo
    {
        [JsonPropertyName("UnlimitedPriorActsCoverageInd")]
        public bool UnlimitedPriorActsCoverageInd { get; set; }

        [JsonPropertyName("CurrentRetroactiveDt")]
        public DateTime CurrentRetroactiveDt { get; set; }

        [JsonPropertyName("RetroactiveCoverageInd")]
        public bool RetroactiveCoverageInd { get; set; }
    }

    public class CurrentTermAmount
    {
        [JsonPropertyName("Amt")]
        public string Amt { get; set; } = string.Empty;
    }

    public class CoverageOption
    {
        [JsonPropertyName("OptionTypeCd")]
        public string OptionTypeCd { get; set; } = string.Empty;

        [JsonPropertyName("OptionValue")]
        public string OptionValue { get; set; } = string.Empty;

        [JsonPropertyName("OptionValueDesc")]
        public string OptionValueDesc { get; set; } = string.Empty;

        [JsonPropertyName("LocationNo")]
        public string LocationNo { get; set; } = string.Empty;

        [JsonPropertyName("BuildingNo")]
        public string BuildingNo { get; set; } = string.Empty;
    }

    public class CreditOrSurcharge
    {
        [JsonPropertyName("CreditSurchargeCd")]
        public string? CreditSurchargeCd { get; set; }

        [JsonPropertyName("NumericValue")]
        public NumericValue? NumericValue { get; set; }
    }

    public class NumericValue
    {
        [JsonPropertyName("FormatModFactor")]
        public decimal FormatModFactor { get; set; }
    }

    public class MinPremiumAmount
    {
        [JsonPropertyName("Amt")]
        public decimal Amt { get; set; }
    }

    public class PropCarrierSpecified
    {
        [JsonPropertyName("SquareFootagePercentageOccupiedByInsured")]
        public string SquareFootagePercentageOccupiedByInsured { get; set; } = string.Empty;

        [JsonPropertyName("IsOwnedByInsured")]
        public string IsOwnedByInsured { get; set; } = string.Empty;

        [JsonPropertyName("RoofShapeType")]
        public string RoofShapeType { get; set; } = string.Empty;

        [JsonPropertyName("RoofConstructionType")]
        public string RoofConstructionType { get; set; } = string.Empty;

        [JsonPropertyName("IsHistoricalRegistry")]
        public string IsHistoricalRegistry { get; set; } = string.Empty;

        [JsonPropertyName("IsTemporaryOrIncidental")]
        public string IsTemporaryOrIncidental { get; set; } = string.Empty;

        [JsonPropertyName("IsPlumbingTypeInListOfIneligibleTypes")]
        public string IsPlumbingTypeInListOfIneligibleTypes { get; set; } = string.Empty;

        [JsonPropertyName("IsHeatingTypeInListOfIneligibleTypes")]
        public string IsHeatingTypeInListOfIneligibleTypes { get; set; } = string.Empty;

        [JsonPropertyName("IsWiringTypeInListOfIneligibleTypes")]
        public string IsWiringTypeInListOfIneligibleTypes { get; set; } = string.Empty;

        [JsonPropertyName("IsElectricCircuitBreakerProtection")]
        public string IsElectricCircuitBreakerProtection { get; set; } = string.Empty;

        [JsonPropertyName("IsOperatingBusinessOpenPastMidnight")]
        public string IsOperatingBusinessOpenPastMidnight { get; set; } = string.Empty;

        [JsonPropertyName("NumberOfUnitsOccupyTenant")]
        public string NumberOfUnitsOccupyTenant { get; set; } = string.Empty;

        [JsonPropertyName("PercentageOccupiedByInsured")]
        public string PercentageOccupiedByInsured { get; set; } = string.Empty;

        [JsonPropertyName("PercentageVacantByInsured")]
        public string PercentageVacantByInsured { get; set; } = string.Empty;
    }

    public class PropCarrierSpecifiedPolicyInfo
    {
        [JsonPropertyName("AccountsReceivableLimitAmount")]
        public string AccountsReceivableLimitAmount { get; set; } = string.Empty;

        [JsonPropertyName("WaterSewageBackupLimitAmount")]
        public string WaterSewageBackupLimitAmount { get; set; } = string.Empty;

        [JsonPropertyName("FireDepartmentServiceChargeLimitAmount")]
        public string FireDepartmentServiceChargeLimitAmount { get; set; } = string.Empty;

        [JsonPropertyName("FireProtectionDeviceRechargeLimitAmount")]
        public string FireProtectionDeviceRechargeLimitAmount { get; set; } = string.Empty;

        [JsonPropertyName("ValuablePapersAndRecordsLimitAmount")]
        public string ValuablePapersAndRecordsLimitAmount { get; set; } = string.Empty;

        [JsonPropertyName("PolicyLevelOptionalCoveragePremiumTotal")]
        public string PolicyLevelOptionalCoveragePremiumTotal { get; set; } = string.Empty;
    }

    // Prior Loss
    public class PriorLoss
    {
        [JsonPropertyName("PriorLossHistoryInfo")]
        public List<object>? PriorLossHistoryInfo { get; set; }
    }
}
