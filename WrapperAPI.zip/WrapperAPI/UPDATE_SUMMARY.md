# Wrapper API - Dyad GetRate Implementation Update

## Summary

The .NET 8 Wrapper API has been updated with comprehensive implementation for the Dyad GetRate endpoint, including strongly-typed C# models matching the exact request and response structures.

## What's New

### 1. Strongly-Typed Models
- **DyadGetRateRequest.cs** - Complete C# model for the request (800+ lines)
  - All nested objects properly typed
  - JSON serialization attributes included
  - Matches exact structure from uploaded files
  
- **DyadGetRateResponse.cs** - Complete C# model for the response (600+ lines)
  - Handles array response format
  - All response fields mapped
  - Status and error handling included

### 2. Updated Controller
- **DyedController.GetRate** endpoint now accepts `DyadGetRateRequest`
- Request validation (RqUID required)
- Strongly-typed response deserialization
- Better error handling and logging
- Swagger documentation annotations

### 3. Documentation
- **DYAD_GETRATE_API.md** - Comprehensive API documentation
  - Field descriptions
  - Request/response examples
  - Error scenarios
  - Testing instructions
  - Troubleshooting guide

### 4. Testing Tools
- **Postman Collection** - Ready-to-use Postman collection
  - Full request example
  - Minimal request example
  - Error test cases
  - Dynamic GUID generation
  
- **Example Request** - Real request JSON from uploaded file
  - Located in `/Examples/DyadGetRateRequest-Example.json`

## Project Structure

```
WrapperAPI/
├── Controllers/
│   └── ServiceControllers.cs          # Updated with strongly-typed GetRate
├── Models/
│   └── Dyad/
│       ├── DyadGetRateRequest.cs      # ✨ NEW - Request models
│       └── DyadGetRateResponse.cs     # ✨ NEW - Response models
├── Services/
│   ├── AuthenticationService.cs       # Token management
│   └── ServiceImplementations.cs      # API call implementations
├── Examples/
│   └── DyadGetRateRequest-Example.json # ✨ NEW - Full example
├── Postman/
│   └── DyadGetRate-Collection.json    # ✨ NEW - Postman tests
├── DYAD_GETRATE_API.md                # ✨ NEW - API documentation
├── EXAMPLES.md                        # General examples
├── README.md                          # Main documentation
├── Program.cs                         # Application startup
├── appsettings.json                   # Configuration
└── WrapperAPI.csproj                  # Project file
```

## Key Features

### Type Safety
- IntelliSense support in Visual Studio
- Compile-time type checking
- Easier refactoring and maintenance

### Request Validation
```csharp
if (string.IsNullOrEmpty(request.InsuranceSvcRq?.RqUID))
{
    return BadRequest(new { error = "RqUID is required" });
}
```

### Response Handling
```csharp
// API returns array, properly deserialized
var rateResponse = await response.Content
    .ReadFromJsonAsync<List<DyadGetRateResponse>>();
```

### Better Logging
```csharp
_logger.LogInformation("GetRate request received for Quote No: {QuoteNo}", 
    request.InsuranceSvcRq?.IRH_QuoteNo);
```

## Usage Examples

### C# Client Example
```csharp
var request = new DyadGetRateRequest
{
    SignonRq = new SignonRequest
    {
        SignonPswd = new SignonPassword
        {
            CustId = new CustomerIdentity 
            { 
                CustLoginId = "SLBGROUP" 
            }
        }
    },
    InsuranceSvcRq = new InsuranceServiceRequest
    {
        RqUID = Guid.NewGuid().ToString(),
        IRH_QuoteNo = "Q123456",
        IRH_Application_Name = "My App",
        IRH_Application_Type = "QRB",
        IRH_Request_Type = "QUOTE"
        // ... more fields
    }
};

var response = await httpClient.PostAsJsonAsync(
    "https://localhost:5001/api/dyed/getrate", 
    request);
    
var result = await response.Content
    .ReadFromJsonAsync<List<DyadGetRateResponse>>();
```

### cURL Example
```bash
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

### PowerShell Example
```powershell
$body = Get-Content "Examples/DyadGetRateRequest-Example.json" -Raw
$response = Invoke-RestMethod `
    -Uri "https://localhost:5001/api/dyed/getrate" `
    -Method POST `
    -Body $body `
    -ContentType "application/json"
```

## Model Highlights

### Request Model Key Objects
- **SignonRequest** - Authentication credentials
- **InsuranceServiceRequest** - Main service request
- **CommercialPackagePolicyQuoteRequest** - Policy details
- **Producer** - Producer/agent information
- **InsuredOrPrincipal** - Insured party details
- **Policy** - Policy terms and dates
- **Location** - Property locations
- **GeneralLiabilityLineBusiness** - GL coverage
- **PropertyLineBusiness** - Property coverage

### Response Model Key Objects
- **SignonResponse** - Sign-on confirmation
- **InsuranceServiceResponse** - Service response wrapper
- **CommercialPackagePolicyQuoteResponse** - Quote details
- **MessageStatus** - Success/error messages
- **BrokerageCommissionInfo** - Commission details

## Testing the API

### 1. Using Postman
1. Import `Postman/DyadGetRate-Collection.json`
2. Set environment variable `baseUrl` to `https://localhost:5001`
3. Run any of the pre-configured requests
4. GUID is auto-generated using `{{$guid}}`

### 2. Using Swagger
1. Run the application: `dotnet run`
2. Navigate to `https://localhost:5001/swagger`
3. Expand the `/api/dyed/getrate` endpoint
4. Click "Try it out"
5. Paste the example JSON
6. Click "Execute"

### 3. Using the Example File
```bash
cd WrapperAPI
dotnet run

# In another terminal
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

## Response Structure

The API returns an **array** with one or more response objects:

```json
[
  {
    "SignonRs": { ... },
    "InsuranceSvcRs": {
      "RqUID": "...",
      "IRH_QuoteNo": "...",
      "CommlPkgPolicyQuoteInqRs": {
        "IRH_Rating_StatusCd": "Success",
        "MsgStatus": [
          {
            "MsgStatusCd": "Success",
            "MsgStatusDesc": "Quote generated successfully"
          }
        ]
      }
    }
  }
]
```

## Error Handling

### Validation Errors (400)
```json
{
  "error": "RqUID is required"
}
```

### Authentication Errors (401)
```json
{
  "error": "Internal server error",
  "message": "Failed to authenticate with Dyed service"
}
```

### API Errors (200 with error status)
```json
{
  "IRH_Rating_StatusCd": "Error",
  "MsgStatus": [
    {
      "MsgStatusCd": "Error",
      "MsgStatusDesc": "Not authorized for this carrier"
    }
  ]
}
```

## Next Steps

1. **Update appsettings.json** with your actual credentials
2. **Test the endpoint** using Postman or Swagger
3. **Review logs** for authentication and API call details
4. **Customize models** if needed for your specific use case
5. **Add more endpoints** following the same pattern

## Benefits

✅ **Type Safety** - Catch errors at compile time  
✅ **IntelliSense** - Auto-completion in IDE  
✅ **Documentation** - Models serve as documentation  
✅ **Validation** - Built-in request validation  
✅ **Testability** - Easier to write unit tests  
✅ **Maintainability** - Clear structure and contracts  

## Files Modified/Added

### Modified
- `Controllers/ServiceControllers.cs` - Added strongly-typed GetRate endpoint

### Added
- `Models/Dyad/DyadGetRateRequest.cs` - Complete request models
- `Models/Dyad/DyadGetRateResponse.cs` - Complete response models
- `Examples/DyadGetRateRequest-Example.json` - Full example request
- `Postman/DyadGetRate-Collection.json` - Postman test collection
- `DYAD_GETRATE_API.md` - Comprehensive API documentation
- `UPDATE_SUMMARY.md` - This file

## Need Help?

1. Check `DYAD_GETRATE_API.md` for detailed API documentation
2. Review example requests in `Examples/` folder
3. Use Postman collection for quick testing
4. Check Swagger UI for interactive testing
5. Review application logs for detailed error messages

---

## Quick Start

```bash
# 1. Extract the project
unzip WrapperAPI.zip
cd WrapperAPI

# 2. Update credentials in appsettings.json

# 3. Restore and run
dotnet restore
dotnet run

# 4. Test with example
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

Enjoy your strongly-typed Dyad GetRate API! 🚀
