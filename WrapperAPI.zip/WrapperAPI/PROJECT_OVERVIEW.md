# 📦 Wrapper API - Complete Package Overview

## 🎯 What You're Getting

A complete, production-ready .NET 8 Web API wrapper for Dyad/Dyed, Herald, and Zywave insurance services with **strongly-typed models** for the Dyad GetRate endpoint.

---

## 📂 Project Structure

```
WrapperAPI/
│
├── 📄 QUICK_START.md              ⭐ START HERE - 5 minute setup guide
├── 📄 DYAD_GETRATE_API.md         📖 Complete Dyad API documentation
├── 📄 UPDATE_SUMMARY.md            📝 What's new in this version
├── 📄 README.md                    📚 General project documentation
├── 📄 EXAMPLES.md                  💡 Usage examples for all endpoints
│
├── 🔧 Program.cs                   ⚙️ Application startup & DI config
├── 🔧 appsettings.json             🔑 Configuration & credentials
├── 🔧 WrapperAPI.csproj            📦 Project file
├── 🔧 Dockerfile                   🐳 Docker support
├── 🔧 .gitignore                   🚫 Git ignore rules
│
├── 📁 Controllers/
│   └── ServiceControllers.cs      🎮 API endpoints (Dyed, Herald, Zywave)
│
├── 📁 Services/
│   ├── AuthenticationService.cs   🔐 Token management & caching
│   └── ServiceImplementations.cs  🔌 API call implementations
│
├── 📁 Models/
│   └── Dyad/
│       ├── DyadGetRateRequest.cs  ✨ 800+ lines of typed request models
│       └── DyadGetRateResponse.cs ✨ 600+ lines of typed response models
│
├── 📁 Examples/
│   └── DyadGetRateRequest-Example.json  📋 Full working request example
│
└── 📁 Postman/
    └── DyadGetRate-Collection.json      🧪 Postman test collection
```

---

## ✨ Key Features

### 🔒 Automatic Authentication
```
Your Request → Wrapper → Get Token → Call API → Return Response
                  ↓
            Token Cache
            (Auto-refresh)
```

### 💪 Strongly-Typed Models
```csharp
// IntelliSense magic! ✨
var request = new DyadGetRateRequest
{
    SignonRq = new SignonRequest { ... },
    InsuranceSvcRq = new InsuranceServiceRequest
    {
        RqUID = Guid.NewGuid().ToString(),
        CommlPkgPolicyQuoteInqRq = new CommercialPackagePolicyQuoteRequest
        {
            Producer = new List<Producer> { ... }
        }
    }
};
```

### 📊 Request Validation
```csharp
✅ RqUID required
✅ Proper format checking
✅ Helpful error messages
```

### 📝 Comprehensive Logging
```
[INFO] GetRate request received for Quote No: Q123456
[INFO] Using cached token for Dyed
[INFO] Calling Dyed API at https://acehubtest.i-engineering.com/acehub/GetRate
[INFO] Response received with status: 200 OK
```

---

## 🚀 Quick Start (30 seconds)

```bash
# 1. Extract
unzip WrapperAPI.zip && cd WrapperAPI

# 2. Run
dotnet run

# 3. Test
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

---

## 📚 Documentation Files

| File | Purpose | When to Use |
|------|---------|-------------|
| **QUICK_START.md** | Get started in 5 min | First time setup |
| **DYAD_GETRATE_API.md** | Complete API reference | Building integrations |
| **UPDATE_SUMMARY.md** | What's new | Understanding changes |
| **README.md** | Project overview | General information |
| **EXAMPLES.md** | Code examples | Learning the API |

---

## 🛠️ Available Endpoints

### ✅ Fully Implemented with Types
```
POST /api/dyed/getrate      ← Strongly-typed models
```

### ⚙️ Ready to Use (Generic object)
```
POST /api/dyed/getdocument
POST /api/herald/quote
POST /api/herald/bind
POST /api/zywave/pay
```

---

## 🎯 What Makes This Special

### Before (Generic object)
```csharp
[HttpPost("getrate")]
public async Task<IActionResult> GetRate([FromBody] object request)
{
    // No IntelliSense 😞
    // No validation 😞
    // Hard to maintain 😞
}
```

### After (Strongly-typed) ✨
```csharp
[HttpPost("getrate")]
public async Task<IActionResult> GetRate([FromBody] DyadGetRateRequest request)
{
    // Full IntelliSense! 😊
    // Automatic validation! 😊
    // Type-safe! 😊
    
    if (string.IsNullOrEmpty(request.InsuranceSvcRq?.RqUID))
        return BadRequest(new { error = "RqUID is required" });
    
    var response = await _dyedService.GetRateAsync(request);
    return Ok(await response.Content.ReadFromJsonAsync<List<DyadGetRateResponse>>());
}
```

---

## 📦 What's Included

### Models (1,400+ lines of typed code)
- ✅ SignonRequest / SignonResponse
- ✅ InsuranceServiceRequest / InsuranceServiceResponse
- ✅ Producer, InsuredOrPrincipal, Policy
- ✅ Location, SubLocation, Address
- ✅ GeneralLiabilityLineBusiness
- ✅ PropertyLineBusiness
- ✅ Coverage, Deductible, Limit
- ✅ MessageStatus, BrokerageCommissionInfo
- ✅ And 50+ more nested types!

### Testing Tools
- ✅ Postman collection with 4 test cases
- ✅ Full example JSON request
- ✅ Swagger/OpenAPI documentation
- ✅ cURL examples
- ✅ PowerShell examples

### Documentation
- ✅ API reference guide
- ✅ Field descriptions
- ✅ Error scenarios
- ✅ Troubleshooting tips
- ✅ Integration examples

---

## 🎓 Learning Path

1. **Day 1**: Read `QUICK_START.md` → Run the project → Test with Postman
2. **Day 2**: Read `DYAD_GETRATE_API.md` → Understand the models
3. **Day 3**: Review `Models/Dyad/` → Build your first integration
4. **Day 4**: Check `EXAMPLES.md` → Customize for your needs

---

## 💡 Use Cases

### ✅ Perfect For:
- Building insurance quote systems
- Integrating with multiple carriers
- Creating broker portals
- Automating insurance workflows
- Multi-carrier rate comparison tools

### ✅ Benefits:
- **Type Safety**: Catch errors at compile-time
- **Productivity**: IntelliSense speeds up development
- **Maintainability**: Clear contracts and structure
- **Testability**: Easy to mock and unit test
- **Documentation**: Models serve as living docs

---

## 🔧 Configuration

### Required: Update `appsettings.json`
```json
{
  "Dyed": {
    "Credentials": {
      "ClientId": "YOUR_CLIENT_ID",        ← Change this
      "ClientSecret": "YOUR_CLIENT_SECRET"  ← Change this
    }
  }
}
```

---

## 🧪 Testing Options

### 1. Swagger UI (Interactive)
```
https://localhost:5001/swagger
```

### 2. Postman (Pre-built Collection)
```
Import: Postman/DyadGetRate-Collection.json
```

### 3. cURL (Command Line)
```bash
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

### 4. Visual Studio (Debugging)
```
F5 to run with debugger
```

---

## 📊 Response Handling

### Success Response
```json
[{
  "InsuranceSvcRs": {
    "IRH_Rating_StatusCd": "Success",
    "CommlPkgPolicyQuoteInqRs": {
      "BrokerageCommissionInfo": {
        "CommissionAmt": 1500.00
      }
    }
  }
}]
```

### Error Response (API Level)
```json
[{
  "InsuranceSvcRs": {
    "CommlPkgPolicyQuoteInqRs": {
      "IRH_Rating_StatusCd": "Error",
      "MsgStatus": [{
        "MsgStatusCd": "Error",
        "MsgStatusDesc": "Not authorized"
      }]
    }
  }
}]
```

### Error Response (Wrapper Level)
```json
{
  "error": "RqUID is required"
}
```

---

## 🚦 Status Codes

| Code | Meaning | Action |
|------|---------|--------|
| 200 | Success | Process response |
| 400 | Bad Request | Check request format |
| 401 | Unauthorized | Check credentials |
| 500 | Server Error | Check logs |

---

## 📈 Performance Features

- ✅ **Token Caching**: Reuses tokens until 1 min before expiry
- ✅ **Thread-Safe**: Prevents duplicate token requests
- ✅ **Automatic Refresh**: Seamlessly refreshes expired tokens
- ✅ **Connection Pooling**: Efficient HTTP client usage

---

## 🎯 Production Ready

- ✅ Proper error handling
- ✅ Comprehensive logging
- ✅ Request validation
- ✅ Docker support
- ✅ Health checks ready
- ✅ Swagger documentation
- ✅ Type-safe contracts

---

## 📞 Support

### Having Issues?
1. Check `QUICK_START.md` for setup
2. Review `DYAD_GETRATE_API.md` for API details
3. Check application logs
4. Try the Postman collection
5. Review example requests

### Common Solutions
- **401 Error**: Update credentials in `appsettings.json`
- **RqUID Error**: Generate a new GUID for each request
- **Carrier Error**: Verify carrier name and authorization
- **Connection Error**: Check network and firewall settings

---

## 🎉 You're Ready!

### Next Steps:
1. ✅ Extract the project
2. ✅ Update `appsettings.json`
3. ✅ Run `dotnet run`
4. ✅ Test with examples
5. ✅ Build your integration

### Pro Tips:
- 💡 Start with the minimal request example
- 💡 Use Postman for quick testing
- 💡 Check Swagger for interactive docs
- 💡 Review models for field understanding
- 💡 Enable detailed logging for debugging

---

**Happy Coding! 🚀**

For questions, check the documentation files or review the example code.
