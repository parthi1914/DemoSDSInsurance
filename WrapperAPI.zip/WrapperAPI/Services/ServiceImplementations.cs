using System.Net.Http.Headers;

namespace WrapperAPI.Services
{
    public interface IDyedService
    {
        Task<HttpResponseMessage> GetRateAsync(object requestBody);
        Task<HttpResponseMessage> GetDocumentAsync(object requestBody);
    }

    public interface IHeraldService
    {
        Task<HttpResponseMessage> GetQuoteAsync(object requestBody);
        Task<HttpResponseMessage> BindAsync(object requestBody);
    }

    public interface IZywaveService
    {
        Task<HttpResponseMessage> PayAsync(object requestBody);
    }

    public class DyedService : IDyedService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAuthenticationService _authService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<DyedService> _logger;

        public DyedService(
            IHttpClientFactory httpClientFactory,
            IAuthenticationService authService,
            IConfiguration configuration,
            ILogger<DyedService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _authService = authService;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<HttpResponseMessage> GetRateAsync(object requestBody)
        {
            var baseUrl = _configuration["Dyed:BaseUrl"] 
                ?? "https://acehubtest.i-engineering.com/acehub";
            
            return await ExecuteRequestAsync($"{baseUrl}/GetRate", requestBody);
        }

        public async Task<HttpResponseMessage> GetDocumentAsync(object requestBody)
        {
            var baseUrl = _configuration["Dyed:BaseUrl"] 
                ?? "https://acehubtest.i-engineering.com/acehub";
            
            return await ExecuteRequestAsync($"{baseUrl}/GetDocument", requestBody);
        }

        private async Task<HttpResponseMessage> ExecuteRequestAsync(string url, object requestBody)
        {
            var token = await _authService.GetTokenAsync("Dyed");
            if (token == null)
            {
                _logger.LogError("Failed to obtain token for Dyed service");
                return new HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized)
                {
                    Content = new StringContent("Failed to authenticate with Dyed service")
                };
            }

            var httpClient = _httpClientFactory.CreateClient("DyedService");
            httpClient.DefaultRequestHeaders.Authorization = 
                new AuthenticationHeaderValue("Bearer", token.AccessToken);

            try
            {
                var response = await httpClient.PostAsJsonAsync(url, requestBody);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calling Dyed API at {Url}", url);
                throw;
            }
        }
    }

    public class HeraldService : IHeraldService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAuthenticationService _authService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<HeraldService> _logger;

        public HeraldService(
            IHttpClientFactory httpClientFactory,
            IAuthenticationService authService,
            IConfiguration configuration,
            ILogger<HeraldService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _authService = authService;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<HttpResponseMessage> GetQuoteAsync(object requestBody)
        {
            var baseUrl = _configuration["Herald:BaseUrl"] ?? "https://herald-api.example.com";
            return await ExecuteRequestAsync($"{baseUrl}/quote", requestBody);
        }

        public async Task<HttpResponseMessage> BindAsync(object requestBody)
        {
            var baseUrl = _configuration["Herald:BaseUrl"] ?? "https://herald-api.example.com";
            return await ExecuteRequestAsync($"{baseUrl}/bind", requestBody);
        }

        private async Task<HttpResponseMessage> ExecuteRequestAsync(string url, object requestBody)
        {
            var token = await _authService.GetTokenAsync("Herald");
            if (token == null)
            {
                _logger.LogError("Failed to obtain token for Herald service");
                return new HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized)
                {
                    Content = new StringContent("Failed to authenticate with Herald service")
                };
            }

            var httpClient = _httpClientFactory.CreateClient("HeraldService");
            httpClient.DefaultRequestHeaders.Authorization = 
                new AuthenticationHeaderValue("Bearer", token.AccessToken);

            try
            {
                var response = await httpClient.PostAsJsonAsync(url, requestBody);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calling Herald API at {Url}", url);
                throw;
            }
        }
    }

    public class ZywaveService : IZywaveService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAuthenticationService _authService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<ZywaveService> _logger;

        public ZywaveService(
            IHttpClientFactory httpClientFactory,
            IAuthenticationService authService,
            IConfiguration configuration,
            ILogger<ZywaveService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _authService = authService;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<HttpResponseMessage> PayAsync(object requestBody)
        {
            var baseUrl = _configuration["Zywave:BaseUrl"] ?? "https://zywave-api.example.com";
            return await ExecuteRequestAsync($"{baseUrl}/pay", requestBody);
        }

        private async Task<HttpResponseMessage> ExecuteRequestAsync(string url, object requestBody)
        {
            var token = await _authService.GetTokenAsync("Zywave");
            if (token == null)
            {
                _logger.LogError("Failed to obtain token for Zywave service");
                return new HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized)
                {
                    Content = new StringContent("Failed to authenticate with Zywave service")
                };
            }

            var httpClient = _httpClientFactory.CreateClient("ZywaveService");
            httpClient.DefaultRequestHeaders.Authorization = 
                new AuthenticationHeaderValue("Bearer", token.AccessToken);

            try
            {
                var response = await httpClient.PostAsJsonAsync(url, requestBody);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calling Zywave API at {Url}", url);
                throw;
            }
        }
    }
}
