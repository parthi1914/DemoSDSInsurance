using System.Text.Json.Serialization;

namespace WrapperAPI.Services
{
    public interface IAuthenticationService
    {
        Task<TokenResponse?> GetTokenAsync(string service);
    }

    public class AuthenticationService : IAuthenticationService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AuthenticationService> _logger;
        private readonly Dictionary<string, TokenCache> _tokenCache = new();
        private readonly SemaphoreSlim _semaphore = new(1, 1);

        public AuthenticationService(
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration,
            ILogger<AuthenticationService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<TokenResponse?> GetTokenAsync(string service)
        {
            // Check if we have a valid cached token
            if (_tokenCache.TryGetValue(service, out var cache) && cache.IsValid())
            {
                _logger.LogInformation("Using cached token for {Service}", service);
                return cache.Token;
            }

            await _semaphore.WaitAsync();
            try
            {
                // Double-check after acquiring lock
                if (_tokenCache.TryGetValue(service, out cache) && cache.IsValid())
                {
                    return cache.Token;
                }

                // Get new token
                var token = await FetchTokenAsync(service);
                
                if (token != null)
                {
                    _tokenCache[service] = new TokenCache(token);
                    _logger.LogInformation("Fetched new token for {Service}", service);
                }

                return token;
            }
            finally
            {
                _semaphore.Release();
            }
        }

        private async Task<TokenResponse?> FetchTokenAsync(string service)
        {
            var credentials = GetCredentials(service);
            if (credentials == null)
            {
                _logger.LogError("Credentials not found for service: {Service}", service);
                return null;
            }

            var httpClient = _httpClientFactory.CreateClient();
            var tokenUrl = _configuration[$"{service}:TokenUrl"] 
                ?? "https://acehubtest.i-engineering.com/acehub/GetToken";

            try
            {
                var response = await httpClient.PostAsJsonAsync(tokenUrl, credentials);
                response.EnsureSuccessStatusCode();

                var tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>();
                return tokenResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching token for {Service}", service);
                return null;
            }
        }

        private TokenRequest? GetCredentials(string service)
        {
            var section = _configuration.GetSection($"{service}:Credentials");
            var clientId = section["ClientId"];
            var clientSecret = section["ClientSecret"];

            if (string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(clientSecret))
            {
                return null;
            }

            return new TokenRequest
            {
                ClientId = clientId,
                ClientSecret = clientSecret
            };
        }

        private class TokenCache
        {
            public TokenResponse Token { get; }
            public DateTime ExpiresAt { get; }

            public TokenCache(TokenResponse token)
            {
                Token = token;
                // Refresh token 1 minute before expiry
                ExpiresAt = token.Expires.AddMinutes(-1);
            }

            public bool IsValid() => DateTime.UtcNow < ExpiresAt;
        }
    }

    public class TokenRequest
    {
        [JsonPropertyName("client_id")]
        public string ClientId { get; set; } = string.Empty;

        [JsonPropertyName("client_secret")]
        public string ClientSecret { get; set; } = string.Empty;
    }

    public class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = string.Empty;

        [JsonPropertyName("userName")]
        public string UserName { get; set; } = string.Empty;

        [JsonPropertyName("roles")]
        public string Roles { get; set; } = string.Empty;

        [JsonPropertyName("issued")]
        public DateTime Issued { get; set; }

        [JsonPropertyName("expires")]
        public DateTime Expires { get; set; }
    }
}
