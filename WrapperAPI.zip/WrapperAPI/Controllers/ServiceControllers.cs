using Microsoft.AspNetCore.Mvc;
using WrapperAPI.Models.Dyad;
using WrapperAPI.Services;

namespace WrapperAPI.Controllers
{
    /// <summary>
    /// Controller for Dyed/Dyad insurance service endpoints
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class DyedController : ControllerBase
    {
        private readonly IDyedService _dyedService;
        private readonly ILogger<DyedController> _logger;

        public DyedController(IDyedService dyedService, ILogger<DyedController> logger)
        {
            _dyedService = dyedService;
            _logger = logger;
        }

        /// <summary>
        /// Get insurance rate quote from Dyad
        /// </summary>
        /// <param name="request">Complete rate request with policy and coverage details</param>
        /// <returns>Rate response with pricing and coverage information</returns>
        [HttpPost("getrate")]
        [ProducesResponseType(typeof(List<DyadGetRateResponse>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetRate([FromBody] DyadGetRateRequest request)
        {
            try
            {
                _logger.LogInformation("GetRate request received for Quote No: {QuoteNo}", 
                    request.InsuranceSvcRq?.IRH_QuoteNo);

                // Validate request
                if (request == null)
                {
                    return BadRequest(new { error = "Request body is required" });
                }

                if (string.IsNullOrEmpty(request.InsuranceSvcRq?.RqUID))
                {
                    return BadRequest(new { error = "RqUID is required" });
                }

                var response = await _dyedService.GetRateAsync(request);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("GetRate returned non-success status: {StatusCode}, Content: {Content}", 
                        response.StatusCode, errorContent);
                    return StatusCode((int)response.StatusCode, errorContent);
                }

                // Deserialize the response to strongly-typed model
                var rateResponse = await response.Content.ReadFromJsonAsync<List<DyadGetRateResponse>>();
                
                return Ok(rateResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetRate endpoint for Quote No: {QuoteNo}", 
                    request?.InsuranceSvcRq?.IRH_QuoteNo);
                return StatusCode(500, new 
                { 
                    error = "Internal server error", 
                    message = ex.Message,
                    timestamp = DateTime.UtcNow
                });
            }
        }

        /// <summary>
        /// Get insurance document from Dyad
        /// </summary>
        /// <param name="request">Document request with quote details</param>
        /// <returns>Document data or download link</returns>
        [HttpPost("getdocument")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetDocument([FromBody] object request)
        {
            try
            {
                _logger.LogInformation("GetDocument request received");

                if (request == null)
                {
                    return BadRequest(new { error = "Request body is required" });
                }

                var response = await _dyedService.GetDocumentAsync(request);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("GetDocument returned non-success status: {StatusCode}", 
                        response.StatusCode);
                    return StatusCode((int)response.StatusCode, errorContent);
                }

                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetDocument endpoint");
                return StatusCode(500, new 
                { 
                    error = "Internal server error", 
                    message = ex.Message,
                    timestamp = DateTime.UtcNow
                });
            }
        }
    }

    /// <summary>
    /// Controller for Herald insurance service endpoints
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class HeraldController : ControllerBase
    {
        private readonly IHeraldService _heraldService;
        private readonly ILogger<HeraldController> _logger;

        public HeraldController(IHeraldService heraldService, ILogger<HeraldController> logger)
        {
            _heraldService = heraldService;
            _logger = logger;
        }

        /// <summary>
        /// Get insurance quote from Herald
        /// </summary>
        /// <param name="request">Quote request</param>
        /// <returns>Quote response</returns>
        [HttpPost("quote")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetQuote([FromBody] object request)
        {
            try
            {
                _logger.LogInformation("Herald GetQuote request received");

                if (request == null)
                {
                    return BadRequest(new { error = "Request body is required" });
                }

                var response = await _heraldService.GetQuoteAsync(request);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("Herald GetQuote returned non-success status: {StatusCode}", 
                        response.StatusCode);
                    return StatusCode((int)response.StatusCode, errorContent);
                }

                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Herald GetQuote endpoint");
                return StatusCode(500, new 
                { 
                    error = "Internal server error", 
                    message = ex.Message,
                    timestamp = DateTime.UtcNow
                });
            }
        }

        /// <summary>
        /// Bind policy with Herald
        /// </summary>
        /// <param name="request">Bind request</param>
        /// <returns>Bind confirmation</returns>
        [HttpPost("bind")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Bind([FromBody] object request)
        {
            try
            {
                _logger.LogInformation("Herald Bind request received");

                if (request == null)
                {
                    return BadRequest(new { error = "Request body is required" });
                }

                var response = await _heraldService.BindAsync(request);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("Herald Bind returned non-success status: {StatusCode}", 
                        response.StatusCode);
                    return StatusCode((int)response.StatusCode, errorContent);
                }

                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Herald Bind endpoint");
                return StatusCode(500, new 
                { 
                    error = "Internal server error", 
                    message = ex.Message,
                    timestamp = DateTime.UtcNow
                });
            }
        }
    }

    /// <summary>
    /// Controller for Zywave payment service endpoints
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class ZywaveController : ControllerBase
    {
        private readonly IZywaveService _zywaveService;
        private readonly ILogger<ZywaveController> _logger;

        public ZywaveController(IZywaveService zywaveService, ILogger<ZywaveController> logger)
        {
            _zywaveService = zywaveService;
            _logger = logger;
        }

        /// <summary>
        /// Process payment with Zywave
        /// </summary>
        /// <param name="request">Payment request</param>
        /// <returns>Payment confirmation</returns>
        [HttpPost("pay")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Pay([FromBody] object request)
        {
            try
            {
                _logger.LogInformation("Zywave Pay request received");

                if (request == null)
                {
                    return BadRequest(new { error = "Request body is required" });
                }

                var response = await _zywaveService.PayAsync(request);
                
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("Zywave Pay returned non-success status: {StatusCode}", 
                        response.StatusCode);
                    return StatusCode((int)response.StatusCode, errorContent);
                }

                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Zywave Pay endpoint");
                return StatusCode(500, new 
                { 
                    error = "Internal server error", 
                    message = ex.Message,
                    timestamp = DateTime.UtcNow
                });
            }
        }
    }
}
