# API Request Examples

This file contains example requests you can use to test the Wrapper API.

## Prerequisites
- The API should be running on `https://localhost:5001` or `http://localhost:5000`
- Use a tool like Postman, curl, or any HTTP client

---

## 1. Dyed Service - Get Rate

### Endpoint
```
POST https://localhost:5001/api/dyed/getrate
```

### Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "SignonRq": {
    "SignonPswd": {
      "CustId": {
        "CustLoginId": "SLBGROUP"
      }
    }
  },
  "InsuranceSvcRq": {
    "RqUID": "12345678-1234-1234-1234-123456789012",
    "TRH_QuoteNo": "1424",
    "comTRH_CarrierRequestExt": {
      "PolicyInfo": {
        "EffectiveDate": "2025-01-01",
        "ExpirationDate": "2026-01-01"
      }
    }
  }
}
```

### cURL Example
```bash
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d '{
    "SignonRq": {
      "SignonPswd": {
        "CustId": {
          "CustLoginId": "SLBGROUP"
        }
      }
    },
    "InsuranceSvcRq": {
      "RqUID": "12345678-1234-1234-1234-123456789012",
      "TRH_QuoteNo": "1424",
      "comTRH_CarrierRequestExt": {}
    }
  }'
```

---

## 2. Dyed Service - Get Document

### Endpoint
```
POST https://localhost:5001/api/dyed/getdocument
```

### Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "SignonRq": {
    "SignonPswd": {
      "CustId": {
        "CustLoginId": "SLBGROUP"
      }
    }
  },
  "InsuranceSvcRq": {
    "RqUID": "12345678-1234-1234-1234-123456789012",
    "TRH_QuoteNo": "1424",
    "DocumentType": "Quote"
  }
}
```

### cURL Example
```bash
curl -X POST https://localhost:5001/api/dyed/getdocument \
  -H "Content-Type: application/json" \
  -d '{
    "SignonRq": {
      "SignonPswd": {
        "CustId": {
          "CustLoginId": "SLBGROUP"
        }
      }
    },
    "InsuranceSvcRq": {
      "RqUID": "12345678-1234-1234-1234-123456789012",
      "TRH_QuoteNo": "1424",
      "DocumentType": "Quote"
    }
  }'
```

---

## 3. Herald Service - Get Quote

### Endpoint
```
POST https://localhost:5001/api/herald/quote
```

### Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "quoteRequest": {
    "customerId": "CUST123",
    "productType": "AutoInsurance",
    "coverageAmount": 100000,
    "deductible": 500
  }
}
```

### cURL Example
```bash
curl -X POST https://localhost:5001/api/herald/quote \
  -H "Content-Type: application/json" \
  -d '{
    "quoteRequest": {
      "customerId": "CUST123",
      "productType": "AutoInsurance",
      "coverageAmount": 100000,
      "deductible": 500
    }
  }'
```

---

## 4. Herald Service - Bind Policy

### Endpoint
```
POST https://localhost:5001/api/herald/bind
```

### Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "bindRequest": {
    "quoteId": "QUOTE123",
    "customerId": "CUST123",
    "effectiveDate": "2025-01-01",
    "paymentMethod": "CreditCard"
  }
}
```

### cURL Example
```bash
curl -X POST https://localhost:5001/api/herald/bind \
  -H "Content-Type: application/json" \
  -d '{
    "bindRequest": {
      "quoteId": "QUOTE123",
      "customerId": "CUST123",
      "effectiveDate": "2025-01-01",
      "paymentMethod": "CreditCard"
    }
  }'
```

---

## 5. Zywave Service - Process Payment

### Endpoint
```
POST https://localhost:5001/api/zywave/pay
```

### Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "paymentRequest": {
    "policyNumber": "POL123",
    "amount": 1500.00,
    "currency": "USD",
    "paymentMethod": {
      "type": "CreditCard",
      "cardNumber": "4111111111111111",
      "expiryMonth": "12",
      "expiryYear": "2025",
      "cvv": "123"
    }
  }
}
```

### cURL Example
```bash
curl -X POST https://localhost:5001/api/zywave/pay \
  -H "Content-Type: application/json" \
  -d '{
    "paymentRequest": {
      "policyNumber": "POL123",
      "amount": 1500.00,
      "currency": "USD",
      "paymentMethod": {
        "type": "CreditCard",
        "cardNumber": "4111111111111111",
        "expiryMonth": "12",
        "expiryYear": "2025",
        "cvv": "123"
      }
    }
  }'
```

---

## Testing with PowerShell

### Example 1: Dyed Get Rate
```powershell
$body = @{
    SignonRq = @{
        SignonPswd = @{
            CustId = @{
                CustLoginId = "SLBGROUP"
            }
        }
    }
    InsuranceSvcRq = @{
        RqUID = "12345678-1234-1234-1234-123456789012"
        TRH_QuoteNo = "1424"
        comTRH_CarrierRequestExt = @{}
    }
} | ConvertTo-Json -Depth 10

$response = Invoke-RestMethod -Uri "https://localhost:5001/api/dyed/getrate" `
    -Method POST `
    -Body $body `
    -ContentType "application/json"

$response | ConvertTo-Json -Depth 10
```

---

## Testing with Python

### Example 1: Dyed Get Rate
```python
import requests
import json

url = "https://localhost:5001/api/dyed/getrate"

payload = {
    "SignonRq": {
        "SignonPswd": {
            "CustId": {
                "CustLoginId": "SLBGROUP"
            }
        }
    },
    "InsuranceSvcRq": {
        "RqUID": "12345678-1234-1234-1234-123456789012",
        "TRH_QuoteNo": "1424",
        "comTRH_CarrierRequestExt": {}
    }
}

headers = {
    "Content-Type": "application/json"
}

response = requests.post(url, json=payload, headers=headers, verify=False)

print(f"Status Code: {response.status_code}")
print(f"Response: {json.dumps(response.json(), indent=2)}")
```

---

## Expected Responses

### Success Response Example
```json
{
  "status": "success",
  "data": {
    "quoteId": "QUOTE123",
    "premium": 1500.00,
    "effectiveDate": "2025-01-01"
  }
}
```

### Error Response Example
```json
{
  "error": "Internal server error",
  "message": "Failed to authenticate with Dyed service"
}
```

---

## Monitoring Token Behavior

Watch the console logs while making requests to see:
1. Token fetch operations
2. Token cache hits
3. Automatic token refresh before expiry
4. API call success/failures

Example log output:
```
info: WrapperAPI.Services.AuthenticationService[0]
      Fetched new token for Dyed
info: WrapperAPI.Services.DyedService[0]
      Calling Dyed API at https://acehubtest.i-engineering.com/acehub/GetRate
info: WrapperAPI.Services.AuthenticationService[0]
      Using cached token for Dyed
```
