# Dyad GetRate - Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Extract and Navigate
```bash
unzip WrapperAPI.zip
cd WrapperAPI
```

### Step 2: Restore Dependencies
```bash
dotnet restore
```

### Step 3: Run the Application
```bash
dotnet run
```

The API will start on:
- HTTPS: `https://localhost:5001`
- HTTP: `http://localhost:5000`
- Swagger: `https://localhost:5001/swagger`

### Step 4: Test the Endpoint

#### Option A: Using cURL
```bash
curl -X POST https://localhost:5001/api/dyed/getrate \
  -H "Content-Type: application/json" \
  -d @Examples/DyadGetRateRequest-Example.json
```

#### Option B: Using Postman
1. Import `Postman/DyadGetRate-Collection.json`
2. Set variable `baseUrl` = `https://localhost:5001`
3. Run "Dyad GetRate - Full Request"

#### Option C: Using Swagger
1. Open browser: `https://localhost:5001/swagger`
2. Find `/api/dyed/getrate` endpoint
3. Click "Try it out"
4. Paste content from `Examples/DyadGetRateRequest-Example.json`
5. Click "Execute"

## 📁 Important Files

### For Development
- **Models/Dyad/DyadGetRateRequest.cs** - Request model (800+ lines, fully typed)
- **Models/Dyad/DyadGetRateResponse.cs** - Response model (600+ lines, fully typed)
- **Controllers/ServiceControllers.cs** - API endpoints with validation

### For Testing
- **Examples/DyadGetRateRequest-Example.json** - Full working example
- **Postman/DyadGetRate-Collection.json** - Postman test collection
- **DYAD_GETRATE_API.md** - Complete API documentation

### Configuration
- **appsettings.json** - Update with your credentials

## 🔑 Key Features

✅ **Strongly Typed Models** - Full IntelliSense support  
✅ **Automatic Token Management** - No manual auth needed  
✅ **Request Validation** - Built-in validation  
✅ **Comprehensive Logging** - Track every step  
✅ **Swagger Documentation** - Interactive testing  

## 📋 Request Example

Minimal request:
```json
{
  "SignonRq": {
    "SignonPswd": {
      "CustId": {
        "CustLoginId": "SLBGROUP"
      }
    }
  },
  "InsuranceSvcRq": {
    "RqUID": "YOUR-GUID-HERE",
    "IRH_QuoteNo": "Q123456",
    "IRH_Application_Name": "My App",
    "IRH_Application_Type": "QRB",
    "IRH_Request_Type": "QUOTE"
  }
}
```

## 📤 Response Example

Success:
```json
[
  {
    "InsuranceSvcRs": {
      "RqUID": "4ac5e506-a9b0-40d8-a7be-45a2800f4878",
      "IRH_QuoteNo": "Q123456",
      "CommlPkgPolicyQuoteInqRs": {
        "IRH_Rating_StatusCd": "Success",
        "MsgStatus": [
          {
            "MsgStatusCd": "Success",
            "MsgStatusDesc": "Quote generated"
          }
        ]
      }
    }
  }
]
```

## ⚠️ Common Issues

### Issue: "RqUID is required"
**Solution**: Add a valid GUID to `InsuranceSvcRq.RqUID`
```csharp
RqUID = Guid.NewGuid().ToString()
```

### Issue: 401 Unauthorized
**Solution**: Check credentials in `appsettings.json`
```json
{
  "Dyed": {
    "Credentials": {
      "ClientId": "YOUR_CLIENT_ID",
      "ClientSecret": "YOUR_CLIENT_SECRET"
    }
  }
}
```

### Issue: "Not authorized for carrier"
**Solution**: Verify carrier name and your permissions
- Check carrier spelling: "USLI", "ACI", etc.
- Confirm your account has access to this carrier

## 📚 Documentation

- **DYAD_GETRATE_API.md** - Complete API reference
- **UPDATE_SUMMARY.md** - What's new and changed
- **README.md** - General project documentation
- **EXAMPLES.md** - Usage examples for all endpoints

## 🛠️ Development

### Using in Your C# Application
```csharp
using WrapperAPI.Models.Dyad;

var request = new DyadGetRateRequest
{
    SignonRq = new SignonRequest
    {
        SignonPswd = new SignonPassword
        {
            CustId = new CustomerIdentity { CustLoginId = "SLBGROUP" }
        }
    },
    InsuranceSvcRq = new InsuranceServiceRequest
    {
        RqUID = Guid.NewGuid().ToString(),
        IRH_QuoteNo = "Q123456"
    }
};

var response = await httpClient.PostAsJsonAsync(
    "https://localhost:5001/api/dyed/getrate", 
    request);
```

### IntelliSense Support
All models are strongly typed, giving you:
- Auto-completion in Visual Studio
- Compile-time error checking
- Easy refactoring
- Better code documentation

## 🔍 Monitoring

Watch the console for logs:
```
info: WrapperAPI.Controllers.DyedController[0]
      GetRate request received for Quote No: Q123456
info: WrapperAPI.Services.AuthenticationService[0]
      Using cached token for Dyed
info: WrapperAPI.Services.DyedService[0]
      Calling Dyed API at https://acehubtest.i-engineering.com/acehub/GetRate
```

## 🎯 Next Steps

1. ✅ Run the application
2. ✅ Test with example requests
3. ✅ Review the strongly-typed models
4. ✅ Check Swagger documentation
5. ✅ Integrate into your application

## 📞 Support Resources

- **API Documentation**: See `DYAD_GETRATE_API.md`
- **Model Reference**: Check `Models/Dyad/` folder
- **Example Requests**: See `Examples/` folder
- **Postman Tests**: Import `Postman/DyadGetRate-Collection.json`

---

**Happy Coding! 🎉**

For detailed documentation, see `DYAD_GETRATE_API.md`
