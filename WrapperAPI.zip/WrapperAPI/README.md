# Wrapper API for Dyed, Herald, and Zywave Services

This is a .NET 8 Web API that provides a unified authentication layer for calling Dyed, Herald, and Zywave APIs. The wrapper handles token management, caching, and automatic token refresh.

## Features

- **Automatic Token Management**: Fetches and caches JWT tokens for each service
- **Token Caching**: Tokens are cached and automatically refreshed before expiry
- **Thread-Safe**: Uses semaphores to prevent race conditions during token refresh
- **Service Abstraction**: Clean separation of concerns with service interfaces
- **Error Handling**: Comprehensive error logging and handling
- **Swagger Integration**: Built-in API documentation

## Project Structure

```
WrapperAPI/
├── Controllers/
│   └── ServiceControllers.cs          # API endpoints for Dyed, Herald, Zywave
├── Services/
│   ├── AuthenticationService.cs       # Handles token fetch and caching
│   └── ServiceImplementations.cs      # Service-specific API calls
├── Program.cs                         # Application startup and DI configuration
├── appsettings.json                   # Configuration and credentials
└── WrapperAPI.csproj                  # Project file
```

## Setup Instructions

### Prerequisites
- .NET 8 SDK installed
- Visual Studio 2022 or VS Code

### Configuration

Update `appsettings.json` with your actual credentials for each service:

```json
{
  "Dyed": {
    "BaseUrl": "https://acehubtest.i-engineering.com/acehub",
    "TokenUrl": "https://acehubtest.i-engineering.com/acehub/GetToken",
    "Credentials": {
      "ClientId": "YOUR_CLIENT_ID",
      "ClientSecret": "YOUR_CLIENT_SECRET"
    }
  },
  "Herald": {
    "BaseUrl": "https://herald-api.example.com",
    "TokenUrl": "https://acehubtest.i-engineering.com/acehub/GetToken",
    "Credentials": {
      "ClientId": "YOUR_CLIENT_ID",
      "ClientSecret": "YOUR_CLIENT_SECRET"
    }
  },
  "Zywave": {
    "BaseUrl": "https://zywave-api.example.com",
    "TokenUrl": "https://acehubtest.i-engineering.com/acehub/GetToken",
    "Credentials": {
      "ClientId": "YOUR_CLIENT_ID",
      "ClientSecret": "YOUR_CLIENT_SECRET"
    }
  }
}
```

### Running the Application

1. Navigate to the project directory:
```bash
cd WrapperAPI
```

2. Restore dependencies:
```bash
dotnet restore
```

3. Run the application:
```bash
dotnet run
```

The API will start on `https://localhost:5001` (HTTPS) and `http://localhost:5000` (HTTP).

## API Endpoints

### Dyed Service

#### Get Rate
```
POST /api/dyed/getrate
Content-Type: application/json

{
  "SignonRq": {
    "SignonPswd": {
      "CustId": {
        "CustLoginId": "SLBGROUP"
      }
    }
  },
  "InsuranceSvcRq": {
    "RqUID": "{{guid}}",
    "TRH_QuoteNo": "1424",
    "comTRH_CarrierRequestExt": {
      // Your request payload
    }
  }
}
```

#### Get Document
```
POST /api/dyed/getdocument
Content-Type: application/json

{
  // Your document request payload
}
```

### Herald Service

#### Get Quote
```
POST /api/herald/quote
Content-Type: application/json

{
  // Your quote request payload
}
```

#### Bind Policy
```
POST /api/herald/bind
Content-Type: application/json

{
  // Your bind request payload
}
```

### Zywave Service

#### Process Payment
```
POST /api/zywave/pay
Content-Type: application/json

{
  // Your payment request payload
}
```

## How It Works

### Authentication Flow

1. **Initial Request**: When you call any endpoint (e.g., `/api/dyed/getrate`), the service checks if a valid token exists in the cache.

2. **Token Fetch**: If no valid token exists:
   - The `AuthenticationService` calls the token endpoint for the specific service
   - Sends credentials (client_id and client_secret)
   - Receives JWT token with expiry time

3. **Token Caching**: The token is cached with an expiry time (1 minute before actual expiry to be safe)

4. **API Call**: The service uses the Bearer token to call the actual API endpoint

5. **Token Refresh**: When a token is about to expire, a new token is automatically fetched

### Thread Safety

The implementation uses `SemaphoreSlim` to ensure that only one thread fetches a new token at a time, preventing duplicate API calls during concurrent requests.

## Example Usage with Postman

### Step 1: Get Rate from Dyed

```http
POST https://localhost:5001/api/dyed/getrate
Content-Type: application/json

{
  "SignonRq": {
    "SignonPswd": {
      "CustId": {
        "CustLoginId": "SLBGROUP"
      }
    }
  },
  "InsuranceSvcRq": {
    "RqUID": "12345678-1234-1234-1234-123456789012",
    "TRH_QuoteNo": "1424",
    "comTRH_CarrierRequestExt": {}
  }
}
```

The wrapper will:
1. Fetch a token from `https://acehubtest.i-engineering.com/acehub/GetToken`
2. Use the token to call `https://acehubtest.i-engineering.com/acehub/GetRate`
3. Return the response to you

## Logging

The application includes comprehensive logging:
- Token fetch operations
- API calls to external services
- Errors and exceptions
- Token cache hits

Check the console output or configure file logging in `appsettings.json`.

## Error Handling

- **401 Unauthorized**: Returned when token fetch fails
- **500 Internal Server Error**: Returned for unexpected errors
- **Pass-through**: Other status codes from the external APIs are passed through

## Security Considerations

1. **Credentials**: Store credentials securely (use Azure Key Vault, AWS Secrets Manager, or environment variables in production)
2. **HTTPS**: Always use HTTPS in production
3. **Token Storage**: Tokens are stored in-memory only
4. **Logging**: Be careful not to log sensitive information

## Production Deployment

For production:

1. Move credentials to a secure secrets manager
2. Configure proper logging (Application Insights, Serilog, etc.)
3. Add health checks
4. Implement rate limiting
5. Add monitoring and alerting
6. Use distributed caching (Redis) for multi-instance deployments

## Extending the API

To add a new service:

1. Add configuration in `appsettings.json`
2. Create a service interface in `Services/`
3. Implement the service using the authentication service
4. Create a controller in `Controllers/`
5. Register the service in `Program.cs`

## Testing

You can use the included Swagger UI to test endpoints:
```
https://localhost:5001/swagger
```

## Troubleshooting

### Token Not Fetching
- Check credentials in `appsettings.json`
- Verify token URL is correct
- Check network connectivity

### API Calls Failing
- Verify the base URL for each service
- Check that tokens are being passed correctly
- Review logs for detailed error messages

## License

[Your License Here]
