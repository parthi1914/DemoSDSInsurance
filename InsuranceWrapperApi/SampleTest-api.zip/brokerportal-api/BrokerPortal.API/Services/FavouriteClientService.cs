﻿using AutoMapper;
using Azure;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;


namespace BrokerPortal.API.Services
{
    public class FavouriteClientService : IFavouriteClientService
    {
        private readonly IFavouriteClientRepository _repository;
  

        private readonly IMapper _mapper;
        public FavouriteClientService(IFavouriteClientRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
            
        }

        public async Task<List<FavouriteClientModel>> GetAllFavouriteClients()
        {
            List<FavouriteClientModel> response = new List<FavouriteClientModel>();
            List<FavouriteClient> entityList = await _repository.GetAllFavouriteClients();
            if (entityList == null || entityList.Count == 0)
                return null;

            response = _mapper.Map<List<FavouriteClientModel>>(entityList);
            return response;
        }

        public async Task<List<FavouriteClientModel>> GetUserFavouriteClients(string securityUserId)
        {
            List<FavouriteClientModel> response = new List<FavouriteClientModel>();
            List<FavouriteClient> entityList = await _repository.GetUserFavouriteClients(securityUserId);
            if (entityList == null || entityList.Count == 0)
                return null;

            response = _mapper.Map<List<FavouriteClientModel>>(entityList);
            return response;
        }

        public async Task<FavouriteClientModel> GetUserFavouriteClientById(string securityUserId, Guid favoriteClientId)
        {
            FavouriteClientModel response = new FavouriteClientModel();
            FavouriteClient entity = await _repository.GetUserFavouriteClientById(securityUserId, favoriteClientId);

            if (entity == null)
                return null;
            
            response = _mapper.Map<FavouriteClientModel>(entity);
            return response;
        }

        public async Task<FavouriteClientModel> SaveUserFavouriteClient(string securityUserId, FavouriteClientRequest favoriteClientRequest)
        {
            var sagittaClientId = Convert.ToInt64(favoriteClientRequest.SagittaClientId);
            FavouriteClientModel response = new FavouriteClientModel();
            FavouriteClient entity = new FavouriteClient();
            entity.FavouriteClientId = Guid.NewGuid();
            entity.SagittaClientId = sagittaClientId;
            entity.SecurityUserId = securityUserId;
            entity.CreatedBy = securityUserId;
            entity.CreatedDate = DateTime.Now;
            entity.IsDeleted = false;

            FavouriteClient? existingEntity = await _repository.GetUserFavouriteClientByClientId( securityUserId, sagittaClientId);
            if (existingEntity != null)
                return response;

            var exist = _repository.IsClientIdExists(sagittaClientId);
            if (exist)
            {
                var result = await _repository.SaveUserFavouriteClient(entity);
            }
            else
            {
                SagittaClient sagittaClient = new SagittaClient();
                sagittaClient.SagittaClientId = sagittaClientId;
                sagittaClient.ClientName = favoriteClientRequest.ClientName;
                sagittaClient.ClientCode = favoriteClientRequest.ClientCode;
                sagittaClient.ClientCity = favoriteClientRequest.City ?? null;
                sagittaClient.ClientState = favoriteClientRequest.State;
                sagittaClient.ClientContPersCode = favoriteClientRequest.ClientContPersCode??null;
                sagittaClient.ClientContPersEmail = favoriteClientRequest.ClientContPersEmail ?? null;
                sagittaClient.ClientContPersName = favoriteClientRequest.ClientContPersName??null;
                sagittaClient.ClientContPersPhone1 = favoriteClientRequest.ClientContPersPhone1 ?? null;
                sagittaClient.IsDatedOff = false;
                sagittaClient.IsSagSync = true;
                sagittaClient.LastSagSyncDate = DateTime.Now;
                sagittaClient.CreatedBy = securityUserId;
                sagittaClient.CreatedDate = DateTime.Now;

                await _repository.AddSagittaClient(sagittaClient);
                var result = await _repository.SaveUserFavouriteClient(entity);
            }
           
            response = _mapper.Map<FavouriteClientModel>(entity);
            return response;
        }

        public async Task<FavouriteClientModel> UpdateUserFavouriteClient(string securityUserId, Guid favoriteClientId, FavouriteClientRequest favoriteClientRequest)
        {
            FavouriteClientModel response = new FavouriteClientModel();
            FavouriteClient entity = new FavouriteClient();
            entity.FavouriteClientId = favoriteClientId;
            entity.UpdatedBy = securityUserId;
            entity.UpdatedDate = DateTime.Now;
            entity.IsDeleted = true;

            var result = await _repository.UpdateUserFavouriteClient(entity);
            response = _mapper.Map<FavouriteClientModel>(entity);
            return response;
        }
    }
}
