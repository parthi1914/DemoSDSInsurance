﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Utilities;


namespace BrokerPortal.API.Services
{
    public class SagittaPolicyService : ISagittaPolicyService
    {
        private readonly ISagittaPolicyRepository _repository;
        private readonly IMapper _mapper;

        public SagittaPolicyService(ISagittaPolicyRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public List<SagittaPolicyModel> GetSagittaPoliciesByStrategyId(Guid? strategyId)
        {
            List<SagittaPolicy> policyList = _repository.GetSagittaPoliciesByStrategyId(strategyId);
            var policyListResponse = _mapper.Map<List<SagittaPolicyModel>>(policyList);
            return policyListResponse;
        }

        public List<SagittaPolicyModel> BulkMergeSagittaPolicies(string? securityUserId, List<SagittaPolicyModelRequest> sagittaPolicyRequests)
        {
            List<SagittaPolicyModel> mergeResponse = null;

            List<SagittaPolicy> syncSagittaPolicyEntityList = new List<SagittaPolicy>();
            List<long?> sagittaPolicyIds = new List<long?>();
            bool isAnySagittaPolicyAlreadyExists = false;

            if (sagittaPolicyRequests != null && sagittaPolicyRequests.Count > 0)
            {
                sagittaPolicyIds = sagittaPolicyRequests.Select(x => x.SagittaPolicyId).ToList();

                List<SagittaPolicy> existingSagittaPolicyEntityList = _repository.GetSagittaPoliciesByIds(sagittaPolicyIds.ToArray());
                if (existingSagittaPolicyEntityList != null && existingSagittaPolicyEntityList.Count > 0)
                    isAnySagittaPolicyAlreadyExists = true;

                foreach (var sagittaPolicyRequest in sagittaPolicyRequests)
                {
                    SagittaPolicy? existingSagittaPolicyEntity = null;
                    if (isAnySagittaPolicyAlreadyExists)
                        existingSagittaPolicyEntity = existingSagittaPolicyEntityList.FirstOrDefault(x => x.SagittaPolicyId.Equals(sagittaPolicyRequest.SagittaPolicyId));

                    existingSagittaPolicyEntity = BuildUpsertSagittaPolicyEntity(sagittaPolicyRequest, existingSagittaPolicyEntity, isAnySagittaPolicyAlreadyExists, securityUserId);
                    if (existingSagittaPolicyEntity != null)
                        syncSagittaPolicyEntityList.Add(existingSagittaPolicyEntity);
                }
            }

            if (syncSagittaPolicyEntityList != null && syncSagittaPolicyEntityList.Count > 0)
                _repository.BulkMerge(syncSagittaPolicyEntityList);
            mergeResponse = _mapper.Map<List<SagittaPolicyModel>>(syncSagittaPolicyEntityList);

            return mergeResponse;
        }


        public async Task MergeSagittaPolicy(string? securityUserId, SagittaPolicyModelRequest sagittaPolicyRequest)
        {
            SagittaPolicyModel mergeResponse = null;

            List<SagittaPolicy> syncSagittaPolicyEntityList = new List<SagittaPolicy>();
            List<long?> sagittaPolicyIds = new List<long?>();
            bool isAnySagittaPolicyAlreadyExists = false;

            if (sagittaPolicyRequest != null)
            {
                SagittaPolicy existingSagittaPolicyEntityList = await _repository.GetSagittaPoliciesRepository(sagittaPolicyRequest.SagittaPolicyId);

                    SagittaPolicy? existingSagittaPolicyEntity = null;

                    existingSagittaPolicyEntity = BuildUpsertSagittaPolicyEntity(sagittaPolicyRequest, existingSagittaPolicyEntity, isAnySagittaPolicyAlreadyExists, securityUserId);
                    if (existingSagittaPolicyEntity != null)
                        syncSagittaPolicyEntityList.Add(existingSagittaPolicyEntity);
                
            }

            if (syncSagittaPolicyEntityList != null && syncSagittaPolicyEntityList.Count > 0)
                _repository.BulkMerge(syncSagittaPolicyEntityList);
            //mergeResponse = _mapper.Map<SagittaPolicyModel>(syncSagittaPolicyEntityList.SingleOrDefault());

            //return mergeResponse;
        }

        public async Task<SagittaPolicyModel> SaveSagittaPolicy(string? securityUserId, SagittaPolicyModelRequest saveSagittaPolicyRequest)
        {

            bool isAnySagittaPolicyAlreadyExists = false;

            SagittaPolicy existingSagittaPolicyEntity = await _repository.GetSagittaPoliciesRepository(saveSagittaPolicyRequest.SagittaPolicyId);
            if (existingSagittaPolicyEntity != null)
            {
                isAnySagittaPolicyAlreadyExists = true;
            }
            SagittaPolicy? sagittaSaveEntity = BuildUpsertSagittaPolicyEntity(saveSagittaPolicyRequest, existingSagittaPolicyEntity, isAnySagittaPolicyAlreadyExists, securityUserId);
            await _repository.SaveSagittaEntity(sagittaSaveEntity);
            var sagittaPolicyResponse = _mapper.Map<SagittaPolicyModel>(sagittaSaveEntity);
            return sagittaPolicyResponse;
        }

        public async Task<SagittaPolicyModel> UpdateSagittaPolicy(string? securityUserId, SagittaPolicyModelRequest updateSagittaPolicyRequest)
        {
            bool isAnySagittaPolicyAlreadyExists = false;

            SagittaPolicy existingSagittaPolicyEntity = await _repository.GetSagittaPoliciesRepository(updateSagittaPolicyRequest.SagittaPolicyId);
            if (existingSagittaPolicyEntity != null)
            {
                isAnySagittaPolicyAlreadyExists = true;
            }
            SagittaPolicy? sagittaSaveEntity = BuildUpsertSagittaPolicyEntity(updateSagittaPolicyRequest, existingSagittaPolicyEntity, isAnySagittaPolicyAlreadyExists, securityUserId);
            await _repository.UpdateSagittaEntity(sagittaSaveEntity);
            var sagittaPolicyResponse = _mapper.Map<SagittaPolicyModel>(sagittaSaveEntity);
            return sagittaPolicyResponse;
        }


        #region PrivateMethods

        private bool IsAnyChangeDetectedSagittaPolicies(SagittaPolicyModelRequest sagittaPolicyRequest, SagittaPolicy? existingSagittaPolicyEntity)
        {
            if (!DataCompareUtility.IsEquals(sagittaPolicyRequest.PolicyNumber, existingSagittaPolicyEntity.PolicyNumber)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PolicyEffDate.Value, existingSagittaPolicyEntity.PolicyEffDate.Value)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PolicyExpDate, existingSagittaPolicyEntity.PolicyExpDate)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PolicyDescription, existingSagittaPolicyEntity.PolicyDescription)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PolicyType, existingSagittaPolicyEntity.PolicyType)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.NewRenew, existingSagittaPolicyEntity.NewRenew)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.CovId, existingSagittaPolicyEntity.CovId)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.CovCode, existingSagittaPolicyEntity.CovCode)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.InsurorId, existingSagittaPolicyEntity.InsurorId)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.InsurorCode, existingSagittaPolicyEntity.InsurorCode)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PayeeId, existingSagittaPolicyEntity.PayeeId)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PayeeCode, existingSagittaPolicyEntity.PayeeCode)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PayeeName, existingSagittaPolicyEntity.PayeeName)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Prod1Code, existingSagittaPolicyEntity.Prod1Code)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Prod2Code, existingSagittaPolicyEntity.Prod2Code)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Prod3Code, existingSagittaPolicyEntity.Prod3Code)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Prod1Name, existingSagittaPolicyEntity.Prod1Name)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Prod2Name, existingSagittaPolicyEntity.Prod2Name)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Prod3Name, existingSagittaPolicyEntity.Prod3Name)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Serv1Code, existingSagittaPolicyEntity.Serv1Code)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Serv2Code, existingSagittaPolicyEntity.Serv2Code)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Serv3Code, existingSagittaPolicyEntity.Serv3Code)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Serv1Name, existingSagittaPolicyEntity.Serv1Name)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Serv2Name, existingSagittaPolicyEntity.Serv2Name)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.Serv3Name, existingSagittaPolicyEntity.Serv3Name)

                 || !DataCompareUtility.IsEquals(sagittaPolicyRequest.PremiumAmt, existingSagittaPolicyEntity.PremiumAmt)
                  || !DataCompareUtility.IsEquals(sagittaPolicyRequest.CommissionAmt, existingSagittaPolicyEntity.CommissionAmt)

                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.MarketingRepId, existingSagittaPolicyEntity.MarketingRepId)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.MarketingRepCode, existingSagittaPolicyEntity.MarketingRepCode)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.MarketingRepName, existingSagittaPolicyEntity.MarketingRepName)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.AccountExecId, existingSagittaPolicyEntity.AccountExecId)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.AccountExecCode, existingSagittaPolicyEntity.AccountExecCode)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.AccountExecName, existingSagittaPolicyEntity.AccountExecName)

                 || !DataCompareUtility.IsEquals(sagittaPolicyRequest.IsActive, existingSagittaPolicyEntity.IsActive)
                || !DataCompareUtility.IsEquals(sagittaPolicyRequest.IsSagSync, existingSagittaPolicyEntity.IsSagSync)
                )
                return true;
            else
                return false;
        }


        private SagittaPolicy BuildUpsertSagittaPolicyEntity(SagittaPolicyModelRequest sagittaPolicyRequest, SagittaPolicy existingSagittaPolicyEntity, bool isAnySagittaPolicyAlreadyExists, string securityUserId)
        {
            bool isValidForDBChange = false;
            SagittaPolicy? syncSagittaPolicyEntity = null;


            if (existingSagittaPolicyEntity != null)
            {
                if (IsAnyChangeDetectedSagittaPolicies(sagittaPolicyRequest, existingSagittaPolicyEntity))
                {
                    isValidForDBChange = true;
                    syncSagittaPolicyEntity = existingSagittaPolicyEntity;
                    syncSagittaPolicyEntity.UpdatedBy = securityUserId;
                    syncSagittaPolicyEntity.UpdatedDate = DateTime.Now;
                }
            }
            else if (existingSagittaPolicyEntity == null)
            {
                isValidForDBChange = true;
                syncSagittaPolicyEntity = new SagittaPolicy();

                syncSagittaPolicyEntity.CreatedBy = securityUserId;
                syncSagittaPolicyEntity.CreatedDate = DateTime.Now;
            }
            if (isValidForDBChange)
            {
                syncSagittaPolicyEntity.SagittaPolicyId = sagittaPolicyRequest.SagittaPolicyId.Value;
                syncSagittaPolicyEntity.SagittaClientId = sagittaPolicyRequest.SagittaClientId.Value;
                syncSagittaPolicyEntity.PolicyNumber = string.IsNullOrEmpty(sagittaPolicyRequest.PolicyNumber) ? null : sagittaPolicyRequest.PolicyNumber;
                syncSagittaPolicyEntity.PolicyDescription = string.IsNullOrEmpty(sagittaPolicyRequest.PolicyDescription) ? null : sagittaPolicyRequest.PolicyDescription;
                syncSagittaPolicyEntity.PolicyEffDate = sagittaPolicyRequest.PolicyEffDate ?? null;
                syncSagittaPolicyEntity.PolicyExpDate = sagittaPolicyRequest.PolicyExpDate ?? null;
                syncSagittaPolicyEntity.PolicyType = string.IsNullOrEmpty(sagittaPolicyRequest.PolicyType) ? null : sagittaPolicyRequest.PolicyType;
                syncSagittaPolicyEntity.NewRenew = string.IsNullOrEmpty(sagittaPolicyRequest.NewRenew) ? null : sagittaPolicyRequest.NewRenew;
                syncSagittaPolicyEntity.CovId = sagittaPolicyRequest.CovId ?? null;

                syncSagittaPolicyEntity.CovCode = string.IsNullOrEmpty(sagittaPolicyRequest.CovCode) ? null : sagittaPolicyRequest.CovCode;
                syncSagittaPolicyEntity.InsurorId = sagittaPolicyRequest.InsurorId ?? null;

                syncSagittaPolicyEntity.InsurorCode = string.IsNullOrEmpty(sagittaPolicyRequest.InsurorCode) ? null : sagittaPolicyRequest.InsurorCode;
                syncSagittaPolicyEntity.PayeeId = string.IsNullOrEmpty(sagittaPolicyRequest.PayeeId) ? null : sagittaPolicyRequest.PayeeId;
                syncSagittaPolicyEntity.PayeeCode = string.IsNullOrEmpty(sagittaPolicyRequest.PayeeCode) ? null : sagittaPolicyRequest.PayeeCode;
                syncSagittaPolicyEntity.PayeeName = string.IsNullOrEmpty(sagittaPolicyRequest.PayeeName) ? null : sagittaPolicyRequest.PayeeName;
                syncSagittaPolicyEntity.Prod1Code = string.IsNullOrEmpty(sagittaPolicyRequest.Prod1Code) ? null : sagittaPolicyRequest.Prod1Code;
                syncSagittaPolicyEntity.Prod2Code = string.IsNullOrEmpty(sagittaPolicyRequest.Prod2Code) ? null : sagittaPolicyRequest.Prod2Code;

                syncSagittaPolicyEntity.Prod3Code = string.IsNullOrEmpty(sagittaPolicyRequest.Prod3Code) ? null : sagittaPolicyRequest.Prod3Code;
                syncSagittaPolicyEntity.Prod1Name = string.IsNullOrEmpty(sagittaPolicyRequest.Prod1Name) ? null : sagittaPolicyRequest.Prod1Name;
                syncSagittaPolicyEntity.Prod2Name = string.IsNullOrEmpty(sagittaPolicyRequest.Prod2Name) ? null : sagittaPolicyRequest.Prod2Name;
                syncSagittaPolicyEntity.Prod3Name = string.IsNullOrEmpty(sagittaPolicyRequest.Prod3Name) ? null : sagittaPolicyRequest.Prod3Name;
                syncSagittaPolicyEntity.Serv1Code = string.IsNullOrEmpty(sagittaPolicyRequest.Serv1Code) ? null : sagittaPolicyRequest.Serv1Code;
                syncSagittaPolicyEntity.Serv2Code = string.IsNullOrEmpty(sagittaPolicyRequest.Serv2Code) ? null : sagittaPolicyRequest.Serv2Code;
                syncSagittaPolicyEntity.Serv3Code = string.IsNullOrEmpty(sagittaPolicyRequest.Serv3Code) ? null : sagittaPolicyRequest.Serv3Code;

                syncSagittaPolicyEntity.Serv1Name = string.IsNullOrEmpty(sagittaPolicyRequest.Serv1Name) ? null : sagittaPolicyRequest.Serv1Name;
                syncSagittaPolicyEntity.Serv2Name = string.IsNullOrEmpty(sagittaPolicyRequest.Serv2Name) ? null : sagittaPolicyRequest.Serv2Name;
                syncSagittaPolicyEntity.Serv3Name = string.IsNullOrEmpty(sagittaPolicyRequest.Serv3Name) ? null : sagittaPolicyRequest.Serv3Name;

                syncSagittaPolicyEntity.PremiumAmt = sagittaPolicyRequest.PremiumAmt ?? null;
                syncSagittaPolicyEntity.CommissionAmt = sagittaPolicyRequest.CommissionAmt ?? null;
                syncSagittaPolicyEntity.IsActive = true;

                syncSagittaPolicyEntity.IsActive = true;
                syncSagittaPolicyEntity.IsSagSync = true;
                syncSagittaPolicyEntity.LastSagSyncDate = DateTime.Now;

                syncSagittaPolicyEntity.MarketingRepId = string.IsNullOrEmpty(sagittaPolicyRequest.MarketingRepId) ? null : sagittaPolicyRequest.MarketingRepId;
                syncSagittaPolicyEntity.MarketingRepCode = string.IsNullOrEmpty(sagittaPolicyRequest.MarketingRepCode) ? null : sagittaPolicyRequest.MarketingRepCode;
                syncSagittaPolicyEntity.MarketingRepName = string.IsNullOrEmpty(sagittaPolicyRequest.MarketingRepName) ? null : sagittaPolicyRequest.MarketingRepName;
                syncSagittaPolicyEntity.AccountExecId = string.IsNullOrEmpty(sagittaPolicyRequest.AccountExecId) ? null : sagittaPolicyRequest.AccountExecId;
                syncSagittaPolicyEntity.AccountExecCode = string.IsNullOrEmpty(sagittaPolicyRequest.AccountExecCode) ? null : sagittaPolicyRequest.AccountExecCode;
                syncSagittaPolicyEntity.AccountExecName = string.IsNullOrEmpty(sagittaPolicyRequest.AccountExecName) ? null : sagittaPolicyRequest.AccountExecName;

                //syncSagittaPolicyEntityList.Add(syncSagittaPolicyEntity);
            }

            return syncSagittaPolicyEntity;
        }
        #endregion

    }
}