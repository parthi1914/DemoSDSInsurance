﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.Services
{
    public class StrategyService : IStrategyService
    {

        private readonly IStrategyRepository _repository;
        private readonly ISagittaStaffRepository _sagittaStaffRepository;
        private readonly ILookupDataRepository _lookupDataRepository;
        private readonly ITaskStackRepository _taskStackRepository;
        private readonly IMarketRepository _marketRepository;
        private readonly ISecurityUserRepository _securityUserRepository;
        private readonly IMapper _mapper;
        public StrategyService(IStrategyRepository strategyRepository, ISagittaStaffRepository sagittaStaffRepository,
            ILookupDataRepository lookupDataRepository, ITaskStackRepository taskStackRepository, IMarketRepository marketRepository,
            ISecurityUserRepository securityUserRepository, IMapper mapper)
        {
            _repository = strategyRepository;
            _sagittaStaffRepository = sagittaStaffRepository;
            _lookupDataRepository = lookupDataRepository;
            _taskStackRepository = taskStackRepository;
            _marketRepository = marketRepository;
            _securityUserRepository = securityUserRepository;
            _mapper = mapper;
        }

        public async Task<List<StrategyModel>> GetAllStrategies()
        {
            List<Strategy> strategies = await _repository.GetAllStrategies();
            var strategyResponseList = _mapper.Map<List<StrategyModel>>(strategies);
            return strategyResponseList;
        }

        public async Task<StrategyModel> GetStrategyById(Guid? strategyId, bool includeMarkets)
        {
            StrategyModel strategyResponse = null;
            if (strategyId != Guid.Empty)
            {
                var strategy = await _repository.GetStrategyById(strategyId, includeMarkets);
                if (strategy != null)
                {
                    strategy.Markets = _marketRepository.GetAllMarketByStrategy(strategyId);
                    strategyResponse = _mapper.Map<StrategyModel>(strategy);
                    MapStepTimelinesStaffAssignmentByStrategy(strategyResponse, includeMarkets);
                }
            }

            return strategyResponse;
        }

        public async Task<StrategyModel> GetStrategyByPlanId(Guid planId)
        {
            StrategyModel strategyResponse = null;
            Guid? strategyId = await _repository.GetStrategyIdByPlanId(planId);
            if (strategyId != Guid.Empty)
                strategyResponse = await GetStrategyById(strategyId, true);
            return strategyResponse;
        }

        public async Task<StrategyModel> SaveStrategy(StrategyRequest strategy)
        {
            StrategyModel strategyResponse = null;
            string? securityUserId = strategy.SecurityUsers.SecurityUserId;
            DateTime currentDateTime = DateTime.Now;

            Strategy strategyEntity = BuildNewStrategy(securityUserId, currentDateTime, strategy);
            await _repository.SaveStrategy(strategyEntity);

            strategyResponse = await GetStrategyById(strategyEntity.StrategyId, true);
            return strategyResponse;
        }

        public async Task<StrategyModel> UpdateStrategy(Guid strategyId, StrategyRequest strategyUpdateRequest)
        {
            StrategyModel strategyResponse = null;

            string? securityUserId = strategyUpdateRequest.SecurityUsers.SecurityUserId;
            DateTime currentDateTime = DateTime.Now;
            Strategy? existingStrategyEntity = await _repository.GetStrategyForUpdate(strategyId);

            if (existingStrategyEntity != null && existingStrategyEntity.StrategyId != Guid.Empty
                && strategyUpdateRequest != null)
            {
                existingStrategyEntity = BuildUpdateStrategy(securityUserId, currentDateTime,
                    existingStrategyEntity, strategyUpdateRequest);
                await _repository.TrackStrategyChanges(existingStrategyEntity);
                await _repository.UpdateStrategy(existingStrategyEntity);
            }

            strategyResponse = await GetStrategyById(existingStrategyEntity.StrategyId, true);
            return strategyResponse;
        }

        public async Task<List<StrategyTimelineModel>> UpdateStrategyTimelines(Guid? strategyId, string? securityUserId,
            List<StrategyTimelinesRequest> strategyTimelineUpdateRequests)
        {
            List<StrategyTimelineModel> response = new List<StrategyTimelineModel>();

            //NEED TO UPDATE STRATEGY TIMELINES ASSIGNMENT DUE DATE
            //NEED TO UPDATE MARKET TIMELINES ASSIGNMENT DUE DATE IF EXIST
            //NEED TO UPDATE STRATEGY AND MARKETS TASKS ASSIGNMENT DUE DATE IF EXISTS
            DateTime currentDateTime = DateTime.Now;
            Strategy? existingStrategyEntity = await _repository.GetStrategyForUpdate(strategyId);

            if (existingStrategyEntity != null)
            {
                existingStrategyEntity.StrategyTimelines =
                BuildUpdateStrategyTimelines(securityUserId, currentDateTime, true,
                        existingStrategyEntity.StrategyTimelines.ToList(), strategyTimelineUpdateRequests);

                if (existingStrategyEntity.StrategyTimelines != null && existingStrategyEntity.StrategyTimelines.Count > 0)
                {
                    existingStrategyEntity.UpdatedBy = securityUserId;
                    existingStrategyEntity.UpdatedDate = currentDateTime;
                    existingStrategyEntity.Version = existingStrategyEntity.Version + 1;
                    await _repository.TrackStrategyChanges(existingStrategyEntity);
                    await _repository.UpdateStrategy(existingStrategyEntity);
                    response = _mapper.Map<List<StrategyTimelineModel>>(existingStrategyEntity.StrategyTimelines);
                }
            }

            return response;
        }
        public async Task<bool> RemoveStrategy(Guid strategyId, string securityUserId)
        {
            return await _repository.RemoveStrategy(strategyId, securityUserId);
        }
        public async Task<bool> ArchiveStrategy(Guid strategyId, string securityUserId)
        {
            return await _repository.ArchiveStrategy(strategyId, securityUserId);
        }
        public async Task<bool> SyncStrategyForMarkets(Guid strategyId, string securityUserId)
        {
            Strategy? strategyEntity = await _repository.GetStrategyForUpdateToSyncMarketChanges(strategyId);
            List<Market>? marketEntityList = await _marketRepository.GetMarketsForStrategySyncByStrategy(strategyEntity.StrategyId);
            List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
            List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
            List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
            List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

            if (strategyEntity != null)
            {
                strategyEntity =
                BuildSyncStrategyForMarketUpdates(securityUserId, strategyEntity, marketEntityList,
                                                    allStepDefList, allSubStepDefList,
                                                    allStepStatusCodes, allTaskStatusCodes);
                await _repository.TrackStrategyChanges(strategyEntity);
                await _repository.UpdateStrategy(strategyEntity);
            }

            return true;
        }
        public async Task<List<StrategyModel>> SearchStrategies(SearchBaseFilterType baseFilterType, StrategySearchType searchType,
            StrategySearchCriterias searchCriterias, string? securityUserId, string? sagittaClientId)
        {

            List<StrategyModel> strategyResponseList = new List<StrategyModel>();
            string[]? strategyStatusCodes = searchCriterias.strategyStatusCodes?.Select(s => s.ToUpperInvariant()).ToArray();

            List<string>? mapUserSagStaffIds = null;
            if (!string.IsNullOrEmpty(securityUserId))
                mapUserSagStaffIds =
                    await _securityUserRepository.GetSecurityUserMapExternalSystemUserIds(securityUserId, AppConstants.EXTERNAL_SYS_SAGITTA);
            string[] sagittaStaffIds = mapUserSagStaffIds != null ? mapUserSagStaffIds.ToArray() : null;

            if (strategyStatusCodes != null)
            {
                if (strategyStatusCodes.Contains(AppConstants.OPTION_ALL))
                    searchCriterias.strategyStatusCodes = _lookupDataRepository.GetAllBPStatusCodesIds().ToArray();

                if (strategyStatusCodes.Contains(AppConstants.STEP_STATUSGROUPCODE_ACTIVE))
                    searchCriterias.strategyStatusCodes = _lookupDataRepository.GetAllBPStatusCodesIdsByGroupCode(AppConstants.STEP_STATUSGROUPCODE_ACTIVE).ToArray();

                if (strategyStatusCodes.Contains(AppConstants.STEP_STATUSGROUPCODE_COMPLETED))
                    searchCriterias.strategyStatusCodes = _lookupDataRepository.GetAllBPStatusCodesIdsByGroupCode(AppConstants.STEP_STATUSGROUPCODE_COMPLETED).ToArray();
            }
            else
            {
                //DEFAULT ACTIVE ONLY
                searchCriterias.strategyStatusCodes = _lookupDataRepository.GetAllBPStatusCodesIdsByGroupCode(AppConstants.STEP_STATUSGROUPCODE_ACTIVE).ToArray();
            }

            List<Strategy>? StrategyEntityList = await _repository.SearchStrategies(baseFilterType, searchType, searchCriterias, securityUserId, sagittaStaffIds, sagittaClientId);

            if (StrategyEntityList != null && StrategyEntityList.Count > 0)
            {
                List<Guid> strategyIds = StrategyEntityList.Select(x => x.StrategyId).ToList();
                List<Market>? marketEntityListByStrategies = _marketRepository.GetAllMarketByStrategies(strategyIds);

                MapStrategyAndMarkets(StrategyEntityList, marketEntityListByStrategies);
                strategyResponseList = _mapper.Map<List<StrategyModel>>(StrategyEntityList);
                MapStepTimelinesStaffAssignmentByStrategyList(strategyResponseList, true);
                AssignAccessAndAnalyticsByStrategyList(securityUserId, mapUserSagStaffIds, strategyResponseList);
            }
            return strategyResponseList;
        }
        public async Task<string?> GetStrategyClientId(Guid? strategyId)
        {
            return await _repository.GetStrategyClientId(strategyId);
        }
        public async Task<List<StrategyTimelineModel>> GetStrategyTimelines(Guid? strategyId)
        {
            List<StrategyTimeline> strategyTimelineEntityList = await _repository.GetStrategyTimelines(strategyId);
            var strategyTimelineResponseList = _mapper.Map<List<StrategyTimelineModel>>(strategyTimelineEntityList);
            return strategyTimelineResponseList;
        }

        #region PRIVATE

        #region NEW STRATEGY RELATED
        private Strategy BuildNewStrategy(string? securityUserId, DateTime currentDateTime, StrategyRequest strategyRequest)
        {
            Strategy strategyEntity = new Strategy();
            strategyEntity.PlanId = strategyRequest.PlanId;
            strategyEntity.StrategyId = Guid.NewGuid();
            strategyEntity.StrategyName = strategyRequest.StrategyName;
            strategyEntity.StrategyEffDate = strategyRequest.StrategyEffDate;
            strategyEntity.CreatedDate = currentDateTime;
            strategyEntity.CreatedBy = securityUserId;
            strategyEntity.IsDeleted = false;
            strategyEntity.StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE;
            strategyEntity.Version = 1;


            List<StrategyClient> strategyClientEntityList = new List<StrategyClient>();
            StrategyClient strategyClientEntity = new StrategyClient();
            strategyClientEntity.StrategyId = strategyEntity.StrategyId;
            strategyClientEntity.StratgeyClientId = Guid.NewGuid();
            strategyClientEntity.SagittaClientId = strategyRequest.SagittaClientId;
            strategyClientEntity.CreatedBy = securityUserId;
            strategyClientEntity.CreatedDate = currentDateTime;
            strategyClientEntity.IsDeleted = false;
            strategyClientEntity.Version = 1;
            strategyClientEntityList.Add(strategyClientEntity);
            strategyEntity.StrategyClients = strategyClientEntityList;

            strategyEntity.StrategyTimelines =
                BuildNewStrategyTimelines(securityUserId, currentDateTime, strategyEntity.StrategyId, strategyRequest.StrategyTimelines?.ToList());

            List<StrategyTaskMeta> strategyTaskEntityList =
                BuildNewStrategyTaskMetas(securityUserId, currentDateTime, strategyEntity.PlanId, strategyEntity.StrategyId,
                    strategyRequest.SagittaClientId, strategyEntity.StrategyTimelines.ToList());
            strategyEntity.StrategyTaskMeta = strategyTaskEntityList;

            strategyEntity.StrategyStaffs = null;
            return strategyEntity;
        }
        private List<StrategyTimeline> BuildNewStrategyTimelines(string? securityUserId, DateTime currentDateTime, Guid strategyId, List<StrategyTimelinesRequest>? strategyTimelineRequestList)
        {
            List<StrategyTimeline> strategyTimelineEntityList = new List<StrategyTimeline>();
            foreach (var strategyTimelineRequest in strategyTimelineRequestList)
            {

                StrategyTimeline strategyTimelineEntity = new StrategyTimeline();
                strategyTimelineEntity.StrategyTimelineId = Guid.NewGuid();
                strategyTimelineEntity.StrategyId = strategyId;
                strategyTimelineEntity.StepDefId = strategyTimelineRequest.StepDefId;
                strategyTimelineEntity.DueDate = strategyTimelineRequest.DueDate;
                strategyTimelineEntity.CreatedDate = currentDateTime;
                strategyTimelineEntity.CreatedBy = securityUserId;
                strategyTimelineEntity.LastStepStatusUpdatedBy = securityUserId;
                strategyTimelineEntity.LastStepStatusUpdatedDate = currentDateTime;
                if (strategyTimelineRequest.StepDefId.Equals(AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION))
                    strategyTimelineEntity.StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE;
                else
                    strategyTimelineEntity.StatusCodeId = AppConstants.STEP_STATUSCODE_INITIALIZE;
                strategyTimelineEntity.IsDeleted = false;
                strategyTimelineEntity.Version = 1;
                strategyTimelineEntityList.Add(strategyTimelineEntity);
            }
            return strategyTimelineEntityList;
        }

        private List<StrategyTaskMeta> BuildNewStrategyTaskMetas(string? securityUserId, DateTime currentDateTime,
            Guid planId, Guid strategyId, long sagittaClientId, List<StrategyTimeline>? strategyTimelineEntityList)
        {

            List<StepDef> stepDefs = _lookupDataRepository.GetAllStepDefsByFlowDef(AppConstants.FLOWDEF_STRATEGY);
            List<StrategyTaskMeta> strategyTaskEntityList = new List<StrategyTaskMeta>();

            foreach (StrategyTimeline strategyTimelineEntity in strategyTimelineEntityList)
            {
                string stepDefId = strategyTimelineEntity.StepDefId;
                string stepName = stepDefs.FirstOrDefault(x => x.StepDefId.Equals(stepDefId)).StepName;
                DateTime? taskDueDate = strategyTimelineEntity.AssignmentDueDate ?? strategyTimelineEntity.DueDate;

                StrategyTaskMeta strategyTaskEntity = new StrategyTaskMeta();
                strategyTaskEntity.StrategyTaskId = Guid.NewGuid();
                strategyTaskEntity.StrategyId = strategyId;
                strategyTaskEntity.StrategyTimelineId = strategyTimelineEntity.StrategyTimelineId;
                strategyTaskEntity.IsDeleted = false;
                strategyTaskEntity.CreatedBy = AppConstants.SYSTEM_USER_ID;
                strategyTaskEntity.CreatedDate = currentDateTime;

                TaskStack taskStackEntity =
                    BuildStrategyTimelineNewTaskAndSteps(securityUserId, currentDateTime, planId, strategyId, strategyTimelineEntity, stepDefs);

                strategyTaskEntity.TaskStackId = taskStackEntity.TaskStackId;
                strategyTaskEntity.TaskStack = taskStackEntity;

                strategyTaskEntityList.Add(strategyTaskEntity);
            }
            return strategyTaskEntityList;
        }

        private TaskStack BuildStrategyTimelineNewTaskAndSteps(string securityUserId, DateTime currentDateTime,
            Guid planId, Guid strategyId, StrategyTimeline strategyTimelineEntity, List<StepDef> stepDefs)
        {
            string stepDefId = strategyTimelineEntity.StepDefId;
            string stepName = stepDefs.FirstOrDefault(x => x.StepDefId.Equals(stepDefId)).StepName;
            DateTime? taskDueDate = strategyTimelineEntity.AssignmentDueDate ?? strategyTimelineEntity.DueDate;

            TaskStack taskStackEntity = new TaskStack();
            taskStackEntity.TaskStackId = Guid.NewGuid();
            taskStackEntity.ParentTaskStackId = null;
            taskStackEntity.TaskRefType = nameof(TaskRefType.STRATEGY);
            taskStackEntity.TaskRefKey = Convert.ToString(strategyId)?.ToUpper();
            taskStackEntity.TaskDueDate = taskDueDate;
            taskStackEntity.TaskFollowUpDate = taskDueDate;
            taskStackEntity.TaskName = stepName;
            taskStackEntity.TaskDesc = stepName;
            taskStackEntity.TaskSender = securityUserId;
            taskStackEntity.TaskProirity = AppConstants.TASK_PRIORITY_DEFAULT;
            taskStackEntity.TaskNotes = null;
            taskStackEntity.TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN;
            taskStackEntity.TaskSendDate = currentDateTime;
            taskStackEntity.TaskStatusReason = null;
            taskStackEntity.CreatedBy = AppConstants.SYSTEM_USER_ID;
            taskStackEntity.CreatedDate = currentDateTime;
            taskStackEntity.IsDeleted = false;
            taskStackEntity.IsSysGen = true;
            taskStackEntity.LastTaskStatusUpdatedDate = currentDateTime;
            taskStackEntity.LastTaskStatusUpdatedBy = securityUserId;
            taskStackEntity.Version = 1;

            //Add Task Step
            List<TaskStep> taskSteps = new List<TaskStep>();
            TaskStep taskStep = new TaskStep();
            taskStep.TaskStepId = Guid.NewGuid();
            taskStep.TaskStackId = taskStackEntity.TaskStackId;
            taskStep.StepDefId = stepDefId;
            taskStep.StatusCodeId = strategyTimelineEntity.StatusCodeId;
            taskStep.StatusCode = strategyTimelineEntity.StatusCode;
            taskStep.TaskStepRefType = nameof(TaskStepRefType.STRATEGY_TIMELINE);
            taskStep.TaskStepRefKey = Convert.ToString(strategyTimelineEntity.StrategyTimelineId)?.ToUpper();
            taskStep.CreatedBy = AppConstants.SYSTEM_USER_ID;
            taskStep.CreatedDate = currentDateTime;
            taskStep.IsDeleted = false;
            taskStep.LastStepStatusUpdatedDate = currentDateTime;
            taskStep.LastStepStatusUpdatedBy = securityUserId;
            taskStep.Version = 1;
            taskSteps.Add(taskStep);
            taskStackEntity.TaskSteps = taskSteps;

            //Add Task Meta
            TaskMeta taskMetaEntity = new TaskMeta();
            taskMetaEntity.TaskMetaId = Guid.NewGuid();
            taskMetaEntity.TaskStackId = taskStackEntity.TaskStackId;
            taskMetaEntity.PlanId = planId;
            taskMetaEntity.StrategyId = strategyId;
            taskMetaEntity.StrategyTimelineId = strategyTimelineEntity.StrategyTimelineId;
            taskMetaEntity.CreatedBy = AppConstants.SYSTEM_USER_ID;
            taskMetaEntity.CreatedDate = currentDateTime;
            taskMetaEntity.IsDeleted = false;
            taskMetaEntity.Version = 1;
            taskStackEntity.TaskMeta.Add(taskMetaEntity);
            return taskStackEntity;
        }
        #endregion

        #region UPDATE STRATEGY RELATED
        private Strategy BuildUpdateStrategy(string? securityUserId, DateTime currentDateTime,
            Strategy existingStrategyEntity, StrategyRequest strategyUpdateRequest)
        {
            existingStrategyEntity.StrategyName = strategyUpdateRequest.StrategyName;
            existingStrategyEntity.StrategyEffDate = strategyUpdateRequest.StrategyEffDate;
            existingStrategyEntity.UpdatedBy = securityUserId;
            existingStrategyEntity.UpdatedDate = currentDateTime;
            existingStrategyEntity.Version = existingStrategyEntity.Version + 1;

            foreach (var existingStrategyClientEntity in existingStrategyEntity.StrategyClients)
            {
                if (!existingStrategyClientEntity.SagittaClientId.Equals(strategyUpdateRequest.SagittaClientId))
                {
                    existingStrategyClientEntity.SagittaClientId = strategyUpdateRequest.SagittaClientId;
                    existingStrategyClientEntity.UpdatedBy = securityUserId;
                    existingStrategyClientEntity.UpdatedDate = currentDateTime;
                    existingStrategyClientEntity.Version = existingStrategyClientEntity.Version + 1;
                }
            }

            existingStrategyEntity.StrategyTimelines =
                BuildUpdateStrategyTimelines(securityUserId, currentDateTime, false,
                        existingStrategyEntity.StrategyTimelines.ToList(), strategyUpdateRequest.StrategyTimelines.ToList());

            return existingStrategyEntity;
        }

        private List<StrategyTimeline> BuildUpdateStrategyTimelines(string? securityUserId, DateTime currentDateTime, bool isReqUpdateAssignmentDueDate,
            List<StrategyTimeline> existingStrategyTimelineEntityList, List<StrategyTimelinesRequest>? strategyTimelineUpdateRequestList)
        {
            foreach (var existingStrategyTimelineEntity in existingStrategyTimelineEntityList)
            {
                StrategyTimelinesRequest? strategyTimelineUpdateRequest =
                    strategyTimelineUpdateRequestList
                        .Where(x => x.StrategyTimelineId.Equals(existingStrategyTimelineEntity.StrategyTimelineId))
                        .FirstOrDefault();

                if (strategyTimelineUpdateRequest != null)
                {
                    bool isTimelineHasUpdate = false;

                    if (!existingStrategyTimelineEntity.DueDate.Equals(strategyTimelineUpdateRequest?.DueDate))
                    {
                        isTimelineHasUpdate = true;
                        existingStrategyTimelineEntity.DueDate = strategyTimelineUpdateRequest?.DueDate;
                    }

                    if (isReqUpdateAssignmentDueDate)
                    {
                        if (existingStrategyTimelineEntity.AssignmentDueDate == null
                            || !existingStrategyTimelineEntity.AssignmentDueDate.Equals(strategyTimelineUpdateRequest?.AssignmentDueDate))
                        {
                            isTimelineHasUpdate = true;
                            existingStrategyTimelineEntity.AssignmentDueDate = strategyTimelineUpdateRequest?.AssignmentDueDate;

                            foreach (var strategyTaskMeta in existingStrategyTimelineEntity.StrategyTaskMeta)
                            {
                                strategyTaskMeta.TaskStack.TaskDueDate = strategyTimelineUpdateRequest?.AssignmentDueDate;
                                strategyTaskMeta.TaskStack.UpdatedBy = securityUserId;
                                strategyTaskMeta.TaskStack.UpdatedDate = currentDateTime;
                                strategyTaskMeta.TaskStack.Version = strategyTaskMeta.TaskStack.Version + 1;
                            }

                            foreach (var existingMarketTimelineEntity in existingStrategyTimelineEntity.MarketTimelines)
                            {
                                existingMarketTimelineEntity.AssignmentDueDate = strategyTimelineUpdateRequest?.AssignmentDueDate;
                                existingMarketTimelineEntity.UpdatedBy = securityUserId;
                                existingMarketTimelineEntity.UpdatedDate = currentDateTime;
                            }
                        }
                    }

                    if (isTimelineHasUpdate)
                    {
                        existingStrategyTimelineEntity.UpdatedBy = securityUserId;
                        existingStrategyTimelineEntity.UpdatedDate = currentDateTime;
                        existingStrategyTimelineEntity.StatusCode = null;
                        existingStrategyTimelineEntity.Version = existingStrategyTimelineEntity.Version + 1;
                    }
                }
            }
            return existingStrategyTimelineEntityList;
        }
        #endregion

        #region RELATED TO STRATEGY SYNC FOR MARKETS 
        private Strategy BuildSyncStrategyForMarketUpdates(string? securityUserId, Strategy? strategyEntity, List<Market>? marketEntityList,
            List<StepDef> allStepDefList, List<SubStepDef> allSubStepDefList,
            List<BpstatusCode> allStepStatusCodes, List<TaskStatusCode> allTaskStatusCodes)
        {
            List<StrategyTimeline>? updatedStrategyTimelineEntityList = new List<StrategyTimeline>();
            List<StrategyTimeline>? strategyTimelineEntityList = strategyEntity?.StrategyTimelines?.ToList();
            List<StrategyTaskMeta> strategyTaskEntityList = strategyEntity?.StrategyTaskMeta?.ToList();
            bool isStrategyCompleted = true;
            //IF ANY MARKET EXIST(NON REMOVED)
            //    FOR EACH Step
            //            GET: 	ALL MARKETS (TIMELINES) IN Looped Step
            //                CHECK IF ATLEAST ONE MARKET GROUP CODE IS ACTIVE
            //                    IF YES -STRATEGY STEP: ACTIVE ELSE COMPLETED
            //ELSE
            //    RESET STRATEGY TIMELINES IF NOT ALREADY IN RESET STATE
            foreach (var stepDefEntity in allStepDefList)
            {
                StrategyTimeline? stepLevelStrategyTimeline =
                    strategyTimelineEntityList.Where(x => x.StepDefId.Equals(stepDefEntity.StepDefId)).FirstOrDefault();

                string strategyTimelineEvalStatusCodeId =
                    evaluateStepLevelStrategyTimelineStatusByMarketTimelines(allStepStatusCodes, allStepDefList,
                            stepDefEntity, marketEntityList);

                if (!strategyTimelineEvalStatusCodeId.Equals(nameof(GenericStatusCodes.COMP)))
                    isStrategyCompleted = false;

                if (!DataCompareUtility.IsEquals(stepLevelStrategyTimeline?.StatusCodeId, strategyTimelineEvalStatusCodeId))
                {
                    BpstatusCode? strategyTimelPrevStatusCodeEntity = allStepStatusCodes
                        .Where(x => x.StatusCodeId.Equals(stepLevelStrategyTimeline.StatusCodeId)).SingleOrDefault();
                    BpstatusCode? strategyTimelCurrStatusCodeEntity = allStepStatusCodes
                        .Where(x => x.StatusCodeId.Equals(strategyTimelineEvalStatusCodeId)).SingleOrDefault();

                    stepLevelStrategyTimeline.PrevStatusCodeId = stepLevelStrategyTimeline.StatusCodeId;
                    stepLevelStrategyTimeline.PrevStatusCode = strategyTimelPrevStatusCodeEntity;
                    stepLevelStrategyTimeline.StatusCodeId = strategyTimelineEvalStatusCodeId;
                    stepLevelStrategyTimeline.StatusCode = strategyTimelCurrStatusCodeEntity;
                    stepLevelStrategyTimeline.Version = stepLevelStrategyTimeline.Version + 1;
                    stepLevelStrategyTimeline.LastStepStatusUpdatedDate = DateTime.Now;
                    stepLevelStrategyTimeline.LastStepStatusUpdatedBy = securityUserId;

                    stepLevelStrategyTimeline.StrategyTaskMeta =
                   BuildSyncStrategyTaskEntityByStepStatus(securityUserId, strategyEntity,
                       allStepStatusCodes, allTaskStatusCodes, stepLevelStrategyTimeline);

                }
                updatedStrategyTimelineEntityList.Add(stepLevelStrategyTimeline);
            }
            strategyEntity.StrategyTimelines = updatedStrategyTimelineEntityList;

            if (isStrategyCompleted)
            {
                //IF NOT COMPLETED THEN MARK COMPLETE
                if (!DataCompareUtility.IsEquals(strategyEntity?.StatusCodeId, nameof(GenericStatusCodes.COMP)))
                {
                    BpstatusCode? strategyPrevStatusCodeEntity = allStepStatusCodes
                        .Where(x => x.StatusCodeId.Equals(strategyEntity?.StatusCodeId)).SingleOrDefault();
                    BpstatusCode? strategyCurrStatusCodeEntity = allStepStatusCodes
                        .Where(x => x.StatusCodeId.Equals(nameof(GenericStatusCodes.COMP))).SingleOrDefault();

                    strategyEntity.PrevStatusCodeId = strategyEntity.StatusCodeId;
                    strategyEntity.PrevStatusCode = strategyPrevStatusCodeEntity;
                    strategyEntity.StatusCodeId = nameof(GenericStatusCodes.COMP);
                    strategyEntity.StatusCode = strategyCurrStatusCodeEntity;
                }
            }
            else
            {
                //IF ALREADY COMPLETED THEN REACTIVATE STRATEGY
                BpstatusCode? strategyStatusCodeEntity = allStepStatusCodes
                       .Where(x => x.StatusCodeId.Equals(strategyEntity?.StatusCodeId)).SingleOrDefault();

                if (!strategyStatusCodeEntity.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.ACTI)))
                {
                    BpstatusCode? strategyPrevStatusCodeEntity = allStepStatusCodes
                        .Where(x => x.StatusCodeId.Equals(strategyEntity?.StatusCodeId)).SingleOrDefault();
                    BpstatusCode? strategyCurrStatusCodeEntity = allStepStatusCodes
                        .Where(x => x.StatusCodeId.Equals(nameof(GenericStatusCodes.ACTI))).SingleOrDefault();

                    strategyEntity.PrevStatusCodeId = strategyEntity.StatusCodeId;
                    strategyEntity.PrevStatusCode = strategyPrevStatusCodeEntity;
                    strategyEntity.StatusCodeId = nameof(GenericStatusCodes.COMP);
                    strategyEntity.StatusCode = strategyCurrStatusCodeEntity;
                }
            }
            strategyEntity.UpdatedBy = securityUserId;
            strategyEntity.UpdatedDate = DateTime.Now;
            strategyEntity.Version = strategyEntity.Version + 1;

            return strategyEntity;
        }
        private List<StrategyTaskMeta> BuildSyncStrategyTaskEntityByStepStatus(string? securityUserId, Strategy? strategyEntity,
            List<BpstatusCode> allStepStatusCodes, List<TaskStatusCode> allTaskStatusCodes,
            StrategyTimeline? stepLevelStrategyTimeline)
        {
            List<StrategyTaskMeta> existingStrategyTaskEntityList = stepLevelStrategyTimeline.StrategyTaskMeta.ToList();
            foreach (var existingStrategyTaskEntity in existingStrategyTaskEntityList)
            {
                TaskStack updatedTaskStack = existingStrategyTaskEntity.TaskStack;

                string? evaluatedTaskStatusCodeId = evaluateTaskStatusByStepStatus(stepLevelStrategyTimeline.StatusCodeId);
                if (!DataCompareUtility.IsEquals(updatedTaskStack?.TaskStatusCodeId, evaluatedTaskStatusCodeId))
                {
                    TaskStatusCode? taskPrevStatusCodeEntity =
                        allTaskStatusCodes.Where(x => x.TaskStatusCodeId.Equals(updatedTaskStack?.TaskStatusCodeId)).SingleOrDefault();
                    TaskStatusCode? taskCurrStatusCodeEntity =
                        allTaskStatusCodes.Where(x => x.TaskStatusCodeId.Equals(evaluatedTaskStatusCodeId)).SingleOrDefault();

                    updatedTaskStack.PrevTaskStatusCodeId = updatedTaskStack?.TaskStatusCodeId;
                    updatedTaskStack.PrevTaskStatusCode = taskPrevStatusCodeEntity;
                    updatedTaskStack.TaskStatusCodeId = evaluatedTaskStatusCodeId;
                    updatedTaskStack.TaskStatusCode = taskCurrStatusCodeEntity;
                    updatedTaskStack.Version = updatedTaskStack.Version + 1;

                    foreach (var existingTaskMeta in updatedTaskStack.TaskMeta)
                    {
                        existingTaskMeta.UpdatedBy = securityUserId;
                        existingTaskMeta.UpdatedDate = DateTime.Now;
                        existingTaskMeta.Version = existingTaskMeta.Version + 1;
                    }
                }
                List<TaskStep> existingTaskStepEntityList = updatedTaskStack.TaskSteps.ToList();
                if (existingTaskStepEntityList != null)
                {
                    foreach (TaskStep existingTaskStepEntity in existingTaskStepEntityList)
                    {
                        bool isAnyChangeInStep = false;
                        string? taskStepEvalStatusCodeId = stepLevelStrategyTimeline.StatusCodeId;

                        if (!DataCompareUtility.IsEquals(existingTaskStepEntity.StatusCodeId, taskStepEvalStatusCodeId))
                        {
                            BpstatusCode? taskStepCurrStatusCodeEntity = allStepStatusCodes
                                .Where(x => x.StatusCodeId.Equals(taskStepEvalStatusCodeId)).SingleOrDefault();

                            isAnyChangeInStep = true;
                            existingTaskStepEntity.StatusCodeId = taskStepEvalStatusCodeId;
                            existingTaskStepEntity.StatusCode = taskStepCurrStatusCodeEntity;
                            existingTaskStepEntity.UpdatedBy = securityUserId;
                            existingTaskStepEntity.UpdatedDate = DateTime.Now;
                            existingTaskStepEntity.LastStepStatusUpdatedBy = securityUserId;
                            existingTaskStepEntity.LastStepStatusUpdatedDate = DateTime.Now;
                            existingTaskStepEntity.Version = existingTaskStepEntity.Version + 1;
                        }
                    }
                    updatedTaskStack.TaskSteps = existingTaskStepEntityList;
                }

                existingStrategyTaskEntity.TaskStack = updatedTaskStack;
                existingStrategyTaskEntity.UpdatedBy = securityUserId;
                existingStrategyTaskEntity.UpdatedDate = DateTime.Now;
            }
            return existingStrategyTaskEntityList;
        }
        private string evaluateStepLevelStrategyTimelineStatusByMarketTimelines(List<BpstatusCode> allStepStatusCodes, List<StepDef> allStepDefList,
            StepDef strategyCurrStepDef, List<Market>? marketEntityList)
        {
            string strategyTimelineStatusCodeId = null;

            //default status active if first step else init(not sarted yet)
            if (strategyCurrStepDef.StepOrder == 1)
                strategyTimelineStatusCodeId = nameof(GenericStatusCodes.ACTI);
            else
                strategyTimelineStatusCodeId = nameof(GenericStatusCodes.INIT);

            //IF ALL MARKETS COMPLETED THEN COMPLETED
            //ELSE
            //    IF all market timelines group code in curr step is compl THEN COMPLETED
            //    ELSE IF atleast one market timeline status code in curr step is active
            //    ELSE 
            //       IF atleast one +ve market timeline group code in curr step is completed
            //       ELSE IF atleast one -ve market timeline group status code is compl && strategysteporder <= max(stepOrder) then active
            //       ELSE INIT (NOT STARTED YET)

            if (marketEntityList != null && marketEntityList.Count > 0)
            {
                List<string?> allMarketGroupStatusList =
                               marketEntityList.Select(x => x.StatusCode.StatusGroupCode).Distinct().ToList();

                if (allMarketGroupStatusList != null
                                && allMarketGroupStatusList.Count == 1
                                && allMarketGroupStatusList.Single().Equals(nameof(GenericStatusGroupCodes.COMP)))
                {
                    strategyTimelineStatusCodeId = nameof(GenericStatusCodes.COMP);
                }
                else
                {
                    List<MarketTimeline>? currStepMarketTimelines =
                       marketEntityList?
                       .SelectMany(x => x.MarketTimelines.Where(x => x.StepDefId.Equals(strategyCurrStepDef.StepDefId))).ToList();
                    List<string?> currStepMarketTimelinesStatusList =
                                currStepMarketTimelines.Select(x => x.StatusCodeId).Distinct().ToList();
                    List<string?> currStepMarketTimelinesGroupStatusList =
                                currStepMarketTimelines.Select(x => x.StatusCode.StatusGroupCode).Distinct().ToList();

                    if (currStepMarketTimelinesGroupStatusList != null && currStepMarketTimelinesGroupStatusList.Count == 1
                                && currStepMarketTimelinesGroupStatusList.Single().Equals(nameof(GenericStatusGroupCodes.COMP)))
                    {
                        strategyTimelineStatusCodeId = nameof(GenericStatusCodes.COMP);
                    }
                    else if (currStepMarketTimelinesStatusList.Contains(nameof(GenericStatusCodes.ACTI)))
                    {
                        strategyTimelineStatusCodeId = nameof(GenericStatusCodes.ACTI);
                    }
                    else
                    {
                        //IF atleast one +ve market timeline group code in curr step is completed
                        //ELSE IF atleast one -ve market timeline group status code is compl && strategysteporder <= max(stepOrder) then active
                        //ELSE INIT (NOT STARTED YET)
                        List<MarketTimeline>? currStepPosMarketTimelines =
                                                  marketEntityList?
                                                  .Where(x => !x.StatusCodeId.Equals(nameof(GenericStatusCodes.COMPI)))
                                                  .SelectMany(x => x.MarketTimelines
                                                                            .Where(x => x.StepDefId.Equals(strategyCurrStepDef.StepDefId)))
                                                  .ToList();

                        List<MarketTimeline>? currStepNegMarketTimelines =
                                                  marketEntityList?
                                                  .Where(x => x.StatusCodeId.Equals(nameof(GenericStatusCodes.COMPI)))
                                                  .SelectMany(x => x.MarketTimelines
                                                                            .Where(x => x.StepDefId.Equals(strategyCurrStepDef.StepDefId)))
                                                  .ToList();

                        if (currStepPosMarketTimelines != null
                                && currStepPosMarketTimelines.Count > 0
                                && currStepPosMarketTimelines.Any(x => x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusCodes.COMP))))
                        {
                            strategyTimelineStatusCodeId = nameof(GenericStatusCodes.ACTI);
                        }
                        else if (currStepNegMarketTimelines != null
                                && currStepNegMarketTimelines.Count > 0
                                && currStepNegMarketTimelines.Any(x => x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusCodes.COMP))))
                        {
                            List<string?>? allStepDefIdsOfNegMarkets =
                                    marketEntityList?.Where(x => x.StatusCodeId.Equals(nameof(GenericStatusCodes.COMPI)))
                                                    .Select(x => x.StepDefId).ToList();

                            int maxStepOrderOfAllNegMarkets =
                                allStepDefList.Where(x => allStepDefIdsOfNegMarkets.Contains(x.StepDefId))
                                               .Select(x => x.StepOrder).ToList().Max();

                            if (strategyCurrStepDef.StepOrder <= maxStepOrderOfAllNegMarkets)
                                strategyTimelineStatusCodeId = nameof(GenericStatusCodes.ACTI);
                            else
                                strategyTimelineStatusCodeId = nameof(GenericStatusCodes.INIT);
                        }
                        else
                        {
                            if (strategyCurrStepDef.StepOrder == 1)
                                strategyTimelineStatusCodeId = nameof(GenericStatusCodes.ACTI);
                            else
                                strategyTimelineStatusCodeId = nameof(GenericStatusCodes.INIT);
                        }
                    }
                }
            }

            return strategyTimelineStatusCodeId;
        }
        private string evaluateTaskStatusByStepStatus(string stepStatus)
        {
            string? taskStatus = null;
            switch (stepStatus)
            {
                case "ARCH":
                case "CANC":
                case "REMO":
                case "SKIP":
                    taskStatus = stepStatus;
                    break;
                case "COMP":
                    taskStatus = nameof(TaskStatusCodes.CLOS); ;
                    break;
                case "COMPI":
                case "INAC":
                    taskStatus = nameof(TaskStatusCodes.CLOSI); ;
                    break;
                default:
                    taskStatus = nameof(TaskStatusCodes.OPEN);
                    break;
            }
            return taskStatus;
        }
        #endregion

        #region RESPONSE RELATED
        private void MapStrategyAndMarkets(List<Strategy> strategyList, List<Market>? marketList)
        {
            if (marketList != null && marketList.Count > 0)
            {
                foreach (var strategy in strategyList)
                {
                    strategy.Markets =
                        marketList?.Where(x => x.StrategyId == strategy.StrategyId).ToList();
                }
            }
        }
        private void MapStepTimelinesStaffAssignmentByStrategyList(List<StrategyModel> strategyModelList, bool includeMarkets)
        {
            List<StepTimelineStaffAssignment>? stepStaffAssignmentList = null;
            if (strategyModelList != null && strategyModelList.Count > 0)
            {
                List<Guid> stepTimeLineIds = new List<Guid>();
                foreach (var strategyModel in strategyModelList)
                {
                    if (strategyModel != null && strategyModel.StrategyTimelines != null && strategyModel.StrategyTimelines.Count > 0)
                    {
                        List<Guid> strategyStepTimeLineIds = ExtractTimelinesId(strategyModel, includeMarkets);
                        if (strategyStepTimeLineIds != null)
                            stepTimeLineIds.AddRange(strategyStepTimeLineIds);
                    }
                }
                if (stepTimeLineIds.Count > 0)
                {
                    stepStaffAssignmentList = GetStaffAssignmentsByTimelines(stepTimeLineIds, includeMarkets);
                    if (stepStaffAssignmentList != null && stepStaffAssignmentList.Count > 0)
                    {
                        List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList =
                            _mapper.Map<List<StepTimelineStaffAssignmentModel>>(stepStaffAssignmentList);

                        if (stepTimelineStaffAssignedResponseList != null && stepTimelineStaffAssignedResponseList.Count > 0)
                        {
                            foreach (var strategyModel in strategyModelList)
                            {
                                AssignStaffAssignmentsByStrategy(strategyModel, includeMarkets, stepTimelineStaffAssignedResponseList);
                            }
                        }

                    }
                }
            }
        }

        private void MapStepTimelinesStaffAssignmentByStrategy(StrategyModel strategyModel, bool includeMarkets)
        {
            List<StepTimelineStaffAssignment>? stepStaffAssignmentList = null;

            if (strategyModel != null && strategyModel.StrategyTimelines != null && strategyModel.StrategyTimelines.Count > 0)
            {
                List<Guid> stepTimeLineIds = ExtractTimelinesId(strategyModel, includeMarkets);
                stepStaffAssignmentList = GetStaffAssignmentsByTimelines(stepTimeLineIds, includeMarkets);
                if (stepStaffAssignmentList != null && stepStaffAssignmentList.Count > 0)
                {
                    List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList =
                        _mapper.Map<List<StepTimelineStaffAssignmentModel>>(stepStaffAssignmentList);
                    AssignStaffAssignmentsByStrategy(strategyModel, includeMarkets, stepTimelineStaffAssignedResponseList);
                }
            }
        }

        private List<Guid> ExtractTimelinesId(StrategyModel strategyModel, bool includeMarkets)
        {
            List<Guid> stepTimeLineIds = new List<Guid>();

            if (strategyModel != null && strategyModel.StrategyTimelines != null && strategyModel.StrategyTimelines.Count > 0)
            {
                List<Guid> strategyTimelineIds = strategyModel.StrategyTimelines.Select(x => x.StrategyTimelineId).ToList();
                stepTimeLineIds.AddRange(strategyTimelineIds);

                if (includeMarkets && strategyModel.Markets != null
                    && strategyModel.Markets.Count > 0
                    && strategyModel.Markets.Any(x => x.MarketTimelines != null && x.MarketTimelines.Count > 0))
                {
                    List<Guid?>? marketTimelineIds = strategyModel.Markets?.SelectMany(opt => opt.MarketTimelines
                                                    .Select(x => x.MarketTimelineId))?.ToList();
                    if (marketTimelineIds != null && marketTimelineIds.Count > 0)
                        stepTimeLineIds.AddRange(marketTimelineIds.Where(id => id.HasValue).Select(id => id.Value));
                }
            }
            return stepTimeLineIds;
        }

        private List<StepTimelineStaffAssignment>? GetStaffAssignmentsByTimelines(List<Guid> stepTimeLineIds, bool includeMarkets)
        {
            List<StepTimelineStaffAssignment>? stepStaffAssignmentList = null;
            if (stepTimeLineIds != null && stepTimeLineIds.Count > 0)
            {
                if (includeMarkets)
                    stepStaffAssignmentList =
                   _taskStackRepository.GetStaffAssignedByStrategyAndMarketsTimelines(stepTimeLineIds);
            }
            else
            {
                stepStaffAssignmentList =
                _taskStackRepository.GetStaffAssignedByStrategyTimelines(stepTimeLineIds);
            }
            return stepStaffAssignmentList;
        }

        private void AssignStaffAssignmentsByStrategy(StrategyModel strategyModel, bool includeMarkets,
            List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList)
        {
            if (stepTimelineStaffAssignedResponseList != null && stepTimelineStaffAssignedResponseList.Count > 0)
            {
                foreach (StrategyTimelineModel strategyTimeline in strategyModel.StrategyTimelines)
                {
                    strategyTimeline.StepAssignments =
                    stepTimelineStaffAssignedResponseList.Where(x => x.StepTimelineId.Equals(strategyTimeline.StrategyTimelineId)).ToList();

                    if (includeMarkets && strategyModel.Markets != null
                    && strategyModel.Markets.Count > 0
                    && strategyModel.Markets.Any(x => x.MarketTimelines != null && x.MarketTimelines.Count > 0))
                    {
                        List<MarketTimelineModel>? marketTimelines
                            = strategyModel.Markets?.SelectMany(opt => opt.MarketTimelines)?.ToList();
                        if (marketTimelines != null && marketTimelines.Count > 0)
                        {
                            foreach (MarketTimelineModel marketTimeline in marketTimelines)
                            {
                                marketTimeline.StepAssignments =
                                    stepTimelineStaffAssignedResponseList
                                        .Where(x => x.StepTimelineId.Equals(marketTimeline.MarketTimelineId)).ToList();
                            }
                        }
                    }
                }
            }
        }

        private void AssignAccessAndAnalyticsByStrategyList(string securityUserId, List<string> mapUserSagStaffIds, List<StrategyModel> strategyResponseList)
        {
            foreach (var strategyResponse in strategyResponseList)
            {
                strategyResponse.IsStrategyAcesssEnable = false;
                //var strategyEntity = StrategyEntityList.Where(x => x.StrategyId == strategyResponse.StrategyId).FirstOrDefault();

                if (strategyResponse.StrategyStaffs != null)
                {
                    if (!string.IsNullOrEmpty(securityUserId)
                        && !string.IsNullOrEmpty(strategyResponse.CreatedBy) && strategyResponse.CreatedBy.Equals(securityUserId))
                        strategyResponse.IsStrategyAcesssEnable = true;

                    if (mapUserSagStaffIds != null && mapUserSagStaffIds.Count > 0
                        && strategyResponse.StrategyStaffs.Any(s => mapUserSagStaffIds.Contains(s.SagittaStaffId)))
                        strategyResponse.IsStrategyAcesssEnable = true;
                }
                if (strategyResponse.Markets != null)
                {
                    var marketList = strategyResponse.Markets;
                    decimal? totalPremAmt = 0;
                    List<int?> marketGrpNumberList = marketList.Where(x => x.GrpNumber != null).Select(x => x.GrpNumber).ToList();
                    foreach (int marketGrpNumber in marketGrpNumberList)
                    {
                        totalPremAmt = totalPremAmt + marketList.Where(x => x.GrpNumber.Equals(marketGrpNumber)).Select(x => x.PremiumAmt).FirstOrDefault() ?? Convert.ToDecimal(0);
                    }

                    List<long?> sagittaPolicyIds = marketList.Where(x => x.SagittaPolicyId != null).Select(x => x.SagittaPolicyId).ToList();
                    List<int?> sagittaCovIds = marketList.Where(x => x.CovId != null).Select(x => x.CovId).ToList();

                    strategyResponse.TotalCountPolicies = sagittaPolicyIds != null ? sagittaPolicyIds.Distinct().Count() : 0;
                    strategyResponse.TotalCountPolicyLines = sagittaCovIds != null ? sagittaCovIds.Distinct().Count() : 0;
                    strategyResponse.TotalPremium = totalPremAmt ?? 0;
                }
            }
        }
        #endregion

        #endregion
    }
}
