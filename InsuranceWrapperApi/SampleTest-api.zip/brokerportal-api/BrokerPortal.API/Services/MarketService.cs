﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;
namespace BrokerPortal.API.Services
{
    public class MarketService : IMarketService
    {

        private readonly IMarketRepository _repository;
        private readonly ITaskStackRepository _taskStackrepository;
        private readonly IMarketTaskRepository _marketTaskrepository;
        private readonly IStrategyRepository _strategyRepository;
        private readonly IStrategyTaskRepository _strategyTaskRepository;
        private readonly ILookupDataRepository _lookupDataRepository;
        private readonly ISagittaStaffRepository _sagittaStaffRepository;
        private readonly IMapper _mapper;

        public MarketService(IMarketRepository repository, IMapper mapper,
            ITaskStackRepository taskStackrepository, IMarketTaskRepository marketTaskrepository,
            IStrategyRepository strategyRepository, IStrategyTaskRepository strategyTaskRepository, ILookupDataRepository lookupDataRepository, ISagittaStaffRepository sagittaStaffRepository)
        {
            _repository = repository;
            _mapper = mapper;
            _taskStackrepository = taskStackrepository;
            _marketTaskrepository = marketTaskrepository;
            _strategyRepository = strategyRepository;
            _strategyTaskRepository = strategyTaskRepository;
            _lookupDataRepository = lookupDataRepository;
            _sagittaStaffRepository = sagittaStaffRepository;
        }

        public List<MarketModel>? GetAllMarketByStrategy(Guid? strategyId)
        {
            List<MarketModel>? responseList = null;
            List<Market>? markets = _repository.GetAllMarketByStrategy(strategyId);
            if (markets != null && markets.Count > 0)
            {
                responseList = _mapper.Map<List<MarketModel>>(markets);
                MapStepAssignmentsByMarkets(responseList);
            }
            return responseList;
        }

        public async Task<MarketModel> GetMarketById(Guid? marketId)
        {
            MarketModel response = null;
            if (marketId != Guid.Empty)
            {
                Market market = await _repository.GetMarketById(marketId);
                response = _mapper.Map<MarketModel>(market);
                MapStepAssignmentsByMarket(response);
            }

            return response;
        }

        public async Task<MarketModel> SaveMarket(Guid strategyId, string securityUserId, MarketRequest marketSaveRequest)
        {
            Guid? marketId = Guid.Empty;

            if (strategyId != Guid.Empty && marketSaveRequest != null)
            {
                Strategy? strategyEntity = await _strategyRepository.GetStrategyForMarketChanges(strategyId);
                List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
                List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
                List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
                List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

                if (strategyEntity != null)
                {
                    //NEW MARKET
                    Market? newMarketEntity =
                        BuildNewMarketEntity(securityUserId, strategyEntity, allStepDefList, allSubStepDefList,
                                            allStepStatusCodes, allTaskStatusCodes,
                                            marketSaveRequest);

                    if (newMarketEntity != null)
                    {
                        await _repository.SaveMarket(newMarketEntity);
                        marketId = newMarketEntity.MarketId;
                    }
                }
            }

            return await GetMarketById(marketId);
        }


        public async Task<MarketModel> UpdateMarket(Guid marketId, string securityUserId, MarketRequest marketUpdateRequest)
        {
            Guid? strategyId = await _repository.GetStrategyIdByMarketId(marketId);
            if (strategyId != Guid.Empty && marketUpdateRequest != null)
            {
                Strategy? strategyEntity = await _strategyRepository.GetStrategyForMarketChanges(strategyId);
                Market? existingMarketEntity = await _repository.GetMarketForUpdateById(marketId);
                List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
                List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
                List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
                List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

                if (strategyEntity != null)
                {
                    if (existingMarketEntity != null)
                    {
                        //UPDATE MARKET
                        existingMarketEntity =
                                 BuildUpdateMarketEntity(securityUserId, strategyEntity, allStepDefList, allSubStepDefList,
                                                            allStepStatusCodes, allTaskStatusCodes,
                                                             existingMarketEntity, marketUpdateRequest);
                        await _repository.TrackMarketChanges(existingMarketEntity);
                        await _repository.UpdateMarket(existingMarketEntity);
                    }
                }
            }
            return await GetMarketById(marketId);
        }
        public async Task<List<MarketModel>?> BulkMergeMarkets(Guid? strategyId, string? securityUserId, List<MarketRequest> marketBulkRequest)
        {
            if (marketBulkRequest != null && marketBulkRequest.Count > 0)
            {
                Strategy? strategyEntity = await _strategyRepository.GetStrategyForMarketChanges(strategyId);
                List<Market>? existingMarketEntityList = await _repository.GetMarketsForUpdateByStrategy(strategyId);
                List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
                List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
                List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
                List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

                if (strategyEntity != null)
                {
                    foreach (var marketRequest in marketBulkRequest)
                    {
                        Market? existingMarketEntity =
                            existingMarketEntityList?.SingleOrDefault(x => marketRequest.MarketId != null && x.MarketId.Equals(marketRequest.MarketId));

                        if (existingMarketEntity != null)
                        {
                            //UPDATE MARKET
                            existingMarketEntity =
                                BuildUpdateMarketEntity(securityUserId, strategyEntity,
                                                            allStepDefList, allSubStepDefList, allStepStatusCodes, allTaskStatusCodes,
                                                            existingMarketEntity, marketRequest);
                            await _repository.TrackMarketChanges(existingMarketEntity);
                            await _repository.UpdateMarket(existingMarketEntity);
                        }
                        else
                        {
                            //NEW MARKET
                            Market? newMarketEntity =
                               BuildNewMarketEntity(securityUserId, strategyEntity, allStepDefList, allSubStepDefList,
                                                    allStepStatusCodes, allTaskStatusCodes,
                                                    marketRequest);
                            await _repository.SaveMarket(newMarketEntity);
                        }
                    }
                }
            }
            return GetAllMarketByStrategy(strategyId);
        }


        public async Task<MarketModel> MergeMarket(Guid? strategyId, string? securityUserId, MarketRequest marketRequest)
        {
            Guid? marketId = marketRequest.MarketId;
            if (marketRequest != null)
            {
                Strategy? strategyEntity = await _strategyRepository.GetStrategyForMarketChanges(strategyId);
                List<Market>? existingMarketEntityList = await _repository.GetMarketsForUpdateByStrategy(strategyId);
                List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
                List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
                List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
                List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

                if (strategyEntity != null)
                {
                    Market? existingMarketEntity =
                            existingMarketEntityList?.SingleOrDefault(x => marketRequest.MarketId != null && x.MarketId.Equals(marketRequest.MarketId));

                    if (existingMarketEntity != null)
                    {
                        //UPDATE MARKET
                        existingMarketEntity =
                            BuildUpdateMarketEntity(securityUserId, strategyEntity,
                                                        allStepDefList, allSubStepDefList, allStepStatusCodes, allTaskStatusCodes,
                                                        existingMarketEntity, marketRequest);
                        await _repository.TrackMarketChanges(existingMarketEntity);
                        await _repository.UpdateMarket(existingMarketEntity);
                    }
                    else
                    {
                        //NEW MARKET
                        Market? newMarketEntity =
                           BuildNewMarketEntity(securityUserId, strategyEntity, allStepDefList, allSubStepDefList,
                                                allStepStatusCodes, allTaskStatusCodes,
                                                marketRequest);
                        await _repository.SaveMarket(newMarketEntity);
                        marketId = newMarketEntity.MarketId;
                    }
                }
            }
            return GetMarketById(marketId).GetAwaiter().GetResult();
        }



        public async Task<bool> RemoveMarket(Guid? marketId, string securityUserId)
        {
            Guid? strategyId = await _repository.GetStrategyIdByMarketId(marketId);
            if (strategyId != Guid.Empty)
            {

                List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
                List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
                List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
                List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

                await _repository.RemoveMarket(marketId, securityUserId);
            }
            return true;
        }

        public async Task<bool> ArchiveMarket(Guid? marketId, string securityUserId)
        {
            Guid? strategyId = await _repository.GetStrategyIdByMarketId(marketId);
            if (strategyId != Guid.Empty)
            {
                List<StepDef> allStepDefList = _lookupDataRepository.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY);
                List<SubStepDef> allSubStepDefList = _lookupDataRepository.GetAllSubStepDefs();
                List<BpstatusCode> allStepStatusCodes = _lookupDataRepository.GetAllBPStatusCodes();
                List<TaskStatusCode> allTaskStatusCodes = _lookupDataRepository.GetAllTaskStatusCodes();

                await _repository.ArchiveMarket(marketId, securityUserId);
            }
            return true;
        }

        public async Task<Guid?> GetStrategyIdByMarketId(Guid? marketId)
        {
            return await _repository.GetStrategyIdByMarketId(marketId);
        }


        #region PRIVATE FINAL
        #region NEW MARKET RELATED
        private Market? BuildNewMarketEntity(string? securityUserId, Strategy? strategyEntity,
             List<StepDef> allStepDefList, List<SubStepDef> allSubStepDefList, List<BpstatusCode> allStepStatusCodes, List<TaskStatusCode> allTaskStatusCodes,
             MarketRequest marketRequest)
        {
            StepDef? currStepDefEntity = allStepDefList.SingleOrDefault(x => x.StepDefId == marketRequest.StepDefId);
            SubStepDef? currSubStepDefEntity = allSubStepDefList.SingleOrDefault(x => x.SubStepDefId == marketRequest.SubStepDefId);

            List<MarketTimelineRequest>? marketTimeLineRequestList = marketRequest.MarketTimelines.ToList();
            MarketTimelineRequest? currStepMarketTimelineRequest =
                        marketTimeLineRequestList?.Where(x => x.StepDefId.Equals(currStepDefEntity.StepDefId)).FirstOrDefault();

            Market? marketEntity = new Market();
            marketEntity.MarketId = Guid.NewGuid();
            marketEntity.Version = 1;
            marketEntity.StrategyId = strategyEntity.StrategyId;
            marketEntity.StatusCodeId = evaluateNewMarketStatus(currStepDefEntity, currSubStepDefEntity);
            marketEntity.PrevStatusCodeId = null;
            marketEntity.StepDefId = marketRequest.StepDefId;
            marketEntity.PrevStepDefId = null;
            marketEntity.SubStepDefId = marketRequest.SubStepDefId;
            marketEntity.PrevSubStepDefId = null;
            marketEntity.SagittaPolicyId = marketRequest.SagittaPolicyId;
            marketEntity.IsSagPol = marketRequest.IsSagPol ?? (marketRequest.SagittaPolicyId != null ? true : false);
            marketEntity.CovId = marketRequest.CovId;
            marketEntity.CovCode = marketRequest.CovCode;
            marketEntity.CovDesc = marketRequest.CovDesc;
            marketEntity.GrpNumber = marketRequest.GrpNumber;
            marketEntity.PremiumAmt = marketRequest.PremiumAmt;
            marketEntity.SagittaPayeeId = marketRequest.SagittaPayeeId;
            marketEntity.UnderwriterId = marketRequest.UnderwriterId;
            marketEntity.UnderwriterVersion = marketRequest.UnderwriterVersion;
            marketEntity.IsIncumbent = marketRequest.IsIncumbent ?? false;
            marketEntity.Notes = marketRequest.Notes;
            marketEntity.SubmissionSentDateTime = marketRequest.SubmissionSentDateTime ?? null;
            marketEntity.QuoteRecievedDateTime = marketRequest.QuoteRecievedDateTime ?? null;
            marketEntity.IsDeleted = false;
            marketEntity.CreatedBy = securityUserId;
            marketEntity.CreatedDate = DateTime.Now;

            if (marketRequest.MarketAddlCoverages != null && marketRequest.MarketAddlCoverages.Count > 0)
            {
                List<MarketAddlCovRequest> marketAddlCovRequestList = marketRequest.MarketAddlCoverages.ToList();
                marketEntity.MarketAddlCovs = BuildNewMarketAddlCovEntityList(securityUserId, marketEntity.MarketId, marketAddlCovRequestList);
            }

            if (strategyEntity != null
                && marketRequest.MarketTimelines != null
                && marketRequest.MarketTimelines.Count() > 0
                && currStepMarketTimelineRequest != null)
            {
                marketEntity.MarketTimelines =
                    BuildNewMarketTimeLines(securityUserId, strategyEntity, allStepDefList,
                        marketEntity, currStepMarketTimelineRequest,
                        currStepDefEntity, currSubStepDefEntity);

                marketEntity.MarketTaskMeta =
                    BuildNewMarketTaskEntity(securityUserId, strategyEntity,
                        marketEntity, marketTimeLineRequestList,
                        currStepDefEntity, currSubStepDefEntity);
            }

            return marketEntity;
        }
        private List<MarketAddlCov> BuildNewMarketAddlCovEntityList(string securityUserId, Guid marketId, List<MarketAddlCovRequest> marketAddlCovRequestList)
        {
            List<MarketAddlCov> marketAddlCovEntityList = new List<MarketAddlCov>();
            foreach (MarketAddlCovRequest marketAddlCovRequest in marketAddlCovRequestList)
            {
                MarketAddlCov marketAddlCovEntity = BuildNewMarketAddlCovEntity(securityUserId, marketId, marketAddlCovRequest);
                marketAddlCovEntityList.Add(marketAddlCovEntity);
            }
            return marketAddlCovEntityList;
        }
        private MarketAddlCov BuildNewMarketAddlCovEntity(string securityUserId, Guid marketId, MarketAddlCovRequest marketAddlCovRequest)
        {
            MarketAddlCov marketAddlCovEntity = new MarketAddlCov();
            marketAddlCovEntity.MarketAddlCovId = Guid.NewGuid();
            marketAddlCovEntity.Version = 1;
            marketAddlCovEntity.MarketId = marketId;
            marketAddlCovEntity.CovCode = marketAddlCovRequest.CovCode;
            marketAddlCovEntity.CovId = marketAddlCovRequest.CovId;
            marketAddlCovEntity.CovDesc = marketAddlCovRequest.CovDesc;
            marketAddlCovEntity.IsDeleted = false;
            marketAddlCovEntity.CreatedBy = securityUserId;
            marketAddlCovEntity.CreatedDate = DateTime.Now;
            return marketAddlCovEntity;
        }
        private List<MarketTimeline>? BuildNewMarketTimeLines(string? securityUserId, Strategy? strategyEntity, List<StepDef> allStepDefList,
            Market? marketEntity, MarketTimelineRequest? currStepMarketTimelineRequest,
            StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {
            int marketCurrStepOrder =
                allStepDefList.Where(x => x.StepDefId.Equals(marketEntity.StepDefId)).Select(x => x.StepOrder).FirstOrDefault();

            //LOOP THROUGH ALL STEPS AND CHECK
            //  CURRENT STEP: WILL BE MARKED AS PER MARKET STATUS
            //  PAST STEPS  : WILL BE MARKED SKIPPED EVEN IF FORCE CLOUSRE
            //  FUTURE STEPS: WILL BE MARKED PENDING BUT IF FORCE CLOUSRE THEN MARK SKIP

            List<MarketTimeline> newMarketTimeLines = new List<MarketTimeline>();
            foreach (var stepDefEntity in allStepDefList)
            {
                StrategyTimeline? strategyStepTimelineEntityByStep =
                        strategyEntity?.StrategyTimelines.Where(x => x.StepDefId.Equals(stepDefEntity.StepDefId)).FirstOrDefault();

                MarketTimeline newMarketTimeLine = new MarketTimeline();
                newMarketTimeLine.MarketTimelineId = Guid.NewGuid();
                newMarketTimeLine.Version = 1;
                newMarketTimeLine.MarketId = marketEntity.MarketId;
                newMarketTimeLine.StrategyId = strategyEntity.StrategyId;
                newMarketTimeLine.StepDefId = stepDefEntity.StepDefId;
                newMarketTimeLine.StrategyTimelineId = strategyStepTimelineEntityByStep.StrategyTimelineId;

                //SKIPPED STEPS HANDLING
                if (stepDefEntity.StepOrder < marketCurrStepOrder)
                {
                    newMarketTimeLine.StatusCodeId = nameof(GenericStatusCodes.SKIP);
                    newMarketTimeLine.AssignmentDueDate = null;
                    newMarketTimeLine.AssignmentFollowUpDate = null;
                }
                //CURRENT STEP HANDLING
                else if (stepDefEntity.StepOrder.Equals(marketCurrStepOrder))
                {
                    newMarketTimeLine.StatusCodeId = marketEntity.StatusCodeId;
                    newMarketTimeLine.AssignmentDueDate = currStepMarketTimelineRequest.AssignmentDueDate;
                    newMarketTimeLine.AssignmentFollowUpDate = currStepMarketTimelineRequest.AssignmentDueDate;
                }
                //FUTURE STEPS HANDLING
                else
                {
                    newMarketTimeLine.StatusCodeId =
                        isMarketEligibleForForceClosure(currStepDefEntity, currSubStepDefEntity)
                        ? nameof(GenericStatusCodes.SKIP) : nameof(GenericStatusCodes.PEND);
                    newMarketTimeLine.AssignmentDueDate = null;
                    newMarketTimeLine.AssignmentFollowUpDate = null;
                }
                newMarketTimeLine.PrevStatusCodeId = null;
                newMarketTimeLine.IsDeleted = false;
                newMarketTimeLine.CreatedBy = securityUserId;
                newMarketTimeLine.CreatedDate = DateTime.Now;
                newMarketTimeLine.LastStepStatusUpdatedDate = DateTime.Now;
                newMarketTimeLine.LastStepStatusUpdatedBy = securityUserId;
                newMarketTimeLines.Add(newMarketTimeLine);
            }

            return newMarketTimeLines;
        }
        private List<MarketTaskMeta> BuildNewMarketTaskEntity(string? securityUserId, Strategy? strategyEntity,
            Market marketEntity, List<MarketTimelineRequest> marketTimeLineRequestList,
            StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {

            List<MarketTaskMeta> marketTaskEntityList = new List<MarketTaskMeta>();
            MarketTaskMeta marketTaskEntity = new MarketTaskMeta();
            marketTaskEntity.MarketTaskId = Guid.NewGuid();
            marketTaskEntity.MarketId = marketEntity.MarketId;

            TaskStack taskStackEntity =
                BuildNewTaskEntity(securityUserId, strategyEntity, marketEntity, currStepDefEntity, currSubStepDefEntity);
            List<TaskStep> taskStepEntityList = new List<TaskStep>();

            foreach (var marketTimeline in marketEntity.MarketTimelines)
            {
                MarketTimelineRequest? marketStepTimelineRequestByStep =
                        marketTimeLineRequestList
                        .Where(x => x.StepDefId.Equals(marketTimeline.StepDefId))
                        .FirstOrDefault();

                TaskStep taskStepEntity =
                    BuildNewTaskStepAndAssignment(securityUserId, taskStackEntity, strategyEntity, marketTimeline, marketStepTimelineRequestByStep);
                taskStepEntityList.Add(taskStepEntity);
            }

            taskStackEntity.TaskSteps = taskStepEntityList;
            marketTaskEntity.TaskStackId = taskStackEntity.TaskStackId;
            marketTaskEntity.IsDeleted = false;
            marketTaskEntity.CreatedBy = securityUserId;
            marketTaskEntity.CreatedDate = DateTime.Now;
            marketTaskEntity.TaskStack = taskStackEntity;
            marketTaskEntityList.Add(marketTaskEntity);
            return marketTaskEntityList;
        }
        private TaskStack BuildNewTaskEntity(string? securityUserId, Strategy? strategyEntity,
            Market marketEntity, StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {
            MarketTimeline? marketCurrStepTimeline =
               marketEntity.MarketTimelines
               .Where(x => x.StepDefId.Equals(currStepDefEntity.StepDefId)).FirstOrDefault();

            TaskStack taskStackEntity = new TaskStack();
            taskStackEntity.TaskStackId = Guid.NewGuid();
            taskStackEntity.TaskName = currStepDefEntity.StepName;
            taskStackEntity.TaskDesc = currSubStepDefEntity.SubStepName;
            taskStackEntity.TaskSender = securityUserId;
            taskStackEntity.TaskSendDate = DateTime.Now;
            taskStackEntity.TaskProirity = AppConstants.TASK_PRIORITY_DEFAULT;
            taskStackEntity.TaskNotes = marketEntity.Notes;
            taskStackEntity.TaskRefType = nameof(TaskRefType.MARKET);
            taskStackEntity.TaskRefKey = Convert.ToString(marketEntity.MarketId)?.ToUpper();
            taskStackEntity.TaskStatusReason = null;
            taskStackEntity.IsDeleted = false;
            taskStackEntity.IsSysGen = true;
            taskStackEntity.Version = 1;
            taskStackEntity.CreatedBy = AppConstants.SYSTEM_USER_ID;
            taskStackEntity.CreatedDate = DateTime.Now;
            taskStackEntity.LastTaskStatusUpdatedDate = DateTime.Now;
            taskStackEntity.LastTaskStatusUpdatedBy = securityUserId;
            taskStackEntity.TaskDueDate = marketCurrStepTimeline.AssignmentDueDate;
            taskStackEntity.TaskFollowUpDate = marketCurrStepTimeline.AssignmentDueDate;
            taskStackEntity.PrevTaskStatusCodeId = null;
            taskStackEntity.TaskStatusCodeId = evaluateTaskStatusByStepStatus(marketEntity.StatusCodeId);

            List<TaskMeta> taskMetaEntityList = new List<TaskMeta>();
            TaskMeta taskMetaEntity = new TaskMeta();
            taskMetaEntity.TaskMetaId = Guid.NewGuid();
            taskMetaEntity.TaskStackId = taskStackEntity.TaskStackId;
            taskMetaEntity.PlanId = strategyEntity.PlanId;
            taskMetaEntity.StrategyId = strategyEntity.StrategyId;
            taskMetaEntity.StrategyTimelineId = marketCurrStepTimeline?.StrategyTimelineId;
            taskMetaEntity.MarketId = marketEntity.MarketId;
            taskMetaEntity.IsDeleted = false;
            taskMetaEntity.Version = 1;
            taskMetaEntity.CreatedBy = securityUserId;
            taskMetaEntity.CreatedDate = DateTime.Now;
            taskMetaEntityList.Add(taskMetaEntity);
            taskStackEntity.TaskMeta.Add(taskMetaEntity);
            return taskStackEntity;
        }
        private TaskStep BuildNewTaskStepAndAssignment(string? securityUserId, TaskStack taskStackEntity, Strategy? strategyEntity,
            MarketTimeline? marketTimeLineEntity, MarketTimelineRequest? marketStepTimelineRequestByStep)
        {
            //TaskSteps
            TaskStep taskStep = new TaskStep();
            taskStep.TaskStepId = Guid.NewGuid();
            taskStep.TaskStackId = taskStackEntity.TaskStackId;
            taskStep.StepDefId = marketTimeLineEntity.StepDefId;
            taskStep.StatusCodeId = marketTimeLineEntity.StatusCodeId;
            taskStep.TaskStepRefType = nameof(TaskStepRefType.MARKET_TIMELINE);
            taskStep.TaskStepRefKey = Convert.ToString(marketTimeLineEntity.MarketTimelineId);
            taskStep.LastStepStatusUpdatedDate = DateTime.Now;
            taskStep.LastStepStatusUpdatedBy = securityUserId;
            taskStep.IsDeleted = false;
            taskStep.Version = 1;
            taskStep.CreatedBy = AppConstants.SYSTEM_USER_ID;
            taskStep.CreatedDate = DateTime.Now;

            //TaskAssignments
            if (marketStepTimelineRequestByStep != null
                && marketStepTimelineRequestByStep.StepAssignments != null
                && marketStepTimelineRequestByStep.StepAssignments.Count > 0)
            {
                List<TaskAssignment> taskAssignments = new List<TaskAssignment>();

                List<StrategyStaff> strategyStaffEntityList = strategyEntity.StrategyStaffs.ToList();
                foreach (var assignment in marketStepTimelineRequestByStep.StepAssignments)
                {
                    StrategyStaff? strategyStaffEntity =
                        strategyStaffEntityList.Where(x => x.StrategyStaffId.Equals(assignment.StrategyStaffId)).FirstOrDefault();

                    if (strategyStaffEntity != null)
                    {
                        TaskAssignment newTaskAssignmentEntity = new TaskAssignment();
                        newTaskAssignmentEntity.TaskAssignmentId = Guid.NewGuid();
                        newTaskAssignmentEntity.ParentTaskAssignmentId = null;
                        newTaskAssignmentEntity.TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID);
                        newTaskAssignmentEntity.TaskAssignTo = strategyStaffEntity.SagittaStaffId;
                        newTaskAssignmentEntity.TaskAssignDate = DateTime.Now;
                        newTaskAssignmentEntity.HasLocked = false;
                        newTaskAssignmentEntity.IsActive = true;
                        newTaskAssignmentEntity.IsDelegated = false;
                        newTaskAssignmentEntity.IsDeleted = false;
                        newTaskAssignmentEntity.Version = 1;
                        newTaskAssignmentEntity.CreatedBy = securityUserId;
                        newTaskAssignmentEntity.CreatedDate = DateTime.Now;
                        newTaskAssignmentEntity.TaskStep = taskStep;
                        taskAssignments.Add(newTaskAssignmentEntity);
                    }

                }
                if (taskAssignments != null && taskAssignments.Count > 0)
                    taskStep.TaskAssignments = taskAssignments;
            }
            return taskStep;
        }
        #endregion

        #region MARKET UPDATE RELEATED
        private Market BuildUpdateMarketEntity(string securityUserId, Strategy? strategyEntity,
             List<StepDef> allStepDefList, List<SubStepDef> allSubStepDefList, List<BpstatusCode> allStepStatusCodes, List<TaskStatusCode> allTaskStatusCodes,
             Market existingMarketEntity, MarketRequest marketUpdateRequest)
        {

            StepDef? currStepDefEntity = allStepDefList.SingleOrDefault(x => x.StepDefId == marketUpdateRequest.StepDefId);
            SubStepDef? currSubStepDefEntity = allSubStepDefList.SingleOrDefault(x => x.SubStepDefId == marketUpdateRequest.SubStepDefId);

            List<MarketTimelineRequest>? marketTimeLineRequestList = marketUpdateRequest.MarketTimelines.ToList();
            MarketTimelineRequest? currStepMarketTimelineRequest =
                        marketTimeLineRequestList?.Where(x => x.StepDefId.Equals(currStepDefEntity.StepDefId)).FirstOrDefault();

            if (IsAnyChangeDetectedMarket(existingMarketEntity, marketUpdateRequest))
            {
                if (!DataCompareUtility.IsEquals(existingMarketEntity?.StepDefId, currStepDefEntity.StepDefId)
                || !DataCompareUtility.IsEquals(existingMarketEntity?.SubStepDefId, currSubStepDefEntity.StepDefId))
                {
                    string? marketCurrStatusCodeId = evaluateExistingMarketStatus(existingMarketEntity, currStepDefEntity, currSubStepDefEntity);
                    StepDef? prevStepDefEntity = allStepDefList.SingleOrDefault(x => x.StepDefId == existingMarketEntity.PrevStepDefId);
                    SubStepDef? prevSubStepDefEntity = allSubStepDefList.SingleOrDefault(x => x.SubStepDefId == existingMarketEntity.PrevSubStepDefId);
                    BpstatusCode? marketPrevStatusCodeEntity = allStepStatusCodes.Where(x => x.StatusCodeId.Equals(existingMarketEntity.StatusCodeId)).SingleOrDefault();
                    BpstatusCode? marketCurrStatusCodeEntity = allStepStatusCodes.Where(x => x.StatusCodeId.Equals(marketCurrStatusCodeId)).SingleOrDefault();

                    if (!DataCompareUtility.IsEquals(existingMarketEntity?.StepDefId, marketUpdateRequest.StepDefId))
                    {
                        existingMarketEntity.PrevStepDefId = existingMarketEntity?.StepDefId;
                        existingMarketEntity.PrevStepDef = prevStepDefEntity;
                        existingMarketEntity.StepDefId = marketUpdateRequest.StepDefId;
                        existingMarketEntity.StepDef = currStepDefEntity;
                    }

                    if (!DataCompareUtility.IsEquals(existingMarketEntity?.SubStepDefId, marketUpdateRequest.SubStepDefId))
                    {
                        existingMarketEntity.PrevSubStepDefId = existingMarketEntity?.SubStepDefId;
                        existingMarketEntity.PrevSubStepDef = prevSubStepDefEntity;
                        existingMarketEntity.SubStepDefId = marketUpdateRequest.SubStepDefId;
                        existingMarketEntity.SubStepDef = currSubStepDefEntity;
                    }

                    if (!DataCompareUtility.IsEquals(existingMarketEntity?.StatusCodeId, marketCurrStatusCodeId))
                    {

                        existingMarketEntity.PrevStatusCodeId = existingMarketEntity.StatusCodeId;
                        existingMarketEntity.PrevStatusCode = marketPrevStatusCodeEntity;
                        existingMarketEntity.StatusCodeId = marketCurrStatusCodeId;
                        existingMarketEntity.StatusCode = marketCurrStatusCodeEntity;
                    }
                }                
                existingMarketEntity.SagittaPolicyId = marketUpdateRequest.SagittaPolicyId;
                existingMarketEntity.IsSagPol = marketUpdateRequest.IsSagPol ?? (marketUpdateRequest.SagittaPolicyId != null ? true : false);
                existingMarketEntity.CovId = marketUpdateRequest.CovId;
                existingMarketEntity.CovCode = marketUpdateRequest.CovCode;
                existingMarketEntity.CovDesc = marketUpdateRequest.CovDesc;
                existingMarketEntity.GrpNumber = marketUpdateRequest.GrpNumber;
                existingMarketEntity.PremiumAmt = marketUpdateRequest.PremiumAmt;
                existingMarketEntity.SagittaPayeeId = marketUpdateRequest.SagittaPayeeId;
                existingMarketEntity.UnderwriterId = marketUpdateRequest.UnderwriterId;
                existingMarketEntity.UnderwriterVersion = marketUpdateRequest.UnderwriterVersion;
                existingMarketEntity.IsIncumbent = marketUpdateRequest.IsIncumbent ?? false;
                existingMarketEntity.Notes = marketUpdateRequest.Notes;
                existingMarketEntity.SubmissionSentDateTime = marketUpdateRequest.SubmissionSentDateTime ?? null;
                existingMarketEntity.QuoteRecievedDateTime = marketUpdateRequest.QuoteRecievedDateTime ?? null;
                existingMarketEntity.IsDeleted = marketUpdateRequest.IsDeleted ?? false;
                
            }
            

            if ((marketUpdateRequest.MarketAddlCoverages != null && marketUpdateRequest.MarketAddlCoverages.Count > 0)
                || (existingMarketEntity.MarketAddlCovs != null && existingMarketEntity.MarketAddlCovs.Count > 0))
            {
                if (IsAnyChangeInMarketAddlCoverages(existingMarketEntity.MarketAddlCovs?.ToList(), marketUpdateRequest.MarketAddlCoverages?.ToList()))
                {
                    List<MarketAddlCovRequest>? marketAddlCovRequestList = marketUpdateRequest.MarketAddlCoverages?.ToList();
                    List<MarketAddlCov>? marketAddlCovEntityList = existingMarketEntity.MarketAddlCovs?.ToList();
                    existingMarketEntity.MarketAddlCovs =
                        BuildUpdateMarketAddlCovEntityList(securityUserId, existingMarketEntity.MarketId,
                                                            marketAddlCovEntityList, marketAddlCovRequestList);
                }
            }
            if (existingMarketEntity.MarketTimelines != null
                && existingMarketEntity.MarketTimelines.Count() > 0)
            {
                existingMarketEntity.MarketTimelines =
                    BuildUpdateMarketTimeLines(securityUserId, allStepDefList, allStepStatusCodes,
                                                    existingMarketEntity, existingMarketEntity.MarketTimelines.ToList(),
                                                    currStepMarketTimelineRequest);

           



                existingMarketEntity.MarketTaskMeta =
                   BuildUpdateMarketTaskEntity(securityUserId, strategyEntity,
                       allStepStatusCodes, allTaskStatusCodes,
                       existingMarketEntity, currStepMarketTimelineRequest,
                       currStepDefEntity, currSubStepDefEntity);
            }
            existingMarketEntity.Version = existingMarketEntity.Version !=null? existingMarketEntity.Version + 1 : 1;
            existingMarketEntity.UpdatedBy = securityUserId;
            existingMarketEntity.UpdatedDate = DateTime.Now;
            return existingMarketEntity;
        }
        private List<MarketAddlCov> BuildUpdateMarketAddlCovEntityList(string securityUserId, Guid marketId,
            List<MarketAddlCov>? existingMarketAddlCovEntityList, List<MarketAddlCovRequest>? marketAddlCovRequestList)
        {
            List<MarketAddlCov>? bulkMergeMarketAddlCovEntityList = new List<MarketAddlCov>();
            Guid?[] requestMarketAddlCovIds = null;
            Guid[] existingMarketAddlCovIds = null;

            if (existingMarketAddlCovEntityList != null && existingMarketAddlCovEntityList.Count > 0)
                existingMarketAddlCovIds = existingMarketAddlCovEntityList.Select(x => x.MarketAddlCovId).ToArray();

            if (marketAddlCovRequestList != null && marketAddlCovRequestList.Count > 0)
                requestMarketAddlCovIds = marketAddlCovRequestList.Select(x => x.MarketAddlCovId).ToArray();

            if (existingMarketAddlCovEntityList != null && existingMarketAddlCovEntityList.Count > 0)
            {
                //delete if db has MarketAddlCov but not present in request
                foreach (MarketAddlCov existingMarketAddCov in existingMarketAddlCovEntityList)
                {
                    if (requestMarketAddlCovIds == null
                           || (requestMarketAddlCovIds != null && !requestMarketAddlCovIds.Contains(existingMarketAddCov.MarketAddlCovId)))
                    {
                        existingMarketAddCov.Version = existingMarketAddCov.Version != null ? existingMarketAddCov.Version + 1 : 1;
                        existingMarketAddCov.IsDeleted = true;
                        existingMarketAddCov.UpdatedDate = DateTime.Now;
                        existingMarketAddCov.UpdatedBy = securityUserId;
                        bulkMergeMarketAddlCovEntityList.Add(existingMarketAddCov);
                    }
                }
            }

            if (marketAddlCovRequestList != null && marketAddlCovRequestList.Count > 0)
            {
                foreach (MarketAddlCovRequest marketAddlCovRequest in marketAddlCovRequestList)
                {

                    MarketAddlCov? existingMarketAddlCovEntity =
                        existingMarketAddlCovEntityList?.Where(x => x.MarketAddlCovId.Equals(marketAddlCovRequest.MarketAddlCovId)).SingleOrDefault();
                    if (existingMarketAddlCovEntity != null)
                    {
                        MarketAddlCov? marketAddlCovUpdateEntity =
                            BuildUpdateMarketAddlCovEntity(securityUserId, existingMarketAddlCovEntity, marketAddlCovRequest);
                        bulkMergeMarketAddlCovEntityList.Add(marketAddlCovUpdateEntity);
                    }
                    else
                    {
                        MarketAddlCov? marketAddlCovNewEntity =
                            BuildNewMarketAddlCovEntity(securityUserId, marketId, marketAddlCovRequest);
                        bulkMergeMarketAddlCovEntityList.Add(marketAddlCovNewEntity);
                    }
                }
            }
            return bulkMergeMarketAddlCovEntityList;
        }
        private MarketAddlCov BuildUpdateMarketAddlCovEntity(string securityUserId, MarketAddlCov marketAddlCovEntity, MarketAddlCovRequest marketAddlCovRequest)
        {
            if (IsAnyChangeDetectedMarketAddlCov(marketAddlCovEntity, marketAddlCovRequest))
            {
                
                marketAddlCovEntity.CovId = marketAddlCovRequest.CovId;
                marketAddlCovEntity.CovCode = marketAddlCovRequest.CovCode;
                marketAddlCovEntity.CovDesc = marketAddlCovRequest.CovDesc;
                marketAddlCovEntity.IsDeleted = marketAddlCovRequest.IsDeleted ?? false;
                marketAddlCovEntity.Version = marketAddlCovEntity.Version != null ? marketAddlCovEntity.Version + 1 : 1;
                marketAddlCovEntity.UpdatedBy = securityUserId;
                marketAddlCovEntity.UpdatedDate = DateTime.Now;
            }
            return marketAddlCovEntity;
        }
        private List<MarketTimeline> BuildUpdateMarketTimeLines(string securityUserId,
            List<StepDef> allStepDefList, List<BpstatusCode> allStepStatusCodes,
            Market existingMarketEntity, List<MarketTimeline> existingMarketTimeLines, MarketTimelineRequest? currStepMarketTimelineRequest)
        {
            int marketCurrStepOrder =
                allStepDefList.Where(x => x.StepDefId.Equals(existingMarketEntity.StepDefId)).Select(x => x.StepOrder).FirstOrDefault();

            //LOOP THROUGH ALL STEPS AND CHECK
            //  CURRENT STEP: WILL BE MARKED AS PER MARKET STATUS
            //  PAST STEPS  : WILL BE MARKED SKIPPED ONLY IF ALREADY NO OTHER STATUS ASSIGNED
            //  FUTURE STEPS: WILL BE RESET IF ALREADY COMPLETED IN PAST THEN MARK PENDING BUT IF FORCE CLOUSRE THEN MARK SKIP
            List<MarketTimeline> updatedEntityList = new List<MarketTimeline>();

            foreach (var stepDefEntity in allStepDefList)
            {
                foreach (var existingMarketTimeLine in existingMarketTimeLines)
                {
                    if (existingMarketTimeLine.StepDefId.Equals(stepDefEntity.StepDefId))
                    {
                        string? updatedTimelineStatusByStep = existingMarketTimeLine.StatusCodeId;
                        DateTime? updatedAssignmentDueDateByStep = existingMarketTimeLine.AssignmentDueDate;
                        DateTime? updatedAssignmentFollowUpDateByStep = existingMarketTimeLine.AssignmentFollowUpDate;

                        //PAST STEPS HANDLING
                        if (stepDefEntity.StepOrder < marketCurrStepOrder)
                        {
                            if (existingMarketTimeLine.StatusCodeId == null
                                || existingMarketTimeLine.StatusCodeId.Equals(nameof(GenericStatusCodes.PEND)))
                                updatedTimelineStatusByStep = nameof(GenericStatusCodes.SKIP);
                            else if (existingMarketTimeLine.StatusCodeId.Equals(nameof(GenericStatusCodes.ACTI)))
                                updatedTimelineStatusByStep = nameof(GenericStatusCodes.COMP);
                        }
                        //CURRENT STEP HANDLING
                        else if (stepDefEntity.StepOrder.Equals(marketCurrStepOrder))
                        {
                            updatedTimelineStatusByStep = existingMarketEntity.StatusCodeId;
                            updatedAssignmentDueDateByStep = currStepMarketTimelineRequest.AssignmentDueDate;
                            updatedAssignmentFollowUpDateByStep = currStepMarketTimelineRequest.AssignmentFollowUpDate;
                        }
                        //FUTURE STEPS HANDLING
                        else
                        {
                            string? existingMarketStatusGroupCode = allStepStatusCodes
                                .Where(x => x.StatusCodeId.Equals(existingMarketEntity.StatusCodeId))
                                .Select(x => x.StatusGroupCode)
                                .FirstOrDefault();

                            if (existingMarketStatusGroupCode.Equals(nameof(GenericStatusGroupCodes.ACTI)))
                            {
                                updatedTimelineStatusByStep = nameof(GenericStatusCodes.PEND);
                            }
                            if (existingMarketStatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP)))
                            {
                                updatedTimelineStatusByStep = nameof(GenericStatusCodes.SKIP);
                            }
                        }

                        if (!DataCompareUtility.IsEquals(existingMarketTimeLine?.StatusCodeId, updatedTimelineStatusByStep)
                            || !DataCompareUtility.IsEquals(existingMarketTimeLine?.AssignmentDueDate, updatedAssignmentDueDateByStep)
                            || !DataCompareUtility.IsEquals(existingMarketTimeLine?.AssignmentFollowUpDate, updatedAssignmentFollowUpDateByStep))
                        {

                            

                            if (!DataCompareUtility.IsEquals(existingMarketTimeLine?.StatusCodeId, updatedTimelineStatusByStep))
                            {
                                BpstatusCode? timelinePrevStatusCodeEntity = allStepStatusCodes
                                    .Where(x => x.StatusCodeId.Equals(existingMarketTimeLine.StatusCodeId)).SingleOrDefault();
                                BpstatusCode? timelineCurrStatusCodeEntity = allStepStatusCodes
                                    .Where(x => x.StatusCodeId.Equals(updatedTimelineStatusByStep)).SingleOrDefault();

                                existingMarketTimeLine.PrevStatusCodeId = existingMarketTimeLine.StatusCodeId;
                                existingMarketTimeLine.PrevStatusCode = timelinePrevStatusCodeEntity;
                                existingMarketTimeLine.StatusCodeId = updatedTimelineStatusByStep;
                                existingMarketTimeLine.StatusCode = timelineCurrStatusCodeEntity;
                            }

                            if (!DataCompareUtility.IsEquals(existingMarketTimeLine?.AssignmentDueDate, updatedAssignmentDueDateByStep))
                                existingMarketTimeLine.AssignmentDueDate = updatedAssignmentDueDateByStep;
                            if (!DataCompareUtility.IsEquals(existingMarketTimeLine?.AssignmentFollowUpDate, updatedAssignmentFollowUpDateByStep))
                                existingMarketTimeLine.AssignmentFollowUpDate = updatedAssignmentFollowUpDateByStep;

                            existingMarketTimeLine.Version = existingMarketTimeLine.Version != null ? existingMarketTimeLine.Version + 1 : 1;
                            existingMarketTimeLine.UpdatedBy = securityUserId;
                            existingMarketTimeLine.UpdatedDate = DateTime.Now;                            
                            existingMarketTimeLine.LastStepStatusUpdatedDate = DateTime.Now;
                            existingMarketTimeLine.LastStepStatusUpdatedBy = securityUserId;
                        }
                        updatedEntityList.Add(existingMarketTimeLine);
                    }
                }
            }
            return updatedEntityList;
        }
        private List<MarketTaskMeta> BuildUpdateMarketTaskEntity(string? securityUserId, Strategy? strategyEntity,
            List<BpstatusCode> allStepStatusCodes, List<TaskStatusCode> allTaskStatusCodes,
            Market? existingMarketEntity, MarketTimelineRequest? currStepMarketTimelineRequest,
            StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {
            List<MarketTaskMeta> existingMarketTaskEntityList = existingMarketEntity.MarketTaskMeta.ToList();
            foreach (var existingMarketTaskEntity in existingMarketTaskEntityList)
            {
                TaskStack updatedTaskStack =
                    BuildUpdateTaskEntity(securityUserId, strategyEntity,
                            allStepStatusCodes, allTaskStatusCodes,
                            existingMarketEntity, existingMarketTaskEntity.TaskStack, currStepMarketTimelineRequest,
                            currStepDefEntity, currSubStepDefEntity);

                existingMarketTaskEntity.TaskStack = updatedTaskStack;
                existingMarketTaskEntity.UpdatedBy = securityUserId;
                existingMarketTaskEntity.UpdatedDate = DateTime.Now;
            }
            return existingMarketTaskEntityList;
        }
        private TaskStack BuildUpdateTaskEntity(string? securityUserId, Strategy? strategyEntity,
            List<BpstatusCode> allStepStatusCodes, List<TaskStatusCode> allTaskStatusCodes,
            Market existingMarketEntity, TaskStack existingTaskStackEntity, MarketTimelineRequest? currStepMarketTimelineRequest,
            StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {
            MarketTimeline? marketCurrStepTimeline =
               existingMarketEntity.MarketTimelines
               .Where(x => x.StepDefId.Equals(currStepDefEntity.StepDefId)).FirstOrDefault();

            existingTaskStackEntity.TaskName = currStepDefEntity.StepName;
            existingTaskStackEntity.TaskDesc = currSubStepDefEntity.SubStepName;
            existingTaskStackEntity.TaskNotes = existingMarketEntity.Notes;
            existingTaskStackEntity.TaskDueDate = marketCurrStepTimeline.AssignmentDueDate;
            existingTaskStackEntity.TaskFollowUpDate = marketCurrStepTimeline.AssignmentDueDate;

            string? evaluatedTaskStatusCodeId = evaluateTaskStatusByStepStatus(existingMarketEntity.StatusCodeId);
            if (!DataCompareUtility.IsEquals(existingTaskStackEntity?.TaskStatusCodeId, evaluatedTaskStatusCodeId))
            {
                TaskStatusCode? taskPrevStatusCodeEntity =
                    allTaskStatusCodes.Where(x => x.TaskStatusCodeId.Equals(existingTaskStackEntity?.TaskStatusCodeId)).SingleOrDefault();
                TaskStatusCode? taskCurrStatusCodeEntity =
                    allTaskStatusCodes.Where(x => x.TaskStatusCodeId.Equals(evaluatedTaskStatusCodeId)).SingleOrDefault();

                existingTaskStackEntity.PrevTaskStatusCodeId = existingTaskStackEntity?.TaskStatusCodeId;
                existingTaskStackEntity.PrevTaskStatusCode = taskPrevStatusCodeEntity;
                existingTaskStackEntity.TaskStatusCodeId = evaluatedTaskStatusCodeId;
                existingTaskStackEntity.TaskStatusCode = taskCurrStatusCodeEntity;
            }

            foreach (var existingTaskMeta in existingTaskStackEntity.TaskMeta)
            {
                existingTaskMeta.StrategyTimelineId = marketCurrStepTimeline?.StrategyTimelineId;
                existingTaskMeta.UpdatedBy = securityUserId;
                existingTaskMeta.UpdatedDate = DateTime.Now;
            }

            List<TaskStep> existingTaskStepEntityList = existingTaskStackEntity.TaskSteps.ToList();
            if (existingTaskStepEntityList != null)
            {
                foreach (TaskStep existingTaskStepEntity in existingTaskStepEntityList)
                {
                    bool isAnyChangeInStep = false;
                    string? marketTimelineStatusByStep =
                        existingMarketEntity.MarketTimelines
                        .Where(x => x.StepDefId.Equals(existingTaskStepEntity.StepDefId))
                        .Select(x => x.StatusCodeId)
                        .FirstOrDefault();

                    if (!DataCompareUtility.IsEquals(existingTaskStepEntity.StatusCodeId, marketTimelineStatusByStep))
                    {
                        BpstatusCode? taskStepCurrStatusCodeEntity = allStepStatusCodes
                            .Where(x => x.StatusCodeId.Equals(marketTimelineStatusByStep)).SingleOrDefault();

                        isAnyChangeInStep = true;
                        existingTaskStepEntity.StatusCodeId = marketTimelineStatusByStep;
                        existingTaskStepEntity.StatusCode = taskStepCurrStatusCodeEntity;
                    }

                    //IF CURRENT STEP THEN REFER REQUEST FOR STEP ASSIGNMENT
                    if (existingTaskStepEntity.StepDefId.Equals(currStepDefEntity.StepDefId))
                    {
                        List<StrategyStaff> strategyStaffEntityList = strategyEntity.StrategyStaffs.ToList();
                        List<TaskAssignment>? existingTaskAssignments = existingTaskStepEntity.TaskAssignments?.ToList();
                        List<StrategyStaff>? requestedAssignments = new List<StrategyStaff>();

                        if (currStepMarketTimelineRequest.StepAssignments != null && currStepMarketTimelineRequest.StepAssignments.Count > 0)
                        {
                            List<Guid?> requestCurrStepAssignmentStrategyStaffIds =
                               currStepMarketTimelineRequest.StepAssignments?.Select(x => x.StrategyStaffId).ToList();
                            requestedAssignments =
                                        strategyStaffEntityList
                                        .Where(x => requestCurrStepAssignmentStrategyStaffIds.Contains(x.StrategyStaffId)).ToList();
                        }

                        if (IsAnyChangeDetectedInAssignments(existingTaskAssignments, requestedAssignments))
                        {
                            isAnyChangeInStep = true;
                            existingTaskStepEntity.TaskAssignments =
                                BuildUpdateTaskAssignment(securityUserId, existingTaskStepEntity,
                                                requestedAssignments);
                        }

                        if (isAnyChangeInStep)
                        {
                            existingTaskStepEntity.Version = existingTaskStepEntity.Version != null ? existingTaskStepEntity.Version + 1 : 1;
                            existingTaskStepEntity.UpdatedBy = securityUserId;
                            existingTaskStepEntity.UpdatedDate = DateTime.Now;
                            existingTaskStepEntity.LastStepStatusUpdatedBy = securityUserId;
                            existingTaskStepEntity.LastStepStatusUpdatedDate = DateTime.Now;                           
                        }
                    }
                }
                existingTaskStackEntity.TaskSteps = existingTaskStepEntityList;
            }
            existingTaskStackEntity.Version = existingTaskStackEntity.Version != null ? existingTaskStackEntity.Version + 1 : 1;
            existingTaskStackEntity.UpdatedBy = securityUserId;
            existingTaskStackEntity.UpdatedDate = DateTime.Now;
            existingTaskStackEntity.LastTaskStatusUpdatedDate = DateTime.Now;
            existingTaskStackEntity.LastTaskStatusUpdatedBy = securityUserId;

            return existingTaskStackEntity;
        }
        private List<TaskAssignment> BuildUpdateTaskAssignment(string? securityUserId, TaskStep existingTaskStepEntity,
            List<StrategyStaff>? requestedAssignments)
        {
            List<TaskAssignment>? bulkMergeStepAssignmentEntityList = new List<TaskAssignment>();
            if (requestedAssignments != null && requestedAssignments.Count > 0)
            {
                List<string?> requestedAssignedSagittaStaffIds =
                    requestedAssignments.Select(x => x.SagittaStaffId).ToList();

                //delete if staff assignments already exist but not in request - it means they are removed and we need to remove from db also
                List<TaskAssignment>? existingTaskAssignmentEntityList = existingTaskStepEntity.TaskAssignments?.ToList();
                if (existingTaskAssignmentEntityList != null && existingTaskAssignmentEntityList.Count > 0)
                {
                    foreach (TaskAssignment existingTaskAssignmentEntity in existingTaskAssignmentEntityList)
                    {
                        if (requestedAssignedSagittaStaffIds == null
                               || (requestedAssignedSagittaStaffIds != null && !requestedAssignedSagittaStaffIds.Contains(existingTaskAssignmentEntity.TaskAssignTo)))
                        {
                            existingTaskAssignmentEntity.IsDeleted = true;
                            existingTaskAssignmentEntity.UpdatedDate = DateTime.Now;
                            existingTaskAssignmentEntity.UpdatedBy = securityUserId;
                            existingTaskAssignmentEntity.Version = existingTaskAssignmentEntity.Version != null ? existingTaskAssignmentEntity.Version + 1 : 1;
                            bulkMergeStepAssignmentEntityList.Add(existingTaskAssignmentEntity);
                        }
                    }
                }
                //CHECK IF NEW STAFF ASSIGN AND IF EXISTING THEN NO CHANGE
                foreach (StrategyStaff requestedAssignment in requestedAssignments)
                {
                    TaskAssignment? existingTaskAssignmentEntity = null;
                    if (existingTaskAssignmentEntityList != null && existingTaskAssignmentEntityList.Count > 0)
                    {
                        existingTaskAssignmentEntity =
                            existingTaskAssignmentEntityList.FirstOrDefault(x => x.TaskAssignTo.Equals(requestedAssignment.SagittaStaffId));
                    }

                    if (existingTaskAssignmentEntity != null)
                    {
                        bulkMergeStepAssignmentEntityList.Add(existingTaskAssignmentEntity);
                    }
                    else
                    {
                        TaskAssignment newTaskAssignmentEntity = new TaskAssignment();
                        newTaskAssignmentEntity.TaskAssignmentId = Guid.NewGuid();
                        newTaskAssignmentEntity.ParentTaskAssignmentId = null;
                        newTaskAssignmentEntity.TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID);
                        newTaskAssignmentEntity.TaskAssignTo = requestedAssignment.SagittaStaffId;
                        newTaskAssignmentEntity.TaskAssignDate = DateTime.Now;
                        newTaskAssignmentEntity.HasLocked = false;
                        newTaskAssignmentEntity.IsActive = true;
                        newTaskAssignmentEntity.IsDelegated = false;
                        newTaskAssignmentEntity.IsDeleted = false;
                        newTaskAssignmentEntity.Version = 1;
                        newTaskAssignmentEntity.CreatedBy = securityUserId;
                        newTaskAssignmentEntity.CreatedDate = DateTime.Now;
                        newTaskAssignmentEntity.TaskStep = existingTaskStepEntity;
                        bulkMergeStepAssignmentEntityList.Add(newTaskAssignmentEntity);
                    }
                }
            }
            return bulkMergeStepAssignmentEntityList;
        }

        private string evaluateNewMarketStatus(StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {
            string? evaluatedStatus = null;
            bool isMarketForceClosure =
                isMarketEligibleForForceClosure(currStepDefEntity, currSubStepDefEntity);
            bool isMarketFullClosure =
                isMarketEligibleForFullClosure(currStepDefEntity, currSubStepDefEntity);

            if (isMarketForceClosure || isMarketFullClosure)
            {
                if (isMarketForceClosure)
                    evaluatedStatus = isMarketForceClosure ? nameof(GenericStatusCodes.COMPI) : nameof(GenericStatusCodes.ACTI);
                if (isMarketFullClosure)
                    evaluatedStatus = isMarketFullClosure ? nameof(GenericStatusCodes.COMP) : nameof(GenericStatusCodes.ACTI);
            }
            else
            {
                evaluatedStatus = nameof(GenericStatusCodes.ACTI);
            }

            return evaluatedStatus;
        }
        private string evaluateExistingMarketStatus(Market? existingMarketEntity, StepDef? currStepDefEntity, SubStepDef? currSubStepDefEntity)
        {
            string? evaluatedStatus = existingMarketEntity.StatusCodeId;

            if (!DataCompareUtility.IsEquals(existingMarketEntity?.StepDefId, currStepDefEntity.StepDefId)
                || !DataCompareUtility.IsEquals(existingMarketEntity?.SubStepDefId, currSubStepDefEntity.StepDefId))
            {
                bool isMarketForceClosure = isMarketEligibleForForceClosure(currStepDefEntity, currSubStepDefEntity);
                bool isMarketFullClosure = isMarketEligibleForFullClosure(currStepDefEntity, currSubStepDefEntity);

                if (isMarketForceClosure || isMarketFullClosure)
                {


                    if (!existingMarketEntity.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusCodes.COMP)))
                    {
                        if (isMarketForceClosure)
                            evaluatedStatus = nameof(GenericStatusCodes.COMPI);
                        if (isMarketFullClosure)
                            evaluatedStatus = nameof(GenericStatusCodes.COMP);
                    }
                }
                else
                {
                    if (existingMarketEntity.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusCodes.COMP)))
                    {
                        evaluatedStatus = nameof(GenericStatusCodes.ACTI);
                    }
                }
            }

            return evaluatedStatus;
        }
        private string evaluateTaskStatusByStepStatus(string stepStatus)
        {
            string? taskStatus = null;
            switch (stepStatus)
            {
                case "ARCH":
                case "CANC":
                case "REMO":
                case "SKIP":
                    taskStatus = stepStatus;
                    break;
                case "COMP":
                    taskStatus = nameof(TaskStatusCodes.CLOS); ;
                    break;
                case "COMPI":
                case "INAC":
                    taskStatus = nameof(TaskStatusCodes.CLOSI); ;
                    break;
                default:
                    taskStatus = nameof(TaskStatusCodes.OPEN);
                    break;
            }
            return taskStatus;
        }

        #endregion

        #region RESPONSE RELATED
        private void MapStepAssignmentsByMarkets(List<MarketModel>? marketList)
        {
            List<StepTimelineStaffAssignment>? stepStaffAssignmentList = null;

            if (marketList != null && marketList.Count > 0)
            {
                List<Guid> stepTimeLineIds = ExtractTimelinesIdByMarkets(marketList);
                if (stepTimeLineIds != null && stepTimeLineIds.Count > 0)
                {
                    stepStaffAssignmentList =
                       _taskStackrepository.GetStaffAssignedByMarketsTimelines(stepTimeLineIds);
                    if (stepStaffAssignmentList != null && stepStaffAssignmentList.Count > 0)
                    {
                        List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList =
                            _mapper.Map<List<StepTimelineStaffAssignmentModel>>(stepStaffAssignmentList);
                        AssignStaffAssignmentsByMarkets(marketList, stepTimelineStaffAssignedResponseList);
                    }
                }

            }
        }
        private void MapStepAssignmentsByMarket(MarketModel? market)
        {
            List<StepTimelineStaffAssignment>? stepStaffAssignmentList = null;

            List<Guid> stepTimeLineIds = ExtractTimelinesIdByMarket(market);
            if (stepTimeLineIds != null && stepTimeLineIds.Count > 0)
            {
                stepStaffAssignmentList =
                   _taskStackrepository.GetStaffAssignedByMarketsTimelines(stepTimeLineIds);
                if (stepStaffAssignmentList != null && stepStaffAssignmentList.Count > 0)
                {
                    List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList =
                        _mapper.Map<List<StepTimelineStaffAssignmentModel>>(stepStaffAssignmentList);
                    AssignStaffAssignmentsByMarket(market, stepTimelineStaffAssignedResponseList);
                }
            }
        }
        private List<Guid> ExtractTimelinesIdByMarkets(List<MarketModel> marketModelList)
        {
            List<Guid> stepTimeLineIds = new List<Guid>();

            if (marketModelList != null && marketModelList.Count > 0)
            {
                List<Guid?>? marketTimelineIds = marketModelList?.SelectMany(opt => opt.MarketTimelines
                                                    .Select(x => x.MarketTimelineId))?.ToList();
                if (marketTimelineIds != null && marketTimelineIds.Count > 0)
                    stepTimeLineIds.AddRange(marketTimelineIds.Where(id => id.HasValue).Select(id => id.Value));
            }
            return stepTimeLineIds;
        }
        private List<Guid> ExtractTimelinesIdByMarket(MarketModel marketModel)
        {
            List<Guid> stepTimeLineIds = new List<Guid>();

            if (marketModel != null && marketModel.MarketTimelines != null && marketModel.MarketTimelines.Count > 0)
            {
                List<Guid?>? marketTimelineIds = marketModel?.MarketTimelines.Select(x => x.MarketTimelineId)?.ToList();
                if (marketTimelineIds != null && marketTimelineIds.Count > 0)
                    stepTimeLineIds.AddRange(marketTimelineIds.Where(id => id.HasValue).Select(id => id.Value));
            }
            return stepTimeLineIds;
        }
        private void AssignStaffAssignmentsByMarkets(List<MarketModel>? marketList,
           List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList)
        {
            foreach (var market in marketList)
            {
                AssignStaffAssignmentsByMarket(market, stepTimelineStaffAssignedResponseList);
            }
        }
        private void AssignStaffAssignmentsByMarket(MarketModel market,
            List<StepTimelineStaffAssignmentModel>? stepTimelineStaffAssignedResponseList)
        {
            if (stepTimelineStaffAssignedResponseList != null
                && stepTimelineStaffAssignedResponseList.Count > 0
                && market.MarketTimelines != null
                && market.MarketTimelines.Count > 0)
            {
                foreach (MarketTimelineModel marketTimeline in market.MarketTimelines)
                {
                    marketTimeline.StepAssignments =
                    stepTimelineStaffAssignedResponseList.Where(x => x.StepTimelineId.Equals(marketTimeline.MarketTimelineId)).ToList();
                }
            }
        }
        #endregion

        #region GENERIC
        private bool IsAnyChangeDetectedMarket(Market? existingMarketEntity, MarketRequest marketUpdateRequest)
        {
            if (!DataCompareUtility.IsEquals(existingMarketEntity.StepDefId, marketUpdateRequest.StepDefId)
                || !DataCompareUtility.IsEquals(existingMarketEntity.SubStepDefId, marketUpdateRequest.SubStepDefId)
                || !DataCompareUtility.IsEquals(existingMarketEntity.SagittaPolicyId, marketUpdateRequest.SagittaPolicyId)
                || !DataCompareUtility.IsEquals(existingMarketEntity.IsSagPol, marketUpdateRequest.IsSagPol)
                || !DataCompareUtility.IsEquals(existingMarketEntity.CovId, marketUpdateRequest.CovId)
                || !DataCompareUtility.IsEquals(existingMarketEntity.CovCode, marketUpdateRequest.CovCode)
                || !DataCompareUtility.IsEquals(existingMarketEntity.CovDesc, marketUpdateRequest.CovDesc)
                || !DataCompareUtility.IsEquals(existingMarketEntity.GrpNumber, marketUpdateRequest.GrpNumber)
                || !DataCompareUtility.IsEquals(existingMarketEntity.PremiumAmt, marketUpdateRequest.PremiumAmt)
                || !DataCompareUtility.IsEquals(existingMarketEntity.UnderwriterId, marketUpdateRequest.UnderwriterId)
                || !DataCompareUtility.IsEquals(existingMarketEntity.UnderwriterVersion, marketUpdateRequest.UnderwriterVersion)
                || !DataCompareUtility.IsEquals(existingMarketEntity.IsIncumbent, marketUpdateRequest.IsIncumbent)
                || !DataCompareUtility.IsEquals(existingMarketEntity.Notes, marketUpdateRequest.Notes)
                || !DataCompareUtility.IsEquals(existingMarketEntity.SubmissionSentDateTime, marketUpdateRequest.SubmissionSentDateTime)
                || !DataCompareUtility.IsEquals(existingMarketEntity.QuoteRecievedDateTime, marketUpdateRequest.QuoteRecievedDateTime)
                || !DataCompareUtility.IsEquals(existingMarketEntity.IsDeleted, marketUpdateRequest.IsDeleted)
                )
                return true;
            else
                return false;
        }
        private bool IsAnyChangeInMarketAddlCoverages(List<MarketAddlCov>? existingMarketAddlCovEntityList, List<MarketAddlCovRequest>? marketAddlCoverageRequests)
        {
            bool isAnyChange = false;
            int existingAddlCovCount = 0;
            int reqAddlCovCount = 0;

            if (marketAddlCoverageRequests != null && marketAddlCoverageRequests.Count > 0)
                reqAddlCovCount = marketAddlCoverageRequests.Count;

            if (existingMarketAddlCovEntityList != null && existingMarketAddlCovEntityList.Count > 0)
                existingAddlCovCount = existingMarketAddlCovEntityList.Count;

            if (existingAddlCovCount != reqAddlCovCount)
            {
                isAnyChange = true;
            }
            else
            {
                foreach (var existingMarketAddlCovEntity in existingMarketAddlCovEntityList)
                {
                    if (!marketAddlCoverageRequests.Any(x => x.MarketAddlCovId.Equals(existingMarketAddlCovEntity.MarketAddlCovId)))
                    {
                        isAnyChange = true;
                    }
                }
            }

            return isAnyChange;
        }
        private bool IsAnyChangeDetectedMarketAddlCov(MarketAddlCov marketAddlCovEntity, MarketAddlCovRequest marketAddlCovRequest)
        {
            if (!DataCompareUtility.IsEquals(marketAddlCovEntity.CovId, marketAddlCovRequest.CovId)
                || !DataCompareUtility.IsEquals(marketAddlCovEntity.CovCode, marketAddlCovRequest.CovCode)
                || !DataCompareUtility.IsEquals(marketAddlCovEntity.CovDesc, marketAddlCovRequest.CovDesc)
                || !DataCompareUtility.IsEquals(marketAddlCovEntity.IsDeleted, marketAddlCovRequest.IsDeleted)
                )
                return true;
            else
                return false;
        }
        private bool isMarketEligibleForForceClosure(StepDef stepDefEntity, SubStepDef subStepDefEntity)
        {
            if (stepDefEntity.IsValidForTaskAutoClose.Equals(true) || subStepDefEntity.IsValidForTaskAutoClose.Equals(true))
                return true;
            else
                return false;
        }
        private bool isMarketEligibleForFullClosure(StepDef stepDefEntity, SubStepDef subStepDefEntity)
        {
            if (stepDefEntity.StepDefId.Equals(AppConstants.MARKET_FULLCOMPLETE_STEPCODE)
                && subStepDefEntity.SubStepDefId.Equals(AppConstants.MARKET_FULLCOMPLETE_SUBSTEPDEFCODE))
                return true;
            else
                return false;
        }
        private bool IsAnyChangeDetectedInAssignments(List<TaskAssignment>? existingTaskAssignments, List<StrategyStaff>? requestedAssignments)
        {
            bool isAnyChange = false;
            int existingAssignCount = 0;
            int requestedAssignCount = 0;

            if (existingTaskAssignments != null && existingTaskAssignments.Count > 0)
                existingAssignCount = existingTaskAssignments.Count;

            if (requestedAssignments != null && requestedAssignments.Count > 0)
                requestedAssignCount = requestedAssignments.Count;

            if (existingAssignCount != requestedAssignCount)
            {
                isAnyChange = true;
            }
            else
            {
                foreach (var existingTaskAssignment in existingTaskAssignments)
                {
                    if (!requestedAssignments.Any(x => x.SagittaStaffId.Equals(existingTaskAssignment.TaskAssignTo)))
                    {
                        isAnyChange = true;
                    }
                }
            }

            return isAnyChange;
        }
        #endregion

        //private MarketsHistory BuildMarketHistoryEntity(Market existingMarketEntity)
        //{
        //    List<MarketAddlCovHistory> marketAddlCovHistories = new List<MarketAddlCovHistory>();
        //    MarketAddlCovHistory marketAddlCovHistory = null;

        //    //List<MarketHistory> marketHistories = new List<MarketHistory>();
        //    MarketsHistory marketHistory = new MarketsHistory();
        //    //getMarketHistory = new MarketHistory();

        //    foreach (var existMarketProp in typeof(Market).GetProperties())
        //    {
        //        var marketHistProp = typeof(MarketsHistory).GetProperty(existMarketProp.Name);
        //        if (marketHistProp != null && marketHistProp.PropertyType == existMarketProp.PropertyType)
        //        {
        //            marketHistProp.SetValue(marketHistory, existMarketProp.GetValue(existingMarketEntity));
        //        }
        //    }
        //    foreach (var existMarkAddlCov in existingMarketEntity.MarketAddlCovs)
        //    {
        //        marketAddlCovHistory = new MarketAddlCovHistory();
        //        foreach (var existMarketAddlCovProp in typeof(MarketAddlCov).GetProperties())
        //        {
        //            var marketAddlCovHistProp = typeof(MarketAddlCovHistory).GetProperty(existMarketAddlCovProp.Name);
        //            if (marketAddlCovHistProp != null && marketAddlCovHistProp.PropertyType == existMarketAddlCovProp.PropertyType)
        //            {
        //                marketAddlCovHistProp.SetValue(marketAddlCovHistory, existMarketAddlCovProp.GetValue(existMarkAddlCov));
        //            }
        //        }
        //        marketAddlCovHistory.MarketAddlCovHistoryId = Guid.NewGuid();
        //        marketAddlCovHistories.Add(marketAddlCovHistory);
        //    }

        //    marketHistory.MarketHistoryId = Guid.NewGuid();
        //    marketHistory.MarketAddlCovHistories = marketAddlCovHistories.ToList();

        //    return marketHistory;
        //}
        #endregion
    }
}