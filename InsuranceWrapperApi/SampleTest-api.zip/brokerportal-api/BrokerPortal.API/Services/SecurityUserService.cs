﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.Utilities;


namespace BrokerPortal.API.Services
{
    public class SecurityUserService : ISecurityUserService
    {
        private readonly ISecurityUserRepository _repository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;

        public SecurityUserService(IConfiguration config, ISecurityUserRepository repository, IMapper mapper)
        {
            _config = config;
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<string?> GetEmployeeIdBySecurityUserId(string? securityUserId)
        {
            string? securityUserEmployeeId = await _repository.GetEmployeeIdBySecurityUserId(securityUserId);
            return securityUserEmployeeId;
        }
        public async Task<List<string>?> GetExternalSystemIdsBySecurityUserId(string? securityUserId, string externalSystemId)
        {
            List<string>? externalSystemUserIds = null;
            //PULL EXTERNAL SYSTEM MAPPING
            List<SecurityUserMapExternalSystem>? existingUserExternalSysMapList =
                        await _repository.GetSecurityUserMapExternalSystemUserList(securityUserId, externalSystemId);
            if(existingUserExternalSysMapList!=null && existingUserExternalSysMapList.Count>0)
                externalSystemUserIds = existingUserExternalSysMapList.Select(x => x.ExternalSystemUserId).ToList();
            return externalSystemUserIds;
        }

        public async Task<List<string>?> GetSecurityUserIdsByExternalSystemUserIds(string externalSystemId, string[]? externalSystemUserIds)
        {
            List<string>? securityUserIds = 
                await _repository.GetSecurityUserIdsByExternalSystemUserIds(externalSystemId, externalSystemUserIds);
            return securityUserIds;
        }
        public async Task<bool> BulkMergeUserMapExternalSystem(string? securityUserId, 
            string externalSystemId, List<string> externalSystemUserIds)
        {

            //PULL EXTERNAL SYSTEM MAPPING
            List<SecurityUserMapExternalSystem>? existingUserExternalSysMapList =
                        await _repository.GetSecurityUserMapExternalSystemUserList(securityUserId, externalSystemId);

            List<SecurityUserMapExternalSystem>? newUserExternalSysMapList = new List<SecurityUserMapExternalSystem>();
            foreach (var externalSystemUserId in externalSystemUserIds)
            {
                SecurityUserMapExternalSystem? existingUserSagittaMap = null;
                //IF SAME STAFF MAPPING EXISTS THEN SKIP ELSE ADD MAPPING (We can have multiple sagitta staff map to same security user)
                if (existingUserExternalSysMapList != null && existingUserExternalSysMapList.Count > 0)
                {
                    existingUserSagittaMap =
                            existingUserExternalSysMapList.Where(x => x.ExternalSystemId.Equals(externalSystemId)
                            && x.ExternalSystemUserId.Equals(externalSystemUserId)).FirstOrDefault();
                }
                if (existingUserSagittaMap == null)
                {
                    SecurityUserMapExternalSystem newEntity =
                        BuildNewSecurityUserMapExternalSystemEntity(securityUserId, externalSystemId, externalSystemUserId);
                    if (newEntity != null)
                        newUserExternalSysMapList.Add(newEntity);
                }
            }

            if (newUserExternalSysMapList != null && newUserExternalSysMapList.Count > 0)
                newUserExternalSysMapList = await _repository.BulkSaveSecurityUserMapExternalSystemUserList(newUserExternalSysMapList);
            return true;
        }

        private SecurityUserMapExternalSystem BuildNewSecurityUserMapExternalSystemEntity(string securityUserId,
            string externalSystemId, string externalSystemUserId)
        {
            SecurityUserMapExternalSystem newEntity = null;
            if (!string.IsNullOrEmpty(securityUserId) && !string.IsNullOrEmpty(externalSystemUserId))
            {
                newEntity = new SecurityUserMapExternalSystem();
                newEntity.MapExternalSystemId = Guid.NewGuid();
                newEntity.SecurityUserId = securityUserId;
                newEntity.ExternalSystemId = externalSystemId;
                newEntity.ExternalSystemUserId = externalSystemUserId;
                newEntity.IsActive = true;
                newEntity.CreatedBy = AppConstants.SYSTEM_USER_ID;
                newEntity.CreatedDate = DateTime.Now;
            }
            return newEntity;
        }
    }
}
