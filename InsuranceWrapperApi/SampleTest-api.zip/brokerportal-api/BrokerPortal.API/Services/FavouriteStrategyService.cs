﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts.Views;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.Services
{
    public class FavouriteStrategyService : IFavouriteStrategyService
    {

        private readonly IFavouriteStrategyRepository _repository;
        private readonly ISagittaStaffRepository _sagittaStaffRepository;
        private readonly ISecurityUserRepository _securityUserRepository;
        private readonly IMapper _mapper;
        public FavouriteStrategyService(IFavouriteStrategyRepository repository, ISagittaStaffRepository sagittaStaffRepository,
            ISecurityUserRepository securityUserRepository, IMapper mapper)
        {

            _repository = repository;
            _sagittaStaffRepository = sagittaStaffRepository;
            _securityUserRepository = securityUserRepository;
            _mapper = mapper;
        }

        public async Task<List<FavouriteStrategyModel>> GetAllFavouriteStrategies()
        {
            List<FavouriteStrategyModel> responseList = new List<FavouriteStrategyModel>();
            List<FavouriteStrategy> entityList = await _repository.GetAllFavouriteStrategies();
            if (entityList != null || entityList.Count > 0)
            {
                responseList = _mapper.Map<List<FavouriteStrategyModel>>(entityList);
                MapNestedPropertiesToFavModelList(entityList, responseList);
            }

            return responseList;
        }

        public async Task<FavouriteStrategyModel> GetFavouriteStrategyById(Guid favoriteStrategyId)
        {
            FavouriteStrategyModel response = new FavouriteStrategyModel();
            FavouriteStrategy entity = await _repository.GetFavouriteStrategyById(favoriteStrategyId);

            if (entity != null)
            {
                response = _mapper.Map<FavouriteStrategyModel>(entity);
                MapNestedPropertiesToFavModel(entity, response);
            }

            return response;
        }
        public async Task<FavouriteStrategyModel> SaveFavouriteStrategy(string securityUserId, FavouriteStrategyRequest favouriteStrategyRequest)
        {
            FavouriteStrategyModel response = new FavouriteStrategyModel();
            FavouriteStrategy entity = new FavouriteStrategy();
            entity.FavouriteStrategyId = Guid.NewGuid();
            entity.StrategyId = favouriteStrategyRequest.StrategyId;
            entity.SecurityUserId = securityUserId;
            entity.CreatedBy = securityUserId;
            entity.CreatedDate = DateTime.Now;
            entity.IsDeleted = false;

            FavouriteStrategy existingEntity = await _repository.GetFavouriteStrategyByStrategyId(favouriteStrategyRequest.StrategyId, securityUserId);
            if (existingEntity != null)
                return response;

            var result = await _repository.SaveFavouriteStrategy(entity);
            if (entity != null)
            {
                response = _mapper.Map<FavouriteStrategyModel>(entity);
                MapNestedPropertiesToFavModel(entity, response);
            }
            return response;
        }

        public async Task<FavouriteStrategyModel> UpdateFavouriteStrategy(string securityUserId, Guid favoriteStrategyId, FavouriteStrategyRequest favouriteStrategyRequest)
        {
            FavouriteStrategyModel response = new FavouriteStrategyModel();
            FavouriteStrategy entity = new FavouriteStrategy();
            entity.FavouriteStrategyId = favoriteStrategyId;
            entity.UpdatedBy = securityUserId;
            entity.UpdatedDate = DateTime.Now;
            entity.IsDeleted = true;

            var result = await _repository.UpdateFavouriteStrategy(entity);
            if (entity != null)
            {
                response = _mapper.Map<FavouriteStrategyModel>(entity);
                MapNestedPropertiesToFavModel(entity, response);
            }
            return response;
        }

        public async Task<List<FavouriteStrategyModel>> GetFavouriteStrategiesByUser(string securityUserId)
        {
            List<FavouriteStrategyModel> responseList = new List<FavouriteStrategyModel>();

            List<string>? mapUserSagStaffIds = 
                await _securityUserRepository.GetSecurityUserMapExternalSystemUserIds(securityUserId, AppConstants.EXTERNAL_SYS_SAGITTA);
            string[] sagittaStaffIds = mapUserSagStaffIds != null ? mapUserSagStaffIds.ToArray() : null;

            List<FavouriteStrategyView> entityList = await _repository.GetFavouriteStrategiesByUser(securityUserId, sagittaStaffIds);
            if (entityList != null || entityList.Count > 0)
                responseList = _mapper.Map<List<FavouriteStrategyModel>>(entityList);

            return responseList;
        }

        #region PRIVATE
        private void MapNestedPropertiesToFavModelList(List<FavouriteStrategy>? entityList, List<FavouriteStrategyModel> modelList)
        {
            if (entityList != null && entityList.Count > 0 && modelList != null && modelList.Count > 0)
            {
                foreach (var model in modelList)
                {
                    FavouriteStrategy? entity = entityList.Where(x => x.FavouriteStrategyId.Equals(model.FavouriteStrategyId)).FirstOrDefault();
                    MapNestedPropertiesToFavModel(entity, model);
                }
            }

        }
        private void MapNestedPropertiesToFavModel(FavouriteStrategy? entity, FavouriteStrategyModel model)
        {
            if (entity != null
                && model != null)
            {
                if (entity.Strategy != null)
                {
                    model.StrategyName = entity.Strategy.StrategyName;
                    model.PlanId = entity.Strategy.PlanId;
                    if (entity.Strategy.Plan != null)
                    {
                        model.PlanName = entity.Strategy.Plan.PlanName;
                        if (entity.Strategy.Plan.PlanClients != null && entity.Strategy.Plan.PlanClients.Count > 0)
                        {
                            model.SagittaClientId = entity.Strategy.Plan.PlanClients.ToArray()[0].SagittaClientId.ToString();
                            model.ClientCode = entity.Strategy.Plan.PlanClients.ToArray()[0].SagittaClient.ClientCode;
                            model.ClientName = entity.Strategy.Plan.PlanClients.ToArray()[0].SagittaClient.ClientName;
                        }
                    }
                }
            }

        }
        #endregion

    }
}
