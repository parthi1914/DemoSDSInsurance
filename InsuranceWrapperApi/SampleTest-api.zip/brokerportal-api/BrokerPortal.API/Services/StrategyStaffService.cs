﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;


namespace BrokerPortal.API.Services
{
    public class StrategyStaffService : IStrategyStaffService
    {
        private readonly IStrategyStaffRepository _repository;
        private readonly ITaskStackRepository _taskStackRepository;
        private readonly IMapper _mapper;

        public StrategyStaffService(IStrategyStaffRepository strategyRepository, ITaskStackRepository taskStackRepository, IMapper mapper)
        {
            _repository = strategyRepository;
            _taskStackRepository = taskStackRepository;
            _mapper = mapper;
        }

        public async Task<List<StrategyStaffModel>> GetStrategyStaffs(Guid? strategyId)
        {
            List<StrategyStaff> strategyStaffs = _repository.GetStrategyStaffs(strategyId);
            var strategyStaffResponseList = _mapper.Map<List<StrategyStaffModel>>(strategyStaffs);

            List<StepTimelineStaffAssignment>? strategyStaffAssignmentEntityList = _taskStackRepository.GetStrategyStaffAssignmentsByStrategy(strategyId);
            if (strategyStaffAssignmentEntityList != null && strategyStaffAssignmentEntityList.Count > 0)
                AttachStrategyStaffAssignments(strategyStaffAssignmentEntityList, strategyStaffResponseList);

            return strategyStaffResponseList;
        }

        public async Task<List<StrategyStaffModel>> BulkMergeStrategyStaffs(Guid? strategyId, string? securityUserId, List<StaffRequest> strategyStaffRequests)
        {
            List<StrategyStaff> mergeStrategyStaffEntityList = null;
            if (strategyStaffRequests != null && strategyStaffRequests.Count > 0)
            {
                List<StrategyStaff> existingStrategyStaffEntityList = _repository.GetStrategyStaffs(strategyId);
                mergeStrategyStaffEntityList = BuildUpsertStaffEntityList(strategyId, securityUserId, existingStrategyStaffEntityList, strategyStaffRequests);
                if (mergeStrategyStaffEntityList != null && mergeStrategyStaffEntityList.Count > 0)
                {
                    await _repository.TrackStaffsChanges(mergeStrategyStaffEntityList);
                    await _repository.BulkMergeWithSubEntities(mergeStrategyStaffEntityList);
                }                    
            }
            var strategyStaffResponseList = _mapper.Map<List<StrategyStaffModel>>(mergeStrategyStaffEntityList);
            return strategyStaffResponseList;
        }

        public async Task<bool> DeleteStrategyStaff(string? securityUserId, Guid? strategyStaffId)
        {
            await _repository.DeleteStrategyStaff(securityUserId, strategyStaffId);
            return true;
        }

        public List<StrategyStaffModel> BuildDefaultStrategyStaffsFromClient(Guid? strategyId, List<StrategyTimelineModel>? strategyTimelineList, SagittaStaffResponse securityUserSagittaStaff, SagittaClientResponse? sagittaClientResponse)
        {
            List<StrategyStaffModel> defaultStaffList = new List<StrategyStaffModel>();
            if (sagittaClientResponse != null)
            {

                string? strategyOwnerSagittaStaffId = securityUserSagittaStaff != null ? securityUserSagittaStaff.SagittaStaffId : null;
                bool isMaeAssigned = false;

                var producers = sagittaClientResponse?.Producers?.ToList();
                var servicers = sagittaClientResponse?.Servicers?.ToList();
                var serviceTeams = sagittaClientResponse?.ServiceTeams?.ToList();
                producers?.AddRange(servicers ?? Enumerable.Empty<SagittaStaffResponse>());
                producers?.AddRange(serviceTeams ?? Enumerable.Empty<SagittaStaffResponse>());
                producers?.Add(securityUserSagittaStaff ?? new SagittaStaffResponse());
                producers = producers?
                             .Where(x => x.isActive.Equals(true))
                             .GroupBy(item => item.SagittaStaffId)
                             .Select(group => group.First())
                             .ToList();

                if (producers != null || producers?.Count != 0)
                {
                    foreach (var sagittaStaffResponse in producers ?? Enumerable.Empty<SagittaStaffResponse>())
                    {
                        StrategyStaffModel strategyStaff = new StrategyStaffModel();
                        SagittaStaffModel strategyStaffSagittaDetails = ConvertSagittaStaffResponseToModel(sagittaStaffResponse);
                        strategyStaff.StrategyId = strategyId;
                        strategyStaff.SagittaStaffId = strategyStaffSagittaDetails.SagittaStaffId;
                        strategyStaff.IsAccessible = true;
                        strategyStaff.IsMae = false;
                        strategyStaff.StaffDetails = strategyStaffSagittaDetails;
                        defaultStaffList.Add(strategyStaff);
                    }
                    if (defaultStaffList != null && defaultStaffList.Count > 0)
                    {
                        var defaultStaffSagIds = defaultStaffList.Select(x => x.SagittaStaffId).ToList();
                        var serviceTeamList = sagittaClientResponse?.ServiceTeams?
                                .Where(x => defaultStaffSagIds.Contains(x.SagittaStaffId)).ToList();
                        if (serviceTeamList != null && serviceTeamList.Count > 0)
                        {
                            foreach (var serviceTeam in serviceTeamList)
                            {
                                foreach (var defaultStaff in defaultStaffList)
                                {
                                    if (defaultStaff.SagittaStaffId.Equals(serviceTeam.SagittaStaffId)
                                        && isServiceTeamTitleEligbleForMarketer(serviceTeam.StaffServiceTeamTitle))
                                    {
                                        AssignMarketerRoleToStrategyStaff(defaultStaff, strategyTimelineList);
                                        isMaeAssigned = true;
                                        break;
                                    }
                                }
                            }
                        }

                        if (!isMaeAssigned)
                        {
                            var servicer = sagittaClientResponse?.Servicers?
                                .Where(x => defaultStaffSagIds.Contains(x.SagittaStaffId)).FirstOrDefault();
                            foreach (var defaultStaff in defaultStaffList)
                            {
                                if (servicer != null && servicer.StaffIndex.Equals(1)
                                    && defaultStaff.SagittaStaffId.Equals(servicer.SagittaStaffId))
                                {
                                    AssignMarketerRoleToStrategyStaff(defaultStaff, strategyTimelineList);
                                    isMaeAssigned = true;
                                    break;
                                }
                            }
                            if (!isMaeAssigned && strategyOwnerSagittaStaffId != null)
                            {
                                var strategyOwnerStaff = defaultStaffList.Where(x => x.SagittaStaffId.Equals(strategyOwnerSagittaStaffId)).FirstOrDefault();
                                AssignMarketerRoleToStrategyStaff(strategyOwnerStaff, strategyTimelineList);
                            }
                        }
                    }
                }
            }
            return defaultStaffList;
        }

        #region PrivateMethods

        private List<StrategyStaff> BuildUpsertStaffEntityList(Guid? strategyId, string? securityUserId,
            List<StrategyStaff> existingStrategyStaffEntityList, List<StaffRequest> strategyStaffRequests)
        {
            List<StrategyStaff> mergeStrategyStaffEntityList = new List<StrategyStaff>();

            if (existingStrategyStaffEntityList != null && existingStrategyStaffEntityList.Count > 0)
            {
                //First mark delete already existing staffs
                //To cover if any staff exist in db active but UI is removing that staff from request instead deleted flag
                //then update existing staff from request and that will update the existing staff including deleted flag if request contains that staff
                foreach (StrategyStaff markDelExistingStrategyStaffEntity in existingStrategyStaffEntityList)
                {
                    //mark delete flag true for existing staffs
                    markDelExistingStrategyStaffEntity.IsDeleted = true;
                    markDelExistingStrategyStaffEntity.UpdatedDate = DateTime.Now;
                    markDelExistingStrategyStaffEntity.UpdatedBy = securityUserId;
                    markDelExistingStrategyStaffEntity.Version = markDelExistingStrategyStaffEntity.Version + 1;
                }
            }

            //Loop through each strategy staff request and build entity based on new/update
            foreach (var strategyStaffRequest in strategyStaffRequests)
            {
                StrategyStaff? mergeStrategyStaffEntity = null;
                StrategyStaff? existingStrategyStaffEntity = null;
                if(existingStrategyStaffEntityList!=null && existingStrategyStaffEntityList.Count>0)
                {
                    existingStrategyStaffEntity = 
                        existingStrategyStaffEntityList.FirstOrDefault(x => x.StrategyStaffId.Equals(strategyStaffRequest.StrategyStaffId));
                }                

                if (existingStrategyStaffEntity != null)
                {                    
                    mergeStrategyStaffEntity =
                        BuildUpdateStrategyStaffEntity(strategyId, securityUserId, existingStrategyStaffEntity, strategyStaffRequest);
                }
                else
                {
                    mergeStrategyStaffEntity =
                        BuildNewStrategyStaffEntity(strategyId, securityUserId, strategyStaffRequest);
                }
                mergeStrategyStaffEntityList.Add(mergeStrategyStaffEntity);
            }
            return mergeStrategyStaffEntityList;
        }

        private StrategyStaff BuildUpdateStrategyStaffEntity(Guid? strategyId, string? securityUserId,
            StrategyStaff existingStrategyStaffEntity, StaffRequest strategyStaffRequest)
        {
            existingStrategyStaffEntity.IsMae = strategyStaffRequest.IsMae ?? false;
            existingStrategyStaffEntity.IsAccessible = strategyStaffRequest.IsAccessible ?? false;
            existingStrategyStaffEntity.IsDeleted = strategyStaffRequest.IsDeleted ?? false;
            existingStrategyStaffEntity.UpdatedBy = securityUserId;
            existingStrategyStaffEntity.UpdatedDate = DateTime.Now;
            existingStrategyStaffEntity.Version = existingStrategyStaffEntity.Version + 1;
            return existingStrategyStaffEntity;
        }

        private StrategyStaff BuildNewStrategyStaffEntity(Guid? strategyId, string? securityUserId, StaffRequest strategyStaffRequest)
        {
            StrategyStaff newStaffEntity = new StrategyStaff();
            newStaffEntity.StrategyId = strategyId;
            newStaffEntity.StrategyStaffId = Guid.NewGuid();
            newStaffEntity.SagittaStaffId = strategyStaffRequest.SagittaStaffId;
            newStaffEntity.IsMae = strategyStaffRequest.IsMae ?? false;
            newStaffEntity.IsAccessible = strategyStaffRequest.IsAccessible ?? false;
            newStaffEntity.IsDeleted = false;
            newStaffEntity.CreatedBy = securityUserId;
            newStaffEntity.CreatedDate = DateTime.Now;
            newStaffEntity.Version = 1;
            return newStaffEntity;
        }

        private bool isServiceTeamTitleEligbleForMarketer(string? serviceTeamTitle)
        {
            if (!string.IsNullOrEmpty(serviceTeamTitle)
                && (serviceTeamTitle.Trim().Equals("Marketing Account Executive")
                || serviceTeamTitle.Trim().Equals("Client Account Executive")
                || serviceTeamTitle.Trim().Equals("Marketing Lead"))
                )
                return true;
            else
                return false;
        }

        private void AssignMarketerRoleToStrategyStaff(StrategyStaffModel strategyStaff, List<StrategyTimelineModel>? strategyTimelineList)
        {
            strategyStaff.IsMae = true;
            List<StepTimelineStaffAssignmentModel> strategyStaffAssignmentModels = new List<StepTimelineStaffAssignmentModel>();
            foreach (var strategyTimeline in strategyTimelineList)
            {
                StepTimelineStaffAssignmentModel strategyStaffAssignmentModel = new StepTimelineStaffAssignmentModel();
                strategyStaffAssignmentModel.TaskAssignmentId = null;
                strategyStaffAssignmentModel.StrategyStaffId = null;
                strategyStaffAssignmentModel.StepDefId = strategyTimeline.StepDefId;
                strategyStaffAssignmentModel.IsDeleted = false;
                strategyStaffAssignmentModels.Add(strategyStaffAssignmentModel);
            }
            strategyStaff.StrategyStaffAssignments = strategyStaffAssignmentModels;
        }
        private SagittaStaffModel ConvertSagittaStaffResponseToModel(SagittaStaffResponse sagittaStaffResponse)
        {
            SagittaStaffModel sagittaStaffModel = new SagittaStaffModel();
            sagittaStaffModel.SagittaStaffId = sagittaStaffResponse.SagittaStaffId;
            sagittaStaffModel.StaffName = sagittaStaffResponse.StaffName;
            sagittaStaffModel.StaffCode = sagittaStaffResponse.StaffCode;
            sagittaStaffModel.StaffTitle = sagittaStaffResponse.StaffTitle;
            sagittaStaffModel.StaffEmail = sagittaStaffResponse.EmailAddress;
            sagittaStaffModel.DatedOffDate = sagittaStaffResponse.ActiveByDate ?? null;
            sagittaStaffModel.Address1 = sagittaStaffResponse.Address1;
            sagittaStaffModel.Address2 = sagittaStaffResponse.Address2;
            sagittaStaffModel.City = sagittaStaffResponse.City;
            sagittaStaffModel.State = sagittaStaffResponse.State;
            sagittaStaffModel.DivCode = sagittaStaffResponse.DivisionNo;
            sagittaStaffModel.DeptCode = sagittaStaffResponse.dept;
            sagittaStaffModel.isDatedOff = sagittaStaffResponse.isActive != null && sagittaStaffResponse.isActive.Equals(true) ? false : true;
            sagittaStaffModel.MobilePhone = sagittaStaffResponse.MobilePhone;
            sagittaStaffModel.EmployeeType = sagittaStaffResponse.EmployeeType??null;
            sagittaStaffModel.UserId = sagittaStaffResponse.UserId;
            sagittaStaffModel.StaffEmpCode = sagittaStaffResponse.StaffEmpCode;
            sagittaStaffModel.StaffNetworkId = sagittaStaffResponse.StaffNetworkId;
            sagittaStaffModel.StaffServiceTeamTitle = sagittaStaffResponse.StaffServiceTeamTitle;
            sagittaStaffModel.StaffServiceTeamProdCredit = sagittaStaffResponse.StaffServiceTeamProdCredit;
            return sagittaStaffModel;
        }

        private void AttachStrategyStaffAssignments(List<StepTimelineStaffAssignment>? strategyStaffAssignmentEntityList,
            List<StrategyStaffModel> strategyStaffResponseList)
        {
            if (strategyStaffResponseList != null && strategyStaffResponseList.Count > 0)
            {
                foreach (var strategyStaffResponse in strategyStaffResponseList)
                {
                    List<StepTimelineStaffAssignmentModel> strategyStaffAssignmentModels = new List<StepTimelineStaffAssignmentModel>();

                    if (strategyStaffAssignmentEntityList != null && strategyStaffAssignmentEntityList.Count > 0)
                    {
                        List<StepTimelineStaffAssignment>? selectedStaffAssignmentEntityList =
                        strategyStaffAssignmentEntityList.Where(x => x.StrategyStaffId.Equals(strategyStaffResponse.StrategyStaffId)).ToList();
                        if (selectedStaffAssignmentEntityList != null && selectedStaffAssignmentEntityList.Count > 0)
                        {
                            strategyStaffAssignmentModels = _mapper.Map<List<StepTimelineStaffAssignmentModel>>(selectedStaffAssignmentEntityList);
                            strategyStaffResponse.StrategyStaffAssignments = strategyStaffAssignmentModels;
                        }
                    }
                }
            }
        }
        #endregion
    }
}
