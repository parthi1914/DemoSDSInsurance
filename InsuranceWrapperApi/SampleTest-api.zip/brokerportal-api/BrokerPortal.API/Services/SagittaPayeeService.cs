﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.Services
{
    public class SagittaPayeeService : ISagittaPayeeService
    {
        private readonly ISagittaPayeeRepository _repository;
        private readonly IMapper _mapper;

        public SagittaPayeeService(ISagittaPayeeRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public List<SagittaPayeeModel> BulkMergeSagittaPayees(string? securityUserId, List<SagittaPayeeRequest> sagittaPayeeRequests)
        {
            List<SagittaPayeeModel> mergeResponse = null;

            List<SagittaPayee> syncSagittaPayeeEntityList = new List<SagittaPayee>();
            List<string?> sagittaPayeeIds = new List<string?>();
            bool isAnySagittaPayeeAlreadyExists = false;

            if (sagittaPayeeRequests != null && sagittaPayeeRequests.Count > 0)
            {
                sagittaPayeeIds = sagittaPayeeRequests.Select(x => x.SagittaPayeeId).ToList();

                List<SagittaPayee> existingSagittaPayeeEntityList = _repository.GetSagittaPayeesByIds(sagittaPayeeIds.ToArray());
                if (existingSagittaPayeeEntityList != null && existingSagittaPayeeEntityList.Count > 0)
                    isAnySagittaPayeeAlreadyExists = true;

                foreach (var sagittaPayeeRequest in sagittaPayeeRequests)
                {
                    SagittaPayee? existingSagittaPayeeEntity = null;
                    if (isAnySagittaPayeeAlreadyExists)
                        existingSagittaPayeeEntity = existingSagittaPayeeEntityList.FirstOrDefault(x => x.SagittaPayeeId.Equals(sagittaPayeeRequest.SagittaPayeeId));

                    existingSagittaPayeeEntity = BuildUpsertSagittaPayeeEntity(sagittaPayeeRequest, existingSagittaPayeeEntity, isAnySagittaPayeeAlreadyExists, securityUserId);
                    if (existingSagittaPayeeEntity != null)
                        syncSagittaPayeeEntityList.Add(existingSagittaPayeeEntity);
                }
            }

            if (syncSagittaPayeeEntityList != null && syncSagittaPayeeEntityList.Count > 0)
                _repository.BulkMerge(syncSagittaPayeeEntityList);

            mergeResponse = _mapper.Map<List<SagittaPayeeModel>>(syncSagittaPayeeEntityList);
            return mergeResponse;
        }


        public void MergeSagittaPayee(string? securityUserId, SagittaPayeeRequest sagittaPayeeRequest)
        {
            //SagittaPayeeModel mergeResponse = null;

            List<SagittaPayee> syncSagittaPayeeEntityList = new List<SagittaPayee>();
            List<string?> sagittaPayeeIds = new List<string?>();
            bool isAnySagittaPayeeAlreadyExists = false;

            if (sagittaPayeeRequest != null )
            {
                SagittaPayee existingSagittaPayeeEntityList = _repository.GetSagittaPayeeById(sagittaPayeeRequest.SagittaPayeeId);
                    SagittaPayee? existingSagittaPayeeEntity = null;
                   
                    existingSagittaPayeeEntity = BuildUpsertSagittaPayeeEntity(sagittaPayeeRequest, existingSagittaPayeeEntity, isAnySagittaPayeeAlreadyExists, securityUserId);
                    if (existingSagittaPayeeEntity != null)
                        syncSagittaPayeeEntityList.Add(existingSagittaPayeeEntity);
            }

            if (syncSagittaPayeeEntityList != null && syncSagittaPayeeEntityList.Count > 0)
                _repository.BulkMerge(syncSagittaPayeeEntityList);

            //mergeResponse = _mapper.Map<SagittaPayeeModel>(syncSagittaPayeeEntityList.FirstOrDefault());
            //return mergeResponse;
        }

        #region PrivateMethods
        private SagittaPayee BuildUpsertSagittaPayeeEntity(SagittaPayeeRequest sagittaPayeeRequest, SagittaPayee existingSagittaPayeeEntity, bool isAnySagittaPayeeAlreadyExists, string securityUserId)
        {
            bool isValidForDBChange = false;
            SagittaPayee? syncSagittaPayeeEntity = null;


            if (existingSagittaPayeeEntity != null)
            {
                if (IsAnyChangeDetectedSagittaPayees(sagittaPayeeRequest, existingSagittaPayeeEntity))
                {
                    isValidForDBChange = true;
                    syncSagittaPayeeEntity = existingSagittaPayeeEntity;
                    syncSagittaPayeeEntity.UpdatedBy = securityUserId;
                    syncSagittaPayeeEntity.UpdatedDate = DateTime.Now;
                }
            }
            else if (existingSagittaPayeeEntity == null)
            {
                isValidForDBChange = true;
                syncSagittaPayeeEntity = new SagittaPayee();
                syncSagittaPayeeEntity.CreatedBy = securityUserId;
                syncSagittaPayeeEntity.CreatedDate = DateTime.Now;
            }
            if (isValidForDBChange)
            {
                syncSagittaPayeeEntity.SagittaPayeeId = sagittaPayeeRequest.SagittaPayeeId;
                syncSagittaPayeeEntity.PayeeCode = sagittaPayeeRequest.PayeeCode;
                syncSagittaPayeeEntity.PayeeName = sagittaPayeeRequest.PayeeName;
                syncSagittaPayeeEntity.IsDatedOff = sagittaPayeeRequest.IsDatedOff ?? false;
                syncSagittaPayeeEntity.IsSagSync = true;
                syncSagittaPayeeEntity.LastSagSyncDate = DateTime.Now;

            }

            return syncSagittaPayeeEntity;
        }
        private bool IsAnyChangeDetectedSagittaPayees(SagittaPayeeRequest sagittaPayeeRequest, SagittaPayee? existingSagittaPayeeEntity)
        {
            if (!DataCompareUtility.IsEquals(sagittaPayeeRequest.PayeeName, existingSagittaPayeeEntity.PayeeName))
                return true;
            else
                return false;
        }
        #endregion

    }
}