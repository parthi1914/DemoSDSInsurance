﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Plan;
using BrokerPortal.API.Utilities;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;

namespace BrokerPortal.API.Services
{
    public class PlanService : IPlanService
    {
        private readonly IPlanRepository _repository;
        private readonly IStrategyRepository _strategyRepository;
        private readonly IMapper _mapper;
        public PlanService(IPlanRepository planRepository, IStrategyRepository strategyRepository, IMapper mapper)
        {
            _repository = planRepository;
            _strategyRepository = strategyRepository;
            _mapper = mapper;
        }

        public async Task<List<PlanResponse>> GetAllPlans()
        {
            List<PlanResponse> planList = new List<PlanResponse>();
            List<Plan> plans = await _repository.GetAllPlans();
            var planResponseList = _mapper.Map<List<PlanResponse>>(plans);

            foreach (var plan in planResponseList)
            {
                var sagitta = _mapper.Map<PlanClientDetailsResponse>(plans.SingleOrDefault(a => a.PlanId == plan.PlanId).PlanClients.SingleOrDefault().SagittaClient);
                plan.PlanClients = sagitta;
            }

            return planResponseList;
        }

        public async Task<PlanResponse> GetPlanById(Guid planId)
        {
            PlanResponse planResponse = new PlanResponse();
            if (planId != Guid.Empty)
            {
                var plan = await _repository.GetPlanById(planId);
                if (plan != null)
                {
                    planResponse = _mapper.Map<PlanResponse>(plan);
                    var planClientResponse = _mapper.Map<PlanClientDetailsResponse>(plan.PlanClients.SingleOrDefault().SagittaClient);
                    planResponse.PlanClients = planClientResponse;
                    planResponse.PlanClients.PlanClientId = plan.PlanClients.SingleOrDefault().PlanClientId;
                }
            }

            return planResponse;
        }

        public async Task<PlanResponse> SavePlan(PlanRequest planRequest)
        {
            PlanResponse planResponse = new PlanResponse();
            Plan planEntity = BuildNewPlan(planRequest);
            planEntity = await _repository.SavePlan(planEntity);

            planResponse = await GetPlanById(planEntity.PlanId);
            return planResponse;
        }

        public async Task<PlanResponse> UpdatePlan(PlanRequest planUpdateRequest, Guid planId)
        {
            PlanResponse planResponse = new PlanResponse();

            Plan existingPlanEntity = await _repository.FetchForUpdatePlanAndStrategiesByPlan(planId);
            ValidatePlanUpdateRequest(existingPlanEntity, planUpdateRequest);
            existingPlanEntity = BuildUpdatePlanAndTimelines(existingPlanEntity, planUpdateRequest);

            if (existingPlanEntity.Strategies != null && existingPlanEntity.Strategies.Count > 0)
                existingPlanEntity.Strategies =
                         BuildUpdateStrategyAndTimelinesByPlan(existingPlanEntity.Strategies.ToList(), planUpdateRequest);

            existingPlanEntity = await _repository.UpdatePlan(existingPlanEntity);

            planResponse = await GetPlanById(planId);
            return planResponse;
        }

        public async Task<bool> RemovePlan(Guid planId, string securityUserId)
        {
            await _repository.RemovePlan(planId, securityUserId);
            await _strategyRepository.RemoveStrategyByPlan(planId, securityUserId);
            return true;
        }

        public async Task<bool> ArchivePlan(Guid planId, string securityUserId)
        {
            await _repository.ArchivePlan(planId, securityUserId);
            await _strategyRepository.ArchiveStrategyByPlan(planId, securityUserId);
            return true;
        }

        #region PRIVATE
        private void ValidatePlanUpdateRequest(Plan existingPlanEntity, PlanRequest planUpdateRequest)
        {
            if (existingPlanEntity == null)
                throw new Exception("Plan doesnt exists!");

            if (planUpdateRequest.PlanClients == null)
                throw new Exception("Plan Client doesnt exists!");

            bool isSTaffAlreadyExist = _repository.DoesValidStratgyStaffExistsOnPlan(existingPlanEntity.PlanId) ?? false;
            if (isSTaffAlreadyExist
                && !existingPlanEntity.PlanClients.SingleOrDefault().SagittaClientId.Equals(planUpdateRequest.PlanClients.SagittaClientId))
                throw new Exception("Change of Client on existing plan is not allowed!");
        }

        private Plan BuildNewPlan(PlanRequest planRequest)
        {
            PlanClientDetailsRequest planClientRequest = planRequest.PlanClients;
            string securityUserId = planRequest.SecurityUsers.SecurityUserId;

            Plan planEntity = new Plan();
            planEntity.PlanId = Guid.NewGuid();
            planEntity.PlanName = planRequest.PlanName;
            planEntity.PlanEffDate = (DateTime)planRequest.PlanEffDate;
            planEntity.StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE;
            planEntity.IsDeleted = false;
            planEntity.CreatedBy = securityUserId;
            planEntity.CreatedDate = DateTime.Now;

            SagittaClient sagittaClientEntity = new SagittaClient();
            sagittaClientEntity.SagittaClientId = planClientRequest.SagittaClientId;
            sagittaClientEntity.ClientCode = planClientRequest.ClientCode;
            sagittaClientEntity.ClientName = planClientRequest.ClientName;
            sagittaClientEntity.ClientContPersId = planClientRequest.ClientContPersId ?? null;
            sagittaClientEntity.ClientContPersCode = planClientRequest.ClientContPersCode ?? null;
            sagittaClientEntity.ClientContPersName = planClientRequest.ClientContPersName ?? null;
            sagittaClientEntity.ClientContPersEmail = planClientRequest.ClientContPersEmail ?? null;
            sagittaClientEntity.ClientContPersPhone1 = planClientRequest.ClientContPersPhone1 ?? null;
            sagittaClientEntity.ClientCity = planClientRequest.ClientCity;
            sagittaClientEntity.ClientState = planClientRequest.ClientState;
            sagittaClientEntity.IsDatedOff = planClientRequest.IsDatedOff;
            sagittaClientEntity.DatedOffDate = planClientRequest.DatedOffDate;
            sagittaClientEntity.IsDeleted = false;
            sagittaClientEntity.CreatedBy = securityUserId;
            sagittaClientEntity.CreatedDate = DateTime.Now;
            sagittaClientEntity.UpdatedBy = securityUserId;
            sagittaClientEntity.UpdatedDate = DateTime.Now;

            List<PlanClient> planClientEntityList = new List<PlanClient>();
            if (sagittaClientEntity != null)
            {
                PlanClient planClientEntity = new PlanClient();
                planClientEntity.PlanClientId = Guid.NewGuid();
                planClientEntity.PlanId = planEntity.PlanId;
                planClientEntity.SagittaClientId = sagittaClientEntity.SagittaClientId;
                planClientEntity.SagittaClient = sagittaClientEntity;
                planClientEntity.IsDeleted = false;
                planClientEntity.CreatedBy = securityUserId;
                planClientEntity.CreatedDate = DateTime.Now;
                planClientEntityList.Add(planClientEntity);
                planEntity.PlanClients = planClientEntityList;
            }

            List<PlanTimeline> planTimeEntityList = new List<PlanTimeline>();
            foreach (var planTimelineRequest in planRequest.PlanTimelines)
            {
                PlanTimeline planTimelineEntity = new PlanTimeline();
                planTimelineEntity.PlanTimelineId = Guid.NewGuid();
                planTimelineEntity.PlanId = planEntity.PlanId;
                planTimelineEntity.StepDefId = planTimelineRequest.StepDefId;
                planTimelineEntity.DueDate = planTimelineRequest.DueDate;
                planTimelineEntity.IsDeleted = false;
                planTimelineEntity.CreatedBy = securityUserId;
                planTimelineEntity.CreatedDate = DateTime.Now;
                planTimeEntityList.Add(planTimelineEntity);
            }
            planEntity.PlanTimelines = planTimeEntityList;
            return planEntity;
        }

        private Plan BuildUpdatePlanAndTimelines(Plan existingPlanEntity, PlanRequest planRequest)
        {
            PlanClientDetailsRequest planClientRequest = planRequest.PlanClients;
            string securityUserId = planRequest.SecurityUsers.SecurityUserId;

            existingPlanEntity.PlanName = planRequest.PlanName;
            existingPlanEntity.PlanEffDate = (DateTime)planRequest.PlanEffDate;

            if (existingPlanEntity.PrevStatusCodeId == null
                                || !existingPlanEntity.PrevStatusCodeId.Equals(existingPlanEntity.StatusCodeId))
                existingPlanEntity.PrevStatusCodeId = existingPlanEntity.StatusCodeId;

            existingPlanEntity.UpdatedBy = securityUserId;
            existingPlanEntity.UpdatedDate = DateTime.Now;

            SagittaClient sagittaClientEntity = new SagittaClient();
            sagittaClientEntity.SagittaClientId = planClientRequest.SagittaClientId;
            sagittaClientEntity.ClientCode = planClientRequest.ClientCode;
            sagittaClientEntity.ClientName = planClientRequest.ClientName;
            sagittaClientEntity.ClientContPersId = planClientRequest.ClientContPersId ?? null;
            sagittaClientEntity.ClientContPersCode = planClientRequest.ClientContPersCode ?? null;
            sagittaClientEntity.ClientContPersName = planClientRequest.ClientContPersName ?? null;
            sagittaClientEntity.ClientContPersEmail = planClientRequest.ClientContPersEmail ?? null;
            sagittaClientEntity.ClientContPersPhone1 = planClientRequest.ClientContPersPhone1 ?? null;
            sagittaClientEntity.ClientCity = planClientRequest.ClientCity;
            sagittaClientEntity.ClientState = planClientRequest.ClientState;
            sagittaClientEntity.IsDatedOff = planClientRequest.IsDatedOff;
            sagittaClientEntity.DatedOffDate = planClientRequest.DatedOffDate;
            sagittaClientEntity.IsDeleted = false;
            sagittaClientEntity.CreatedBy = securityUserId;
            sagittaClientEntity.CreatedDate = DateTime.Now;
            sagittaClientEntity.UpdatedBy = securityUserId;
            sagittaClientEntity.UpdatedDate = DateTime.Now;

            if (sagittaClientEntity != null)
            {
                foreach (var existingPlanClientEntity in existingPlanEntity.PlanClients)
                {
                    if (!existingPlanClientEntity.SagittaClientId.Equals(sagittaClientEntity.SagittaClientId))
                    {
                        existingPlanClientEntity.SagittaClientId = sagittaClientEntity.SagittaClientId;
                        existingPlanClientEntity.UpdatedBy = securityUserId;
                        existingPlanClientEntity.UpdatedDate = DateTime.Now;
                        existingPlanClientEntity.SagittaClient = sagittaClientEntity;
                    }
                }
            }

            foreach (var existingPlanTimelineEntity in existingPlanEntity.PlanTimelines)
            {
                foreach (var planTimelineRequest in planRequest.PlanTimelines)
                {
                    if (planTimelineRequest.PlanTimelineId.Equals(existingPlanTimelineEntity.PlanTimelineId)
                        && !planTimelineRequest.DueDate.Equals(existingPlanTimelineEntity.DueDate))
                    {
                        existingPlanTimelineEntity.DueDate = planTimelineRequest.DueDate;
                        existingPlanTimelineEntity.UpdatedBy = securityUserId;
                        existingPlanTimelineEntity.UpdatedDate = DateTime.Now;
                    }
                }
            }
            return existingPlanEntity;
        }

        private List<Strategy> BuildUpdateStrategyAndTimelinesByPlan(List<Strategy> existingStrtageyEntityList, PlanRequest planRequest)
        {
            string securityUserId = planRequest.SecurityUsers.SecurityUserId;
            foreach (var existingStrtageyEntity in existingStrtageyEntityList)
            {
                existingStrtageyEntity.StrategyName = planRequest.PlanName;
                existingStrtageyEntity.StrategyEffDate = (DateTime)planRequest.PlanEffDate;
                if (existingStrtageyEntity.PrevStatusCodeId == null
                                || !existingStrtageyEntity.PrevStatusCodeId.Equals(existingStrtageyEntity.StatusCodeId))
                    existingStrtageyEntity.PrevStatusCodeId = existingStrtageyEntity.StatusCodeId;
                existingStrtageyEntity.UpdatedBy = securityUserId;
                existingStrtageyEntity.UpdatedDate = DateTime.Now;
                existingStrtageyEntity.Version = existingStrtageyEntity.Version + 1;

                foreach (var existingStrategyClientEntity in existingStrtageyEntity.StrategyClients)
                {
                    if (!existingStrategyClientEntity.SagittaClientId.Equals(planRequest.PlanClients.SagittaClientId))
                    {
                        existingStrategyClientEntity.SagittaClientId = planRequest.PlanClients.SagittaClientId;
                        existingStrategyClientEntity.UpdatedBy = securityUserId;
                        existingStrategyClientEntity.UpdatedDate = DateTime.Now;
                        existingStrategyClientEntity.Version = existingStrategyClientEntity.Version + 1;
                    }
                }
                if (planRequest.PlanTimelines != null && planRequest.PlanTimelines.Count > 0)
                {
                    var submissionDate = planRequest.PlanTimelines.Where(x => x.StepDefId.Equals(AppConstants.PLAN_STEP_STEPDEFID_MARKET))
                         .Select(x => x.DueDate).First();
                    var proposalDate = planRequest.PlanTimelines.Where(x => x.StepDefId.Equals(AppConstants.PLAN_STEP_STEPDEFID_PROPOSAL))
                        .Select(x => x.DueDate).First();
                    var quoteDate = (proposalDate - submissionDate).Days < 10 ?
                        submissionDate.AddDays(1) : proposalDate.AddDays(AppConstants.STRATEGY_STEP_QUOTE_DAYS_THRESHOLD);
                    var bindDate = planRequest.PlanTimelines.Where(x => x.StepDefId.Equals(AppConstants.PLAN_STEP_STEPDEFID_BIND))
                        .Select(x => x.DueDate).First();

                    foreach (var existingStrategyTimelineEntity in existingStrtageyEntity.StrategyTimelines)
                    {
                        if (!(existingStrategyTimelineEntity.StatusCodeId.Equals(AppConstants.STEP_STATUSCODE_ARCHIVED)
                                    || existingStrategyTimelineEntity.StatusCodeId.Equals(AppConstants.STEP_STATUSCODE_COMPLETED))
                           )
                        {
                            if (existingStrategyTimelineEntity.StepDefId == AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION)
                                existingStrategyTimelineEntity.DueDate = submissionDate;
                            if (existingStrategyTimelineEntity.StepDefId == AppConstants.STRATEGY_STEP_STEPDEFID_QUOTE)
                                existingStrategyTimelineEntity.DueDate = quoteDate;
                            if (existingStrategyTimelineEntity.StepDefId == AppConstants.STRATEGY_STEP_STEPDEFID_PROPOSAL)
                                existingStrategyTimelineEntity.DueDate = proposalDate;
                            if (existingStrategyTimelineEntity.StepDefId == AppConstants.STRATEGY_STEP_STEPDEFID_BIND)
                                existingStrategyTimelineEntity.DueDate = bindDate;

                            if (existingStrategyTimelineEntity.PrevStatusCodeId == null
                                || !existingStrategyTimelineEntity.PrevStatusCodeId.Equals(existingStrategyTimelineEntity.StatusCodeId))
                                existingStrategyTimelineEntity.PrevStatusCodeId = existingStrategyTimelineEntity.StatusCodeId;

                            existingStrategyTimelineEntity.UpdatedBy = securityUserId;
                            existingStrategyTimelineEntity.UpdatedDate = DateTime.Now;
                            existingStrategyTimelineEntity.StatusCode = null;

                            existingStrategyTimelineEntity.Version = existingStrategyTimelineEntity.Version + 1;
                        }
                    }
                }
            }

            return existingStrtageyEntityList;
        }
        #endregion

    }
}
