﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using BrokerPortal.API.Utilities;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;

namespace BrokerPortal.API.Services
{
    public class SagittaClientService : ISagittaClientService
    {
        private readonly RestServiceClient _sagittaReplService;
        private readonly ISagittaClientRepository _repository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;

        public SagittaClientService(IConfiguration config, IMapper mapper, RestServiceClient sagittaReplService, ISagittaClientRepository repository)
        {
            _mapper = mapper;
            _sagittaReplService = sagittaReplService;
            _config = config;
            _repository = repository;
        }

        public async Task<SagittaClientResponse> GetSagittaClientByIdFromRepl(string? accessToken, string sagittaClientId)
        {
            var clientReplResponse = await _sagittaReplService.GetAsync<SagittaReplClientSearchResponse>(accessToken, _config.GetSection("SagittaURL").Value + "api/sagitta/repl/clients/" + sagittaClientId);
            SagittaClientResponse sagittaClientResponse = _mapper.Map<SagittaClientResponse>(clientReplResponse);
            return sagittaClientResponse;

        }
        public async Task<SagittaClient> GetSagittaClient(string? sagittaClientId)
        {
            return await _repository.GetSagittaClient(sagittaClientId);
        }

        public async Task<bool> IsSagittaClientExists(long? sagittaClientId)
        {
            return await _repository.IsSagittaClientExists(sagittaClientId);
        }

        public async Task<SagittaClientModel> SaveSagittaClientFromReplIfNotExist(string? securityUserId, string? accessToken, string sagittaClientId)
        {
            SagittaClientModel sagittaClientResponse = new SagittaClientModel();

            // CHECK IF ALREADY EXISTS IN DB
            // IF EXIST THEN SKIP ELSE PULL FROM SAGITTA AND STORE IN DB
            SagittaClient? sagittaClientEntity = await _repository.GetSagittaClient(sagittaClientId);
            if (sagittaClientEntity == null)
            {
                SagittaClientResponse? sagittaClientFromRepl =
                    await GetSagittaClientByIdFromRepl(accessToken, sagittaClientId);

                if (sagittaClientFromRepl != null)
                {
                    sagittaClientEntity = BuildNewClientEntity(securityUserId, sagittaClientFromRepl);
                    await _repository.AddSagittaClient(sagittaClientEntity);
                }
                sagittaClientResponse = _mapper.Map<SagittaClientModel>(sagittaClientEntity);
            }
            return sagittaClientResponse;
        }
        public async Task<SagittaClientModel> UpdateSagittaClientFromRepl(string? securityUserId, string? accessToken, string sagittaClientId)
        {

            SagittaClientModel sagittaClientResponse = new SagittaClientModel();
            SagittaClient existingSagittaClientEntity =
                await _repository.GetSagittaClient(sagittaClientId.ToString());

            if (existingSagittaClientEntity != null || existingSagittaClientEntity.SagittaClientId != 0)
            {
                SagittaClientResponse? sagittaClientFromRepl =
                    await GetSagittaClientByIdFromRepl(accessToken, sagittaClientId);
                existingSagittaClientEntity = BuildUpdateClientEntity(securityUserId, existingSagittaClientEntity, sagittaClientFromRepl);
                await _repository.UpdateSagittaClient(existingSagittaClientEntity);
                sagittaClientResponse = _mapper.Map<SagittaClientModel>(existingSagittaClientEntity);
            }

            return sagittaClientResponse;
        }

        public async Task<List<SagittaClientResponse>> SearchSagittaClientsFromRepl(string? accessToken, SagittaClientSearchRequest searchRequest)
        {
            SagittaReplClientSearchRequest sagittaReplClientSearchRequest = buildSagittaReplClientSearchRequest(null, searchRequest);
            var clientReplSearchResponse = await _sagittaReplService.PostAsync<List<SagittaReplClientSearchResponse>>(accessToken, _config.GetSection("SagittaURL").Value + "api/sagitta/repl/clients/search", sagittaReplClientSearchRequest);
            List<SagittaClientResponse> sagittaClientResponseList = _mapper.Map<List<SagittaClientResponse>>(clientReplSearchResponse);
            return sagittaClientResponseList;
        }
        public async Task<List<SagittaClientResponse>> SearchFavSagittaClientsFromRepl(string? accessToken, List<FavouriteClientModel> favClientList, SagittaClientSearchRequest searchRequest)
        {
            string[] sagClientIds = favClientList.Select(x => x.SagittaClientId).ToArray();
            SagittaReplClientSearchRequest sagittaReplClientSearchRequest = buildSagittaReplClientSearchRequest(sagClientIds, searchRequest);
            var clientReplSearchResponse = await _sagittaReplService.PostAsync<List<SagittaReplClientSearchResponse>>(accessToken, _config.GetSection("SagittaURL").Value + "api/sagitta/repl/clients/search", sagittaReplClientSearchRequest);
            List<SagittaClientResponse> sagittaClientResponseList = _mapper.Map<List<SagittaClientResponse>>(clientReplSearchResponse);
            return sagittaClientResponseList;
        }

        #region PRIVATE
        private SagittaReplClientSearchRequest buildSagittaReplClientSearchRequest(string[]? sagClientIds, SagittaClientSearchRequest request)
        {
            SagittaReplClientSearchRequest sagittaReplClientSearchRequest = new SagittaReplClientSearchRequest();
            sagittaReplClientSearchRequest.searchOption = request.searchOption;
            sagittaReplClientSearchRequest.searchCondition = request.searchCondition;
            SagittaReplClientSearchCriterias sagittaReplClientSearchCriterias = new SagittaReplClientSearchCriterias();
            sagittaReplClientSearchCriterias.clientStatusOption = request.SearchCriterias.clientStatusOption;
            if (sagClientIds != null && sagClientIds.Length > 0)
                sagittaReplClientSearchCriterias.clientIds = sagClientIds;
            sagittaReplClientSearchCriterias.clientCode = request.SearchCriterias.clientCode;
            sagittaReplClientSearchCriterias.clientName = request.SearchCriterias.clientName;
            sagittaReplClientSearchCriterias.clientStatusOption = request.SearchCriterias.clientStatusOption;
            sagittaReplClientSearchCriterias.clientAssignedToStaffIds = request.SearchCriterias.clientAssignedToStaffIds;
            sagittaReplClientSearchRequest.SearchCriterias = sagittaReplClientSearchCriterias;
            return sagittaReplClientSearchRequest;
        }

        private SagittaClient BuildNewClientEntity(string securityUserId, SagittaClientResponse newClientRequest)
        {
            SagittaClient sagittaClientEntity = new SagittaClient();
            sagittaClientEntity.SagittaClientId = Convert.ToInt64(newClientRequest.SagittaClientId);
            sagittaClientEntity.ClientCode = newClientRequest.ClientCode;
            sagittaClientEntity.ClientName = newClientRequest.ClientName;
            sagittaClientEntity.ClientContPersId = newClientRequest.ClientContPersId ?? null;
            sagittaClientEntity.ClientContPersCode = newClientRequest.ClientContPersCode;
            sagittaClientEntity.ClientContPersName = newClientRequest.ClientContPersName;
            sagittaClientEntity.ClientContPersEmail = newClientRequest.ClientContPersEmail;
            sagittaClientEntity.ClientContPersPhone1 = newClientRequest.ClientContPersPhone1;
            sagittaClientEntity.ClientCity = newClientRequest.City;
            sagittaClientEntity.ClientState = newClientRequest.State;

            if (newClientRequest.isActive != null && newClientRequest.isActive.Equals(false))
            {
                sagittaClientEntity.IsDatedOff = true;
                sagittaClientEntity.DatedOffDate = null;
            }
            else
            {
                sagittaClientEntity.DatedOffDate = null;
                sagittaClientEntity.IsDatedOff = false;
            }
            sagittaClientEntity.IsDeleted = false;
            sagittaClientEntity.IsSagSync = true;
            sagittaClientEntity.LastSagSyncDate = DateTime.Now;
            sagittaClientEntity.CreatedBy = securityUserId;
            sagittaClientEntity.CreatedDate = DateTime.Now;

            return sagittaClientEntity;
        }
        private SagittaClient BuildUpdateClientEntity(string securityUserId, SagittaClient existingSagittaClientEntity, SagittaClientResponse updateClientRequest)
        {
            existingSagittaClientEntity.ClientCode = updateClientRequest.ClientCode;
            existingSagittaClientEntity.ClientName = updateClientRequest.ClientName;
            existingSagittaClientEntity.ClientContPersId = updateClientRequest.ClientContPersId ?? null;
            existingSagittaClientEntity.ClientContPersCode = updateClientRequest.ClientContPersCode;
            existingSagittaClientEntity.ClientContPersName = updateClientRequest.ClientContPersName;
            existingSagittaClientEntity.ClientContPersEmail = updateClientRequest.ClientContPersEmail;
            existingSagittaClientEntity.ClientContPersPhone1 = updateClientRequest.ClientContPersPhone1;
            existingSagittaClientEntity.ClientCity = updateClientRequest.City;
            existingSagittaClientEntity.ClientState = updateClientRequest.State;

            if (updateClientRequest.isActive != null && updateClientRequest.isActive.Equals(false))
            {
                existingSagittaClientEntity.IsDatedOff = true;
                existingSagittaClientEntity.DatedOffDate = null;
            }
            else
            {
                existingSagittaClientEntity.DatedOffDate = null;
                existingSagittaClientEntity.IsDatedOff = false;
            }
            existingSagittaClientEntity.IsDeleted = false;
            existingSagittaClientEntity.IsSagSync = true;
            existingSagittaClientEntity.LastSagSyncDate = DateTime.Now;
            existingSagittaClientEntity.UpdatedBy = securityUserId;
            existingSagittaClientEntity.UpdatedDate = DateTime.Now;

            return existingSagittaClientEntity;
        }
        #endregion

    }
}
