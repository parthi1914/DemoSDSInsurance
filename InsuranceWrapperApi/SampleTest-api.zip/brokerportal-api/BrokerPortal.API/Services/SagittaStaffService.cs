﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using BrokerPortal.API.Utilities;
using System.Collections.Generic;


namespace BrokerPortal.API.Services
{
    public class SagittaStaffService : ISagittaStaffService
    {
        private readonly RestServiceClient _sagittaReplService;
        private readonly ISagittaStaffRepository _repository;
        private readonly ISecurityUserRepository _securityUserRepository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;

        public SagittaStaffService(IConfiguration config, ISagittaStaffRepository repository,
            ISecurityUserRepository securityUserRepository, IMapper mapper, RestServiceClient sagittaReplService)
        {
            _config = config;
            _repository = repository;
            _securityUserRepository = securityUserRepository;
            _mapper = mapper;
            _sagittaReplService = sagittaReplService;
        }

        public async Task<List<SagittaStaffModel>?> BulkSaveFromReplByIdsIfNotExists(string? securityUserId, string? accessToken,
            List<string>? requestSagittaStaffIds)
        {
            List<SagittaStaffModel>? sagittaStaffResponseList = new List<SagittaStaffModel>();


            if (requestSagittaStaffIds != null && requestSagittaStaffIds.Count > 0)
            {
                List<SagittaStaff>? sagittaStaffFinalList = new List<SagittaStaff>();
                List<SagittaStaff>? existingSagittaStaffList = GetSagittaStaffsByIds(requestSagittaStaffIds.ToArray());

                if (existingSagittaStaffList != null && existingSagittaStaffList.Count > 0)
                    sagittaStaffFinalList.AddRange(existingSagittaStaffList);

                List<string>? newSagittaStaffIds = new List<string>();
                foreach (var requestSagittaStaffId in requestSagittaStaffIds)
                {
                    SagittaStaff? existingSagittaStaff =
                    existingSagittaStaffList?.Where(x => x.SagittaStaffId.Equals(requestSagittaStaffId)).FirstOrDefault();
                    if (existingSagittaStaff == null)
                        newSagittaStaffIds.Add(requestSagittaStaffId);
                }
                if (newSagittaStaffIds != null && newSagittaStaffIds.Count > 0)
                {
                    List<SagittaStaffResponse>? sagittaStaffReplResponseList =
                        await GetSagittaStaffByIdsFromRepl(accessToken, newSagittaStaffIds.ToArray());
                    List<SagittaStaff>? newSagittaStaffList =
                        BuildNewSagittaStaffList(securityUserId, sagittaStaffReplResponseList);

                    if (newSagittaStaffList != null && newSagittaStaffList.Count > 0)
                    {
                        newSagittaStaffList = await _repository.BulkMerge(newSagittaStaffList);
                        sagittaStaffFinalList.AddRange(newSagittaStaffList);
                    }
                }
                if (sagittaStaffFinalList != null && sagittaStaffFinalList.Count > 0)
                    sagittaStaffResponseList = _mapper.Map<List<SagittaStaffModel>>(sagittaStaffFinalList);
            }
            return sagittaStaffResponseList;
        }

        private List<SagittaStaff>? BuildNewSagittaStaffList(string securityUserId, List<SagittaStaffResponse>? sagittaStaffReplResponseList)
        {
            List<SagittaStaff>? newSagittaStaffEntityList = new List<SagittaStaff>();
            foreach (var sagittaStaffReplResponse in sagittaStaffReplResponseList)
            {
                SagittaStaff newSagittaStaffEntity = new SagittaStaff();
                newSagittaStaffEntity.SagittaStaffId = sagittaStaffReplResponse.SagittaStaffId;
                newSagittaStaffEntity.StaffCode = sagittaStaffReplResponse.StaffCode;
                newSagittaStaffEntity.StaffName = sagittaStaffReplResponse.StaffName ?? null;
                newSagittaStaffEntity.StaffTitle = sagittaStaffReplResponse.StaffTitle ?? null;
                newSagittaStaffEntity.StaffEmail = sagittaStaffReplResponse.EmailAddress ?? null;
                newSagittaStaffEntity.EmployeeType = sagittaStaffReplResponse.EmployeeType ?? null;
                newSagittaStaffEntity.UserId = sagittaStaffReplResponse.UserId ?? null;
                newSagittaStaffEntity.StaffEmpCode = sagittaStaffReplResponse.StaffEmpCode ?? null;
                newSagittaStaffEntity.StaffNetworkId = sagittaStaffReplResponse.StaffNetworkId ?? null;
                newSagittaStaffEntity.City = sagittaStaffReplResponse.City ?? null;
                newSagittaStaffEntity.IsDatedOff = sagittaStaffReplResponse.isActive ?? false;
                newSagittaStaffEntity.DatedOffDate = sagittaStaffReplResponse.ActiveByDate ?? null;
                newSagittaStaffEntity.IsSagSync = true;
                newSagittaStaffEntity.LastSagSyncDate = DateTime.Now;
                newSagittaStaffEntity.CreatedBy = securityUserId;
                newSagittaStaffEntity.CreatedDate = DateTime.Now;
                newSagittaStaffEntityList.Add(newSagittaStaffEntity);
            }

            return newSagittaStaffEntityList;
        }

        public async Task<List<SagittaStaffModel>> BulkMergeSagittaStaffs(string? securityUserId, List<SagittaStaffRequest> sagittaStaffRequests)
        {
            List<SagittaStaffModel> mergeResponse = null;

            List<SagittaStaff> syncSagittaStaffEntityList = new List<SagittaStaff>();
            List<string> sagittaStaffIds = new List<string>();
            bool isAnySagittaStaffAlreadyExists = false;

            if (sagittaStaffRequests != null && sagittaStaffRequests.Count > 0)
            {
                sagittaStaffIds = sagittaStaffRequests.Select(x => x.SagittaStaffId).ToList();

                List<SagittaStaff> existingSagittaStaffEntityList = _repository.GetSagittaStaffsByIds(sagittaStaffIds.ToArray());
                if (existingSagittaStaffEntityList != null && existingSagittaStaffEntityList.Count > 0)
                    isAnySagittaStaffAlreadyExists = true;

                foreach (var sagittaStaffRequest in sagittaStaffRequests)
                {
                    SagittaStaff? syncSagittaStaffEntity = null;
                    SagittaStaff? existingSagittaStaffEntity = null;
                    bool isValidForDBChange = false;

                    if (isAnySagittaStaffAlreadyExists)
                        existingSagittaStaffEntity = existingSagittaStaffEntityList.FirstOrDefault(x => x.SagittaStaffId.Equals(sagittaStaffRequest.SagittaStaffId));

                    if (existingSagittaStaffEntity != null)
                    {
                        if (IsAnyChangeDetectedSagittaStaff(sagittaStaffRequest, existingSagittaStaffEntity))
                        {
                            isValidForDBChange = true;
                            syncSagittaStaffEntity = existingSagittaStaffEntity;
                            syncSagittaStaffEntity.UpdatedBy = securityUserId;
                            syncSagittaStaffEntity.UpdatedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        isValidForDBChange = true;
                        syncSagittaStaffEntity = new SagittaStaff();
                        syncSagittaStaffEntity.SagittaStaffId = sagittaStaffRequest.SagittaStaffId;
                        syncSagittaStaffEntity.StaffCode = sagittaStaffRequest.StaffCode;
                        syncSagittaStaffEntity.CreatedBy = securityUserId;
                        syncSagittaStaffEntity.CreatedDate = DateTime.Now;
                    }
                    if (isValidForDBChange)
                    {
                        syncSagittaStaffEntity.StaffName = string.IsNullOrEmpty(sagittaStaffRequest.StaffName) ? null : sagittaStaffRequest.StaffName;
                        syncSagittaStaffEntity.StaffTitle = string.IsNullOrEmpty(sagittaStaffRequest.StaffTitle) ? null : sagittaStaffRequest.StaffTitle;
                        syncSagittaStaffEntity.StaffEmail = string.IsNullOrEmpty(sagittaStaffRequest.StaffEmail) ? null : sagittaStaffRequest.StaffEmail;
                        syncSagittaStaffEntity.IsDatedOff = sagittaStaffRequest.IsDatedOff ?? false;
                        syncSagittaStaffEntity.EmployeeType = sagittaStaffRequest.EmployeeType ?? null;
                        syncSagittaStaffEntity.UserId = string.IsNullOrEmpty(sagittaStaffRequest.UserId) ? null : sagittaStaffRequest.UserId;
                        syncSagittaStaffEntity.StaffEmpCode = string.IsNullOrEmpty(sagittaStaffRequest.StaffEmpCode) ? null : sagittaStaffRequest.StaffEmpCode;
                        syncSagittaStaffEntity.StaffNetworkId = string.IsNullOrEmpty(sagittaStaffRequest.StaffNetworkId) ? null : sagittaStaffRequest.StaffNetworkId;
                        syncSagittaStaffEntity.City = string.IsNullOrEmpty(sagittaStaffRequest.City) ? null : sagittaStaffRequest.City;
                        syncSagittaStaffEntity.DatedOffDate = sagittaStaffRequest.DatedOffDate ?? null;
                        syncSagittaStaffEntity.IsSagSync = true;
                        syncSagittaStaffEntity.LastSagSyncDate = DateTime.Now;
                        syncSagittaStaffEntityList.Add(syncSagittaStaffEntity);
                    }
                }
                if (syncSagittaStaffEntityList != null && syncSagittaStaffEntityList.Count > 0)
                    await _repository.BulkMerge(syncSagittaStaffEntityList);
            }
            mergeResponse = _mapper.Map<List<SagittaStaffModel>>(syncSagittaStaffEntityList);
            return mergeResponse;
        }

        public async Task<List<SagittaStaffModel>> BulkMergeSagittaStaffsFromReplResponse(string? securityUserId, 
            List<SagittaReplStaffModel> sagittaStaffReplRequests)
        {
            List<SagittaStaffModel>? mergeResponse = null;
            if (sagittaStaffReplRequests != null && sagittaStaffReplRequests.Count > 0)
            {
                List<SagittaStaffRequest> sagittaStaffRequestList = 
                    _mapper.Map<List<SagittaStaffRequest>>(sagittaStaffReplRequests);
                mergeResponse =
                    await BulkMergeSagittaStaffs(securityUserId, sagittaStaffRequestList);
            }
            return mergeResponse;
        }

        public async Task<SagittaStaffModel> UpsertSagittaStaff(string? securityUserId, SagittaStaffRequest sagittaStaffRequest)
        {
            SagittaStaffModel response = null;
            string? sagittaStaffId = sagittaStaffRequest.SagittaStaffId;
            SagittaStaff? existingSagittaStaffEntity = await _repository.GetSagittaStaffById(sagittaStaffId);
            SagittaStaff? syncSagittaStaffEntity = new SagittaStaff();

            if (existingSagittaStaffEntity != null)
            {
                if (IsAnyChangeDetectedSagittaStaff(sagittaStaffRequest, existingSagittaStaffEntity))
                {
                    syncSagittaStaffEntity = existingSagittaStaffEntity;
                    syncSagittaStaffEntity.UpdatedBy = securityUserId;
                    syncSagittaStaffEntity.UpdatedDate = DateTime.Now;
                    syncSagittaStaffEntity.IsSagSync = true;
                    syncSagittaStaffEntity.LastSagSyncDate = DateTime.Now;
                    syncSagittaStaffEntity = await _repository.UpdateSagittaStaff(syncSagittaStaffEntity);
                }
            }
            else
            {
                syncSagittaStaffEntity = new SagittaStaff();
                syncSagittaStaffEntity.SagittaStaffId = sagittaStaffRequest.SagittaStaffId;
                syncSagittaStaffEntity.StaffCode = sagittaStaffRequest.StaffCode;
                syncSagittaStaffEntity.StaffName = string.IsNullOrEmpty(sagittaStaffRequest.StaffName) ? null : sagittaStaffRequest.StaffName;
                syncSagittaStaffEntity.StaffTitle = string.IsNullOrEmpty(sagittaStaffRequest.StaffTitle) ? null : sagittaStaffRequest.StaffTitle;
                syncSagittaStaffEntity.StaffEmail = string.IsNullOrEmpty(sagittaStaffRequest.StaffEmail) ? null : sagittaStaffRequest.StaffEmail;
                syncSagittaStaffEntity.IsDatedOff = sagittaStaffRequest.IsDatedOff ?? false;
                syncSagittaStaffEntity.EmployeeType = sagittaStaffRequest.EmployeeType ?? null;
                syncSagittaStaffEntity.UserId = string.IsNullOrEmpty(sagittaStaffRequest.UserId) ? null : sagittaStaffRequest.UserId;
                syncSagittaStaffEntity.StaffEmpCode = string.IsNullOrEmpty(sagittaStaffRequest.StaffEmpCode) ? null : sagittaStaffRequest.StaffEmpCode;
                syncSagittaStaffEntity.StaffNetworkId = string.IsNullOrEmpty(sagittaStaffRequest.StaffNetworkId) ? null : sagittaStaffRequest.StaffNetworkId;
                syncSagittaStaffEntity.City = string.IsNullOrEmpty(sagittaStaffRequest.StaffNetworkId) ? null : sagittaStaffRequest.City;
                syncSagittaStaffEntity.DatedOffDate = sagittaStaffRequest.DatedOffDate ?? null;
                syncSagittaStaffEntity.IsSagSync = true;
                syncSagittaStaffEntity.LastSagSyncDate = DateTime.Now;
                syncSagittaStaffEntity.CreatedBy = securityUserId;
                syncSagittaStaffEntity.CreatedDate = DateTime.Now;
                syncSagittaStaffEntity = await _repository.SaveSagittaStaff(syncSagittaStaffEntity);
            }
            response = _mapper.Map<SagittaStaffModel>(syncSagittaStaffEntity);
            return response;
        }

        public async Task<List<string>?> GetSagittaStaffIdsBySecurityUserId(string? securityUserId)
        {
            List<string>? sagittaStaffIds = null;

            if (!string.IsNullOrEmpty(securityUserId))
                sagittaStaffIds = await _securityUserRepository.GetSecurityUserMapExternalSystemUserIds(securityUserId,AppConstants.EXTERNAL_SYS_SAGITTA);

            return sagittaStaffIds;
        }

        public async Task<SagittaStaffResponse> GetSagittaStaffFromRepl(string? accessToken, string sagittaStaffId)
        {
            SagittaStaffResponse sagittaStaffResponse = null;

            var sagittaStaffReplResponse = await _sagittaReplService.GetAsync<SagittaReplStaffModel>(accessToken, _config.GetSection("SagittaURL").Value + "api/sagitta/repl/staffs/" + sagittaStaffId);
            if (sagittaStaffReplResponse != null && !string.IsNullOrEmpty(sagittaStaffReplResponse.StaffId))
                sagittaStaffResponse = _mapper.Map<SagittaStaffResponse>(sagittaStaffReplResponse);

            return sagittaStaffResponse;
        }

        public async Task<List<SagittaStaffResponse>> GetSagittaStaffByIdsFromRepl(string? accessToken, string[] sagittaStaffId)
        {
            var sagittaStaffReplResponse = await _sagittaReplService.PostAsync<List<SagittaReplStaffModel>>(accessToken, _config.GetSection("SagittaURL").Value + "api/sagitta/repl/staffs/GetStaffByIds", sagittaStaffId);
            List<SagittaStaffResponse> sagittaStaffResponse = _mapper.Map<List<SagittaStaffResponse>>(sagittaStaffReplResponse);
            return sagittaStaffResponse;
        }
        public List<SagittaStaff> GetSagittaStaffsByIds(string[] sagittaStaffIds)
        {
            return _repository.GetSagittaStaffsByIds(sagittaStaffIds);
        }

        public async Task<List<SagittaReplStaffModel>?> GetMappedSagittaStaffsFromReplBySecurityUserEmployeeId(string? accessToken, 
            string securityUserId, string securityUserEmployeeId)
        {
            List<SagittaReplStaffModel>? SagittaReplStaffModelList = null;
           
            if (!string.IsNullOrEmpty(securityUserId) && !string.IsNullOrEmpty(securityUserEmployeeId))
            {
                //PULL FROM SAGITTA REPL AND INSERT THEM FIRST AND THEN RETURN
                SagittaReplStaffModelList =
                 await _sagittaReplService.GetAsync<List<SagittaReplStaffModel>>(accessToken,
                     _config.GetSection("SagittaURL").Value + "api/sagitta/repl/staffs/findmatches/employees/" + securityUserEmployeeId);
            }
            return SagittaReplStaffModelList;
        }

        private bool IsAnyChangeDetectedSagittaStaff(SagittaStaffRequest sagittaStaffRequest, SagittaStaff? existingSagittaStaffEntity)
        {
            if (!DataCompareUtility.IsEquals(sagittaStaffRequest.StaffTitle, existingSagittaStaffEntity.StaffTitle)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.StaffName, existingSagittaStaffEntity.StaffName)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.StaffEmail, existingSagittaStaffEntity.StaffEmail)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.EmployeeType, existingSagittaStaffEntity.EmployeeType)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.UserId, existingSagittaStaffEntity.UserId)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.StaffEmpCode, existingSagittaStaffEntity.StaffEmpCode)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.StaffNetworkId, existingSagittaStaffEntity.StaffNetworkId)
                || !DataCompareUtility.IsEquals(sagittaStaffRequest.City, existingSagittaStaffEntity.City)
                || ((sagittaStaffRequest.IsDatedOff ?? null) != (existingSagittaStaffEntity.IsDatedOff ?? null))
                || ((sagittaStaffRequest.DatedOffDate ?? null) != (existingSagittaStaffEntity.DatedOffDate ?? null))
                )
                return true;
            else
                return false;
        }
    }
}