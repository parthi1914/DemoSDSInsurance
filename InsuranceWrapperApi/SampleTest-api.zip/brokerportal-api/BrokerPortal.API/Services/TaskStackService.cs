﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;
using System.Collections.Generic;

namespace BrokerPortal.API.Services
{
    public class TaskStackService : ITaskStackService
    {

        private readonly ITaskStackRepository _repository;
        private readonly IStrategyRepository _strategyRepository;
        private readonly ISagittaClientService _sagittaClientService;
        private readonly ISagittaStaffService _sagittaStaffService;
        private readonly ILookupDataRepository _lookupDataRepository;
        private readonly ISagittaStaffRepository _sagittaStaffRepository;
        private readonly ISecurityUserService _securityUserService;
        private readonly IMapper _mapper;
        public TaskStackService(ITaskStackRepository repository, IStrategyRepository strategyRepository, ISagittaClientService sagittaClientService,
            ISagittaStaffService sagittaStaffService, ILookupDataRepository lookupDataRepository, ISagittaStaffRepository sagittaStaffRepository,
            ISecurityUserService securityUserService, IMapper mapper)
        {
            _repository = repository;
            _strategyRepository = strategyRepository;
            _sagittaClientService = sagittaClientService;
            _sagittaStaffService = sagittaStaffService;
            _lookupDataRepository = lookupDataRepository;
            _sagittaStaffRepository = sagittaStaffRepository;
            _securityUserService = securityUserService;
            _mapper = mapper;
        }
        public async Task<List<TaskStackModel>> GetAllTaskStacks()
        {
            List<TaskStackModel>? taskStackResponseList = null;
            List<TaskStack> taskStackEntityList = await _repository.GetAllTaskStacks();
            if (taskStackEntityList != null && taskStackEntityList.Count > 0)
            {
                taskStackResponseList = _mapper.Map<List<TaskStackModel>>(taskStackEntityList);
                MapTaskAssignToInfoToResponseList(taskStackResponseList);
            }
            return taskStackResponseList;
        }
        public async Task<TaskStackModel?> GetTaskStackById(Guid? taskStackId)
        {
            TaskStackModel? taskStackResponse = null;
            TaskStack taskStackEntity = await _repository.GetTaskStackById(taskStackId);
            if (taskStackEntity != null)
            {
                taskStackResponse = _mapper.Map<TaskStackModel>(taskStackEntity);
                MapTaskAssignToInfoToResponse(taskStackResponse);
            }
            return taskStackResponse;
        }
        public async Task<TaskStackModel> SaveTaskStack(string? securityUserId, TaskStackRequestInfo taskRequest)
        {
            TaskStackModel? taskResponse = null;

            if (taskRequest != null)
            {
                Guid? taskStackId = null;
                if (taskRequest.TaskType != null && taskRequest.TaskType.Equals(nameof(TaskRefType.GENERIC)))
                {
                    GenericTask genericTaskEntity =
                        BuildNewGenericTaskEntity(securityUserId, taskRequest);
                    genericTaskEntity = await _repository.SaveGenericTask(genericTaskEntity);
                    taskStackId = genericTaskEntity.TaskStackId;
                }
                else
                {
                    TaskStack taskEntity =
                        BuildNewTaskStackEntity(securityUserId, taskRequest);
                    taskEntity = await _repository.SaveTaskStack(taskEntity);
                    taskStackId = taskEntity.TaskStackId;
                }
                if (taskStackId != null && taskStackId != Guid.Empty)
                    taskResponse = await GetTaskStackById(taskStackId);
            }
            return taskResponse;
        }
        public async Task<TaskStackModel?> UpdateTaskStack(string? securityUserId, Guid taskStackId, TaskStackRequestInfo taskUpdateRequest)
        {
            TaskStackModel? taskStackResponse = null;
            if (taskUpdateRequest != null)
            {
                if (taskUpdateRequest.TaskType != null && taskUpdateRequest.TaskType.Equals(nameof(TaskRefType.GENERIC)))
                {
                    GenericTask? existingGenericTaskEntity = await _repository.GetGenericTaskForUpdateByTaskStackId(taskStackId);
                    if (existingGenericTaskEntity != null)
                    {
                        GenericTask genericTaskEntity =
                        BuildUpdateGenericTaskEntity(securityUserId, existingGenericTaskEntity, taskUpdateRequest);
                        List<TaskStack> taskStacks = new List<TaskStack>();
                        taskStacks.Add(genericTaskEntity.TaskStack);
                        await _repository.TrackTasksChanges(taskStacks);
                        genericTaskEntity = await _repository.UpdateGenericTask(genericTaskEntity);

                        TaskStack? taskStackEntity = await _repository.GetTaskStackById(taskStackId);
                        if (taskStackEntity != null)
                        {
                            //this is workaround as somehow it is pulling deleted assignments also which it should not
                            foreach (var step in taskStackEntity.TaskSteps)
                                step.TaskAssignments =
                                       step.TaskAssignments.Where(x => x.IsDeleted.Equals(false)).ToList();
                            taskStackResponse = _mapper.Map<TaskStackModel>(taskStackEntity);
                            MapTaskAssignToInfoToResponse(taskStackResponse);
                        }
                    }
                }
                else
                {
                    //FUTURE NEED NON GENERIC TASK UPDATE                    
                }
            }
            return taskStackResponse;
        }
        public async Task<bool> DeleteTaskStack(Guid taskStackId, string? securityUserId)
        {
            return await _repository.DeleteTaskStack(taskStackId, securityUserId);
        }
        public async Task<bool> RemoveTaskStack(Guid taskStackId, string? securityUserId)
        {
            return await _repository.RemoveTaskStack(taskStackId, securityUserId);
        }
        public async Task BulkMergeStrategyStaffsToTasks(Guid strategyId, string? securityUserId, List<StrategyStepRequest>? strategyStepAssignmentRequestList)
        {
            //WE WILL ADD/REMOVE STRATEGY STAFFS TO STRATEGY LEVEL TASKS ONLY
            //NO CHANGES REQUIRED ON MARKET LEVEL TASKS STEP ASSIGNMENT AS
            // - STRATEGY TEAM SECTIN - STEP LEVEL ASSIGNMENT CHANGES (ADD/REMOVE) DOESNT OVERRIDE MARKET LEVEL STEP ASSIGNMENTS
            // - ONLY IMPACT ON MARKET LEVEL STEP ASSIGNMENT WE NEED TO DO FOR IF ANY STAFF IS REMOVED FROM THE STRATEGY ITSELF, THEN
            //   -- IT SHOULD REMOVED FROM MARKET STEP ALSO THAT IS ALREADY HANDLED IN REMOVE TEAMMATE API            
            //ONLY CHANGE ON MARKET LEVEL TASK IS TASK DUE DATE IF ANY CHANGE IN DUE DATE

            DateTime currentDateTime = DateTime.Now;
            List<TaskStack>? existingTaskStackEntityList = await _repository.GetAllTasksByStrategyInclMarkets(strategyId);
            if (existingTaskStackEntityList != null && existingTaskStackEntityList.Count > 0)
            {
                bool isAnyTaskNeedUpdate = false;
                foreach (var existingTaskStackEntity in existingTaskStackEntityList)
                {

                    if (existingTaskStackEntity.TaskSteps != null && existingTaskStackEntity.TaskSteps.Count > 0)
                    {
                        foreach (var existingTaskStep in existingTaskStackEntity.TaskSteps)
                        {
                            bool isAnyStepAssignmentExist = false;
                            StrategyStepRequest? strategyStepAssignmentRequest =
                                strategyStepAssignmentRequestList?.Where(x => x.StepDefId.Equals(existingTaskStep.StepDefId))
                                .FirstOrDefault();

                            //Update task due date if timeline has changes this need to update on both type of tasks (strategy/market level tasks)
                            if (existingTaskStackEntity.TaskDueDate == null
                                || !existingTaskStackEntity.TaskDueDate.Equals(strategyStepAssignmentRequest.AssignmentDueDate))
                            {
                                isAnyTaskNeedUpdate = true;
                                existingTaskStackEntity.TaskDueDate = strategyStepAssignmentRequest.AssignmentDueDate;
                                existingTaskStackEntity.UpdatedBy = securityUserId;
                                existingTaskStackEntity.UpdatedDate = currentDateTime;
                                existingTaskStackEntity.Version = existingTaskStackEntity.Version + 1;
                            }

                            //Strategy Step level assignment changes needed only on startegy level tasks
                            //hence excluding market level tasks
                            if (existingTaskStackEntity.TaskMeta != null
                                && existingTaskStackEntity.TaskMeta.Any(x => x.MarketId == null))
                            {
                                // First check if existing assignment exist 
                                // if yes, then remove such assignments which doesnt exist in request (means remvoed from frontend and need to remved from db also)
                                string[]? reqStepLevelSagittaStaffIds =
                                    strategyStepAssignmentRequest.StrategyStaffAssignments.Select(x => x.SagittaStaffId).ToArray();
                                if (existingTaskStep.TaskAssignments != null && existingTaskStep.TaskAssignments.Count > 0)
                                {
                                    isAnyStepAssignmentExist = true;
                                    if (reqStepLevelSagittaStaffIds != null && reqStepLevelSagittaStaffIds.Length > 0)
                                    {
                                        List<TaskAssignment>? removeExistingTaskStepAssignmentEntityList =
                                            existingTaskStep.TaskAssignments
                                            .Where(x => x.TaskAssignmentType.Equals(nameof(TaskAssignmentType.SAGITTA_STAFF_ID))
                                                    && !reqStepLevelSagittaStaffIds.Contains(x.TaskAssignTo)).ToList();

                                        if (removeExistingTaskStepAssignmentEntityList != null && removeExistingTaskStepAssignmentEntityList.Count > 0)
                                        {
                                            foreach (var removeExistingTaskStepAssignmentEntity in removeExistingTaskStepAssignmentEntityList)
                                            {
                                                isAnyTaskNeedUpdate = true;
                                                removeExistingTaskStepAssignmentEntity.IsDeleted = true;
                                                removeExistingTaskStepAssignmentEntity.UpdatedDate = DateTime.Now;
                                                removeExistingTaskStepAssignmentEntity.UpdatedBy = securityUserId;
                                                removeExistingTaskStepAssignmentEntity.Version = removeExistingTaskStepAssignmentEntity.Version + 1;
                                            }
                                        }
                                    }
                                }

                                //Loop Through Assignment Request and
                                // Add the staff id does not exist already
                                if (strategyStepAssignmentRequest != null
                                        && strategyStepAssignmentRequest.StrategyStaffAssignments != null
                                        && strategyStepAssignmentRequest.StrategyStaffAssignments.Count > 0)
                                {
                                    List<TaskAssignment> taskAssignmentEntityList = new List<TaskAssignment>();

                                    foreach (var StrategyStaffAssignment in strategyStepAssignmentRequest.StrategyStaffAssignments)
                                    {
                                        bool isAssignmentExist = false;
                                        if (existingTaskStep.TaskAssignments != null && existingTaskStep.TaskAssignments.Count > 0)
                                        {
                                            TaskAssignment? sameStaffAssignmentEntity =
                                                existingTaskStep.TaskAssignments
                                                .Where(x => x.TaskAssignmentType.Equals(nameof(TaskAssignmentType.SAGITTA_STAFF_ID))
                                                        && x.TaskAssignTo.Equals(StrategyStaffAssignment.SagittaStaffId)).FirstOrDefault();

                                            if (sameStaffAssignmentEntity != null)
                                                isAssignmentExist = true;
                                        }

                                        //IT MEANS REQUESTED STAFF IS NOT ASSIGNED SO WE NEED TO ADD
                                        if (!isAssignmentExist
                                           && existingTaskStackEntity.TaskMeta != null)
                                        {
                                            isAnyTaskNeedUpdate = true;
                                            TaskAssignment newTaskAssignmentEntity = new TaskAssignment();
                                            newTaskAssignmentEntity.TaskAssignmentId = Guid.NewGuid();
                                            newTaskAssignmentEntity.ParentTaskAssignmentId = null;
                                            newTaskAssignmentEntity.TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID);
                                            newTaskAssignmentEntity.TaskAssignTo = StrategyStaffAssignment.SagittaStaffId;
                                            newTaskAssignmentEntity.TaskAssignDate = currentDateTime;
                                            newTaskAssignmentEntity.HasLocked = false;
                                            newTaskAssignmentEntity.LockStartDate = null;
                                            newTaskAssignmentEntity.LockEndDate = null;
                                            newTaskAssignmentEntity.IsActive = true;
                                            newTaskAssignmentEntity.IsDeleted = false;
                                            newTaskAssignmentEntity.CreatedBy = securityUserId;
                                            newTaskAssignmentEntity.CreatedDate = currentDateTime;
                                            newTaskAssignmentEntity.IsDelegated = false;
                                            newTaskAssignmentEntity.TaskStepId = existingTaskStep.TaskStepId;
                                            newTaskAssignmentEntity.TaskStep = existingTaskStep;
                                            newTaskAssignmentEntity.Version = 1;

                                            if (isAnyStepAssignmentExist)
                                                existingTaskStep.TaskAssignments.Add(newTaskAssignmentEntity);
                                            else
                                            {
                                                taskAssignmentEntityList.Add(newTaskAssignmentEntity);
                                                existingTaskStep.TaskAssignments = taskAssignmentEntityList;
                                                isAnyStepAssignmentExist = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (isAnyTaskNeedUpdate)
                {
                    await _repository.TrackTasksChanges(existingTaskStackEntityList);
                    await _repository.BulkMergeTaskStacks(existingTaskStackEntityList);
                }
                    
            }
        }
        public async Task<bool> DeleteTaskAssignmentByStrategyStaff(string? securityUserId, Guid strategyStaffId)
        {
            List<TaskAssignment> taskAssignmentEntityList = await _repository.GetTaskAssignmentByStrategyStaffId(strategyStaffId);
            foreach (var taskAssignment in taskAssignmentEntityList)
            {
                taskAssignment.IsDeleted = true;
                taskAssignment.UpdatedDate = DateTime.Now;
                taskAssignment.UpdatedBy = securityUserId;
                taskAssignment.Version = taskAssignment.Version + 1; ;
            }
            await _repository.UpdateRangeTaskAssignments(taskAssignmentEntityList);
            return true;
        }
        public async Task<List<TaskStackModel>> SearchTaskStacks(SearchBaseFilterType baseFilterType, TaskSearchType searchType,
            TaskSearchCriterias searchCriterias, string? securityUserId, long? sagittaClientId, Guid? strategyId)
        {
            List<TaskStackModel> taskSearchResponseList = new List<TaskStackModel>();
            searchCriterias.TaskStatusCodes = GetMatchingTaskStatusCode(searchCriterias.TaskStatusCodes);
            string[]? userSagittaStaffIds = null;
            string[]? teamSagittaStaffIds = null;
            string[]? teamSecurityUserIds = null;

            if (!string.IsNullOrEmpty(securityUserId))
            {
                List<string>? mapUserSagStaffIds = await _sagittaStaffService.GetSagittaStaffIdsBySecurityUserId(securityUserId);
                if (mapUserSagStaffIds != null && mapUserSagStaffIds.Count > 0)
                {
                    userSagittaStaffIds = mapUserSagStaffIds.ToArray();
                    if (!searchType.Equals(TaskSearchType.MYASSIGNMENT))
                    {
                        teamSagittaStaffIds =
                        _repository.FindUserTeamByFilters(baseFilterType, userSagittaStaffIds, sagittaClientId, strategyId);
                        if (teamSagittaStaffIds != null && teamSagittaStaffIds.Length > 0)
                        {
                            List<string>? listTeamSecurityUserIds =
                                await _securityUserService.GetSecurityUserIdsByExternalSystemUserIds("SAGITTA", teamSagittaStaffIds);
                            if (listTeamSecurityUserIds != null && listTeamSecurityUserIds.Count > 0)
                                teamSecurityUserIds = listTeamSecurityUserIds.ToArray();
                        }
                    }

                }
            }

            List<TaskStack>? taskEntityList =
                await _repository.SearchTaskStacks(baseFilterType, searchType, searchCriterias,
                securityUserId, userSagittaStaffIds, teamSecurityUserIds, teamSagittaStaffIds,
                sagittaClientId, strategyId);

            if (taskEntityList != null && taskEntityList.Count > 0)
            {
                taskSearchResponseList = _mapper.Map<List<TaskStackModel>>(taskEntityList);
                MapTaskOwnerShipProperties(taskSearchResponseList,
                                            securityUserId, userSagittaStaffIds, teamSecurityUserIds, teamSagittaStaffIds);
                MapTaskAssignToInfoToResponseList(taskSearchResponseList);
            }
            return taskSearchResponseList;
        }

        #region PRIVATE

        #region NEW TASK/GENERIC TASK RELATED
        private GenericTask BuildNewGenericTaskEntity(string securityUserId, TaskStackRequestInfo taskRequest)
        {
            GenericTask genericTaskEntity = new GenericTask();
            genericTaskEntity.GenericTaskId = Guid.NewGuid();
            genericTaskEntity.RequestedByUserId = securityUserId;

            TaskStack taskStackEntity =
                BuildNewTaskStackEntity(securityUserId, taskRequest);
            genericTaskEntity.TaskStack = taskStackEntity;
            genericTaskEntity.TaskStack.TaskRefKey = genericTaskEntity.GenericTaskId.ToString().ToUpper();
            genericTaskEntity.TaskStack.TaskSteps.ToList()
                .ForEach(x => x.TaskStepRefKey = genericTaskEntity.GenericTaskId.ToString().ToUpper());

            List<TaskMeta> taskMetaEntityList = taskStackEntity.TaskMeta.ToList();
            foreach (var taskMeta in taskMetaEntityList)
            {
                taskMeta.GenericTaskId = genericTaskEntity.GenericTaskId;
                taskMeta.GenericTask = genericTaskEntity;
            }

            List<GenericTaskMeta> genericTaskMetas =
                BuildNewGenericTaskMetaEntityList(securityUserId, genericTaskEntity, taskMetaEntityList);

            genericTaskEntity.GenericTaskMeta = genericTaskMetas;
            genericTaskEntity.IsDeleted = false;
            genericTaskEntity.CreatedBy = securityUserId;
            genericTaskEntity.CreatedDate = DateTime.Now;

            return genericTaskEntity;
        }

        private List<GenericTaskMeta> BuildNewGenericTaskMetaEntityList(string securityUserId,
            GenericTask genericTaskEntity, List<TaskMeta> taskMetaEntityList)
        {
            List<GenericTaskMeta> genericTaskMetas = new List<GenericTaskMeta>();
            foreach (var taskMeta in taskMetaEntityList)
            {
                GenericTaskMeta genericTaskMeta = new GenericTaskMeta();
                genericTaskMeta.GenericTaskMetaId = Guid.NewGuid();
                genericTaskMeta.GenericTaskId = genericTaskEntity.GenericTaskId;
                genericTaskMeta.SagittaClientId = taskMeta.SagittaClientId;
                genericTaskMeta.PlanId = taskMeta.PlanId;
                genericTaskMeta.StrategyId = taskMeta.StrategyId;
                genericTaskMeta.StrategyTimelineId = taskMeta.StrategyTimelineId;
                genericTaskMeta.MarketId = taskMeta.MarketId;
                genericTaskMeta.SagittaPolicyId = taskMeta.SagittaPolicyId;
                genericTaskMeta.UnderwriterId = taskMeta.UnderwriterId;
                genericTaskMeta.GenericTask = genericTaskEntity;
                genericTaskMeta.CreatedBy = securityUserId;
                genericTaskMeta.CreatedDate = DateTime.Now;

                genericTaskMetas.Add(genericTaskMeta);
            }
            return genericTaskMetas;
        }

        private TaskStack BuildNewTaskStackEntity(string securityUserId, TaskStackRequestInfo taskRequest)
        {
            TaskStack taskEntity = new TaskStack();
            taskEntity.TaskStackId = Guid.NewGuid();
            taskEntity.ParentTaskStackId = null;
            taskEntity.TaskName = taskRequest.StepDefId != null ? taskRequest.StepDefId : nameof(TaskGenericSteps.GENERIC);
            taskEntity.TaskDesc = taskRequest.TaskDesc ?? null;
            taskEntity.TaskSender = securityUserId;
            taskEntity.TaskProirity = taskRequest.TaskProirity ?? AppConstants.TASK_PRIORITY_DEFAULT;
            taskEntity.TaskNotes = taskRequest.TaskNotes ?? null;
            taskEntity.TaskDueDate = taskRequest.TaskDueDate ?? null;
            taskEntity.TaskFollowUpDate = taskRequest.TaskFollowUpDate ?? null;
            taskEntity.TaskStatusCodeId = taskRequest.TaskStatusCodeId ?? nameof(TaskStatusCodes.OPEN);
            taskEntity.TaskSendDate = DateTime.Now;
            taskEntity.TaskStatusReason = null;
            taskEntity.IsDeleted = false;
            taskEntity.IsSysGen = false;
            taskEntity.CreatedBy = securityUserId;
            taskEntity.CreatedDate = DateTime.Now;
            taskEntity.LastTaskStatusUpdatedBy = securityUserId;
            taskEntity.LastTaskStatusUpdatedDate = DateTime.Now;
            taskEntity.TaskRefType = taskRequest.TaskType ?? null;
            taskEntity.TaskRefKey = null;
            taskEntity.Version = 1;

            List<TaskMeta>? taskMetas = BuildNewTaskMetaEntityList(securityUserId, taskEntity,
                                            taskRequest.TaskMeta);

            List<TaskStep>? taskSteps = BuildNewTaskStepEntityList(securityUserId, taskEntity, taskRequest);

            taskEntity.TaskMeta = taskMetas;
            taskEntity.TaskSteps = taskSteps;
            return taskEntity;
        }

        private List<TaskMeta> BuildNewTaskMetaEntityList(string securityUserId, TaskStack taskEntity,
            TaskMetaRequest? taskMetaRequest)
        {
            List<TaskMeta>? taskMetas = new List<TaskMeta>();
            TaskMeta newTaskMetaEntity = new TaskMeta();
            newTaskMetaEntity.TaskMetaId = Guid.NewGuid();
            newTaskMetaEntity.TaskStackId = taskEntity.TaskStackId;

            if (taskMetaRequest?.SagittaClientId != null && taskMetaRequest?.SagittaClientId > 0)
            {
                newTaskMetaEntity.SagittaClientId = taskMetaRequest?.SagittaClientId;
                if (taskMetaRequest?.StrategyId != null && taskMetaRequest?.StrategyId != Guid.Empty)
                {
                    Strategy? strategyEntity = _strategyRepository.GetStrategyHeaderById(taskMetaRequest?.StrategyId);
                    newTaskMetaEntity.PlanId = strategyEntity?.PlanId;
                    newTaskMetaEntity.StrategyId = strategyEntity?.StrategyId;
                }
            }
            else
            {
                newTaskMetaEntity.SagittaClientId = null;
                newTaskMetaEntity.PlanId = null;
                newTaskMetaEntity.StrategyId = null;
            }
            newTaskMetaEntity.StrategyTimelineId = null;
            newTaskMetaEntity.UnderwriterId = null;
            newTaskMetaEntity.MarketId = null;
            newTaskMetaEntity.SagittaPolicyId = null;
            newTaskMetaEntity.IsDeleted = false;
            newTaskMetaEntity.CreatedBy = securityUserId;
            newTaskMetaEntity.CreatedDate = DateTime.Now;
            newTaskMetaEntity.Version = 1;
            taskMetas.Add(newTaskMetaEntity);

            return taskMetas;
        }
        private List<TaskStep>? BuildNewTaskStepEntityList(string securityUserId, TaskStack taskEntity,
            TaskStackRequestInfo taskRequest)
        {
            List<TaskStep>? taskSteps = new List<TaskStep>();
            TaskStep newTaskStepEntity = new TaskStep();
            newTaskStepEntity.TaskStepId = Guid.NewGuid();
            newTaskStepEntity.TaskStackId = taskEntity.TaskStackId;
            if (taskRequest.StepDefId != null)
                newTaskStepEntity.StepDefId = taskRequest.StepDefId;
            else
                newTaskStepEntity.StepDefId = AppConstants.STEP_STEPDEFID_GENERIC;
            newTaskStepEntity.StatusCodeId = taskEntity.TaskStatusCodeId.Equals(nameof(TaskStatusCodes.CLOS)) ?
                                                    nameof(GenericStatusCodes.COMP) : nameof(GenericStatusCodes.ACTI);
            newTaskStepEntity.IsDeleted = false;
            newTaskStepEntity.CreatedBy = securityUserId;
            newTaskStepEntity.CreatedDate = DateTime.Now;
            newTaskStepEntity.LastStepStatusUpdatedBy = securityUserId;
            newTaskStepEntity.LastStepStatusUpdatedDate = DateTime.Now;
            newTaskStepEntity.TaskStack = taskEntity;
            newTaskStepEntity.TaskStepRefType = taskRequest.TaskType ?? null;
            newTaskStepEntity.TaskStepRefKey = null;
            newTaskStepEntity.Version = 1;

            newTaskStepEntity.TaskAssignments =
                BuildNewTaskAssignnmentEntityList(securityUserId, newTaskStepEntity, taskRequest.TaskAssignTo);
            taskSteps.Add(newTaskStepEntity);

            return taskSteps;
        }

        private List<TaskAssignment> BuildNewTaskAssignnmentEntityList(string securityUserId, TaskStep taskStepEntity,
            List<string> sagittaStaffIds)
        {
            List<TaskAssignment> newTaskAssignmentListEntity = new List<TaskAssignment>();
            foreach (var item in sagittaStaffIds)
            {
                TaskAssignment newTaskAssignmentEntity = new TaskAssignment();
                newTaskAssignmentEntity.TaskAssignmentId = Guid.NewGuid();
                newTaskAssignmentEntity.TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID);
                newTaskAssignmentEntity.TaskAssignTo = item;
                newTaskAssignmentEntity.TaskAssignDate = DateTime.Now;
                newTaskAssignmentEntity.HasLocked = false;
                newTaskAssignmentEntity.IsActive = true;
                newTaskAssignmentEntity.IsDelegated = false;
                newTaskAssignmentEntity.IsDeleted = false;
                newTaskAssignmentEntity.CreatedBy = securityUserId;
                newTaskAssignmentEntity.CreatedDate = DateTime.Now;
                newTaskAssignmentEntity.TaskStep = taskStepEntity;
                newTaskAssignmentEntity.Version = 1;
                newTaskAssignmentListEntity.Add(newTaskAssignmentEntity);
            }
            return newTaskAssignmentListEntity;
        }
        #endregion

        #region UPDATE TASK RELATED
        private GenericTask BuildUpdateGenericTaskEntity(string securityUserId, GenericTask? existingGenericTaskEntity,
           TaskStackRequestInfo taskUpdateRequest)
        {

            TaskStack updatedTaskEntity =
                BuildUpdateTaskStackEntity(securityUserId, existingGenericTaskEntity.TaskStack, taskUpdateRequest);
            existingGenericTaskEntity.TaskStack = updatedTaskEntity;

            List<GenericTaskMeta> updatedGenericTaskMetas =
                BuildUpdateGenericTaskMetaEntityList(securityUserId, existingGenericTaskEntity, updatedTaskEntity.TaskMeta.ToList());

            existingGenericTaskEntity.GenericTaskMeta = updatedGenericTaskMetas;
            existingGenericTaskEntity.UpdatedBy = securityUserId;
            existingGenericTaskEntity.UpdatedDate = DateTime.Now;

            return existingGenericTaskEntity;
        }
        private TaskStack BuildUpdateTaskStackEntity(string securityUserId, TaskStack existingTaskEntity,
            TaskStackRequestInfo taskUpdateRequest)
        {
            bool isStatusChangeDetected = false;
            existingTaskEntity.TaskDesc = taskUpdateRequest.TaskDesc ?? null;
            existingTaskEntity.TaskNotes = taskUpdateRequest.TaskNotes ?? null;
            existingTaskEntity.TaskDueDate = taskUpdateRequest.TaskDueDate ?? null;
            existingTaskEntity.TaskFollowUpDate = taskUpdateRequest.TaskFollowUpDate ?? null;

            string? evaluatedTaskStatusCodeId = taskUpdateRequest.TaskStatusCodeId ?? nameof(TaskStatusCodes.OPEN);
            if (!DataCompareUtility.IsEquals(existingTaskEntity?.TaskStatusCodeId, evaluatedTaskStatusCodeId))
            {
                existingTaskEntity.PrevTaskStatusCodeId = existingTaskEntity?.TaskStatusCodeId;
                existingTaskEntity.TaskStatusCodeId = evaluatedTaskStatusCodeId;
                existingTaskEntity.LastTaskStatusUpdatedBy = securityUserId;
                existingTaskEntity.LastTaskStatusUpdatedDate = DateTime.Now;
                existingTaskEntity.Version = existingTaskEntity.Version + 1;

            }
            existingTaskEntity.UpdatedBy = securityUserId;
            existingTaskEntity.UpdatedDate = DateTime.Now;
            existingTaskEntity.Version = existingTaskEntity.Version + 1;

            List<TaskMeta>? updatedTaskMetaEntityList =
                BuildUpdateTaskMetaEntityList(securityUserId, existingTaskEntity.TaskMeta.ToList(),
                                            taskUpdateRequest.TaskMeta);

            List<TaskStep>? updatedTaskSteps =
                BuildUpdateTaskStepEntityList(securityUserId, existingTaskEntity,
                                            existingTaskEntity.TaskSteps.ToList(),
                                            taskUpdateRequest.TaskAssignTo);

            existingTaskEntity.TaskMeta = updatedTaskMetaEntityList;
            existingTaskEntity.TaskSteps = updatedTaskSteps;
            return existingTaskEntity;
        }
        private List<TaskMeta>? BuildUpdateTaskMetaEntityList(string securityUserId, List<TaskMeta>? existingTaskMetaEntityList,
            TaskMetaRequest? taskMetaRequest)
        {
            foreach (var taskMeta in existingTaskMetaEntityList)
            {
                if (taskMetaRequest?.SagittaClientId != null && taskMetaRequest?.SagittaClientId > 0)
                {
                    taskMeta.SagittaClientId = taskMetaRequest?.SagittaClientId;
                    if (taskMetaRequest?.StrategyId != null && taskMetaRequest?.StrategyId != Guid.Empty)
                    {
                        Strategy? strategyEntity = _strategyRepository.GetStrategyHeaderById(taskMetaRequest?.StrategyId);
                        taskMeta.PlanId = strategyEntity?.PlanId;
                        taskMeta.StrategyId = strategyEntity?.StrategyId;
                    }
                    else
                    {
                        taskMeta.PlanId = null;
                        taskMeta.StrategyId = null;
                    }
                }
                else
                {
                    taskMeta.SagittaClientId = null;
                    taskMeta.PlanId = null;
                    taskMeta.StrategyId = null;
                }
                taskMeta.StrategyTimelineId = null;
                taskMeta.UnderwriterId = null;
                taskMeta.MarketId = null;
                taskMeta.SagittaPolicyId = null;
                taskMeta.UpdatedBy = securityUserId;
                taskMeta.UpdatedDate = DateTime.Now;
                taskMeta.Version = taskMeta.Version + 1;
            }
            return existingTaskMetaEntityList;
        }
        private List<TaskStep>? BuildUpdateTaskStepEntityList(string securityUserId, TaskStack existingTaskEntity,
            List<TaskStep>? existingTaskStepEntityList, List<string>? updateRequestSagittaStaffIds)
        {
            foreach (var existingTaskStepEntity in existingTaskStepEntityList)
            {
                string? evaluatedStatusCodeId = existingTaskEntity.TaskStatusCodeId.Equals(nameof(TaskStatusCodes.CLOS)) ?
                                                    nameof(GenericStatusCodes.COMP) : nameof(GenericStatusCodes.ACTI);
                if (!DataCompareUtility.IsEquals(existingTaskStepEntity.StatusCodeId, evaluatedStatusCodeId))
                {
                    existingTaskStepEntity.StatusCodeId = evaluatedStatusCodeId;
                    existingTaskStepEntity.LastStepStatusUpdatedBy = securityUserId;
                    existingTaskStepEntity.LastStepStatusUpdatedDate = DateTime.Now;
                }
                existingTaskStepEntity.UpdatedBy = securityUserId;
                existingTaskStepEntity.UpdatedDate = DateTime.Now;
                existingTaskStepEntity.Version = existingTaskStepEntity.Version + 1;


                existingTaskStepEntity.TaskAssignments =
                    BuildUpdateTaskAssignnmentEntityList(securityUserId, existingTaskStepEntity,
                                                        existingTaskStepEntity?.TaskAssignments?.ToList(),
                                                        updateRequestSagittaStaffIds);
            }

            return existingTaskStepEntityList;
        }
        private List<TaskAssignment> BuildUpdateTaskAssignnmentEntityList(string securityUserId, TaskStep existingTaskStepEntity,
            List<TaskAssignment>? existingTaskAssignmentList, List<string> sagittaStaffIds)
        {
            List<TaskAssignment> updatedTaskAssignmentList = new List<TaskAssignment>();
            if (existingTaskAssignmentList == null)
            {
                updatedTaskAssignmentList = new List<TaskAssignment>();
                foreach (var sagittaStaffId in sagittaStaffIds)
                {
                    TaskAssignment newTaskAssignmentEntity = new TaskAssignment();
                    newTaskAssignmentEntity.TaskAssignmentId = Guid.NewGuid();
                    newTaskAssignmentEntity.TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID);
                    newTaskAssignmentEntity.TaskAssignTo = sagittaStaffId;
                    newTaskAssignmentEntity.TaskAssignDate = DateTime.Now;
                    newTaskAssignmentEntity.HasLocked = false;
                    newTaskAssignmentEntity.IsActive = true;
                    newTaskAssignmentEntity.IsDelegated = false;
                    newTaskAssignmentEntity.IsDeleted = false;
                    newTaskAssignmentEntity.CreatedBy = securityUserId;
                    newTaskAssignmentEntity.CreatedDate = DateTime.Now;
                    newTaskAssignmentEntity.TaskStep = existingTaskStepEntity;
                    newTaskAssignmentEntity.Version = 1;
                    updatedTaskAssignmentList.Add(newTaskAssignmentEntity);
                }
            }
            else
            {
                //updatedTaskAssignmentList = existingTaskAssignmentList;
                //Mark Delete which are removed from assignment
                foreach (var existingTaskAssignment in existingTaskAssignmentList)
                {
                    if (!sagittaStaffIds.Contains(existingTaskAssignment.TaskAssignTo))
                    {
                        existingTaskAssignment.IsDeleted = true;
                        existingTaskAssignment.UpdatedBy = securityUserId;
                        existingTaskAssignment.UpdatedDate = DateTime.Now;
                        existingTaskAssignment.Version = existingTaskAssignment.Version + 1;

                    }
                    updatedTaskAssignmentList.Add(existingTaskAssignment);
                }

                foreach (var sagittaStaffId in sagittaStaffIds)
                {
                    if (!updatedTaskAssignmentList.Any(x => x.TaskAssignTo.Equals(sagittaStaffId)))
                    {
                        TaskAssignment newTaskAssignmentEntity = new TaskAssignment();
                        newTaskAssignmentEntity.TaskAssignmentId = Guid.NewGuid();
                        newTaskAssignmentEntity.TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID);
                        newTaskAssignmentEntity.TaskAssignTo = sagittaStaffId;
                        newTaskAssignmentEntity.TaskAssignDate = DateTime.Now;
                        newTaskAssignmentEntity.HasLocked = false;
                        newTaskAssignmentEntity.IsActive = true;
                        newTaskAssignmentEntity.IsDelegated = false;
                        newTaskAssignmentEntity.IsDeleted = false;
                        newTaskAssignmentEntity.CreatedBy = securityUserId;
                        newTaskAssignmentEntity.CreatedDate = DateTime.Now;
                        newTaskAssignmentEntity.TaskStep = existingTaskStepEntity;
                        newTaskAssignmentEntity.Version = 1;
                        updatedTaskAssignmentList.Add(newTaskAssignmentEntity);
                    }
                }
            }

            return updatedTaskAssignmentList;
        }
        private List<GenericTaskMeta> BuildUpdateGenericTaskMetaEntityList(string securityUserId,
            GenericTask existingGenericTaskEntity, List<TaskMeta> existingTaskMetaEntityList)
        {
            List<GenericTaskMeta> updatedGenericTaskMetas =
                existingGenericTaskEntity.GenericTaskMeta.ToList();

            foreach (var taskMeta in existingTaskMetaEntityList)
            {
                foreach (var updatedGenericTaskMeta in updatedGenericTaskMetas)
                {
                    updatedGenericTaskMeta.SagittaClientId = taskMeta.SagittaClientId;
                    updatedGenericTaskMeta.PlanId = taskMeta.PlanId;
                    updatedGenericTaskMeta.StrategyId = taskMeta.StrategyId;
                    updatedGenericTaskMeta.StrategyTimelineId = taskMeta.StrategyTimelineId;
                    updatedGenericTaskMeta.MarketId = taskMeta.MarketId;
                    updatedGenericTaskMeta.SagittaPolicyId = taskMeta.SagittaPolicyId;
                    updatedGenericTaskMeta.UnderwriterId = taskMeta.UnderwriterId;
                    updatedGenericTaskMeta.UpdatedBy = securityUserId;
                    updatedGenericTaskMeta.UpdatedDate = DateTime.Now;
                }
            }
            return updatedGenericTaskMetas;
        }
        #endregion

        #region RESPONSE RELATED
        private string[] GetMatchingTaskStatusCode(string[] requestedTaskStatusCodes)
        {
            string[] taskStatusCodes = requestedTaskStatusCodes.Select(s => s.ToUpperInvariant()).ToArray();
            string[] matchedTaskStatusCodes = null;

            if (taskStatusCodes.Contains(nameof(TaskStatusCodesSearchCriteria.ALL)))
                matchedTaskStatusCodes = _repository.GetAllTaskStatusCodesIds().ToArray();
            else if (taskStatusCodes.Contains(nameof(TaskStatusCodesSearchCriteria.OPEN)))
                matchedTaskStatusCodes = _repository.GetAllTaskStatusCodesIdsByGroupCode(AppConstants.TASK_STATUS_GROUP_CODE_OPEN).ToArray();
            else if (taskStatusCodes.Contains(nameof(TaskStatusCodesSearchCriteria.CLOS)))
                matchedTaskStatusCodes = _repository.GetAllTaskStatusCodesIdsByGroupCode(AppConstants.TASK_STATUS_GROUP_CODE_CLOSED).ToArray();
            return matchedTaskStatusCodes;
        }
        private void MapTaskAssignToInfoToResponse(TaskStackModel? taskStackResponse)
        {
            List<Guid>? taskStepIds = taskStackResponse?.TaskSteps?
                                            .Select(x => x.TaskStepId).ToList();
            if (taskStepIds != null && taskStepIds.Count > 0)
            {
                List<SagittaStaff>? sagittaStaffList =
                    _sagittaStaffRepository.GetSagittaStaffsByAssignedStepIds(taskStepIds);
                if (sagittaStaffList != null && sagittaStaffList.Count > 0)
                {
                    List<TaskAssignedToInfo> taskAssignedToInfos =
                    _mapper.Map<List<TaskAssignedToInfo>>(sagittaStaffList);
                    foreach (var taskStep in taskStackResponse.TaskSteps)
                    {
                        foreach (var taskAssign in taskStep.TaskAssignments)
                        {
                            taskAssign.TaskAssignedToInfo =
                                taskAssignedToInfos?.Where(x => x.StaffCode.Equals(taskAssign.TaskAssignTo)).FirstOrDefault();
                        }
                    }
                }
            }
        }
        private void MapTaskAssignToInfoToResponseList(List<TaskStackModel>? taskStackResponseList)
        {
            List<Guid>? taskStepIds =
                taskStackResponseList?
                .SelectMany(x => x.TaskSteps?.Select(x => x.TaskStepId))
                .ToList();

            if (taskStepIds != null && taskStepIds.Count > 0)
            {
                List<SagittaStaff>? sagittaStaffList =
                    _sagittaStaffRepository.GetSagittaStaffsByAssignedStepIds(taskStepIds);
                if (sagittaStaffList != null && sagittaStaffList.Count > 0)
                {
                    List<TaskAssignedToInfo> taskAssignedToInfos =
                    _mapper.Map<List<TaskAssignedToInfo>>(sagittaStaffList);
                    foreach (var taskStackResponse in taskStackResponseList)
                    {
                        foreach (var taskStep in taskStackResponse.TaskSteps)
                        {
                            foreach (var taskAssign in taskStep.TaskAssignments)
                            {
                                taskAssign.TaskAssignedToInfo =
                                    taskAssignedToInfos?.Where(x => x.StaffCode.Equals(taskAssign.TaskAssignTo)).FirstOrDefault();
                            }
                        }
                    }
                }
            }
        }
        private void MapTaskOwnerShipProperties(List<TaskStackModel> taskSearchResponseList,
            string? securityUserId, string[]? userSagittaStaffIds, string[]? teamSecurityUserIds, string[]? teamSagittaStaffIds)
        {
            MapTaskOwnerShipAssignmentProperties(taskSearchResponseList, userSagittaStaffIds, teamSagittaStaffIds);
            MapTaskOwnerShipRequestedByProperties(taskSearchResponseList, securityUserId, teamSecurityUserIds);
        }
        private void MapTaskOwnerShipAssignmentProperties(List<TaskStackModel> taskSearchResponseList,
            string[]? userSagittaStaffIds, string[]? teamSagittaStaffIds)
        {
            foreach (TaskStackModel taskSearchResponse in taskSearchResponseList)
            {
                foreach (var taskStep in taskSearchResponse.TaskSteps)
                {
                    List<string>? taskAssignments = taskStep?.TaskAssignments.Select(x => x.TaskAssignTo).ToList();
                    if (taskAssignments != null && taskAssignments.Count > 0)
                    {
                        if (userSagittaStaffIds != null && userSagittaStaffIds.Any(item => taskAssignments.Contains(item)))
                            taskSearchResponse.TaskOwnerTypeAssignTo = nameof(TaskOwnerTypeAssignTo.MYASSIGNMENT);
                        else if (teamSagittaStaffIds != null && teamSagittaStaffIds.Any(item => taskAssignments.Contains(item)))
                            taskSearchResponse.TaskOwnerTypeAssignTo = nameof(TaskOwnerTypeAssignTo.MYTEAMASSIGNMENT);
                        else
                            taskSearchResponse.TaskOwnerTypeAssignTo = nameof(TaskOwnerTypeAssignTo.OTHERS);
                    }
                }
            }
        }
        private void MapTaskOwnerShipRequestedByProperties(List<TaskStackModel> taskSearchResponseList,
            string? securityUserId, string[]? teamSecurityUserIds)
        {
            foreach (TaskStackModel taskSearchResponse in taskSearchResponseList)
            {
                if (!string.IsNullOrEmpty(taskSearchResponse.RequestedByUserId))
                {
                    //MAP RequestedBy after AssignToOwner already map
                    if (taskSearchResponse.TaskOwnerTypeAssignTo == null
                        || (!string.IsNullOrEmpty(taskSearchResponse.TaskOwnerTypeAssignTo)
                            && taskSearchResponse.TaskOwnerTypeAssignTo.Equals(nameof(TaskOwnerTypeAssignTo.OTHERS)))
                        )
                    {
                        if (!string.IsNullOrEmpty(securityUserId) && taskSearchResponse.RequestedByUserId.Equals(securityUserId, StringComparison.OrdinalIgnoreCase))
                            taskSearchResponse.TaskOwnerTypeRequestedBy = nameof(TaskOwnerTypeRequestedBy.MYREQUEST);
                        else if (teamSecurityUserIds != null
                            && teamSecurityUserIds.Any(x => x.Equals(taskSearchResponse.RequestedByUserId, StringComparison.OrdinalIgnoreCase)))
                            taskSearchResponse.TaskOwnerTypeRequestedBy = nameof(TaskOwnerTypeRequestedBy.MYTEAMREQUEST);
                        else
                            taskSearchResponse.TaskOwnerTypeRequestedBy = nameof(TaskOwnerTypeRequestedBy.OTHERS);
                    }
                }

            }
        }
        #endregion        

        #endregion
    }
}
