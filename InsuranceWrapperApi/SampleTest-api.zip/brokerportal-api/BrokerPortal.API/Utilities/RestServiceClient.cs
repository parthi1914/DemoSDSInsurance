﻿using Azure.Core;
using System.Net.Http.Headers;

namespace BrokerPortal.API.Utilities
{
    public class RestServiceClient
    {
        private readonly HttpClient _httpClient;

        public RestServiceClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task<T> PostAsync<T>(string? accessToken, string url, object data)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            var response = await _httpClient.PostAsJsonAsync(url, data);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<T>();
        }
        public async Task<T> GetAsync<T>(string? accessToken, string url)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            return await _httpClient.GetFromJsonAsync<T>(url);
        }
    }
}
