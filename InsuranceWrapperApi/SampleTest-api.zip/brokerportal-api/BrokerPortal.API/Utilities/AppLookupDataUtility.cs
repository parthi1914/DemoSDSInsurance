﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.Utilities
{
    public static class AppLookupDataUtility
    {
        public static List<SubStepDef> LoadSubStepDefs()
        {
            var subStepDefs = new List<SubStepDef>()
            {
                 new SubStepDef(){SubStepDefId = "101",SubStepName="Unsent" },
                 new SubStepDef(){SubStepDefId = "102",SubStepName="Ready" },
                 new SubStepDef(){SubStepDefId = "103",SubStepName="Reserved - Incomplete" },
                 new SubStepDef(){SubStepDefId = "201",SubStepName="Pending Quote" },
                 new SubStepDef(){SubStepDefId = "202",SubStepName="Received - Needs Review" },
                 new SubStepDef(){SubStepDefId = "203",SubStepName="Received - Revising" },
                 new SubStepDef(){SubStepDefId = "204",SubStepName="Declined - Carrier" },
                 new SubStepDef(){SubStepDefId = "205",SubStepName="Not Proposed" },
                 new SubStepDef(){SubStepDefId = "301",SubStepName="Proposing" },
                 new SubStepDef(){SubStepDefId = "302",SubStepName="Ready" },
                 new SubStepDef(){SubStepDefId = "303",SubStepName="Awaiting Bind Order" },
                 new SubStepDef(){SubStepDefId = "304",SubStepName="Binding" },
                 new SubStepDef(){SubStepDefId = "305",SubStepName="Bound - Docs Pending" },
                 new SubStepDef(){SubStepDefId = "306",SubStepName="Declined - Client" },
                 new SubStepDef(){SubStepDefId = "307",SubStepName="Option Not Taken" },
                 new SubStepDef(){SubStepDefId = "308",SubStepName="Bound - Complete" },
                 new SubStepDef(){SubStepDefId = "901",SubStepName="Canceled" },
                 new SubStepDef(){SubStepDefId = "902",SubStepName="Lost on BOR" },
                 new SubStepDef(){SubStepDefId = "903",SubStepName="Client Withdrew" },
                 new SubStepDef(){SubStepDefId = "904",SubStepName="Other" }

            };
            return subStepDefs;
        }

        public static List<StepDef> LoadStepDefs()
        {
            var StepDefs = new List<StepDef>()
            {
                new StepDef(){StepDefId="MS-SUBM",StepName="SUBMISSION"},
                new StepDef(){StepDefId="MS-QUOT",StepName="QUOTE"},
                new StepDef(){StepDefId="MS-PROP",StepName="PROPOSAL"},
                new StepDef(){StepDefId="MS-BIND",StepName="BIND"},
                new StepDef(){StepDefId="MS-REMO",StepName="REMOVED"}
            };

            return StepDefs;
        }

        public static string GetSubStepNameById(string SubStepDefId)
        {
            var subStepDefs = LoadSubStepDefs();
            string subStepName = null;
            if (subStepDefs != null && subStepDefs.Any())
            {
                var subStepDef = subStepDefs.Where(s => s.SubStepDefId == SubStepDefId).SingleOrDefault();
                if (subStepDef != null)
                    subStepName = subStepDef.SubStepName;
            }

            return subStepName;

        }

        public static string GetStepNameById(string StepDefId)
        {
            var stepDefs = LoadStepDefs();
            string stepDefName = null;
            if (stepDefs != null && stepDefs.Any())
            {
                var stepDef = stepDefs.Where(s => s.StepDefId == StepDefId).SingleOrDefault();
                if (stepDef != null)
                    stepDefName = stepDef.StepName;
            }

            return stepDefName;

        }
    }
}
