﻿namespace BrokerPortal.API.Utilities
{
    
    public enum SearchBaseFilterType
    {
        ALL,
        USER_SPECIFIC,
        CLIENT_SPECIFIC,
        STRATEGY_SPECIFIC
    }

    public enum StrategySearchType
    {
        ALL,
        MYFAVORITE,
        MYACCESS,
        MYASSIGNMENT
    }

    //MYACCESS & MYTEAMASSIGNMENT are same (UI send MYACCESS for my team)
    //MYASSIGNMENT (Ui send my work)
    public enum TaskSearchType
    {
        ALL,
        MYFAVORITE,
        MYACCESS,
        MYTEAMASSIGNMENT,
        MYASSIGNMENT
    }

    public enum TaskCategorySearchCriteria
    {
        ALL,
        GENERIC,
        SYSTEM
    }

    public enum TaskAssignTypeSearchCriteria
    {
        ALL,
        MYASSIGNMENT,
        MYREQUEST
    }

    public enum TaskStatusCodesSearchCriteria
    {
        ALL,
        OPEN,
        CLOS
    }

    public enum TaskRefType
    {
        STRATEGY,
        MARKET,
        GENERIC
    }

    public enum TaskStepRefType
    {
        STRATEGY_TIMELINE,
        MARKET_TIMELINE
    }
    public enum TaskAssignmentType
    {
        SAGITTA_STAFF_ID
    }

    public enum TaskOwnerTypeAssignTo
    {
        MYASSIGNMENT,
        MYTEAMASSIGNMENT,
        OTHERS
    }
    public enum TaskOwnerTypeRequestedBy
    {
        MYREQUEST,
        MYTEAMREQUEST,
        OTHERS
    }

    public enum GenericStatusGroupCodes
    {
        ACTI,
        COMP
    }

    public enum TaskGenericSteps
    {
        GENERIC
    }

    
    public enum GenericStatusCodes
    {
        ACTI,
        ARCH,
        CANC,
        COMP,
        COMPI,
        INAC,
        INIT,
        REMO,
        SKIP,
        PEND
    }

    public enum TaskStatusGroupCodes
    {
        OPEN,
        CLOS
    }

    public enum TaskStatusCodes
    {
        ARCH,
        CANC,
        CLOS,
        CLOSI,
        OPEN,
        REMO,
        REOP,
        SKIP,
        STAR,
        PEND
    }
}
