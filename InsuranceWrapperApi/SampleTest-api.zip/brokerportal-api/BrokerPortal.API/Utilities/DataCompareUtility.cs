﻿namespace BrokerPortal.API.Utilities
{
    public static class DataCompareUtility
    {
        public static bool IsEquals(DateTime? sourceItem, DateTime? targetItem)
        {
            if (sourceItem == null && targetItem == null) return true;

            if ((sourceItem == null && targetItem != null) || (sourceItem != null && targetItem == null)) return false;

            if ((sourceItem.Value.Date != targetItem.Value.Date))
                return false;

            return true;
        }

        public static bool IsEquals(long? sourceItem, long? targetItem)
        {
            if (sourceItem == null && targetItem == null) return true;
            else if ((sourceItem == null && targetItem != null) || (sourceItem != null && targetItem == null)) return false;
            else if (sourceItem == targetItem) return true;
            else return false;
        }

        public static bool IsEquals(int? sourceItem, int? targetItem)
        {
            if (sourceItem == null && targetItem == null) return true;
            else if ((sourceItem == null && targetItem != null) || (sourceItem != null && targetItem == null)) return false;
            else if (sourceItem.Equals(targetItem)) return true;
            else return false;
        }

        public static bool IsEquals(decimal? sourceItem, decimal? targetItem)
        {
            if (sourceItem == null && targetItem == null) return true;
            else if ((sourceItem == null && targetItem != null) || (sourceItem != null && targetItem == null)) return false;
            else if (Decimal.Compare(sourceItem.Value, targetItem.Value) == 0) return true;
            else return false;
        }

        public static bool IsEquals(Guid? sourceItem, Guid? targetItem)
        {
            if (sourceItem == null && targetItem == null) return true;
            else if ((sourceItem == null && targetItem != null) || (sourceItem != null && targetItem == null)) return false;
            else if (sourceItem.Equals(targetItem)) return true;
            else return false;
        }

        public static bool IsEquals(string? sourceItem, string? targetItem)
        {
            if ((string.IsNullOrEmpty(sourceItem) ? "" : sourceItem) == (string.IsNullOrEmpty(targetItem) ? "" : targetItem))
                return true;
            else
                return false;
        }

        public static bool IsEquals(bool? sourceItem, bool? targetItem)
        {
            if (sourceItem == null && targetItem == null) return true;
            else if ((sourceItem == null && targetItem != null) || (sourceItem != null && targetItem == null)) return false;
            else if (sourceItem.Value.CompareTo(targetItem.Value) == 0) return true;
            else return false;
        }
    }
}
