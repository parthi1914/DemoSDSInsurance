﻿using System.Diagnostics.CodeAnalysis;
using Veracode.Attributes;

namespace BrokerPortal.API.Utilities.GlobalException
{
    [ExcludeFromCodeCoverage]
    public static class CustomLogger
    {
        /// <summary>
        /// Add log message based on different log level using global contants and entity name
        /// </summary>
        /// <param name="_logger"></param>
        /// <param name="logLevel"></param>
        /// <param name="globalConstants"></param>
        /// <param name="entityName"></param>
        /// <param name="exception"></param>
        [CRLFCleanser]
        public static void AddLog(ILogger _logger, LogLevel logLevel, string message, string entityName = null)
        {
            var cleanMsg = System.Net.WebUtility.HtmlEncode(message);
            var cleanEntity = System.Net.WebUtility.HtmlEncode(entityName);
            switch (logLevel)
            {
                case LogLevel.Error:
                    _logger.LogError(string.Format(cleanMsg, cleanEntity ?? string.Empty));
                    break;
                case LogLevel.Information:
                    _logger.LogInformation(string.Format(cleanMsg, cleanEntity ?? string.Empty));
                    break;
                case LogLevel.Trace:
                    _logger.LogTrace(string.Format(cleanMsg, cleanEntity ?? string.Empty));
                    break;
                default:
                    _logger.LogInformation(cleanMsg, cleanEntity);
                    break;
            }
        }
        /// <summary>
        /// This method write the logs based on exception caught in catch block.
        /// </summary>
        /// <param name="_logger"></param>
        /// <param name="logLevel"></param>
        /// <param name="message"></param>
        /// <param name="entityName"></param>
        /// <param name="exception"></param>
        [CRLFCleanser]
        public static void AddCatchLog(ILogger _logger, LogLevel logLevel, Exception exception)
        {
            switch (logLevel)
            {
                case LogLevel.Error:
                    _logger.LogError($"Error occurred: {exception.GetType().Name} - {exception.Message}\nStackTrack: {exception.StackTrace}");
                    break;
            }
        }
    }
}
