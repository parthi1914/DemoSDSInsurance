﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace BrokerPortal.API.Utilities.GlobalException
{
    public class GlobalExceptionHandler(IHostEnvironment hostEnvironment, ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
    {

        private const string ExceptionMessage = "An unhandled exception has occurred while executing the request.";

        public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
        {

            logger.LogError(exception, exception is Exception ? exception.Message : ExceptionMessage);
            
            var problemDetails = CreateProblemDetails(httpContext, exception);
            if (problemDetails != null && problemDetails.Status!=null && problemDetails.Status.HasValue)
                httpContext.Response.StatusCode = (int)problemDetails.Status;

            await httpContext.Response.WriteAsJsonAsync(problemDetails, cancellationToken);
            return true;
        }

        private ProblemDetails CreateProblemDetails(in HttpContext httpContext, in Exception exception)
        {
            httpContext.Response.ContentType = "application/json";
            int statusCode = httpContext.Response.StatusCode;

            switch (exception)
            {
                case BadRequestException:
                    statusCode = (int)HttpStatusCode.BadRequest;
                    break;
                case NotFoundException:
                    statusCode = (int)HttpStatusCode.NotFound;
                    break;
                
                case UnAuthorizedException:
                    statusCode = (int)HttpStatusCode.Unauthorized;
                    break;
                case ForbiddenException:
                    statusCode = (int)HttpStatusCode.Forbidden;
                    break;
                case DbException:
                case InternalException:
                case NotImplementedException notImplementedException:
                    statusCode = (int)HttpStatusCode.InternalServerError;
                    break;
                default:
                    statusCode = httpContext.Response.StatusCode;
                    break;
            }

            return new ProblemDetails
            {
                Status = statusCode,                
                Type = exception.GetType().Name,
                Title = exception.Message,
                Detail = exception.StackTrace,
                Instance = $"{httpContext.Request.Method} {httpContext.Request.Path}"
            };

        }
    }

    public class BadRequestException : Exception
    {
        public BadRequestException(string message) : base(message) { }

    }

    public class DbException : Exception
    {
        private readonly HttpStatusCode httpStatusCode;
        public DbException(string message, HttpStatusCode statusCode) : base(message)
        {
            this.httpStatusCode = statusCode;
        }

        public HttpStatusCode HttpStatusCode { get { return httpStatusCode; } }
    }

    public class ForbiddenException : Exception
    {
        public ForbiddenException(string message) : base(message) { }
    }

    public class InternalException : Exception
    {
        public InternalException(string message) : base(message) { }
    }

    public class NotFoundException : Exception
    {
        public NotFoundException(string message) : base(message) { }
    }

    public class UnAuthorizedException : Exception
    {
        public UnAuthorizedException(string message) : base(message) { }
    }

}
