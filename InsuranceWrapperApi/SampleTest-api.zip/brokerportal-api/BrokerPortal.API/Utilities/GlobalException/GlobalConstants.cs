﻿using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;

namespace BrokerPortal.API.Utilities.GlobalException
{
    [ExcludeFromCodeCoverage]
    public static class GlobalConstants
    {
        public const string ERROR_PROCCESS_REQ = "An error occurred while processing the request in {0}";
        public const string ERROR_PROCCESS_REQUEST = "An error occurred while processing the request";
        public const string ERROR_RETURN_NULL = "Returns a null value";
        public const string ERROR_REQUEST_NULL = "Input parameter is null or empty.";
        public const string ERROR_REQUEST_LIMIT = "Please search with atleast 3 characters.";
        public const string ERROR_RETURN_NULL_EMPTY = "Result set is empty or null.";

        public const string ERROR_API = "An error occured while processing {0}.";
        public const string ERROR_INVALID_SEARCHTYPE = "User input '{0}' is not a valid value from the Search Type enum. Valid values for Search Type: (Invoice Number = 0, Invoice RefId = 1, Order Number = 2, Supplier Name = 3, Supplier Id = 4, Recently Created Invoice = 5)";
        public const string ERROR_INVALID_LOBTYPE = "User input '{0}' is not a valid value from the Lob enum.";
        public const string ERROR_PARAM_NULL_EMPTY = "Request Parameter is NULL or Empty.";

        public const string INFO_SERVICE_START = "{0} api has been called.";
        public const string INFO_SERVICE_COMPLETE = "{0} api has been completed.";
        public const string INFO_MASTER_START = "{0} method calls started in service master with parameters {1}";
        public const string INFO_MASTER_COMPLETE = "{0} method calls completed in service master";

        public const string STATUS_INPROGRESS = "In progress";
        public const string STATUS_NOTSTARTED = "Not Started";
        public const string STATUS_COMPLETED = "Completed";
        public const string TIME_ZONE_ID_EST = "Eastern Standard Time";

        public const string RESULT_SUCCESS = "Success";
        public const string RESULT_FAILURE = "Failure";
        public const string RESULT_WARNING = "Warning";
        public const string RESULT_RETURN_NULL_EMPTY = "Result set is empty or null.";
        public const string RESULT_NOT_FOUND = "Result not found.";

        public const string ERROR_UNAUTHORIZED = "Authorization failed. Invalid token or GUID.";
        public const string CUSTOM_HEADER = "X-GUID";

        public const string INVALID_REQUEST = "Invalid Request";

    }


    public enum StrategyStepDef
    {
        [Description("MS-SUBM")]
        SUBMISSION ,
        [Description("MS-QUOT")]
        QUOTE,
        [Description("MS-PROP")]
        PROPOSAL,
        [Description("MS-BIND")]
        BIND,
        [Description("MS-REMO")]
        REMOVED
    }
}



