﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.Utilities
{
    [ExcludeFromCodeCoverage]
    public static class AppConstants
    {
        #region GENERIC
        public const string SYSTEM_USER_ID = "SYSTEM_USER";
        public const string OPTION_ALL = "ALL";
        public const string USER_CLAIM_TYPE_EMAIL = @"http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
        public const string MARKET_FULLCOMPLETE_STEPCODE = "MS-BIND";
        public const string MARKET_FULLCOMPLETE_SUBSTEPDEFCODE = "403";

        public const string STEP_STATUSGROUPCODE_ACTIVE = "ACTI";
        public const string STEP_STATUSGROUPCODE_COMPLETED = "COMP";

        public const string STEP_STATUSCODE_INITIALIZE = "INIT";
        public const string STEP_STATUSCODE_ACTIVE = "ACTI";
        public const string STEP_STATUSCODE_INACTIVE = "INAC";
        public const string STEP_STATUSCODE_COMPLETED = "COMP";
        public const string STEP_STATUSCODE_ARCHIVED = "ARCH";
        public const string STEP_STATUSCODE_REMOVED = "REMO";

        public const string EXTERNAL_SYS_SAGITTA = "SAGITTA";

        #endregion


        #region PLAN & STRATEGY RELATED
        public const string FLOWDEF_PLAN = "MP";
        public const string PLAN_STEP_STEPDEFID_MARKET = "MP-MARK";
        public const string PLAN_STEP_STEPDEFID_PROPOSAL = "MP-PROP";
        public const string PLAN_STEP_STEPDEFID_BIND = "MP-BIND";

        public const string FLOWDEF_STRATEGY = "MS";
        public const int STRATEGY_STEP_QUOTE_DAYS_THRESHOLD = -10;
        public const string STRATEGY_STEP_STEPDEFID_SUBMISSION = "MS-SUBM";
        public const string STRATEGY_STEP_STEPDEFID_QUOTE = "MS-QUOT";
        public const string STRATEGY_STEP_STEPDEFID_PROPOSAL = "MS-PROP";
        public const string STRATEGY_STEP_STEPDEFID_BIND = "MS-BIND";
        public const string STRATEGY_STEP_STEPDEFID_REMOVED = "MS-REMO";
        #endregion

        #region TASK RELATED
        public const int TASK_PRIORITY_DEFAULT = 5;
        public const string STEP_STEPDEFID_GENERIC = "MS-GENE";
        public const string STEP_GENERIC = "GENERIC";
        
        public const string TASK_STATUS_GROUP_CODE_OPEN = "OPEN";
        public const string TASK_STATUS_GROUP_CODE_CLOSED = "CLOS";

        public const string TASK_STATUS_CODE_START = "STAR";
        public const string TASK_STATUS_CODE_OPEN = "OPEN";
        public const string TASK_STATUS_CODE_REOPEN = "REOP";
        public const string TASK_STATUS_CODE_CLOSED = "CLOS";
        public const string TASK_STATUS_CODE_ARCHIVED = "ARCH";
        public const string TASK_STATUS_CODE_CANCELED = "CANC";
        public const string TASK_STATUS_CODE_REMOVED = "REMO";

        //public const string TASK_STATUS_CODE_CLOSED = "CLOS";
        //public const string TASK_STATUS_CODE_CLOSED_COMPLETED = "CLCO";
        //public const string TASK_STATUS_CODE_CLOSED_REMOVED = "CLRE";        
        
        #endregion

        #region SEARCH RELATED
        public const string SAGITTA_CLIENT_SEARCH_TYPE_FAVOURITE = "FAVORITE";
        public const string SAGITTA_CLIENT_SEARCH_TYPE_ASSIGNEDTOME = "ASSIGNEDTOME";
        public const string SEARCH_CONDITION_AND = "AND";
        public const string SEARCH_CONDITION_OR = "OR";
        public const string SEARCH_OPTION_EXACT = "EXACT";
        public const string SEARCH_OPTION_STARTSWITH = "STARTSWITH";
        public const string SEARCH_OPTION_CONTAINS = "CONTAINS";
        public const string STATUS_OPTION_ACTIVE = "ACTIVE";
        public const string STATUS_OPTION_INACTIVE = "INACTIVE";
        #endregion

        #region VALIDATION MESSAGES
        public const string MSG_ALLOWED_STRATEGY_SEARCH_TYPES = "Allowed search types are ALL, MYFAVORITE, MYACCESS, MYASSIGNMENT";
        public const string MSG_ALLOWED_TASK_SEARCH_TYPES = "Allowed search types are ALL, MYACCESS, MYASSIGNMENT";
        public const string MSG_ALLOWED_SEARCH_CONDITIONS = "Allowed search conditions are AND, OR";
        public const string MSG_REQUIRED_SECURITY_USER = "Security user is required";
        public const string MSG_REQUIRED_SEARCH_CRITERIAS = "Atleast one SearchCriteria is required";
        public const string MSG_REQUIRED_SEARCH_CRITERIAS_LENGTH = "Atleast 3 characters is required for ClientCode\\ClientName";
        public const string MSG_ALLOWED_SEARCH_OPTIONS = "Allowed search options are EXACT, STARTSWITH, CONTAINS";
        public const string MSG_ALLOWED_CLIENT_SEARCH_TYPES = "Allowed search types are ALL, MYFAVORITE, MYACCESS, MYASSIGNMENT";
        public const string MSG_REQUIRED_STATUS_OPTIONS = "Allowed status options are ALL, ACTIVE, INACTIVE";
        public const string MSG_SEARCH_REQUIRED_USER = "User is required for search user specific";
        public const string MSG_SEARCH_REQUIRED_CLIENT = "Client is required for search user specific";
        public const string MSG_SEARCH_REQUIRED_STRATEGY = "Strategy is required for search user specific";
        #endregion
    }
}
