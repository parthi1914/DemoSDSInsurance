﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts.Views;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.ServiceContracts.Models.Plan;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.ServiceContracts.Models.Underwriter;

namespace BrokerPortal.API.Utilities.MapProfiles
{
    public class Map : Profile
    {
        public Map()
        {

            #region PlanMapping
            CreateMap<Plan, PlanResponse>().ForMember(dest => dest.PlanClients, opt => opt.Ignore())
                                           .ForMember(dest => dest.PlanCreatedDate, opt => opt.MapFrom(src => src.CreatedDate))
                                           .ForMember(dest => dest.PlanCreatedBy, opt => opt.MapFrom(src => src.CreatedBy))
                                            .ForMember(dest => dest.PlanUpdatedBy, opt => opt.MapFrom(src => src.UpdatedBy))
                                            .ForMember(dest => dest.PlanUpdatedDate, opt => opt.MapFrom(src => src.UpdatedDate))
                                           .ForMember(dest => dest.PlanStatus, opt => opt.MapFrom(src => src.StatusCodeId))
                                           .ForMember(dest => dest.PlanPrevStatusCode, opt => opt.MapFrom(src => src.PrevStatusCodeId))
                                           .ReverseMap();
            CreateMap<SagittaClient, PlanClientDetailsResponse>().ReverseMap();
            CreateMap<PlanTimeline, PlanTimelineModel>().ReverseMap();
            #endregion

            #region StrategyMapping            
            CreateMap<StrategyTimeline, StrategyTimelineModel>()
                .ForMember(dest => dest.StatusCodeId, opt => opt.MapFrom(src => src.StatusCodeId))
                .ForMember(dest => dest.PrevStatusCodeId, opt => opt.MapFrom(src => src.PrevStatusCodeId))
                .ForMember(dest => dest.StepStatusCode, opt => opt.MapFrom(src => src.StatusCodeId))
                .ForMember(dest => dest.StepStatusCodeDesc, opt => opt.MapFrom(src => src.StatusCode == null ? null : src.StatusCode.StatusName))
                .ForMember(dest => dest.StepStatusGroupCode, opt => opt.MapFrom(src => src.StatusCode == null ? null : src.StatusCode.StatusGroupCode))
                .ForMember(dest => dest.StepStatusGroupName, opt => opt.MapFrom(src => src.StatusCode == null ? null : src.StatusCode.StatusGroupCodeName))
                .ForMember(dest => dest.StepDefName, opt => opt.MapFrom(src => src.StepDef == null ? null : src.StepDef.StepName))
                .ForMember(dest => dest.AssignmentDueDate, opt => opt.MapFrom(src => src.AssignmentDueDate == null ? src.DueDate : src.AssignmentDueDate))
                .ForMember(dest => dest.CompletedDate, opt => opt.MapFrom(src => src.StatusCode!=null && src.StatusCode.StatusGroupCode == AppConstants.STEP_STATUSCODE_COMPLETED ? src.LastStepStatusUpdatedDate : null))
                .ReverseMap();

            CreateMap<Strategy, StrategyResponse>().ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => src.CreatedDate))
                                          .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CreatedBy))
                                          .ForMember(dest => dest.StrategyStatus, opt => opt.MapFrom(src => src.StatusCodeId))
                                          .ForMember(dest => dest.StrategyPrevStatusCode, opt => opt.MapFrom(src => src.PrevStatusCodeId))
                                          .ForMember(dest => dest.UpdatedByUserInfo, opt => opt.MapFrom(src => src.UpdatedByNavigation))
                                          .ReverseMap();

            CreateMap<Strategy, StrategyModel>().ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => src.CreatedDate))
                                          .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CreatedBy))
                                          .ForMember(dest => dest.StrategyStatusCode, opt => opt.MapFrom(src => src.StatusCodeId))
                                          .ForMember(dest => dest.StrategyPrevStatusCode, opt => opt.MapFrom(src => src.PrevStatusCodeId))
                                          .ForMember(dest => dest.StrategyStatusName, opt => opt.MapFrom(src => src.StatusCode.StatusName))
                                          .ForMember(dest => dest.StrategyStatusGroupCode, opt => opt.MapFrom(src => src.StatusCode.StatusGroupCode))
                                          .ForMember(dest => dest.StrategyStatusGroupName, opt => opt.MapFrom(src => src.StatusCode.StatusGroupCodeName))
                                          .ForMember(dest => dest.PlanName, opt => opt.MapFrom(src => src.Plan.PlanName))
                                          .ForMember(dest => dest.ClientId, opt => opt.MapFrom(src => src.StrategyClients.ToArray()[0].SagittaClient.SagittaClientId))
                                          .ForMember(dest => dest.SagittaClientId, opt => opt.MapFrom(src => src.StrategyClients.ToArray()[0].SagittaClient.SagittaClientId))
                                          .ForMember(dest => dest.ClientCode, opt => opt.MapFrom(src => src.StrategyClients.ToArray()[0].SagittaClient.ClientCode))
                                          .ForMember(dest => dest.ClientName, opt => opt.MapFrom(src => src.StrategyClients.ToArray()[0].SagittaClient.ClientName))
                                          .ForMember(dest => dest.UpdatedByUserInfo, opt => opt.MapFrom(src => src.UpdatedByNavigation))
                                          .ForMember(dest => dest.Markets, opt => opt.MapFrom(src => src.Markets))
                                          .ForMember(dest => dest.StrategyStaffs, opt => opt.MapFrom(src => src.StrategyStaffs))
                                          .ReverseMap();
            #endregion

            #region StrategyStaffMapping
            CreateMap<SagittaStaff, SagittaStaffModel>().ReverseMap();

            CreateMap<StrategyStaff, StrategyStaffModel>()
                .ForMember(
                dest => dest.StaffDetails,
                opt => opt.MapFrom(src => src.SagittaStaff))
                .ReverseMap();
            #endregion

            #region Sagitta
            CreateMap<SagittaClient, SagittaClientModel>()

                .ReverseMap();
            CreateMap<SagittaStaffResponse, SagittaStaffRequest>().ReverseMap();
            CreateMap<SagittaClientResponse, SagittaReplClientSearchResponse>()
                .ForMember(dest => dest.ClientId, opt => opt.MapFrom(src => src.SagittaClientId))
                .ReverseMap();
            CreateMap<SagittaReplStaffModel, SagittaStaffResponse>()
               .ForMember(dest => dest.SagittaStaffId, opt => opt.MapFrom(src => src.StaffId))
               .ForMember(dest => dest.isActive, opt => opt.MapFrom(src => src.isActive ?? false))
               .ForMember(dest => dest.ActiveByDate, opt => opt.MapFrom(src => src.ActiveByDate ?? null))
               .ReverseMap();
            CreateMap<SagittaReplStaffModel, SagittaStaffRequest>()
                .ForMember(dest => dest.SagittaStaffId, opt => opt.MapFrom(src => src.StaffId))
                .ForMember(dest => dest.IsDatedOff, opt => opt.MapFrom(src => src.isActive??false))
                .ForMember(dest => dest.DatedOffDate, opt => opt.MapFrom(src => src.ActiveByDate?? null))
                .ReverseMap();

            CreateMap<SagittaClientContactResponse, SagittaReplContactModel>().ReverseMap();
            CreateMap<SagittaPolicy, SagittaPolicyModel>().ReverseMap();
            CreateMap<SagittaPayee, SagittaPayeeModel>().ReverseMap();
            #endregion

            #region FavouritesMapping
            CreateMap<FavouriteClient, FavouriteClientModel>()
                                          .ForMember(dest => dest.ClientCode, opt => opt.MapFrom(src => src.SagittaClient.ClientCode))
                                          .ForMember(dest => dest.ClientName, opt => opt.MapFrom(src => src.SagittaClient.ClientName))
                                          .ForMember(dest => dest.City, opt => opt.MapFrom(src => src.SagittaClient.ClientCity))
                                          .ForMember(dest => dest.State, opt => opt.MapFrom(src => src.SagittaClient.ClientState))
                                          .ForMember(dest => dest.ClientContPersCode, opt => opt.MapFrom(src => src.SagittaClient.ClientContPersCode))
                                          .ForMember(dest => dest.ClientContPersName, opt => opt.MapFrom(src => src.SagittaClient.ClientContPersName))
                                          .ForMember(dest => dest.ClientContPersEmail, opt => opt.MapFrom(src => src.SagittaClient.ClientContPersEmail))
                                          .ForMember(dest => dest.ClientContPersPhone1, opt => opt.MapFrom(src => src.SagittaClient.ClientContPersPhone1))

                                          .ReverseMap();
            CreateMap<FavouriteStrategy, FavouriteStrategyModel>().ReverseMap();
            CreateMap<FavouriteStrategyView, FavouriteStrategyModel>().ReverseMap();
            #endregion

            #region TaskStackMapping
            CreateMap<GenericTaskMeta, TaskMetaModel>().ReverseMap();
            CreateMap<TaskMeta, TaskMetaModel>()
                .ForMember(dest => dest.ClientCode, opt => opt.MapFrom(src => src.SagittaClient.ClientCode))
                .ForMember(dest => dest.ClientName, opt => opt.MapFrom(src => src.SagittaClient.ClientName))
                .ForMember(dest => dest.PlanId, opt => opt.MapFrom(src => src.Strategy.PlanId))
                .ForMember(dest => dest.StrategyId, opt => opt.MapFrom(src => src.Strategy.StrategyId))
                .ForMember(dest => dest.StrategyName, opt => opt.MapFrom(src => src.Strategy.StrategyName))
                .ReverseMap();
            CreateMap<GenericTask, TaskStackModel>().ReverseMap();
            CreateMap<TaskStack, TaskStackModel>()
               .ForMember(dest => dest.GenericTaskId, opt => opt.MapFrom(src => src.GenericTasks.SingleOrDefault().GenericTaskId))
               .ForMember(dest => dest.RequestedByUserId, opt => opt.MapFrom(src => src.GenericTasks.SingleOrDefault().RequestedByUserId))
               .ForMember(dest => dest.RequestedByUserInfo, opt => opt.MapFrom(src => src.GenericTasks.SingleOrDefault().RequestedByUser))
               .ForMember(dest => dest.CreatedByUserInfo, opt => opt.MapFrom(src => src.CreatedByNavigation))
               .ForMember(dest => dest.UpdatedByUserInfo, opt => opt.MapFrom(src => src.UpdatedByNavigation))
               .ForMember(dest => dest.LastTaskStatusUpdatedByUserInfo, opt => opt.MapFrom(src => src.LastTaskStatusUpdatedByNavigation))
               .ForMember(dest => dest.TaskMeta, opt => opt.MapFrom(src => src.TaskMeta))
            .ReverseMap();
           
          
            CreateMap<TaskStep, TaskStepModel>().ReverseMap();
            CreateMap<SagittaStaff, TaskAssignedToInfo>()
                .ReverseMap(); 


            CreateMap<TaskStack, TaskSearchModel>()
                .ForMember(dest => dest.TaskStatusName, opt => opt.MapFrom(src => src.TaskStatusCode.TaskStatusName))
                .ForMember(dest => dest.TaskStatusGroupCode, opt => opt.MapFrom(src => src.TaskStatusCode.TaskStatusGroupCode))
                .ForMember(dest => dest.TaskStatusGroupCodeName, opt => opt.MapFrom(src => src.TaskStatusCode.TaskStatusGroupCodeName))
                .ReverseMap();

            CreateMap<TaskAssignment, TaskAssignmentModel>()
                .ReverseMap();
            CreateMap<StepTimelineStaffAssignment, StepTimelineStaffAssignmentModel>().ReverseMap();
            #endregion

            #region MarketMapping
            CreateMap<MarketAddlCov, MarketAddlCovModel>().ReverseMap();
            CreateMap<MarketModel, Market>().ReverseMap()
                                             .ForMember(dest => dest.MarketAddlCovs, opt => opt.MapFrom(src => src.MarketAddlCovs))
                                              .ForPath(dest => dest.StepName, opt => opt.MapFrom(src => src.StepDef.StepName))
                                               .ForPath(dest => dest.SubStepName, opt => opt.MapFrom(src => src.SubStepDef.SubStepName))
                                                .ForPath(dest => dest.UnderwriterName, opt => opt.MapFrom(src => src.Underwriter.UnderwriterName))
                                                .ForPath(dest => dest.PayeeCode, opt => opt.MapFrom(src => src.SagittaPayee.PayeeCode))
                                                .ForPath(dest => dest.PayeeName, opt => opt.MapFrom(src => src.SagittaPayee.PayeeName))
                                                .ForPath(dest => dest.SagittaPolicyNumber, opt => opt.MapFrom(src => src.SagittaPolicy!=null?src.SagittaPolicy.PolicyNumber:null))
                                                .ForPath(dest => dest.PolicyDescription, opt => opt.MapFrom(src => src.SagittaPolicy != null ? src.SagittaPolicy.PolicyDescription : null))
                .ReverseMap();
            CreateMap<Underwriter, UnderwriterModel>().ReverseMap();
            CreateMap<MarketTimeline, MarketTimelineModel>()
                 .ForMember(dest => dest.StepStatusGroupCode, opt => opt.MapFrom(src => src.StatusCode!=null? src.StatusCode.StatusGroupCode:null))
                .ReverseMap();
            #endregion

            #region SecurityUser
            CreateMap<SecurityUser, SecurityUserInfo>().ReverseMap();
            #endregion
        }
    }
}
