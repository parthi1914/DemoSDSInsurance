﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;

namespace BrokerPortal.API.Utilities.MapProfiles
{
    public class TaskMetaResolver : IValueResolver<TaskStack, TaskStackModel, ICollection<TaskMetaModel>>
    {
        private readonly IMapper _mapper;

        public TaskMetaResolver(IMapper mapper)
        {
            _mapper = mapper;
        }

        public ICollection<TaskMetaModel> Resolve(TaskStack source, TaskStackModel destination, ICollection<TaskMetaModel> destMember, ResolutionContext context)
        {
            if (source.TaskRefType == AppConstants.STEP_GENERIC)
            {
                var genericMeta = source?.GenericTasks.SingleOrDefault()?.GenericTaskMeta;
                return _mapper.Map<List<TaskMetaModel>>(genericMeta); // map from GenericTaskMeta to TaskMeta
            }

            return _mapper.Map<List<TaskMetaModel>>(source?.TaskMeta);
        }
    }

}
