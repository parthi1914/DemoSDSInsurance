﻿namespace BrokerPortal.API.Utilities.HealthCheck.Model
{
    public class MemoryCheckOptions
    {
        public string? Memorystatus { get; set; }
        // Failure threshold (in bytes)
        public long Threshold { get; set; } = 1024L * 1024L * 1024L;
    }
}
