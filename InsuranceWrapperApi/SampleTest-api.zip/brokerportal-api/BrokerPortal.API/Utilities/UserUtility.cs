﻿using System.Security.Claims;

namespace BrokerPortal.API.Utilities
{
    public static class UserUtility
    {
        public static string? GetUserEmailFromClaim(IConfiguration config, ClaimsPrincipal? currentUser)
        {
            string? userSecurityId = config.GetSection("SecurityUser").Value;
            if (string.IsNullOrEmpty(userSecurityId))
            {
                if (currentUser!=null && currentUser.Identity.IsAuthenticated && currentUser.Claims.Any())
                    userSecurityId = currentUser.Claims.ToList().ToArray().FirstOrDefault(x => x.Type.Equals(AppConstants.USER_CLAIM_TYPE_EMAIL)).Value;
                else
                    userSecurityId=null;
            }            
            return userSecurityId;
        }
    }
}
