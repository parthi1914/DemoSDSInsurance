﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api")]
    [ApiController]
    public class FavouriteClientsController : ControllerBase
    {
        private readonly ILogger<FavouriteClientsController> _logger;
        private readonly IFavouriteClientService _service;

        public FavouriteClientsController(IFavouriteClientService service, ILogger<FavouriteClientsController> logger)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet("users/{userId}/favouriteclients")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteClientModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Get(string userId)
        {

            if (!ModelState.IsValid)
                return BadRequest(UnprocessableEntity(ModelState));

            List<FavouriteClientModel> results = await _service.GetUserFavouriteClients(userId);
            if (results != null && results.Count > 0)
                return Ok(results);
            else
                return Ok(new List<FavouriteClientModel>());
        }

        // POST api/<FavoriteClient>
        [HttpPost("users/{userId}/favouriteclients")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteClientModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SetFavouriteClient(string userId, [FromBody] FavouriteClientRequest favoriteClientRequest)
        {

            if (!ModelState.IsValid)
                return BadRequest(UnprocessableEntity(ModelState));

            var result = await _service.SaveUserFavouriteClient(userId, favoriteClientRequest);

            if (result == null)
                return Ok("Favorite Client is not created. Check input Data .");

            return Ok(result);

        }

        [HttpPut("users/{userId}/favouriteclients/{favouriteClientid}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteClientModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemoveFavoriteClient(string userId, Guid favouriteClientid, [FromBody] FavouriteClientRequest favoriteClientRequest)
        {
            if (!ModelState.IsValid)
                return BadRequest(UnprocessableEntity(ModelState));

            var result = await _service.UpdateUserFavouriteClient(userId, favouriteClientid, favoriteClientRequest);
            return Ok(result);

        }

        [HttpGet("favouriteclients")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteClientModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllFavouriteClients()
        {
            var results = await _service.GetAllFavouriteClients();
            if (results != null && results.Count > 0)
                return Ok(results);
            else
                return Ok(new List<FavouriteClientModel>());
        }
    }
}
