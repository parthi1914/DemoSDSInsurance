﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api")]
    [ApiController]
    public class MarketsController : ControllerBase
    {
        private readonly ILogger<MarketsController> _logger;
        private readonly IMarketService _service;
        private readonly IStrategyService _strategyService;
        private readonly ISagittaPolicyService _sagittaPolicyService;
        private readonly ISagittaPayeeService _sagittaPayeeService;

        public MarketsController(IMarketService service, IStrategyService strategyService, ILogger<MarketsController> logger, ISagittaPolicyService sagittaPolicyService, ISagittaPayeeService sagittaPayeeService)
        {
            _logger = logger;
            _service = service;
            _strategyService = strategyService;
            _sagittaPolicyService = sagittaPolicyService;
            _sagittaPayeeService = sagittaPayeeService;
        }

        //GET: PULL ALL MARKETS RELATED TO A STRATEGY
        [HttpGet("strategies/{strategyId}/markets")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllMarketByStrategy(Guid strategyId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetAllMarketByStrategy)));

            List<MarketModel> marketList = new List<MarketModel>();
            StrategyMarketBulkResponse strategyMarketBulkResponse = new StrategyMarketBulkResponse();
            marketList = _service.GetAllMarketByStrategy(strategyId);

            List<SagittaPolicyModel> policyList = new List<SagittaPolicyModel>();
            policyList = _sagittaPolicyService.GetSagittaPoliciesByStrategyId(strategyId);

            strategyMarketBulkResponse.Markets = marketList;
            strategyMarketBulkResponse.SagittaPolicies = policyList;
            AssignPolicyGroupNumber(strategyMarketBulkResponse);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetAllMarketByStrategy)));

            if (strategyMarketBulkResponse != null)
                return Ok(strategyMarketBulkResponse);
            else
                return Ok(new List<MarketModel>());
        }

        //GET: PULL A SPECIFIC MARKET
        [HttpGet("markets/{marketId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetMarketById(Guid marketId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetMarketById)));

            if (marketId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var marketResponse = await _service.GetMarketById(marketId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetMarketById)));

            if (marketResponse != null && marketResponse.MarketId != Guid.Empty)
                return Ok(marketResponse);
            else
                return Ok(new List<MarketModel>());
        }

        //GET: PULL ALL MARKET POLICIES FOR A STRATEGY
        [HttpGet("strategies/{strategyId}/marketpolicies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SagittaPolicyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetStrategyAllMarketPolicies(Guid strategyId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetStrategyAllMarketPolicies)));

            List<SagittaPolicyModel> policyList = new List<SagittaPolicyModel>();
            policyList = _sagittaPolicyService.GetSagittaPoliciesByStrategyId(strategyId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetStrategyAllMarketPolicies)));

            if (policyList != null && policyList.Count > 0)
                return Ok(policyList);
            else
                return Ok(new List<SagittaPolicyModel>());
        }

        ////POST: CREATE NEW MARKET UNDER A STRATEGY
        //[HttpPost("strategies/{strategyId}/markets")]
        //[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketModel))]
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //public async Task<IActionResult> SaveMarket(Guid strategyId, [FromBody] StrategyMarketRequest newMarketRequest)
        //{
            //CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SaveMarket)));
            //IsValidMarketSaveRequest(strategyId, newMarketRequest);

            //MarketModel marketResponse = null;

            //string? securityUserId = newMarketRequest.SecurityUser.SecurityUserId;

            //List<SagittaPayeeRequest>? sagittaPayeeRequests = extractSagittaPayeesFromMarkets(securityUserId, newMarketRequest.Markets.ToList());
            //if (sagittaPayeeRequests != null && sagittaPayeeRequests.Count > 0)
            //    _sagittaPayeeService.BulkMergeSagittaPayees(securityUserId, sagittaPayeeRequests);

            //List<SagittaPolicyModelRequest>? sagittaPolicyRequests = newMarketRequest?.SagittaPolicies?.ToList();
            //if (sagittaPolicyRequests != null && sagittaPolicyRequests.Count > 0)
            //    _sagittaPolicyService.BulkMergeSagittaPolicies(securityUserId, sagittaPolicyRequests);

            //MarketRequest? marketSaveRequest = newMarketRequest.Markets.FirstOrDefault();
            //if (marketSaveRequest != null)
            //{
            //    marketResponse = await _service.SaveMarket(strategyId, securityUserId, marketSaveRequest);
            //    if (marketResponse != null && marketResponse.MarketId != Guid.Empty)
            //        await _strategyService.SyncStrategyForMarkets(marketResponse.StrategyId, securityUserId);
            //}

            //CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SaveMarket)));
            //return Ok(marketResponse);
        //}

        ////PUT: UPDATE PARTICULAR MARKET
        //[HttpPut("markets/{marketId}")]
        //[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketModel))]
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //public async Task<IActionResult> UpdateMarket(Guid marketId, [FromBody] StrategyMarketRequest singleMarketRequest)
        //{
            //CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(UpdateMarket)));
            //IsValidMarketUpdateRequest(marketId, singleMarketRequest);

            //MarketModel marketResponse = null;

            //string? securityUserId = singleMarketRequest.SecurityUser.SecurityUserId;

            //List<SagittaPayeeRequest>? sagittaPayeeRequests = extractSagittaPayeesFromMarkets(securityUserId, singleMarketRequest.Markets.ToList());
            //if (sagittaPayeeRequests != null && sagittaPayeeRequests.Count > 0)
            //    _sagittaPayeeService.BulkMergeSagittaPayees(securityUserId, sagittaPayeeRequests);

            //List<SagittaPolicyModelRequest>? sagittaPolicyRequests = singleMarketRequest?.SagittaPolicies?.ToList();
            //if (sagittaPolicyRequests != null && sagittaPolicyRequests.Count > 0)
            //    _sagittaPolicyService.BulkMergeSagittaPolicies(securityUserId, sagittaPolicyRequests);

            //MarketRequest? marketUpdateRequest = singleMarketRequest.Markets.FirstOrDefault();
            //if (marketUpdateRequest != null)
            //{
            //    marketResponse = await _service.UpdateMarket(marketId, securityUserId, marketUpdateRequest);
            //    if (marketResponse != null && marketResponse.StrategyId != Guid.Empty)
            //        await _strategyService.SyncStrategyForMarkets(marketResponse.StrategyId, securityUserId);
            //}

            //CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(UpdateMarket)));
            //return Ok(marketResponse);
        //}

        //PUT: REMOVE PARTICULAR MARKET
        [HttpPut("markets/{marketId}/remove")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemoveMarket(Guid marketId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(RemoveMarket)));

            if (!ModelState.IsValid || marketId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            //Calling this before market remove because if it is last market then strategy id will come null
            Guid? strategyId = await _service.GetStrategyIdByMarketId(marketId);
            var response = await _service.RemoveMarket(marketId, securityUser.SecurityUserId);
            if (response != null && response.Equals(true))
                await _strategyService.SyncStrategyForMarkets((Guid)strategyId, securityUser.SecurityUserId);

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(RemoveMarket)));
            return Ok();
        }

        //PUT: ARCHIVE PARTICULAR MARKET
        [HttpPut("markets/{marketId}/archive")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ArchiveMarket(Guid marketId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(ArchiveMarket)));

            if (!ModelState.IsValid || marketId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            //Calling this before market remove because if it is last market then strategy id will come null
            Guid? strategyId = await _service.GetStrategyIdByMarketId(marketId);
            var response = await _service.ArchiveMarket(marketId, securityUser.SecurityUserId);
            if (response != null && response.Equals(true))
                await _strategyService.SyncStrategyForMarkets((Guid)strategyId, securityUser.SecurityUserId);

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(ArchiveMarket)));
            return Ok();
        }

        //PUT: BULK INSERT/UPDATE OF MARKETS FOR A STRATEGY
        [HttpPut("strategies/{strategyId}/markets")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkMergeMarkets(Guid strategyId, [FromBody] StrategyMarketBulkRequest marketBulkRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(BulkMergeMarkets)));
            IsValidBulkRequest(marketBulkRequest, strategyId);

            StrategyMarketBulkResponse strategyMarketBulkResponse = new StrategyMarketBulkResponse();

            string? securityUserId = marketBulkRequest.SecurityUser.SecurityUserId;

            List<MarketRequest> marketRequests = marketBulkRequest.Markets.ToList();
            List<SagittaPolicyModelRequest> sagittaPolicyRequests = marketBulkRequest.SagittaPolicies.ToList();

            List<SagittaPayeeRequest> sagittaPayeeRequests = extractSagittaPayeesFromMarkets(securityUserId, marketRequests);

            if (sagittaPayeeRequests != null && sagittaPayeeRequests.Count > 0)
                _sagittaPayeeService.BulkMergeSagittaPayees(securityUserId, sagittaPayeeRequests);

            List<SagittaPolicyModel>? sagittaPolicyModelResponseList = null;
            if (sagittaPolicyRequests != null && sagittaPolicyRequests.Count > 0)
                _sagittaPolicyService.BulkMergeSagittaPolicies(securityUserId, sagittaPolicyRequests);

            List<MarketModel> marketModelResponse = new List<MarketModel>();
            if (marketRequests != null && marketRequests.Count > 0)
            {
                marketModelResponse = await _service.BulkMergeMarkets(strategyId, securityUserId, marketRequests);
                strategyMarketBulkResponse.Markets = marketModelResponse;
                await _strategyService.SyncStrategyForMarkets(strategyId, securityUserId);
            }

            List<SagittaPolicyModel> sagittaPolicyResponse = _sagittaPolicyService.GetSagittaPoliciesByStrategyId(strategyId);
            strategyMarketBulkResponse.SagittaPolicies = sagittaPolicyResponse;

            AssignPolicyGroupNumber(strategyMarketBulkResponse);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(BulkMergeMarkets)));
            return Ok(strategyMarketBulkResponse);
        }



          //PUT: INSERT/UPDATE OF SINGLE MARKET FOR A STRATEGY
        [HttpPut("strategies/{strategyId}/market")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarketModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> MergeMarket(Guid strategyId, [FromBody] StrategyMarketRequest strategyMarketRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(MergeMarket)));
            IsValidMarketRequest( strategyId, strategyMarketRequest);

            StrategyMarketResponse strategyMarketResponse = new StrategyMarketResponse();

            string? securityUserId = strategyMarketRequest.SecurityUser.SecurityUserId;

            MarketRequest marketRequest = strategyMarketRequest.Market;

            //SagittaPayee
            SagittaPayeeRequest sagittaPayeeRequest = extractSagittaPayeeFromMarket(securityUserId, marketRequest);

            if (sagittaPayeeRequest != null)
                _sagittaPayeeService.MergeSagittaPayee(securityUserId, sagittaPayeeRequest);

            //SagittaPolicy
            List<SagittaPolicyModelRequest> sagittaPolicyRequests = strategyMarketRequest.SagittaPolicies.ToList();
            if (sagittaPolicyRequests != null && sagittaPolicyRequests.Count > 0)
            {
                var sagittaPolicyRequest = sagittaPolicyRequests.Where(sp => sp.SagittaPolicyId == marketRequest.SagittaPolicyId).SingleOrDefault();
                if(sagittaPolicyRequest != null)
                    await _sagittaPolicyService.MergeSagittaPolicy(securityUserId, sagittaPolicyRequest);
            }

            //Market
           MarketModel marketModelResponse = new MarketModel();
            if (marketRequest != null)
            {
                marketModelResponse = await _service.MergeMarket(strategyId, securityUserId, marketRequest);
                await _strategyService.SyncStrategyForMarkets(strategyId, securityUserId);
            }

            //Response Building
            StrategyModel strategyResponse = await _strategyService.GetStrategyById(strategyId, true);
            strategyMarketResponse.Strategy = strategyResponse;

            List<SagittaPolicyModel> sagittaPolicyResponse = _sagittaPolicyService.GetSagittaPoliciesByStrategyId(strategyId);
            strategyMarketResponse.SagittaPolicies = sagittaPolicyResponse;

            strategyMarketResponse.Strategy.Markets = new List<MarketModel>() { marketModelResponse };

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(BulkMergeMarkets)));
            return Ok(strategyMarketResponse);
        }


        #region PrivateMethods
        private List<SagittaPayeeRequest> extractSagittaPayeesFromMarkets(string securityUserId, List<MarketRequest> marketRequests)
        {
            List<SagittaPayeeRequest> sagittaPayeeRequests = null;

            if (marketRequests != null && marketRequests.Count > 0)
            {
                sagittaPayeeRequests = new List<SagittaPayeeRequest>();
                List<string?> existingSagPayeeIds = new List<string?>();
                foreach (var marketRequest in marketRequests)
                {

                    if (existingSagPayeeIds != null && !existingSagPayeeIds.Contains(marketRequest.SagittaPayeeId))
                    {
                        existingSagPayeeIds.Add(marketRequest.SagittaPayeeId ?? marketRequest.PayeeCode);
                        SagittaPayeeRequest sagittaPayeeRequest = new SagittaPayeeRequest();
                        sagittaPayeeRequest.SagittaPayeeId = marketRequest.SagittaPayeeId ?? marketRequest.PayeeCode;
                        sagittaPayeeRequest.PayeeCode = marketRequest.PayeeCode;
                        sagittaPayeeRequest.PayeeName = marketRequest.PayeeName;
                        sagittaPayeeRequest.CreatedBy = securityUserId;
                        sagittaPayeeRequest.CreatedDate = DateTime.Now;
                        sagittaPayeeRequest.DatedOffDate = null;
                        sagittaPayeeRequest.IsDatedOff = false;
                        sagittaPayeeRequests.Add(sagittaPayeeRequest);
                    }
                }

            }
            return sagittaPayeeRequests;
        }


        private SagittaPayeeRequest extractSagittaPayeeFromMarket(string securityUserId, MarketRequest marketRequest)
        {
            SagittaPayeeRequest sagittaPayeeRequest = null;

            if(marketRequest != null)
            {
                     sagittaPayeeRequest = new SagittaPayeeRequest();
                    sagittaPayeeRequest.SagittaPayeeId = marketRequest.SagittaPayeeId ?? marketRequest.PayeeCode;
                    sagittaPayeeRequest.PayeeCode = marketRequest.PayeeCode;
                    sagittaPayeeRequest.PayeeName = marketRequest.PayeeName;
                    sagittaPayeeRequest.CreatedBy = securityUserId;
                    sagittaPayeeRequest.CreatedDate = DateTime.Now;
                    sagittaPayeeRequest.DatedOffDate = null;
                    sagittaPayeeRequest.IsDatedOff = false;
            }
            return sagittaPayeeRequest;
        }

        private void IsValidBulkRequest(StrategyMarketBulkRequest marketBulkRequest, Guid strategyId)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (strategyId == null
                || marketBulkRequest.Markets == null
                || marketBulkRequest.Markets.Count == 0
                || marketBulkRequest.SecurityUser == null
                || string.IsNullOrEmpty(marketBulkRequest.SecurityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }
        private void IsValidMarketRequest(Guid? strategyId, StrategyMarketRequest newMarketRequest)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (strategyId == null
                || newMarketRequest.Market == null
                || newMarketRequest.SecurityUser == null
                || string.IsNullOrEmpty(newMarketRequest.SecurityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }
        private void IsValidMarketUpdateRequest(Guid? marketId, StrategyMarketRequest marketUpdateRequest)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (marketId == null
                || marketUpdateRequest.Market == null
                || marketUpdateRequest.SecurityUser == null
                || string.IsNullOrEmpty(marketUpdateRequest.SecurityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }
        private void AssignPolicyGroupNumber(StrategyMarketBulkResponse strategyMarketBulkResponse)
        {
            List<MarketModel>? marketList = strategyMarketBulkResponse.Markets != null ? strategyMarketBulkResponse.Markets.ToList() : null;
            List<SagittaPolicyModel>? sagittaPolicyList = strategyMarketBulkResponse.SagittaPolicies != null ? strategyMarketBulkResponse.SagittaPolicies.ToList() : null;

            if (marketList != null && marketList.Count > 0
                && sagittaPolicyList != null && sagittaPolicyList.Count > 0)
            {
                foreach (SagittaPolicyModel sagittaPolicy in sagittaPolicyList)
                {
                    foreach (MarketModel market in marketList)
                    {
                        if (market.SagittaPolicyId != null && sagittaPolicy.SagittaPolicyId.Equals(market.SagittaPolicyId))
                        {
                            sagittaPolicy.GrpNumber = market.GrpNumber;
                            break;
                        }
                    }
                }
            }
        }

        #endregion
    }
}
