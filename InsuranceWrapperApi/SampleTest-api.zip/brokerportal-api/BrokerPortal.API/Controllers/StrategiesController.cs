﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api")]
    [ApiController]
    public class StrategiesController : ControllerBase
    {
        private readonly ILogger<StrategiesController> _logger;
        private readonly IStrategyService _service;

        public StrategiesController(IStrategyService service, ILogger<StrategiesController> logger)
        {
            _logger = logger;
            _service = service;
        }

        // GET: ALL STRATEGIES
        [HttpGet("strategies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllStrategies()
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetAllStrategies)));

            List<StrategyModel> strategyList = new List<StrategyModel>();
            strategyList = await _service.GetAllStrategies();
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetAllStrategies)));

            if (strategyList != null && strategyList.Count > 0)
                return Ok(strategyList);
            else
                return Ok(new List<StrategyModel>());
        }

        // GET: SINGLE STRATEGY
        [HttpGet("strategies/{strategyId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetStrategyById(Guid strategyId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetStrategyById)));

            if (strategyId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var strategy = await _service.GetStrategyById(strategyId,true);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetStrategyById)));
            if (strategy != null)
                return Ok(strategy);
            else
                return Ok(Array.Empty<StrategyModel>());
        }

        // POST: INSERT SINGLE STRATEGY
        [HttpPost("strategies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SaveStrategy([FromBody] StrategyRequest strategyModel)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SaveStrategy)));

            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var strategyResponse = await _service.SaveStrategy(strategyModel);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SaveStrategy)));
            return Ok(strategyResponse);

        }

        // PUT: UPDATE SINGLE STRATEGY
        [HttpPut("strategies/{strategyId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateStrategy(StrategyRequest strategyModel, Guid strategyId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(UpdateStrategy)));

            if (!ModelState.IsValid || strategyId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var strategy = await _service.UpdateStrategy(strategyId, strategyModel);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(UpdateStrategy)));
            return Ok(strategy);
        }

        // PUT: REMOVE/DELETE SINGLE STRATEGY
        [HttpPut("strategies/{strategyId}/remove")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemoveStrategy(Guid strategyId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(RemoveStrategy)));

            if (!ModelState.IsValid || strategyId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var response = await _service.RemoveStrategy(strategyId, securityUser.SecurityUserId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(RemoveStrategy)));
            return Ok(response);
        }

        // PUT: ARCHIVE SINGLE STRATEGY
        [HttpPut("strategies/{strategyId}/archive")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ArchiveStrategy(Guid strategyId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(ArchiveStrategy)));

            if (!ModelState.IsValid || strategyId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var response = await _service.ArchiveStrategy(strategyId, securityUser.SecurityUserId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(ArchiveStrategy)));
            return Ok(response);
        }

        // POST: SEARCH STRATEGIES
        [HttpPost("strategies/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        public async Task<IActionResult> SearchStrtaegies([FromBody] StrategySearchRequest searchRequest)
        {

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchStrtaegies)));

            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
            isValidSearchRequest(SearchBaseFilterType.ALL, searchRequest);

            StrategySearchType searchType = Enum.Parse<StrategySearchType>(searchRequest.SearchType);
            StrategySearchCriterias searchCriterias = searchRequest.SearchCriterias;
            string? securityUserId =
                !string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail) ? searchRequest.SecurityUser.SecurityUserEmail : searchRequest.SecurityUser.SecurityUserId;

            var strategyList = await _service.SearchStrategies(SearchBaseFilterType.ALL, searchType, searchCriterias, securityUserId, null);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchStrtaegies)));
            if (strategyList != null && strategyList.Count > 0)
                return Ok(strategyList);
            else
                return Ok(new List<StrategyModel>());
        }

        // POST: SEARCH USER SPECFIC STRATEGIES
        [HttpPost("users/{userId}/strategies/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        public async Task<IActionResult> SearchUserStrategies(string userId, [FromBody] StrategySearchRequest searchRequest)
        {

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchStrtaegies)));

            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            isValidSearchRequest(SearchBaseFilterType.USER_SPECIFIC, searchRequest);
            StrategySearchType searchType = Enum.Parse<StrategySearchType>(searchRequest.SearchType);
            StrategySearchCriterias searchCriterias = searchRequest.SearchCriterias;

            var strategyList = await _service.SearchStrategies(SearchBaseFilterType.USER_SPECIFIC, searchType, searchCriterias, userId, null);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchStrtaegies)));
            if (strategyList != null && strategyList.Count > 0)
                return Ok(strategyList);
            else
                return Ok(new List<StrategyModel>());
        }

        // POST: SEARCH CLIENT SPECFIC STRATEGIES
        [HttpPost("sagittaclients/{sagittaClientId}/strategies/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        public async Task<IActionResult> SearchStrtaegiesByClient(string sagittaClientId, [FromBody] StrategySearchRequest searchRequest)
        {

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchStrtaegiesByClient)));

            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            isValidSearchRequest(SearchBaseFilterType.CLIENT_SPECIFIC, searchRequest);
            StrategySearchType searchType = Enum.Parse<StrategySearchType>(searchRequest.SearchType);
            StrategySearchCriterias searchCriterias = searchRequest.SearchCriterias;
            string? securityUserId =
               !string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail) ? searchRequest.SecurityUser.SecurityUserEmail : searchRequest.SecurityUser.SecurityUserId;

            var strategyList = await _service.SearchStrategies(SearchBaseFilterType.CLIENT_SPECIFIC, searchType, searchCriterias, securityUserId, sagittaClientId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchStrtaegiesByClient)));
            if (strategyList != null && strategyList.Count > 0)
                return Ok(strategyList);
            else
                return Ok(new List<StrategyModel>());
        }

        #region PRIVATE METHODS
        private void isValidSearchRequest(SearchBaseFilterType baseFilterType, StrategySearchRequest searchRequest)
        {
            if (!baseFilterType.Equals(nameof(SearchBaseFilterType.USER_SPECIFIC))
                && (searchRequest.SecurityUser == null
                || (string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserId) && string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail)))
                )
                throw new BadRequestException(AppConstants.MSG_REQUIRED_SECURITY_USER);

            if (!string.IsNullOrEmpty(searchRequest.SearchType)
                && !(
                        searchRequest.SearchType.Equals(nameof(StrategySearchType.ALL), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(StrategySearchType.MYFAVORITE), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(StrategySearchType.MYACCESS), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(StrategySearchType.MYASSIGNMENT), StringComparison.OrdinalIgnoreCase)
                    )
                )
                throw new BadRequestException(AppConstants.MSG_ALLOWED_STRATEGY_SEARCH_TYPES);

            //if ((searchRequest.SearchCriterias.strategyStatusCodes == null)
            //    || (searchRequest.SearchCriterias.stepDefCodes == null
            //    && searchRequest.SearchCriterias.stepStatusCodes == null))
            //    throw new BadRequestException(AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS);
        }
        #endregion

    }
}
