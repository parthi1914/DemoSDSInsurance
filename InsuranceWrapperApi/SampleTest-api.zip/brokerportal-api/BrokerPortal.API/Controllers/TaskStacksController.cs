﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api")]
    [ApiController]
    public class TaskStacksController : ControllerBase
    {
        private readonly ILogger<TaskStacksController> _logger;
        private readonly ITaskStackService _service;
        private readonly ISagittaStaffService _sagittaStaffService;
        private readonly ISagittaClientService _sagittaClientService;
        public TaskStacksController(ITaskStackService service,
            ISagittaStaffService sagittaStaffService, ISagittaClientService sagittaClientService,
            ILogger<TaskStacksController> logger)
        {
            _logger = logger;
            _service = service;
            _sagittaStaffService = sagittaStaffService;
            _sagittaClientService = sagittaClientService;
        }

        //GET: RETURN ALL TASKS
        [HttpGet("taskstacks")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskStackModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllTaskStacks()
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetAllTaskStacks)));

            List<TaskStackModel> taskList = new List<TaskStackModel>();
            taskList = await _service.GetAllTaskStacks();

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetAllTaskStacks)));
            if (taskList != null && taskList.Count > 0)
                return Ok(taskList);
            else
                return Ok(new List<TaskStackModel>());
        }

        //GET: RETURN A SPECIFIC TASK
        [HttpGet("taskstacks/{taskStackId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskStackModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetTaskStackById(Guid taskStackId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetTaskStackById)));

            if (taskStackId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var taskResponse = await _service.GetTaskStackById(taskStackId);

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetTaskStackById)));
            if (taskResponse != null)
                return Ok(taskResponse);
            else
                return Ok(new List<TaskStackModel>());

        }

        //POST: CREATE NEW TASK
        [HttpPost("taskstacks")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskStackModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SaveTaskStack([FromBody] TaskStackRequest taskRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SaveTaskStack)));
            isValidTaskSaveRequest(taskRequest);

            TaskStackModel response = null;
            string? securityUserId = taskRequest.SecurityUser.SecurityUserId;
            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");
            TaskStackRequestInfo newTaskRequest = taskRequest.TaskInfo;

            if (newTaskRequest != null)
            {
                if (newTaskRequest.TaskMeta != null
                    && newTaskRequest.TaskMeta.SagittaClientId != null
                        && newTaskRequest.TaskMeta.SagittaClientId > 0)
                {
                    string? sagittaClientId = newTaskRequest.TaskMeta.SagittaClientId.ToString();
                    await _sagittaClientService.SaveSagittaClientFromReplIfNotExist(securityUserId, accessToken, sagittaClientId);
                }

                if (newTaskRequest.TaskAssignTo != null
                    && newTaskRequest.TaskAssignTo.Count > 0)
                {
                    List<string>? requestSagittaStaffIds = newTaskRequest.TaskAssignTo;
                    List<SagittaStaffModel>? sagittaStaffList =
                        await _sagittaStaffService.BulkSaveFromReplByIdsIfNotExists(securityUserId, accessToken, requestSagittaStaffIds);
                }
                response = await _service.SaveTaskStack(securityUserId, newTaskRequest);
            }

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SaveTaskStack)));
            return Ok(response);
        }

        //PUT: UPDATE A SPECIFIC TASK
        [HttpPut("taskstacks/{taskStackId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskStackModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateTaskStack(Guid taskStackId, [FromBody] TaskStackRequest taskRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(UpdateTaskStack)));
            isValidTaskUpdateRequest(taskStackId, taskRequest);

            TaskStackModel? response = null;
            string? securityUserId = taskRequest.SecurityUser.SecurityUserId;
            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");

            TaskStackRequestInfo updateTaskRequest = taskRequest.TaskInfo;

            if (updateTaskRequest != null)
            {
                if (updateTaskRequest.TaskMeta != null
                    && updateTaskRequest.TaskMeta.SagittaClientId != null
                        && updateTaskRequest.TaskMeta.SagittaClientId > 0)
                {
                    string? sagittaClientId = updateTaskRequest.TaskMeta.SagittaClientId.ToString();
                    await _sagittaClientService.SaveSagittaClientFromReplIfNotExist(securityUserId, accessToken, sagittaClientId);
                }

                if (updateTaskRequest.TaskAssignTo != null
                    && updateTaskRequest.TaskAssignTo.Count > 0)
                {
                    List<string>? requestSagittaStaffIds = updateTaskRequest.TaskAssignTo;
                    List<SagittaStaffModel>? sagittaStaffList =
                        await _sagittaStaffService.BulkSaveFromReplByIdsIfNotExists(securityUserId, accessToken, requestSagittaStaffIds);
                }
                response = await _service.UpdateTaskStack(securityUserId, taskStackId, updateTaskRequest);
            }

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(UpdateTaskStack)));
            if (response != null)
                return Ok(response);
            else
                return Ok(new List<TaskStackModel>());
        }

        //PUT: REMOVE A SPECIFIC TASK
        [HttpPut("taskstacks/{taskStackId}/remove")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemoveTaskStack(Guid taskStackId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(RemoveTaskStack)));

            if (!ModelState.IsValid || taskStackId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var response = await _service.RemoveTaskStack(taskStackId, securityUser.SecurityUserId);

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(RemoveTaskStack)));
            return Ok(response);
        }

        //POST: SEARCH IN ALL TASKS
        [HttpPost("taskstacks/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskStackModel))]
        public async Task<IActionResult> SearchTaskStacks([FromBody] TaskSearchRequest searchRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchTaskStacks)));
            isValidSearchRequest(SearchBaseFilterType.ALL, searchRequest, null, null, null);

            //REQUEST RELATED
            string? securityUserId =
                !string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail) ? searchRequest.SecurityUser.SecurityUserEmail : searchRequest.SecurityUser.SecurityUserId;
            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType.ToUpper());
            //CONVERTING MY ACCESS TO MYTEAMASSIGNMENT FOR CLARITY
            if (searchType.Equals(TaskSearchType.MYACCESS))
                searchType = TaskSearchType.MYTEAMASSIGNMENT;
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;

            //RESPONSE RELATED 
            List<TaskStackModel> searchResponse =
                await _service.SearchTaskStacks(SearchBaseFilterType.ALL, searchType, searchCriterias, securityUserId, null, null);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchTaskStacks)));
            if (searchResponse != null && searchResponse.Count > 0)
                return Ok(searchResponse);
            else
                return Ok(new List<TaskStackModel>());
        }

        //POST: SEARCH IN ALL TASKS FOR A USER
        [HttpPost("users/{userId}/taskstacks/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskSearchModel))]
        public async Task<IActionResult> SearchTaskStacksByUser(string userId, [FromBody] TaskSearchRequest searchRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchTaskStacks)));
            isValidSearchRequest(SearchBaseFilterType.USER_SPECIFIC, searchRequest, userId, null, null);

            //REQUEST RELATED
            string? securityUserId = userId;
            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType.ToUpper());
            //CONVERTING MY ACCESS TO MYTEAMASSIGNMENT FOR CLARITY
            if (searchType.Equals(TaskSearchType.MYACCESS))
                searchType = TaskSearchType.MYTEAMASSIGNMENT;
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;

            //RESPONSE RELATED
            List<TaskStackModel> searchResponse =
                await _service.SearchTaskStacks(SearchBaseFilterType.USER_SPECIFIC, searchType, searchCriterias, securityUserId, null, null);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchTaskStacks)));
            if (searchResponse != null && searchResponse.Count > 0)
                return Ok(searchResponse);
            else
                return Ok(new List<TaskStackModel>());
        }

        //POST: SEARCH IN ALL TASKS FOR A CLIENT
        [HttpPost("sagittaclients/{sagittaclientid}/taskstacks/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskSearchModel))]
        public async Task<IActionResult> SearchTaskStacksByClient(string sagittaclientid, [FromBody] TaskSearchRequest searchRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchTaskStacks)));
            isValidSearchRequest(SearchBaseFilterType.CLIENT_SPECIFIC, searchRequest, null, sagittaclientid, null);

            //REQUEST RELATED
            string? securityUserId =
                !string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail) ? searchRequest.SecurityUser.SecurityUserEmail : searchRequest.SecurityUser.SecurityUserId;

            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType.ToUpper());
            //CONVERTING MY ACCESS TO MYTEAMASSIGNMENT FOR CLARITY
            if (searchType.Equals(TaskSearchType.MYACCESS))
                searchType = TaskSearchType.MYTEAMASSIGNMENT;
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;

            //RESPONSE RELATED
            List<TaskStackModel> searchResponse =
                await _service.SearchTaskStacks(SearchBaseFilterType.CLIENT_SPECIFIC, searchType, searchCriterias, securityUserId, Convert.ToInt64(sagittaclientid), null);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchTaskStacks)));
            if (searchResponse != null && searchResponse.Count > 0)
                return Ok(searchResponse);
            else
                return Ok(new List<TaskStackModel>());
        }

        //POST: SEARCH IN ALL TASKS FOR A STRATEGY
        [HttpPost("strategies/{strategyId}/taskstacks/search")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TaskSearchModel))]
        public async Task<IActionResult> SearchTaskStacksByStrategy(Guid strategyId, [FromBody] TaskSearchRequest searchRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(SearchTaskStacks)));
            isValidSearchRequest(SearchBaseFilterType.STRATEGY_SPECIFIC, searchRequest, null, null, strategyId);

            //REQUEST RELATED
            string? securityUserId =
                !string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail) ? searchRequest.SecurityUser.SecurityUserEmail : searchRequest.SecurityUser.SecurityUserId;
            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType.ToUpper());
            //CONVERTING MY ACCESS TO MYTEAMASSIGNMENT FOR CLARITY
            if (searchType.Equals(TaskSearchType.MYACCESS))
                searchType = TaskSearchType.MYTEAMASSIGNMENT;
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;

            //RESPONSE RELATED
            List<TaskStackModel> searchResponse =
                await _service.SearchTaskStacks(SearchBaseFilterType.STRATEGY_SPECIFIC, searchType, searchCriterias, securityUserId, null, strategyId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(SearchTaskStacks)));
            if (searchResponse != null && searchResponse.Count > 0)
                return Ok(searchResponse);
            else
                return Ok(new List<TaskStackModel>());
        }

        #region PRIVATE
        private void isValidTaskSaveRequest(TaskStackRequest taskRequest)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (taskRequest == null
                || taskRequest.TaskInfo == null
                || taskRequest.SecurityUser == null
                || string.IsNullOrEmpty(taskRequest.SecurityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }
        private void isValidTaskUpdateRequest(Guid? taskStackId, TaskStackRequest taskRequest)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (taskStackId == null || taskStackId == Guid.Empty
                || taskRequest == null
                || taskRequest.TaskInfo == null
                || taskRequest.SecurityUser == null
                || string.IsNullOrEmpty(taskRequest.SecurityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }

        private void isValidSearchRequest(SearchBaseFilterType baseFilterType, TaskSearchRequest searchRequest,
            string? userId, string? sagittaClientId, Guid? strategyId)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
                        
            if (baseFilterType.Equals(SearchBaseFilterType.USER_SPECIFIC)
                    && string.IsNullOrEmpty(userId))
                throw new BadRequestException(AppConstants.MSG_SEARCH_REQUIRED_USER);
            else if (baseFilterType.Equals(SearchBaseFilterType.CLIENT_SPECIFIC)
                    && string.IsNullOrEmpty(sagittaClientId))
                throw new BadRequestException(AppConstants.MSG_SEARCH_REQUIRED_CLIENT);
            else if (baseFilterType.Equals(SearchBaseFilterType.STRATEGY_SPECIFIC)
                    && strategyId == Guid.Empty)
                throw new BadRequestException(AppConstants.MSG_SEARCH_REQUIRED_STRATEGY);            

            if (!string.IsNullOrEmpty(searchRequest.SearchType)
                && !(
                        searchRequest.SearchType.Equals(nameof(TaskSearchType.ALL), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(TaskSearchType.MYFAVORITE), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(TaskSearchType.MYACCESS), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(TaskSearchType.MYASSIGNMENT), StringComparison.OrdinalIgnoreCase)
                        || searchRequest.SearchType.Equals(nameof(TaskSearchType.MYTEAMASSIGNMENT), StringComparison.OrdinalIgnoreCase)
                    )
                )
                throw new BadRequestException(AppConstants.MSG_ALLOWED_TASK_SEARCH_TYPES);

            if (!baseFilterType.Equals(SearchBaseFilterType.USER_SPECIFIC)
                && (searchRequest.SecurityUser == null
                    || (searchRequest.SecurityUser!=null 
                        && string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserId) 
                        && string.IsNullOrEmpty(searchRequest.SecurityUser.SecurityUserEmail))
                    )
                )
                throw new BadRequestException(AppConstants.MSG_REQUIRED_SECURITY_USER);
        }
        #endregion

    }
}
