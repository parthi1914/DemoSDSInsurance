﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api")]
    [ApiController]
    public class StrategyStaffsController : ControllerBase
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly ILogger<StrategyStaffsController> _logger;
        private readonly IStrategyStaffService _service;
        private readonly IStrategyService _strategyService;
        private readonly ISagittaStaffService _sagittaStaffService;
        private readonly ISagittaClientService _sagittaClientService;
        private readonly ITaskStackService _taskService;
        private readonly IConfiguration _config;

        public StrategyStaffsController(IStrategyStaffService service,
            IStrategyService strategyService, ISagittaStaffService sagittaStaffService, ISagittaClientService sagittaClientService,
            ITaskStackService taskService, ILogger<StrategyStaffsController> logger, BrokerPortalApiDBContext context, IConfiguration config)
        {
            _service = service;
            _strategyService = strategyService;
            _sagittaStaffService = sagittaStaffService;
            _sagittaClientService = sagittaClientService;
            _taskService = taskService;
            _logger = logger;
            _context = context;
            _config = config;
        }

        // GET ALL STRATEGY STAFFS
        [HttpGet("strategies/{strategyId}/strategystaffs")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyStaffsResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetStrategyStaffs(Guid? strategyId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetStrategyStaffs)));

            string? securityUserId = UserUtility.GetUserEmailFromClaim(_config, User);
            if (string.IsNullOrEmpty(securityUserId))
                throw new BadRequestException(GlobalConstants.ERROR_UNAUTHORIZED);

            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");

            StrategyStaffsResponse strategyStaffResponse = new StrategyStaffsResponse();
            List<StrategyStaffModel>? strategyStaffList = null;
            List<StrategyTimelineModel>? strategyTimelineList = null;
            strategyStaffResponse.StrategyId = strategyId;

            strategyStaffList = await _service.GetStrategyStaffs(strategyId);
            strategyTimelineList = await _strategyService.GetStrategyTimelines(strategyId);

            if (strategyStaffList == null || strategyStaffList.Count == 0)
            {
                SagittaStaffResponse securityUserSagittaStaff = null;

                List<string>? securityUserSagittaStaffIds =
                    await _sagittaStaffService.GetSagittaStaffIdsBySecurityUserId(securityUserId);
                if (securityUserSagittaStaffIds != null && securityUserSagittaStaffIds.Count > 0)
                {
                    string sagittaStaffId = securityUserSagittaStaffIds[0];
                    securityUserSagittaStaff = await _sagittaStaffService.GetSagittaStaffFromRepl(accessToken, sagittaStaffId);
                }

                var sagittaClientId = await _strategyService.GetStrategyClientId(strategyId);
                SagittaClientResponse sagittaClientResponse = null;
                sagittaClientResponse = await _sagittaClientService.GetSagittaClientByIdFromRepl(accessToken, sagittaClientId);
                strategyStaffList = _service.BuildDefaultStrategyStaffsFromClient(strategyId, strategyTimelineList, securityUserSagittaStaff, sagittaClientResponse);
            }
            strategyStaffResponse.SagittaStaffs = strategyStaffList;
            strategyStaffResponse.StrategyTimelines = strategyTimelineList;
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetStrategyStaffs)));
            return Ok(strategyStaffResponse);
        }


        //PUT: BULK INSERT/UPDATE STRATEGY STAFFS
        [HttpPut("strategystaffs")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyStaffsResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkMergeStrategyStaffs([FromBody] StrategyStaffsRequest strategyStaffsBulkRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(BulkMergeStrategyStaffs)));

            isValidBulkRequest(strategyStaffsBulkRequest);

            Guid strategyId = (Guid)strategyStaffsBulkRequest.StrategyId;
            string? securityUserId = strategyStaffsBulkRequest.SecurityUsers.SecurityUserId;
            List<StaffRequest> strategyStaffRequests = strategyStaffsBulkRequest.SagittaStaffs.ToList();
            List<SagittaStaffRequest> sagittaStaffRequests = extractSagittaStaffsFromStaffsRequest(strategyStaffRequests);
            List<StrategyTimelinesRequest>? strategyTimelineRequests = strategyStaffsBulkRequest.StrategyTimelines != null ? strategyStaffsBulkRequest.StrategyTimelines.ToList() : null;

            StrategyStaffsResponse strategyStaffResponse = new StrategyStaffsResponse();
            List<StrategyTimelineModel>? strategyTimelineResponseList = null;
            strategyStaffResponse.StrategyId = strategyId;

            //ADD/UPDATE MASTER DATA - SAGITTA STAFFS
            if (sagittaStaffRequests != null && sagittaStaffRequests.Count > 0)
                await _sagittaStaffService.BulkMergeSagittaStaffs(securityUserId, sagittaStaffRequests);

            //UPDATE STRATEGY TIMELINES AND MARKET TIMELINES ASSIGNMENT DUE DATES
            if (strategyTimelineRequests != null && strategyTimelineRequests.Count > 0)
                strategyTimelineResponseList = await _strategyService.UpdateStrategyTimelines(strategyId, securityUserId, strategyTimelineRequests);

            // ADD/UPDATE STRATEGY STAFFS
            // UPDATE STRATEGY STEP LEVEL AND MARKET LEVEL TASKS FOR ASSIGNMENT DUE DATE CHANGE AND STAFF ASSIGNMENTS
            if (strategyStaffRequests != null && strategyStaffRequests.Count > 0)
            {
                // ADD/UPDATE STRATEGY STAFFS
                List<StrategyStaffModel>? savedStrategyStaffList =
                    await _service.BulkMergeStrategyStaffs(strategyId, securityUserId, strategyStaffRequests);

                // BUILD STRATEGY STEP LEVEL STAFF ASIGNED REQUEST TO SIMPLIFIED TASK ASSIGNMENTS
                List<StrategyStepRequest>? strategyStepAssignmentRequestList =
                    BuildStrategyStepLevelStaffAssignmentRequestList(strategyId, strategyTimelineRequests, strategyStaffRequests, savedStrategyStaffList);

                // UPDATE STRATEGY STEP LEVEL AND MARKET LEVEL TASKS FOR ASSIGNMENT DUE DATE CHANGE AND STAFF ASSIGNMENTS
                if (savedStrategyStaffList != null && savedStrategyStaffList.Count > 0)
                    await _taskService.BulkMergeStrategyStaffsToTasks(strategyId, securityUserId, strategyStepAssignmentRequestList);
            }

            //Retrieve Response
            strategyStaffResponse.SagittaStaffs = await _service.GetStrategyStaffs(strategyId);
            strategyStaffResponse.StrategyTimelines = strategyTimelineResponseList;

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(BulkMergeStrategyStaffs)));
            return Ok(strategyStaffResponse);
        }

        //PUT: REMOVE A PARTICULAR STRATEGY STAFF
        [HttpPut("strategystaffs/{strategyStaffId}/remove")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyStaffModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemoveStrategyStaff(Guid strategyStaffId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(RemoveStrategyStaff)));
            
            string? securityUserId = securityUser.SecurityUserId;
            if (strategyStaffId != Guid.Empty)
            {
                await _taskService.DeleteTaskAssignmentByStrategyStaff(securityUserId, strategyStaffId);
                await _service.DeleteStrategyStaff(securityUserId, strategyStaffId);
            }

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(RemoveStrategyStaff)));
            return Ok(true);
        }

        //PUT: THIS IS USE TO REMOVE A PARTICULAR STRATEGY STAFF
        [HttpPut("strategystaffs/{strategyStaffId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyStaffModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateStrategyStaff(Guid strategyStaffId, [FromBody] StrategyStaffRequest staffUpdateRequest)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(UpdateStrategyStaff)));
            isValidStaffRemoveRequest(staffUpdateRequest);

            string? securityUserId = staffUpdateRequest.SecurityUser.SecurityUserId;
            if (strategyStaffId != Guid.Empty)
            {
                await _taskService.DeleteTaskAssignmentByStrategyStaff(securityUserId, strategyStaffId);
                await _service.DeleteStrategyStaff(securityUserId, strategyStaffId);
            }

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(UpdateStrategyStaff)));
            return Ok(true);
        }

        #region PRIVATE METHODS
        private void isValidBulkRequest(StrategyStaffsRequest strategyStaffsBulkRequest)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (strategyStaffsBulkRequest.StrategyId == null
                || strategyStaffsBulkRequest.SagittaStaffs == null
                || strategyStaffsBulkRequest.SagittaStaffs.Count == 0
                || strategyStaffsBulkRequest.SecurityUsers == null
                || string.IsNullOrEmpty(strategyStaffsBulkRequest.SecurityUsers.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }

        private void isValidStaffRemoveRequest(StrategyStaffRequest staffUpdateRequest)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (string.IsNullOrEmpty(staffUpdateRequest.SecurityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);
        }

        private List<SagittaStaffRequest> extractSagittaStaffsFromStaffsRequest(List<StaffRequest> strategyStaffRequests)
        {
            List<SagittaStaffRequest> sagittaStaffRequests = new List<SagittaStaffRequest>();
            foreach (var staffRequest in strategyStaffRequests)
            {
                if (staffRequest.StaffDetails != null)
                    sagittaStaffRequests.Add(staffRequest.StaffDetails);
            }
            return sagittaStaffRequests;
        }

        private List<StrategyStepRequest>? BuildStrategyStepLevelStaffAssignmentRequestList(Guid strategyId,
            List<StrategyTimelinesRequest>? strategyTimelineRequestList,
            List<StaffRequest> strategyStaffRequests, List<StrategyStaffModel>? savedStrategyStaffList)
        {
            //First Map startegyStaffId from saved staffs
            foreach (var strategyStaffRequest in strategyStaffRequests)
            {
                if (strategyStaffRequest.StrategyStaffId == null)
                {
                    StrategyStaffModel? strategyStaffModel =
                        savedStrategyStaffList.Where(x => x.SagittaStaffId.Equals(strategyStaffRequest.SagittaStaffId))
                        .FirstOrDefault();
                    strategyStaffRequest.StrategyStaffId = strategyStaffModel?.StrategyStaffId;
                }
            }

            List<StrategyStepRequest>? stepLevelStaffAssignmentRequestList = new List<StrategyStepRequest>();
            foreach (var strategyTimelineRequest in strategyTimelineRequestList)
            {
                StrategyStepRequest strategyStepAssignmentRequest = new StrategyStepRequest();
                strategyStepAssignmentRequest.StrategyId = strategyId;
                strategyStepAssignmentRequest.StrategyTimelineId = strategyTimelineRequest.StrategyTimelineId;
                strategyStepAssignmentRequest.StepDefId = strategyTimelineRequest.StepDefId;
                strategyStepAssignmentRequest.DueDate = strategyTimelineRequest.DueDate;
                strategyStepAssignmentRequest.AssignmentDueDate = strategyTimelineRequest.AssignmentDueDate;

                List<StrategyStepStaffAssignmentRequest> strategyStepStaffAssignmentRequests = new List<StrategyStepStaffAssignmentRequest>();

                if (strategyStaffRequests != null)
                {
                    List<StaffRequest>? currStepStaffAssignRequestList =
                    strategyStaffRequests.Where(x => x.StrategyStaffAssignments.Any(y => y.StepDefId.Equals(strategyTimelineRequest.StepDefId))).ToList();

                    if (currStepStaffAssignRequestList != null && currStepStaffAssignRequestList.Count > 0)
                    {
                        foreach (StaffRequest currStepStaffAssignRequest in currStepStaffAssignRequestList)
                        {
                            StrategyStepStaffAssignmentRequest strategyStepStaffAssignmentRequest = new StrategyStepStaffAssignmentRequest();
                            strategyStepStaffAssignmentRequest.StrategyStaffId = currStepStaffAssignRequest.StrategyStaffId;
                            strategyStepStaffAssignmentRequest.SagittaStaffId = currStepStaffAssignRequest.SagittaStaffId;
                            strategyStepStaffAssignmentRequest.StepDefId = strategyTimelineRequest.StepDefId;

                            //SET Deleted flag true if
                            //-- staff itself marked deleted then all assignment from steps need to mark delete
                            //-- or part of startegy but removed from step 
                            strategyStepStaffAssignmentRequest.IsDeleted =
                                currStepStaffAssignRequest.IsDeleted.Equals(true) ? true : false;
                            strategyStepStaffAssignmentRequests.Add(strategyStepStaffAssignmentRequest);
                        }
                    }
                }
                if (strategyStepStaffAssignmentRequests != null && strategyStepStaffAssignmentRequests.Count > 0)
                    strategyStepAssignmentRequest.StrategyStaffAssignments = strategyStepStaffAssignmentRequests;

                stepLevelStaffAssignmentRequestList.Add(strategyStepAssignmentRequest);
            }
            return stepLevelStaffAssignmentRequestList;
        }
        #endregion

    }
}
