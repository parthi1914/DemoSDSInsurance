﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Plan;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api/[controller]")]
    [ApiController]
    public class PlansController : ControllerBase
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly ILogger<PlansController> _logger;
        private readonly IPlanService _service;
        private readonly IStrategyService _strategyService;
        public PlansController(IPlanService service, ILogger<PlansController> logger, BrokerPortalApiDBContext context, IStrategyService strategyService)
        {
            _logger = logger;
            _context = context;
            _service = service;
            _strategyService = strategyService;
        }


        //GET: GET ALL PLANS
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Get()
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(Get)));

            List<PlanResponse> planList = new List<PlanResponse>();
            planList = await _service.GetAllPlans();

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(Get)));
            if (planList != null && planList.Count > 0)
                return Ok(planList);
            else
                return Ok(new List<PlanResponse>());
        }

        //GET: GET A SPECIFIC PLAN BY PLAN ID
        [HttpGet("{PlanId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Get(Guid PlanId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(Get)));

            if (PlanId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var plan = await _service.GetPlanById(PlanId);

            if (plan != null)
            {
                StrategyModel strategyResponse = await _strategyService.GetStrategyByPlanId(PlanId);
                plan.Strategy = strategyResponse;
            }

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(Get)));
            if (plan != null)
                return Ok(plan);
            else
                return Ok(new List<PlanResponse>());
        }

        //GET: GET A SPECIFIC PLAN ALL STRATEGIES
        [HttpGet("{PlanId}/strategies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(StrategyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetPlanStrategies(Guid PlanId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(GetPlanStrategies)));

            if (PlanId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var strategyResponse = await _strategyService.GetStrategyByPlanId(PlanId);

            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(GetPlanStrategies)));
            if (strategyResponse != null)
                return Ok(strategyResponse);
            else
                return Ok(new List<StrategyModel>());
        }

        //POST: CREATE NEW PLAN
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Post([FromBody] PlanRequest planModel)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(Post)));

            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            using var transaction = _context.Database.BeginTransaction();
            {
                try
                {
                    var planResponse = await _service.SavePlan(planModel);
                    StrategyRequest saveStrategyRequest = BuildStrategySaveRequestFromPlan(planResponse.PlanId, planModel);
                    var strategyResponse = await _strategyService.SaveStrategy(saveStrategyRequest);
                    planResponse.Strategy = strategyResponse;
                    transaction.Commit();

                    CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(Post)));
                    return Ok(planResponse);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    CustomLogger.AddCatchLog(_logger, LogLevel.Error, ex);
                    throw new Exception("Plan Save Error => " + ex.Message + (ex.InnerException != null ? ex.InnerException.Message : ""));
                }
            }
        }

        //PUT: UPDATE A SPECIFIC PLAN
        [HttpPut("{PlanId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Put(PlanRequest planModel, Guid PlanId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(Put)));

            if (!ModelState.IsValid || PlanId == Guid.Empty)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var planResponse = await _service.UpdatePlan(planModel, PlanId);
            if (planResponse != null)
            {
                StrategyModel strategyResponse = await _strategyService.GetStrategyByPlanId(PlanId);
                planResponse.Strategy = strategyResponse;
            }
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(Put)));
            return Ok(planResponse);

        }

        //PUT: DELETE A SPECIFIC PLAN AND ASSOCIATED STRATEGIES
        [HttpPut("{PlanId}/remove")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemovePlan(Guid PlanId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(RemovePlan)));

            if (!ModelState.IsValid || PlanId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var planResponse = await _service.RemovePlan(PlanId, securityUser.SecurityUserId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(RemovePlan)));
            return Ok(true);
        }

        //PUT: ARCHIVE A SPECIFIC PLAN AND ASSOCIATED STRATEGIES
        [HttpPut("{PlanId}/archive")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ArchivePlan(Guid PlanId, [FromBody] SecurityUserModel securityUser)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(ArchivePlan)));

            if (!ModelState.IsValid || PlanId == Guid.Empty || string.IsNullOrEmpty(securityUser.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            var planResponse = await _service.ArchivePlan(PlanId, securityUser.SecurityUserId);
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(ArchivePlan)));
            return Ok(true);
        }

        #region PRIVATE MTHODS
        private StrategyRequest BuildStrategySaveRequestFromPlan(Guid planId, PlanRequest planRequest)
        {
            StrategyRequest saveStrategyRequest = new StrategyRequest();
            saveStrategyRequest.PlanId = planId;
            saveStrategyRequest.StrategyId = Guid.NewGuid();
            saveStrategyRequest.StrategyName = planRequest.PlanName;
            saveStrategyRequest.StrategyEffDate = (DateTime)planRequest.PlanEffDate;
            saveStrategyRequest.SagittaClientId = planRequest.PlanClients.SagittaClientId;

            if (planRequest.PlanTimelines != null && planRequest.PlanTimelines.Count > 0)
            {
                List<StrategyTimelinesRequest> strategyTimelinesRequestList = new List<StrategyTimelinesRequest>();
                var submissionDate = planRequest.PlanTimelines.Where(x => x.StepDefId.Equals(AppConstants.PLAN_STEP_STEPDEFID_MARKET))
                     .Select(x => x.DueDate)
                      .First();
                var proposalDate = planRequest.PlanTimelines.Where(x => x.StepDefId.Equals(AppConstants.PLAN_STEP_STEPDEFID_PROPOSAL))
                    .Select(x => x.DueDate)
                     .First();
                var quoteDate = (proposalDate - submissionDate).Days < 10 ?
                    submissionDate.AddDays(1) : proposalDate.AddDays(AppConstants.STRATEGY_STEP_QUOTE_DAYS_THRESHOLD);
                var bindDate = planRequest.PlanTimelines.Where(x => x.StepDefId.Equals(AppConstants.PLAN_STEP_STEPDEFID_BIND))
                    .Select(x => x.DueDate)
                     .First();
                foreach (PlanTimelinesRequest planTimelineRequest in planRequest.PlanTimelines)
                {
                    if (planTimelineRequest.StepDefId == AppConstants.PLAN_STEP_STEPDEFID_MARKET)
                    {
                        StrategyTimelinesRequest strategySubmTimelinesRequest = new StrategyTimelinesRequest();
                        strategySubmTimelinesRequest.StrategyTimelineId = Guid.NewGuid();
                        strategySubmTimelinesRequest.StrategyId = (Guid)saveStrategyRequest.StrategyId;
                        strategySubmTimelinesRequest.StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION;
                        strategySubmTimelinesRequest.DueDate = submissionDate;
                        strategyTimelinesRequestList.Add(strategySubmTimelinesRequest);

                        StrategyTimelinesRequest strategyQuotTimelinesRequest = new StrategyTimelinesRequest();
                        strategyQuotTimelinesRequest.StrategyTimelineId = Guid.NewGuid();
                        strategyQuotTimelinesRequest.StrategyId = (Guid)saveStrategyRequest.StrategyId;
                        strategyQuotTimelinesRequest.StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_QUOTE;
                        strategyQuotTimelinesRequest.DueDate = quoteDate;
                        strategyTimelinesRequestList.Add(strategyQuotTimelinesRequest);
                    }
                    else
                    {
                        StrategyTimelinesRequest strategyTimelinesRequest = new StrategyTimelinesRequest();
                        strategyTimelinesRequest.StrategyTimelineId = Guid.NewGuid();
                        strategyTimelinesRequest.StrategyId = (Guid)saveStrategyRequest.StrategyId;
                        if (planTimelineRequest.StepDefId == AppConstants.PLAN_STEP_STEPDEFID_PROPOSAL)
                            strategyTimelinesRequest.StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_PROPOSAL;
                        else
                            strategyTimelinesRequest.StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_BIND;
                        strategyTimelinesRequest.DueDate = planTimelineRequest.DueDate;
                        strategyTimelinesRequestList.Add(strategyTimelinesRequest);
                    }
                }
                saveStrategyRequest.StrategyTimelines = strategyTimelinesRequestList;
                saveStrategyRequest.SecurityUsers = planRequest.SecurityUsers;
            }

            return saveStrategyRequest;
        }
        #endregion


    }
}

