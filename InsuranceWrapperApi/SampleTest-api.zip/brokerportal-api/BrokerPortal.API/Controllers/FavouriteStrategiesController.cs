﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BrokerPortal.API.Controllers
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api")]
    [ApiController]
    public class FavouriteStrategiesController : ControllerBase
    {
        private readonly ILogger<FavouriteStrategiesController> _logger;
        private readonly IFavouriteStrategyService _service;

        public FavouriteStrategiesController(IFavouriteStrategyService service, ILogger<FavouriteStrategiesController> logger)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet("favouritestrategies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteStrategyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllFavoriteStrategies()
        {
            var results = await _service.GetAllFavouriteStrategies();
            if (results != null && results.Count > 0)
                return Ok(results);
            else
                return Ok(new List<FavouriteStrategyModel>());
        }

        [HttpGet("favouritestrategies/{favouriteStrategyId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteStrategyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetFavouriteStrategyById(Guid favouriteStrategyId)
        {
            var result = await _service.GetFavouriteStrategyById(favouriteStrategyId);
            if (result != null)
                return Ok(result);
            else
                return Ok(new List<FavouriteStrategyModel>());
        }

        [HttpGet("users/{userId}/favouritestrategies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteStrategyModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetFavouriteStrategiesByUser(string userId)
        {

            if (!ModelState.IsValid)
                return BadRequest(UnprocessableEntity(ModelState));

            List<FavouriteStrategyModel> results = await _service.GetFavouriteStrategiesByUser(userId);

            if (results != null && results.Count > 0)
                return Ok(results);
            else
                return Ok(new List<FavouriteStrategyModel>());
        }

        // POST api/<FavoriteClient>
        [HttpPost("users/{userId}/favouritestrategies")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteStrategyModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SetFavouriteStrategy(string userId, [FromBody] FavouriteStrategyRequest favouriteStrategyRequest)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(UnprocessableEntity(ModelState));
            }

            var result = await _service.SaveFavouriteStrategy(userId, favouriteStrategyRequest);

            if (result == null)
                return Ok("Favorite Client is not created. Check input Data .");

            return Ok(result);

        }

        [HttpPut("users/{userId}/favouritestrategies/{favouriteStrategyId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FavouriteStrategyModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> RemoveFavoriteStrategy(string userId, Guid favouriteStrategyId, [FromBody] FavouriteStrategyRequest favouriteStrategyRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(UnprocessableEntity(ModelState));
            }

            var result = await _service.UpdateFavouriteStrategy(userId, favouriteStrategyId, favouriteStrategyRequest);
            return Ok(result);

        }       

    }
}