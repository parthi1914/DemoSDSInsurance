﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace BrokerPortal.API.Controllers.Aggregate
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api/aggregate")]
    [ApiController]
    public class SecurityUsersController : ControllerBase
    {
        private readonly ILogger<SecurityUsersController> _logger;
        private readonly ISecurityUserService _service;
        private readonly ISagittaStaffService _sagittaStaffService;
        private readonly IConfiguration _config;

        public SecurityUsersController(ILogger<SecurityUsersController> logger, ISecurityUserService service,
            ISagittaStaffService sagittaStaffService,
            IConfiguration config)
        {
            _logger = logger;
            _service = service;
            _sagittaStaffService = sagittaStaffService;
            _config = config;
        }

        [HttpPost("securityusers/{securityUserId}/map/externalsystems/{externalSystemId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> MapOrSyncSecurityUserToExternalUsers(string securityUserId, string externalSystemId)
        {
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.INFO_SERVICE_START, nameof(MapOrSyncSecurityUserToExternalUsers)));
            if (string.IsNullOrEmpty(securityUserId) || string.IsNullOrEmpty(externalSystemId)
                || !externalSystemId.Equals(AppConstants.EXTERNAL_SYS_SAGITTA,StringComparison.OrdinalIgnoreCase))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");
            
            string? securityUserEmployeeId = await _service.GetEmployeeIdBySecurityUserId(securityUserId);
            if (!string.IsNullOrEmpty(securityUserEmployeeId))
            {
                externalSystemId = externalSystemId.ToUpper();
                List<SagittaReplStaffModel>? SagittaStaffReplResponseList =
                    await _sagittaStaffService.GetMappedSagittaStaffsFromReplBySecurityUserEmployeeId(accessToken, securityUserId, securityUserEmployeeId);

                if(SagittaStaffReplResponseList!=null && SagittaStaffReplResponseList.Count > 0)
                {
                    List<string>? sagittaStaffIdList = 
                        SagittaStaffReplResponseList.Select(x =>x.StaffId ).ToList();

                    //Push Insert/Update Sagitta Staffs
                    List <SagittaStaffModel> SagittaStaffModelList =
                        await _sagittaStaffService.BulkMergeSagittaStaffsFromReplResponse(securityUserId, SagittaStaffReplResponseList);

                    //Push Insert/Update Security User Map Sagitta Staffs in External System Map
                    if (sagittaStaffIdList != null && sagittaStaffIdList.Count > 0)
                       await _service.BulkMergeUserMapExternalSystem(securityUserId, externalSystemId, sagittaStaffIdList);
                }
            }
            CustomLogger.AddLog(_logger, LogLevel.Information, string.Format(GlobalConstants.RESULT_SUCCESS, nameof(MapOrSyncSecurityUserToExternalUsers)));
            return Ok("SUCCESS");
        }
    }
}