﻿using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace BrokerPortal.API.Controllers.Aggregate
{
    [Authorize(Policy = "BrokerPortal.API")]
    [Route("api/aggregate")]
    [ApiController]
    public class SagittaClientsController : ControllerBase
    {
        private readonly ILogger<SagittaClientsController> _logger;
        private readonly ISagittaClientService _service;
        private readonly IFavouriteClientService _favClientService;
        private readonly ISagittaStaffService _sagittaStaffService;
        private readonly IConfiguration _config;

        public SagittaClientsController(ILogger<SagittaClientsController> logger, ISagittaClientService service,
            IFavouriteClientService favClientService, ISagittaStaffService sagittaStaffService, IConfiguration config)
        {
            _logger = logger;
            _service = service;
            _favClientService = favClientService;
            _sagittaStaffService = sagittaStaffService;
            _config = config;
        }

        [HttpGet("sagitta/repl/sagittaclients/{sagittaClientId}")]
        public async Task<IActionResult> GetSagittaClientFromReplById(string sagittaClientId)
        {
            if (string.IsNullOrEmpty(sagittaClientId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            string? securityUserId = UserUtility.GetUserEmailFromClaim(_config, User);
            if (string.IsNullOrEmpty(securityUserId))
                throw new BadRequestException(GlobalConstants.ERROR_UNAUTHORIZED);

            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");

            SagittaClientResponse sagittaClientResponse = null;
            sagittaClientResponse = await _service.GetSagittaClientByIdFromRepl(accessToken, sagittaClientId);

            if (sagittaClientResponse != null)
            {
                if (!string.IsNullOrEmpty(securityUserId))
                {
                    List<FavouriteClientModel> favClientList = await _favClientService.GetUserFavouriteClients(securityUserId);
                    SetFavourite(sagittaClientResponse, favClientList);
                }
            }
            if (sagittaClientResponse != null)
                return Ok(sagittaClientResponse);
            else
                return Ok(new List<SagittaClientResponse>());
        }

        [HttpPost("sagitta/repl/sagittaclients/search")]
        public async Task<IActionResult> SearchSagittaClientsFromRepl([FromBody] SagittaClientSearchRequest requestBodyJson)
        {
            if (!ModelState.IsValid)
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            isValidSearchRequest(requestBodyJson);

            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");

            List<SagittaClientResponse> sagittaClientResponses = null;

            switch (requestBodyJson.searchType.ToUpper())
            {
                case AppConstants.OPTION_ALL:
                    sagittaClientResponses = await _service.SearchSagittaClientsFromRepl(accessToken, requestBodyJson);
                    break;

                case AppConstants.SAGITTA_CLIENT_SEARCH_TYPE_FAVOURITE:
                    List<FavouriteClientModel> favClientList = await _favClientService.GetUserFavouriteClients(requestBodyJson.SecurityUser.SecurityUserId);
                    if (favClientList != null && favClientList.Count > 0)
                        sagittaClientResponses = await _service.SearchFavSagittaClientsFromRepl(accessToken, favClientList, requestBodyJson);
                    break;

                case AppConstants.SAGITTA_CLIENT_SEARCH_TYPE_ASSIGNEDTOME:
                    string? securityUserId = requestBodyJson.SecurityUser.SecurityUserId;
                    List<string>? mapUserSagStaffIds = await _sagittaStaffService.GetSagittaStaffIdsBySecurityUserId(securityUserId);
                    string[] sagittaStaffIds = mapUserSagStaffIds != null ? mapUserSagStaffIds.ToArray() : null;
                    if (sagittaStaffIds != null && sagittaStaffIds.Length > 0)
                    {
                        requestBodyJson.SearchCriterias.clientAssignedToStaffIds = sagittaStaffIds;
                        sagittaClientResponses = await _service.SearchSagittaClientsFromRepl(accessToken, requestBodyJson);
                    }
                    break;
            }

            if (sagittaClientResponses != null && sagittaClientResponses.Count > 0)
            {
                if (requestBodyJson.SecurityUser != null)
                {
                    List<FavouriteClientModel> favClientList = await _favClientService.GetUserFavouriteClients(requestBodyJson.SecurityUser.SecurityUserId);
                    SetFavourite(sagittaClientResponses, favClientList);
                }
            }

            if (sagittaClientResponses != null)
                return Ok(sagittaClientResponses);
            else
                return Ok(new List<SagittaClientResponse>());
        }

        [HttpPut("sagitta/repl/sagittaclients/{sagittaClientId}/sync")]
        public async Task<IActionResult> SyncSagittaClientFromRepl(string sagittaClientId, [FromBody] SecurityUserModel requestBodyJson)
        {
            if (string.IsNullOrEmpty(sagittaClientId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (string.IsNullOrEmpty(requestBodyJson.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            string? securityUserId = requestBodyJson.SecurityUserId;
            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");

            SagittaClientModel updateResponse = 
                await _service.UpdateSagittaClientFromRepl(securityUserId, accessToken, sagittaClientId);

            return Ok(updateResponse);
        }

        [HttpPost("sagitta/repl/sagittaclients/{sagittaClientId}")]
        public async Task<IActionResult> SaveSagittaClientFromRepl(string sagittaClientId, [FromBody] SecurityUserModel requestBodyJson)
        {
            if (string.IsNullOrEmpty(sagittaClientId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            if (string.IsNullOrEmpty(requestBodyJson.SecurityUserId))
                throw new BadRequestException(GlobalConstants.INVALID_REQUEST);

            string? securityUserId = requestBodyJson.SecurityUserId;
            string? accessToken = Request.Headers[HeaderNames.Authorization];
            if (!string.IsNullOrEmpty(accessToken))
                accessToken = accessToken.Replace("Bearer", "");

            SagittaClientModel saveResponse =
                await _service.SaveSagittaClientFromReplIfNotExist(securityUserId, accessToken, sagittaClientId);

            return Ok(saveResponse);
        }

        private void isValidSearchRequest(SagittaClientSearchRequest requestBodyJson)
        {
            if (!string.IsNullOrEmpty(requestBodyJson.searchType)
                && !(
                        requestBodyJson.searchType.Equals(AppConstants.OPTION_ALL, StringComparison.OrdinalIgnoreCase)
                        || requestBodyJson.searchType.Equals(AppConstants.SAGITTA_CLIENT_SEARCH_TYPE_FAVOURITE, StringComparison.OrdinalIgnoreCase)
                        || requestBodyJson.searchType.Equals(AppConstants.SAGITTA_CLIENT_SEARCH_TYPE_ASSIGNEDTOME, StringComparison.OrdinalIgnoreCase)
                    )
                )
                throw new BadRequestException(AppConstants.MSG_ALLOWED_CLIENT_SEARCH_TYPES);

            if (!string.IsNullOrEmpty(requestBodyJson.searchOption)
                && !(
                        requestBodyJson.searchOption.Equals(AppConstants.SEARCH_OPTION_STARTSWITH, StringComparison.OrdinalIgnoreCase)
                        || requestBodyJson.searchOption.Equals(AppConstants.SEARCH_OPTION_EXACT, StringComparison.OrdinalIgnoreCase)
                        || requestBodyJson.searchOption.Equals(AppConstants.SEARCH_OPTION_CONTAINS, StringComparison.OrdinalIgnoreCase)
                    )
                )
                throw new BadRequestException(AppConstants.MSG_ALLOWED_SEARCH_OPTIONS);

            if (!string.IsNullOrEmpty(requestBodyJson.searchCondition)
                 && !(
                         requestBodyJson.searchCondition.Equals(AppConstants.SEARCH_CONDITION_AND, StringComparison.OrdinalIgnoreCase)
                         || requestBodyJson.searchCondition.Equals(AppConstants.SEARCH_CONDITION_OR, StringComparison.OrdinalIgnoreCase)
                     )
                 )
                throw new BadRequestException(AppConstants.MSG_ALLOWED_SEARCH_CONDITIONS);

            if (!string.IsNullOrEmpty(requestBodyJson.searchType) && requestBodyJson.searchType.Equals(AppConstants.OPTION_ALL, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(requestBodyJson.SearchCriterias.clientCode)
                && string.IsNullOrEmpty(requestBodyJson.SearchCriterias.clientName))
                    throw new BadRequestException(AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS);
            }

            if (!string.IsNullOrEmpty(requestBodyJson.SearchCriterias.clientStatusOption)
                && !(
                         requestBodyJson.SearchCriterias.clientStatusOption.Equals(AppConstants.STATUS_OPTION_ACTIVE, StringComparison.OrdinalIgnoreCase)
                         || requestBodyJson.SearchCriterias.clientStatusOption.Equals(AppConstants.STATUS_OPTION_INACTIVE, StringComparison.OrdinalIgnoreCase)
                         || requestBodyJson.SearchCriterias.clientStatusOption.Equals(AppConstants.OPTION_ALL, StringComparison.OrdinalIgnoreCase)
                     )
                 )
                throw new BadRequestException(AppConstants.MSG_REQUIRED_STATUS_OPTIONS);
            if (requestBodyJson?.SearchCriterias?.clientCode?.Trim()?.Length < 3 ||
                requestBodyJson?.SearchCriterias?.clientName?.Trim()?.Length < 3)
                throw new BadRequestException(AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS_LENGTH);
        }
        private async void SetFavourite(List<SagittaClientResponse> sagittaClientResponseList, List<FavouriteClientModel> favClientList)
        {
            if (favClientList != null && favClientList.Count > 0)
            {
                foreach (var sagittaClient in sagittaClientResponseList)
                {
                    foreach (var favClient in favClientList)
                    {
                        if (sagittaClient.SagittaClientId.Equals(favClient.SagittaClientId))
                        {
                            sagittaClient.isFavorite = true;
                            sagittaClient.FavoriteClientId = favClient.FavouriteClientId;
                            break;
                        }
                    }
                }
            }
        }

        private async void SetFavourite(SagittaClientResponse sagittaClientResponse, List<FavouriteClientModel> favClientList)
        {
            if (favClientList != null && favClientList.Count > 0)
            {
                foreach (var favClient in favClientList)
                {
                    if (sagittaClientResponse.SagittaClientId.Equals(favClient.SagittaClientId.ToString()))
                    {
                        sagittaClientResponse.isFavorite = true;
                        sagittaClientResponse.FavoriteClientId = favClient.FavouriteClientId;
                        break;
                    }
                }
            }
        }


    }
}
