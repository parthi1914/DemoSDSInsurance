﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BrokerPortal.API.Controllers
{
    [AllowAnonymous]
    [ApiController]
    public class HealthCheckController : ControllerBase
    {
        private readonly IConfiguration _config;

        public HealthCheckController(IConfiguration config)
        {
            _config = config;
        }

        [HttpGet("api/healthcheck/ping")]
        public async Task<IActionResult> Ping()
        {
            HttpClient httpClientAccessGuardAPI = new HttpClient();
            var accessGuardApiResponse = await httpClientAccessGuardAPI.GetStringAsync(_config.GetSection("AccessGuardApiURL").Value + "api/healthcheck/ping");
            if (accessGuardApiResponse == null)
            {
                throw new Exception("Access Guard API is not responding!!");
            }

            HttpClient httpClientManageAPI = new HttpClient();
            var manageApiResponse = await httpClientManageAPI.GetStringAsync(_config.GetSection("ManageApiURL").Value + "api/healthcheck/ping");
            if (manageApiResponse == null)
            {
                throw new Exception("ManageAPI is not responding!!");
            }

            HttpClient httpClientSagittaAPI = new HttpClient();
            var sagittaAPIResponse = await httpClientManageAPI.GetStringAsync(_config.GetSection("SagittaURL").Value + "api/healthcheck/ping");
            if (sagittaAPIResponse == null)
            {
                throw new Exception("sagittaWrapperAPI is not responding!!");
            }

            return Ok("Healthy");
        }

        [HttpGet("")]
        public async Task<IActionResult> GetHealthCheckTemp2()
        {
            return Ok("Healthy");
        }

    }
}
