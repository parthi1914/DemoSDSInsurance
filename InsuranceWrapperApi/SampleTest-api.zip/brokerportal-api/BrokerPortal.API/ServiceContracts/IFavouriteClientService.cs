﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Favourite;

namespace BrokerPortal.API.ServiceContracts
{
    public interface IFavouriteClientService
    {        
        Task<List<FavouriteClientModel>> GetAllFavouriteClients();
        Task<List<FavouriteClientModel>> GetUserFavouriteClients(string? securityUserId);
        Task<FavouriteClientModel> GetUserFavouriteClientById(string? securityUserId, Guid favoriteClientId);
        Task<FavouriteClientModel> SaveUserFavouriteClient(string? securityUserId, FavouriteClientRequest favoriteClientRequest);
        Task<FavouriteClientModel> UpdateUserFavouriteClient(string? securityUserId, Guid favoriteClientId, FavouriteClientRequest favoriteClientRequest);
    }
}
