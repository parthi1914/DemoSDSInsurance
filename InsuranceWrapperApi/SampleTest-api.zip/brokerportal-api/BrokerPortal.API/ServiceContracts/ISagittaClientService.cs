﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;

namespace BrokerPortal.API.ServiceContracts
{
    public interface ISagittaClientService
    {
        Task<SagittaClientResponse> GetSagittaClientByIdFromRepl(string? accessToken, string sagittaClientId);
        Task<List<SagittaClientResponse>> SearchSagittaClientsFromRepl(string? accessToken, SagittaClientSearchRequest searchRequest);
        Task<List<SagittaClientResponse>> SearchFavSagittaClientsFromRepl(string? accessToken, List<FavouriteClientModel> favClientList, SagittaClientSearchRequest searchRequest);
        Task<SagittaClientModel> UpdateSagittaClientFromRepl(string? securityUserId, string? accessToken, string sagittaClientId);
        Task<SagittaClientModel> SaveSagittaClientFromReplIfNotExist(string? securityUserId, string? accessToken, string sagittaClientId);
        Task<SagittaClient> GetSagittaClient(string sagittaClientId);
        Task<bool> IsSagittaClientExists(long? sagittaClientId);
    }
}
