﻿namespace BrokerPortal.API.ServiceContracts
{
    public interface ISecurityUserService
    {
        Task<string?> GetEmployeeIdBySecurityUserId(string? securityUserId);
        Task<List<string>?> GetExternalSystemIdsBySecurityUserId(string? securityUserId, string externalSystemId);
        Task<List<string>?> GetSecurityUserIdsByExternalSystemUserIds(string externalSystemId, string[]? externalSystemUserIds);
        Task<bool> BulkMergeUserMapExternalSystem(string? securityUserId,
           string externalSystemId, List<string> externalSystemUserIds);
    }
}
