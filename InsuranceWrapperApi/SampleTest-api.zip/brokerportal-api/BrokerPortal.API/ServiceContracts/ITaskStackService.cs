﻿using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.ServiceContracts
{
    public interface ITaskStackService
    {
        Task<List<TaskStackModel>> GetAllTaskStacks();
        Task<TaskStackModel?> GetTaskStackById(Guid? taskStackId);
        Task<TaskStackModel> SaveTaskStack(string? securityUserId, TaskStackRequestInfo taskRequest);
        Task<TaskStackModel?> UpdateTaskStack(string? securityUserId, Guid taskStackId, TaskStackRequestInfo taskUpdateRequest);
        Task<bool> DeleteTaskStack(Guid taskStackId, string? securityUserId);
        Task<bool> RemoveTaskStack(Guid taskStackId, string? securityUserId);
        Task BulkMergeStrategyStaffsToTasks(Guid strategyId, string? securityUserId, List<StrategyStepRequest>? strategyStepAssignmentRequestList);
        Task<bool> DeleteTaskAssignmentByStrategyStaff(string? securityUserId, Guid strategyStaffId);
        Task<List<TaskStackModel>> SearchTaskStacks(SearchBaseFilterType baseFilterType, TaskSearchType searchType,
            TaskSearchCriterias searchCriterias, string? securityUserId, long? sagittaClientId, Guid? strategyId);
    }
}
