﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;

namespace BrokerPortal.API.ServiceContracts
{
    public interface ISagittaStaffService
    {
        Task<List<SagittaStaffModel>?> BulkSaveFromReplByIdsIfNotExists(string? securityUserId, string? accessToken,
            List<string>? requestSagittaStaffIds);
        Task<List<SagittaStaffModel>> BulkMergeSagittaStaffs(string? securityUserId, List<SagittaStaffRequest> sagittaStaffRequests);
        Task<List<SagittaStaffModel>> BulkMergeSagittaStaffsFromReplResponse(string? securityUserId,
            List<SagittaReplStaffModel> sagittaStaffReplRequests);
        Task<SagittaStaffModel> UpsertSagittaStaff(string? securityUserId, SagittaStaffRequest sagittaStaffRequest);
        Task<List<string>?> GetSagittaStaffIdsBySecurityUserId(string? securityUserId);
        Task<SagittaStaffResponse> GetSagittaStaffFromRepl(string? accessToken, string sagittaStaffId);
        Task<List<SagittaStaffResponse>> GetSagittaStaffByIdsFromRepl(string? accessToken, string[] sagittaStaffId);
        List<SagittaStaff> GetSagittaStaffsByIds(string[] sagittaStaffIds);
        Task<List<SagittaReplStaffModel>?> GetMappedSagittaStaffsFromReplBySecurityUserEmployeeId(string? accessToken,
            string securityUserId, string securityUserEmployeeId);
    }
}
