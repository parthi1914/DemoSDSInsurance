﻿using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.ServiceContracts
{
    public interface IStrategyService
    {
        Task<List<StrategyModel>> GetAllStrategies();
        Task<StrategyModel> GetStrategyById(Guid? strategyId, bool includeMarkets);
        Task<StrategyModel> GetStrategyByPlanId(Guid planId);
        Task<StrategyModel> SaveStrategy(StrategyRequest strategy);
        Task<StrategyModel> UpdateStrategy(Guid strategyId, StrategyRequest strategy);
        Task<List<StrategyTimelineModel>> UpdateStrategyTimelines(Guid? strategyId, string? securityUserId, List<StrategyTimelinesRequest> strategyTimelineRequests);
        Task<bool> RemoveStrategy(Guid strategyId, string securityUserId);
        Task<bool> ArchiveStrategy(Guid strategyId, string securityUserId);
        Task<bool> SyncStrategyForMarkets(Guid strategyId, string securityUserId);
        Task<List<StrategyModel>> SearchStrategies(SearchBaseFilterType baseFilterType, StrategySearchType searchType, 
            StrategySearchCriterias searchCriterias, string? securityUserId, string? sagittaClientId);         
        Task<string?> GetStrategyClientId(Guid? strategyId);
        Task<List<StrategyTimelineModel>> GetStrategyTimelines(Guid? strategyId);
    }
}
