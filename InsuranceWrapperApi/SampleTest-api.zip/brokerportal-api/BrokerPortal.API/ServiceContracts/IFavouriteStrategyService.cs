﻿using BrokerPortal.API.ServiceContracts.Models.Favourite;

namespace BrokerPortal.API.ServiceContracts
{
    public interface IFavouriteStrategyService
    {
        Task<List<FavouriteStrategyModel>> GetAllFavouriteStrategies();
        Task<FavouriteStrategyModel> GetFavouriteStrategyById(Guid favoriteStrategyId);
        Task<FavouriteStrategyModel> SaveFavouriteStrategy(string securityUserId, FavouriteStrategyRequest favoriteStrategyRequest);
        Task<FavouriteStrategyModel> UpdateFavouriteStrategy(string securityUserId, Guid favoriteStrategyId, FavouriteStrategyRequest favoriteStrategyRequest);
        Task<List<FavouriteStrategyModel>> GetFavouriteStrategiesByUser(string securityUserId);
    }
}
