﻿using BrokerPortal.API.ServiceContracts.Models.Markets;

namespace BrokerPortal.API.ServiceContracts
{
    public interface IMarketService
    {
        List<MarketModel> GetAllMarketByStrategy(Guid? strategyId);
        Task<MarketModel> GetMarketById(Guid? marketId);
        Task<MarketModel> SaveMarket(Guid strategyId, string securityUserId, MarketRequest marketSaveRequest);
        Task<MarketModel> UpdateMarket(Guid marketId, string securityUserId, MarketRequest marketUpdateRequest);
        Task<bool> RemoveMarket(Guid? marketId, string securityUserId);
        Task<bool> ArchiveMarket(Guid? marketId, string securityUserId);
        Task<List<MarketModel>> BulkMergeMarkets(Guid? strategyId, string? securityUserId, List<MarketRequest> marketBulkRequest);
        Task<MarketModel> MergeMarket(Guid? strategyId, string? securityUserId, MarketRequest marketRequest);
        Task<Guid?> GetStrategyIdByMarketId(Guid? marketId);
    }
}
