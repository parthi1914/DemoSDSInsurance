﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Plan;
[ExcludeFromCodeCoverage]
public partial class PlanClientModel
{
    public Guid? PlanClientId { get; set; }

    public Guid? PlanId { get; set; }

    public long SagittaClientId { get; set; }

    public bool? IsDeleted { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public virtual SagittaClientModel SagittaClient { get; set; } = null!;
}
