﻿using System.Diagnostics.CodeAnalysis;


namespace BrokerPortal.API.ServiceContracts.Models.Plan;
[ExcludeFromCodeCoverage]
public partial class PlanTimelineModel
{
    public Guid? PlanTimelineId { get; set; }

    public Guid? PlanId { get; set; }

    public DateTime DueDate { get; set; }

    public bool? IsDeleted { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? StepDefId { get; set; }

    //public virtual PlanModel Plan { get; set; } = null!;
}
