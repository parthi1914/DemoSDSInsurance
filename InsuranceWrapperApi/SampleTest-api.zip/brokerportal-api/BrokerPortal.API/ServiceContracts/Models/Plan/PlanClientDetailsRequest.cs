﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace BrokerPortal.API.ServiceContracts.Models.Plan;
[ExcludeFromCodeCoverage]
public partial class PlanClientDetailsRequest
{
    public Guid? PlanClientId { get; set; }
    [Required]
    [JsonPropertyName("clientId")]
    public long SagittaClientId { get; set; }

    public string? ClientCode { get; set; }

    public string? ClientName { get; set; }

    public int? ClientContPersId { get; set; }

    public string? ClientContPersCode { get; set; } = null!;

    public string? ClientContPersName { get; set; } = null!;
    public string? ClientContPersEmail { get; set; } = null!;
    public string? ClientContPersPhone1 { get; set; } = null!;
    
    [JsonPropertyName("city")]
    public string? ClientCity { get; set; }
    [JsonPropertyName("state")]
    public string? ClientState { get; set; }

    public bool? IsDatedOff { get; set; }

    public DateTime? DatedOffDate { get; set; }


}
