﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Plan;
[ExcludeFromCodeCoverage]
public partial class PlanTimelinesRequest
{
    public Guid? PlanTimelineId { get; set; }

    [Required]
    public string StepDefId { get; set; }

    [Required]
    public DateTime DueDate { get; set; }

}
