﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Plan;

[ExcludeFromCodeCoverage]
public partial class PlanRequest
{
    public Guid? PlanId { get; set; }
    [Required]
    public string PlanName { get; set; } = null!;
    [Required]
    public DateTime? PlanEffDate { get; set; }
    public virtual PlanClientDetailsRequest PlanClients { get; set; } = new PlanClientDetailsRequest();
    public virtual ICollection<PlanTimelinesRequest> PlanTimelines { get; set; } = new List<PlanTimelinesRequest>();
    public virtual SecurityUserModel SecurityUsers { get; set; } = new SecurityUserModel();
}
