﻿using BrokerPortal.API.ServiceContracts.Models.Strategy;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Plan;

[ExcludeFromCodeCoverage]
public partial class PlanResponse
{
    public Guid PlanId { get; set; }
    public string PlanName { get; set; } = null!;
    public DateTime? PlanEffDate { get; set; }
    public string PlanStatus { get; set; }
    public string PlanPrevStatusCode { get; set; } = null!;
    public DateTime? PlanCreatedDate { get; set; } = null!;
    public string? PlanCreatedBy { get; set; } = null!;
    public DateTime? PlanUpdatedDate { get; set; }
    public string PlanUpdatedBy { get; set; } = null!;
    public virtual PlanClientDetailsResponse PlanClients { get; set; } = new PlanClientDetailsResponse();
    public virtual ICollection<PlanTimelineModel> PlanTimelines { get; set; } = new List<PlanTimelineModel>();
    public StrategyModel Strategy { get; set; } = null!;
}
