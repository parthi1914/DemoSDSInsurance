﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace BrokerPortal.API.ServiceContracts.Models.Plan;
[ExcludeFromCodeCoverage]
public partial class PlanClientDetailsResponse
{

    public Guid PlanClientId { get; set; }
    [JsonPropertyName("clientId")]
    public long SagittaClientId { get; set; }

    public string ClientCode { get; set; } = null!;

    public string ClientName { get; set; } = null!;

    public int? ClientContPersId { get; set; }

    public string? ClientContPersCode { get; set; } 

    public string? ClientContPersName { get; set; }
    public string? ClientContPersEmail { get; set; }
    public string? ClientContPersPhone1 { get; set; }
    
    [JsonPropertyName("city")]
    public string? ClientCity { get; set; }
    [JsonPropertyName("state")]
    public string? ClientState { get; set; }

    public bool? IsDatedOff { get; set; }

    public DateTime? DatedOffDate { get; set; }

    public bool? IsSagSync { get; set; }

    public DateTime? LastSagSyncDate { get; set; }




}
