﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models
{
    [ExcludeFromCodeCoverage]
    public class SecurityUserInfo
    {
        public string SecurityUserId { get; set; } = null!;
        public string UserEmail { get; set; } = null!;
        public string? UserFirstName { get; set; }
        public string? UserMiddleName { get; set; }
        public string? UserLastName { get; set; }
        public string? UserFullName { get; set; }
        public DateTime? EnteredDate { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
