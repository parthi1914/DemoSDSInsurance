﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models;

[ExcludeFromCodeCoverage]
public partial class SecurityUserModel
{
    public string? SecurityUserId { get; set; }
    public string? SecurityUserEmail { get; set; }
}
