﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Underwriter
{
    [ExcludeFromCodeCoverage]
    public class UnderwriterModel
    {
        public Guid UnderwriterId { get; set; }
        public string SagittaPayeeId { get; set; } = null!;
        public string UnderwriterName { get; set; } = null!;
        public string UnderwriterEmail { get; set; } = null!;
        public bool? IsDatedOff { get; set; }
        public DateTime? DatedOffDate { get; set; }
        public string? ChangeReason { get; set; }
        public bool? IsDeleted { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? Version { get; set; }
        public int? ReasonCode { get; set; }
    }
}
