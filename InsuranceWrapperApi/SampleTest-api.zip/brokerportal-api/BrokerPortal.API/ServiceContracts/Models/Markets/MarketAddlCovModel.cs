﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class MarketAddlCovModel
    {
        public Guid MarketAddlCovId { get; set; }
        public int? Version { get; set; }
        public Guid MarketId { get; set; }

        public int? CovId { get; set; }

        public string? CovCode { get; set; }

        public string? CovDesc { get; set; }

        public bool? IsDeleted { get; set; }

        public string? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }
    }
}
