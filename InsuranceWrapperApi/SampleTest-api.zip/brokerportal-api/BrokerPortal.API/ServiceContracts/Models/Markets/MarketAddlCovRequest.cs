﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class MarketAddlCovRequest
    {
        public Guid? MarketAddlCovId { get; set; }
        public int? Version { get; set; }
        public int? CovId { get; set; }

        public string? CovCode { get; set; }

        public string? CovDesc { get; set; }

        public bool? IsDeleted { get; set; }=false;
    }
}
