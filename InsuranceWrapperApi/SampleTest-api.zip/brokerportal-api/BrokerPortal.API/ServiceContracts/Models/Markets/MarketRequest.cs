﻿using System.Diagnostics.CodeAnalysis;


namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class MarketRequest
    {
        public Guid? MarketId { get; set; }
        public int? Version { get; set; }
        public string? StepDefId { get; set; }

        public string? StepDefName { get; set; }

        public string? SubStepDefId { get; set; }

        public string? SubStepDefName { get; set; }

        public long? SagittaPolicyId { get; set; }
        public string? SagittaPolicyNumber { get; set; }

        public bool? IsSagPol { get; set; } = false;

        public int? CovId { get; set; }

        public string? CovCode { get; set; }

        public string? CovDesc { get; set; }

        public int? GrpNumber { get; set; }

        public decimal? PremiumAmt { get; set; }

        public string? SagittaPayeeId { get; set; }
        public string? PayeeCode { get; set; }
        public string? PayeeName { get; set; }

        public Guid? UnderwriterId { get; set; }

        public int? UnderwriterVersion { get; set; }

        public bool? IsIncumbent { get; set; } = false;

        public string? Notes { get; set; }

        public DateTime? SubmissionSentDateTime { get; set; }

        public DateTime? QuoteRecievedDateTime { get; set; }

        public bool? IsDeleted { get; set; } = false;

        public ICollection<MarketAddlCovRequest>? MarketAddlCoverages { get; set; }

        public ICollection<MarketTimelineRequest>? MarketTimelines { get; set; }

    }
}
