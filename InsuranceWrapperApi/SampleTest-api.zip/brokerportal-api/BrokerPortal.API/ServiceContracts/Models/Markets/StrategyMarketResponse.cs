﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class StrategyMarketResponse
    {
        public virtual StrategyModel Strategy { get; set; } = null!;
        public virtual ICollection<SagittaPolicyModel> SagittaPolicies { get; set; } = null!;
    }
}
