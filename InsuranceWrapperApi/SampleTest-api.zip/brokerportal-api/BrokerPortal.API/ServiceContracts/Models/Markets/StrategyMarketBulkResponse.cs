﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class StrategyMarketBulkResponse
    {
        public virtual ICollection<MarketModel> Markets { get; set; } = null!;
        public virtual ICollection<SagittaPolicyModel> SagittaPolicies { get; set; } = null!;
    }
}
