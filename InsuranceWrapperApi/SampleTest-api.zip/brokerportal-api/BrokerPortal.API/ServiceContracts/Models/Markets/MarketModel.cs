﻿using BrokerPortal.API.ServiceContracts.Models.Underwriter;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class MarketModel
    {
        public Guid MarketId { get; set; }
        public int? Version { get; set; }
        public Guid StrategyId { get; set; }

        public string? StepDefId { get; set; }

        public string? PrevStepDefId { get; set; }

        public string? SubStepDefId { get; set; }

        public string? PrevSubStepDefId { get; set; }

        public long? SagittaPolicyId { get; set; }
        public string? SagittaPolicyNumber { get; set; }
        public string? PolicyDescription { get; set; }

        public bool? IsSagPol { get; set; }

        public int? CovId { get; set; }

        public string? CovCode { get; set; }

        public string? CovDesc { get; set; }

        public int? GrpNumber { get; set; }

        public decimal? PremiumAmt { get; set; }

        public string? SagittaPayeeId { get; set; }
        public string? PayeeCode { get; set; }
        public string? PayeeName { get; set; }

        public Guid? UnderwriterId { get; set; }

        public int? UnderwriterVersion { get; set; }

        public bool? IsIncumbent { get; set; }

        public string? Notes { get; set; }

        public DateTime? SubmissionSentDateTime { get; set; }

        public DateTime? QuoteRecievedDateTime { get; set; }

        public bool? IsDeleted { get; set; }

        public string? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string? UpdatedBy { get; set; }

        public string? StepName { get; set; }
        public string? SubStepName { get; set; }
        public string? UnderwriterName { get; set; }
        public string StatusCodeId { get; set; } = null!;
        public string PrevStatusCodeId { get; set; } = null!;
        public DateTime? UpdatedDate { get; set; }
        public ICollection<MarketAddlCovModel>? MarketAddlCovs { get; set; }
        public UnderwriterModel? Underwriter { get; set; }
        public ICollection<MarketTimelineModel>? MarketTimelines { get; set; }



    }
}
