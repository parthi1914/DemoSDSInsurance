﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class StrategyMarketBulkRequest
    {
        public virtual ICollection<MarketRequest> Markets { get; set; } = null!;
        public virtual ICollection<SagittaPolicyModelRequest> SagittaPolicies { get; set; } = null!;
        public virtual SecurityUserModel SecurityUser { get; set; } = new SecurityUserModel();
    }
}
