﻿using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class MarketTimelineModel
    {
        public Guid? MarketTimelineId { get; set; }
        public int? Version { get; set; }
        public Guid? MarketId { get; set; }
        public string? StepDefId { get; set; }
        public DateTime? AssignmentDueDate { get; set; }
        public DateTime? AssignmentFollowUpDate { get; set; }
        public string? StatusCodeId { get; set; }
        public string? StepStatusGroupCode { get; set; }
        public ICollection<StepTimelineStaffAssignmentModel>? StepAssignments { get; set; }


    }
}
