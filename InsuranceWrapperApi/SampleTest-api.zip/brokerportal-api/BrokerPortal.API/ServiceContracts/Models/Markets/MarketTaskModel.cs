﻿using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Markets
{
    [ExcludeFromCodeCoverage]
    public class MarketTaskModel
    {
        public Guid MarketTaskId { get; set; }

        public Guid MarketId { get; set; }
        public Guid? StrategyTimelineId { get; set; }

        public Guid TaskStackId { get; set; }

        public string? TaskStatusCodeId { get; set; }

        public bool? IsDeleted { get; set; }

        public string? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public TaskStackModel? TaskStack { get; set; }
    }
}
