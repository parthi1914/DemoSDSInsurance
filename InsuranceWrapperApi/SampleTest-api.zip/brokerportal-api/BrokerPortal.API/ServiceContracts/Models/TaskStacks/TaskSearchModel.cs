﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskSearchModel
    {
        public Guid TaskStackId { get; set; }

        public Guid? ParentTaskStackId { get; set; }
        public string? StepDefId { get; set; }
        public string? StepName { get; set; }
        public string? SubStepDefId { get; set; }
        public string? SubStepName { get; set; }
        public string? TaskName { get; set; }
        public string? TaskDesc { get; set; }
        public string? TaskSender { get; set; }
        public int? TaskProirity { get; set; }
        public string? TaskNotes { get; set; }
        public DateTime? TaskDueDate { get; set; }
        public string? TaskStatusCodeId { get; set; }
        public DateTime? TaskSendDate { get; set; }
        public DateTime? LastTaskStatusUpdatedDate { get; set; }
        public string? LastTaskStatusUpdatedBy { get; set; }
        public string? TaskStatusReason { get; set; }
        public bool? IsSysGen { get; set; }
        public bool? IsDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        //CUSTOM PROPERTIES
        public string? TaskStatusName { get; set; }
        public string? TaskStatusGroupCode { get; set; }
        public string? TaskStatusGroupCodeName { get; set; }
        public Guid PlanId { get; set; }
        public Guid StrategyId { get; set; }
        public string? StrategyName { get; set; }
        public DateTime? StrategyEffDate { get; set; }
        public bool? IsStrategyAcesssEnable { get; set; }
        public long SagittaClientId { get; set; }
        public string? ClientCode { get; set; }
        public string? ClientName { get; set; }
        public DateTime? TaskClosedDate { get; set; }
        public string? TaskClosedBy { get; set; }
        public DateTime? TaskCancelledDate { get; set; }
        public string? TaskCancelledBy { get; set; }
        public string? TaskCancelReason { get; set; }
        public MarketModel? MarketInfo { get; set; }
        public List<TaskAssignmentModel> TaskAssignments { get; set; } = new List<TaskAssignmentModel>();
        [JsonIgnore]
        public List<StrategyTaskMeta> StrategyTasks { get; set; } = new List<StrategyTaskMeta>();

        public List<TaskSearchModel> SubTasks { get; set; } = new List<TaskSearchModel>();


    }
}
