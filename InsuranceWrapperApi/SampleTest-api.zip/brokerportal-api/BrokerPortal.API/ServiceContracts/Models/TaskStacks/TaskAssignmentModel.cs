﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskAssignmentModel
    {
        public Guid TaskAssignmentId { get; set; }
        public Guid? ParentTaskAssignmentId { get; set; }
        public string? TaskAssignmentType { get; set; }
        public string? TaskAssignTo { get; set; }
        public TaskAssignedToInfo? TaskAssignedToInfo { get; set; } = new TaskAssignedToInfo();
        public DateTime? TaskAssignDate { get; set; }
        public bool? HasLocked { get; set; }
        public DateTime? LockStartDate { get; set; }
        public DateTime? LockEndDate { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDelegated { get; set; }
        public bool? IsDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }        
        //CUSTOM PROPERTIES
        //public string? TaskAssignToName { get; set; }
        //public string? TaskAssignToEmail { get; set; }
        public Guid? TaskStepId { get; set; }
    }
}
