﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class StepTimelineStaffAssignmentModel
    {
        public Guid? TaskAssignmentId { get; set; }
        public Guid? StrategyStaffId { get; set; }
        public string? SagittaStaffId { get; set; }
        public string? StaffName { get; set; }
        public string? StepDefId { get; set; }
        public Guid? StepTimelineId { get; set; }
        public Guid? TaskStackId { get; set; }
        public Guid? TaskStepId { get; set; }
        public bool? IsDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
