﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskStackRequest
    {
        public virtual TaskStackRequestInfo TaskInfo { get; set; } = null!;
        public virtual SecurityUserModel SecurityUser { get; set; } = new SecurityUserModel();
    }
}
