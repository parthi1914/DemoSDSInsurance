﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskStackRequestInfo
    {
        public Guid? TaskStackId { get; set; }
        public Guid? GenericTaskStackId { get; set; }
        public string? StepDefId { get; set; }
        public int? TaskProirity { get; set; }
        public string? TaskSender { get; set; }
        public string? TaskDesc { get; set; }
        public DateTime? TaskDueDate { get; set; }
        public DateTime? TaskFollowUpDate { get; set; }        
        public string? TaskNotes { get; set; }
        public List<string>? TaskAssignTo { get; set; }
        public string? TaskStatusCodeId { get; set; }
        public string? TaskType { get; set; }
        public TaskMetaRequest TaskMeta { get; set; } = new TaskMetaRequest();
    }
}
