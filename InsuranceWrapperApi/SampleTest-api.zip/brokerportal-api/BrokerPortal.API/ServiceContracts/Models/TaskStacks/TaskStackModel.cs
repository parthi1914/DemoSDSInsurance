﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskStackModel
    {
        public Guid TaskStackId { get; set; }
        public Guid? GenericTaskId { get; set; }
        public Guid? ParentTaskStackId { get; set; }
        public string? TaskName { get; set; }
        public string? TaskDesc { get; set; }
        public string? TaskSender { get; set; }
        public int? TaskProirity { get; set; }
        public string? TaskNotes { get; set; }
        public DateTime? TaskDueDate { get; set; }
        public string? TaskStatusCodeId { get; set; }
        public string? PrevTaskStatusCodeId { get; set; }
        public DateTime? TaskSendDate { get; set; }
        public DateTime? LastTaskStatusUpdatedDate { get; set; }
        public string? LastTaskStatusUpdatedBy { get; set; }
        public SecurityUserInfo? LastTaskStatusUpdatedByUserInfo { get; set; }
        public string? TaskStatusReason { get; set; }
        public string? RequestedByUserId { get; set; }
        public SecurityUserInfo? RequestedByUserInfo { get; set; }
        public DateTime? TaskFollowUpDate { get; set; }
        public string? TaskRefType { get; set; }
        public bool? IsSysGen { get; set; }
        public bool? IsDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public SecurityUserInfo? CreatedByUserInfo { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public SecurityUserInfo? UpdatedByUserInfo { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? TaskOwnerTypeAssignTo { get; set; }
        public string? TaskOwnerTypeRequestedBy { get; set; }
        public virtual ICollection<TaskMetaModel>? TaskMeta { get; set; }
        public virtual ICollection<TaskStepModel>? TaskSteps { get; set; }

    }
}
