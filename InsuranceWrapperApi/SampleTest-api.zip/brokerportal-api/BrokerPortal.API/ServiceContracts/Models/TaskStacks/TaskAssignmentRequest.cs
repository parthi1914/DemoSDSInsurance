﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskAssignmentRequest
    {
        public Guid TaskAssignmentId { get; set; }
        public Guid TaskStackId { get; set; }
        public string? TaskAssignToSagittaStaffId { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsDelegated { get; set; }
    }
}
