﻿using BrokerPortal.API.Utilities;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskSearchRequest
    {
        public string SearchType { get; set; } = AppConstants.OPTION_ALL;

        [Required(ErrorMessage = AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS)]
        public TaskSearchCriterias SearchCriterias { get; set; }
        public SecurityUserModel? SecurityUser { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class TaskSearchCriterias
    {
        public string TaskAssignType { get; set; } = nameof(TaskAssignTypeSearchCriteria.ALL);
        public string TaskCategory { get; set; } = nameof(TaskCategorySearchCriteria.ALL);
        public string[] TaskStatusCodes { get; set; } = { nameof(TaskStatusCodesSearchCriteria.ALL) };
    }
}
