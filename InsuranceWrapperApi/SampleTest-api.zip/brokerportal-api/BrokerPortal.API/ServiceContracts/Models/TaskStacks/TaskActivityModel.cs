﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks;

[ExcludeFromCodeCoverage]
public partial class TaskActivityModel
{
    public Guid TaskActivityId { get; set; }

    public Guid TaskStackId { get; set; }

    public Guid TaskAssignmentId { get; set; }

    public Guid? ParentTaskStackId { get; set; }

    
    public string? StepDefId { get; set; }

    
    public string? SubStepDefId { get; set; }

    
    public string? TaskName { get; set; }

  
    public string? TaskDesc { get; set; }

    public int? TaskProirity { get; set; }

    public string? TaskNotes { get; set; }

   
    public string? TaskSender { get; set; }

   
    public string? TaskSendDate { get; set; }

   
    public DateTime? TaskDueDate { get; set; }

   
    public string? TaskStatusCodeId { get; set; }

   
    public DateTime? TaskStatusDate { get; set; }

    public string? TaskStatusReason { get; set; }

   
    public DateTime? ActivitiyDate { get; set; }

    public Guid? TaskStepId { get; set; }

}
