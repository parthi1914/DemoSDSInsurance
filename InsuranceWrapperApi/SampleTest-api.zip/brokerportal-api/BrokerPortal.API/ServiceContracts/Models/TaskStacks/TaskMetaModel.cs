﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskMetaModel
    {        
        public Guid TaskMetaId { get; set; }
        public Guid? GenericTaskMetaId { get; set; }
        public Guid TaskStackId { get; set; }
        public Guid GenericTaskId { get; set; }
        public Guid? PlanId { get; set; }
        public Guid? StrategyId { get; set; }
        public Guid? StrategyTimelineId { get; set; }
        public Guid? MarketId { get; set; }
        public long? SagittaClientId { get; set; }
        public long? SagittaPolicyId { get; set; }      
        public string? ClientCode { get; set; }
        public string? ClientName { get; set; }
        public string? StrategyName { get; set; }
        public Guid? UnderwriterId { get; set; }

    }
}
