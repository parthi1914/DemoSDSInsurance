﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks
{
    [ExcludeFromCodeCoverage]
    public class TaskAssignedToInfo
    {
        public string? StaffCode { get; set; }
        public string? StaffName { get; set; }
        public string? StaffTitle { get; set; }
        public string? StaffEmail { get; set; }
        public string? City { get; set; }
    }
}
