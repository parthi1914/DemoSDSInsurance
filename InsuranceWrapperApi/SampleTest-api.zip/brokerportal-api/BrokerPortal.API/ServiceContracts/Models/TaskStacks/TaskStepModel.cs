﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.TaskStacks;


[ExcludeFromCodeCoverage]
public partial class TaskStepModel
{   
    public Guid TaskStepId { get; set; }
    public Guid TaskStackId { get; set; }
    public string? StepDefId { get; set; }   
    public string? SubStepDefId { get; set; }   
    public string? StatusCodeId { get; set; }   
    public string? TaskStepRefType { get; set; }   
    public string? TaskStepRefKey { get; set; }   
    public DateTime? LastStepStatusUpdatedDate { get; set; }  
    public string? LastStepStatusUpdatedBy { get; set; }
    public bool? IsDeleted { get; set; }  
    public string? CreatedBy { get; set; }  
    public DateTime? CreatedDate { get; set; }   
    public string? UpdatedBy { get; set; }  
    public DateTime? UpdatedDate { get; set; }
    public virtual ICollection<TaskAssignmentModel> TaskAssignments { get; set; } = new List<TaskAssignmentModel>();
    public virtual ICollection<TaskActivityModel> TaskActivities { get; set; } = new List<TaskActivityModel>();

}
