﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Sagitta
{
    [ExcludeFromCodeCoverage]
    public class SagittaClientResponse
    {
        public string? SagittaClientId { get; set; }
        public string? ClientCode { get; set; }
        public string? ClientName { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public string? Catcode1 { get; set; }

        public string? Catcode2 { get; set; }

        public string? Catcode3 { get; set; }

        public string? Catcode4 { get; set; }

        public string? Catcode5 { get; set; }

        public string? City { get; set; }

        public string? ClientContactName { get; set; }
        public int? ClientContPersId { get; set; }
        public string? ClientContPersCode { get; set; }
        public string? ClientContPersName { get; set; }
        public string? ClientContPersEmail { get; set; }
        public string? ClientContPersPhone1 { get; set; }

        public decimal? DivisionCode { get; set; }
        public string? dept { get; set; }

        public string? Emailaddress { get; set; }

        public string? Fein { get; set; }

        public string? Inspectioncontact { get; set; }

        public string? Prod1 { get; set; }

        public string? Prod2 { get; set; }

        public string? Prod3 { get; set; }

        public string? Serv1 { get; set; }

        public string? Serv2 { get; set; }

        public string? Serv3 { get; set; }

        public string? Siccode1 { get; set; }

        public string? Siccode2 { get; set; }

        public string? Siccode3 { get; set; }

        public string? Source { get; set; }

        public string? State { get; set; }

        public string? Status { get; set; }

        public string? Status1 { get; set; }

        public string? Status2 { get; set; }

        public string? Status3 { get; set; }

        public string? Status4 { get; set; }

        public string? Status5 { get; set; }

        public string? Telephone1 { get; set; }

        public string? Telephone2 { get; set; }

        public string? Zipcode { get; set; }

        public string? Zipcodeext { get; set; }
        public bool? isActive { get; set; }=false;

        public bool? isFavorite { get; set; } = false;
        public Guid? FavoriteClientId { get; set; }

        public ICollection<SagittaStaffResponse>? Producers { get; set; }

        public ICollection<SagittaStaffResponse>? Servicers { get; set; }

        public ICollection<SagittaStaffResponse>? ServiceTeams { get; set; }

        public ICollection<SagittaClientContactResponse>? Contacts { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class SagittaStaffResponse
    {
        public string SagittaStaffId { get; set; } = null!;
        public string? EmployeeType { get; set; }
        public string? UserId { get; set; }
        public string? StaffEmpCode { get; set; }
        public string? StaffNetworkId { get; set; }     
        public string? dept { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? DivisionNo { get; set; }
        public string? EmailAddress { get; set; }
        public string? Homephone { get; set; }
        public string? MobilePhone { get; set; }
        public string? Npn { get; set; }
        public string? SecurityRole { get; set; }
        public string? StaffCode { get; set; }
        public string? StaffName { get; set; }
        public string? StaffTitle { get; set; }
        public string? State { get; set; }
        public DateTime? TermDate { get; set; }
        public string? Zipcode { get; set; }
        public bool? isActive { get; set; }
        public DateTime? ActiveByDate { get; set; }
        public int? StaffIndex { get; set; }
        public string? StaffServiceTeamTitle { get; set; }
        public decimal? StaffServiceTeamProdCredit { get; set; }

        
       


    }
    [ExcludeFromCodeCoverage]
    public class SagittaClientContactResponse
    {
        public string ContactId { get; set; } = null!;
        public string BusinessEmailAddress { get; set; }
        public string BusinessMobilePhone { get; set; }
        public string BusinessPhone { get; set; }
        public string BusPhoneExt { get; set; }
        public decimal? ClientId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? TypeCode { get; set; }

    }
}
