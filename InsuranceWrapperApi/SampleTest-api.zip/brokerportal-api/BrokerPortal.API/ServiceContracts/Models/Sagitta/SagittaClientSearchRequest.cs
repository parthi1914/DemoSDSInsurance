﻿using BrokerPortal.API.Utilities;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Sagitta
{
    [ExcludeFromCodeCoverage]
    public class SagittaClientSearchRequest
    {
        public string searchType { get; set; } = AppConstants.OPTION_ALL;
        public string? searchOption { get; set; } = AppConstants.SEARCH_OPTION_CONTAINS;
        public string? searchCondition { get; set; } = AppConstants.SEARCH_CONDITION_OR;

        [Required(ErrorMessage = AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS)]
        public SearchClientCriterias? SearchCriterias { get; set; }
        public SecurityUserModel? SecurityUser { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class SearchClientCriterias
    {
        public string? clientStatusOption { get; set; } = AppConstants.STATUS_OPTION_ACTIVE;
        public string? clientCode { get; set; } = string.Empty;
        public string? clientName { get; set; } = string.Empty;
        public string[]? clientAssignedToStaffIds { get; set; }
    }
}
