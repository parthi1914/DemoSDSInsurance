﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Sagitta
{
    [ExcludeFromCodeCoverage]
    public class SagittaPayeeRequest
    {
        public string SagittaPayeeId { get; set; } = null!;

        public string PayeeCode { get; set; } = null!;

        public string? PayeeName { get; set; }

        public bool? IsDatedOff { get; set; }

        public DateTime? DatedOffDate { get; set; }

        public string CreatedBy { get; set; } = null!;

        public DateTime? CreatedDate { get; set; }
    }
}
