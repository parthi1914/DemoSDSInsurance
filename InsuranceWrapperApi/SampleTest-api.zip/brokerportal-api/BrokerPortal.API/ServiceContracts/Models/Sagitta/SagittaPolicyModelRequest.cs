﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Sagitta
{
    [ExcludeFromCodeCoverage]
    public class SagittaPolicyModelRequest
    {
        public long? SagittaPolicyId { get; set; }

        public long? SagittaClientId { get; set; }

        public string? PolicyNumber { get; set; }
        public string? PolicyDescription { get; set; }

        public DateTime? PolicyEffDate { get; set; }

        public DateTime? PolicyExpDate { get; set; }

        public string? PolicyType { get; set; }

        public string? NewRenew { get; set; }

        public int? CovId { get; set; }

        public string? CovCode { get; set; }

        public int? InsurorId { get; set; }

        public string? InsurorCode { get; set; }

        public string? PayeeId { get; set; }

        public string? PayeeCode { get; set; }

        public string? PayeeName { get; set; }

        public string? Prod1Code { get; set; }

        public string? Prod2Code { get; set; }

        public string? Prod3Code { get; set; }

        public string? Prod1Name { get; set; }

        public string? Prod2Name { get; set; }

        public string? Prod3Name { get; set; }

        public string? Serv1Code { get; set; }

        public string? Serv2Code { get; set; }

        public string? Serv3Code { get; set; }

        public string? Serv1Name { get; set; }

        public string? Serv2Name { get; set; }

        public string? Serv3Name { get; set; }

        public decimal? PremiumAmt { get; set; }

        public decimal? CommissionAmt { get; set; }

        public string? MarketingRepId { get; set; }

        public string? MarketingRepCode { get; set; }

        public string? MarketingRepName { get; set; }

        public string? AccountExecId { get; set; }

        public string? AccountExecCode { get; set; }

        public string? AccountExecName { get; set; }

        public bool? IsActive { get; set; }

        public bool? IsSagSync { get; set; }
    }
}
