﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Sagitta;
[ExcludeFromCodeCoverage]
public partial class SagittaClientModel
{
    public long SagittaClientId { get; set; }

    public string ClientCode { get; set; } = null!;

    public string ClientName { get; set; } = null!;
    public int? ClientContPersId { get; set; }
    public string? ClientContPersCode { get; set; }
    public string? ClientContPersName { get; set; }
    public string? ClientContPersEmail { get; set; }
    public string? ClientContPersPhone1 { get; set; }
    public string? ClientCity { get; set; }
    public string? ClientState { get; set; }

    public bool? IsDatedOff { get; set; }

    public DateTime? DatedOffDate { get; set; }

    public bool? IsSagSync { get; set; }

    public DateTime? LastSagSyncDate { get; set; }

    public bool? IsDeleted { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }
}
