﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Sagitta
{
    [ExcludeFromCodeCoverage]
    public class SagittaPayeeModel
    {
        public string SagittaPayeeId { get; set; }

        public string PayeeCode { get; set; }

        public string? PayeeName { get; set; }

        public bool? IsDatedOff { get; set; }

        public DateTime? DatedOffDate { get; set; }

        public bool? IsSagSync { get; set; }

        public DateTime? LastSagSyncDate { get; set; }

        public string? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string CreatedBy { get; set; } = null!;

        public DateTime? CreatedDate { get; set; }
    }
}
