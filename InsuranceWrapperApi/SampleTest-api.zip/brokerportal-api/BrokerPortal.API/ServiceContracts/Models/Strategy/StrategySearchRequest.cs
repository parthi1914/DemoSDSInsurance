﻿using BrokerPortal.API.Utilities;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategySearchRequest
    {
        public string SearchType { get; set; } = AppConstants.OPTION_ALL;

        [Required(ErrorMessage = AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS)]
        public StrategySearchCriterias SearchCriterias { get; set; }

        public SecurityUserModel? SecurityUser { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class StrategySearchCriterias
    {
        public string[] strategyStatusCodes { get; set; } = { AppConstants.STEP_STATUSGROUPCODE_ACTIVE};
        //public string[] stepDefCodes { get; set; } = { AppConstants.OPTION_ALL };
        //public string[] stepStatusCodes { get; set; } = { AppConstants.OPTION_ALL };
    }
}
