﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyRequest
    {
        public Guid? StrategyId { get; set; }
        [Required]
        public string StrategyName { get; set; }

        [Required]
        public Guid PlanId { get; set; }

        [Required]
        public DateTime StrategyEffDate { get; set; }
        [Required]
        [JsonPropertyName("clientId")]
        public long SagittaClientId { get; set; }

        public virtual ICollection<StrategyTimelinesRequest> StrategyTimelines { get; set; } = new List<StrategyTimelinesRequest>();

        public virtual SecurityUserModel SecurityUsers { get; set; } = new SecurityUserModel();
    }
}
