﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyStaffsRequest
    {
        public Guid? StrategyId { get; set; } = null!;
        public virtual ICollection<StaffRequest> SagittaStaffs { get; set; } = null!;
        public virtual ICollection<StrategyTimelinesRequest> StrategyTimelines { get; set; } = new List<StrategyTimelinesRequest>();
        public virtual SecurityUserModel SecurityUsers { get; set; } = new SecurityUserModel();
    }
}
