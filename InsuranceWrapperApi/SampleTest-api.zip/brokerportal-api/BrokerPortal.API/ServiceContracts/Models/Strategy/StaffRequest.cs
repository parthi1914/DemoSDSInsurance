﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StaffRequest
    {
        public Guid? StrategyStaffId { get; set; }
        public string? SagittaStaffId { get; set; } = null!;
        public bool? IsMae { get; set; }
        public bool? IsAccessible { get; set; }
        public bool? IsDeleted { get; set; }
        public virtual SagittaStaffRequest StaffDetails { get; set; } = null!;
        public virtual ICollection<StrategyStaffAssignmentRequest> StrategyStaffAssignments { get; set; } = new List<StrategyStaffAssignmentRequest>();
    }
}
