﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyStepRequest
    {
        public Guid StrategyId { get; set; }
        public Guid? StrategyTimelineId { get; set; }        
        public string StepDefId { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? AssignmentDueDate { get; set; }
        public virtual List<StrategyStepStaffAssignmentRequest> StrategyStaffAssignments { get; set; } = new List<StrategyStepStaffAssignmentRequest>();
    }
}
