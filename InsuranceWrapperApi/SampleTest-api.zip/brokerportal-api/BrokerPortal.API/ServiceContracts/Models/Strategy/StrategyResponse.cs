﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyResponse
    {
        public Guid StrategyId { get; set; }
        public string StrategyName { get; set; }
        public Guid PlanId { get; set; }
        public DateTime StrategyEffDate { get; set; }
        [JsonPropertyName("clientId")]
        public long SagittaClientId { get; set; }
        public string StrategyStatus { get; set; } = null!;
        public string StrategyPrevStatusCode { get; set; } = null!;
        public DateTime? CreatedDate { get; set; } = null!;
        public string? CreatedBy { get; set; } = null!;
        public DateTime? UpdatedDate { get; set; } = null!;
        public string? UpdatedBy { get; set; } = null!;
        public virtual SecurityUserInfo? UpdatedByUserInfo { get; set; }
        public virtual ICollection<StrategyTimelineModel> StrategyTimelines { get; set; } = new List<StrategyTimelineModel>();
    }

}
