﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyStaffModel
    {
        public Guid? StrategyStaffId { get; set; }

        public Guid? StrategyId { get; set; }
        public string? SagittaStaffId { get; set; }

        public bool? IsMae { get; set; }

        public bool? IsAccessible { get; set; }

        public bool? IsDeleted { get; set; }

        public string? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public SagittaStaffModel? StaffDetails { get; set; }

        public virtual ICollection<StepTimelineStaffAssignmentModel> StrategyStaffAssignments { get; set; } = new List<StepTimelineStaffAssignmentModel>();
    }
}
