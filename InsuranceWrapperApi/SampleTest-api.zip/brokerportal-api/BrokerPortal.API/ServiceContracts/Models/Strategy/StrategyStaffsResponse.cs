﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyStaffsResponse
    {
        public Guid? StrategyId { get; set; } = null!;
        public virtual ICollection<StrategyStaffModel> SagittaStaffs { get; set; } = null!;
        public virtual ICollection<StrategyTimelineModel> StrategyTimelines { get; set; } = new List<StrategyTimelineModel>();
    }
}