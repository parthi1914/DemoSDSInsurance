﻿using BrokerPortal.API.ServiceContracts.Models.Markets;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyModel
    {
        public Guid StrategyId { get; set; }
        public string StrategyName { get; set; } = null!;
        public Guid PlanId { get; set; }
        public string PlanName { get; set; } = null!;
        public DateTime StrategyEffDate { get; set; }
        public long SagittaClientId { get; set; }
        public long ClientId { get; set; }
        public string ClientCode { get; set; } = null!;
        public string ClientName { get; set; } = null!;
        public string StrategyPrevStatusCode { get; set; } = null!;
        public string? StrategyStatusCode { get; set; }
        public string? StrategyStatusName { get; set; }
        public string? StrategyStatusGroupCode { get; set; }
        public string? StrategyStatusGroupName { get; set; }
        public DateTime? CreatedDate { get; set; } = null!;
        public string? CreatedBy { get; set; } = null!;
        public string? UpdatedBy { get; set; } = null!;
        public DateTime? UpdatedDate { get; set; } = null!;
        public decimal TotalPremium { get; set; }
        public int TotalCountPolicyLines { get; set; }
        public int TotalCountPolicies { get; set; }
        public bool? IsStrategyAcesssEnable { get; set; }
        public virtual SecurityUserInfo? UpdatedByUserInfo { get; set; }
        public virtual ICollection<StrategyTimelineModel> StrategyTimelines { get; set; } = new List<StrategyTimelineModel>();
        public virtual ICollection<StrategyStaffModel> StrategyStaffs { get; set; } = new List<StrategyStaffModel>();
        public virtual ICollection<MarketModel> Markets { get; set; } = new List<MarketModel>();
    }
}
