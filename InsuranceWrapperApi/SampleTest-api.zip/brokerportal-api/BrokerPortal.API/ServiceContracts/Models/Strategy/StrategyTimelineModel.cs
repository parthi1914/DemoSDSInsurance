﻿using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyTimelineModel
    {
        public Guid StrategyTimelineId { get; set; }
        public Guid StrategyId { get; set; }
        public string StepDefId { get; set; } = null!;
        public string StepDefName { get; set; } = null!;
        public DateTime DueDate { get; set; }
        public DateTime? AssignmentDueDate { get; set; }
        public DateTime? CompletedDate { get; set; } = null!;
        public string? PrevStatusCodeId { get; set; }
        public string? StatusCodeId { get; set; }
        public string? StepStatusCode { get; set; }
        public string? StepStatusCodeDesc { get; set; }
        public string? StepStatusGroupCode { get; set; }
        public string? StepStatusGroupName { get; set; }
        public bool? IsDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public ICollection<StepTimelineStaffAssignmentModel>? StepAssignments { get; set; }

    }
}
