﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyStaffAssignmentRequest
    {
        public Guid? StrategyStaffId { get; set; }
        public string? SagittaStaffId { get; set; } = null!;
        public virtual string? StepDefId { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
