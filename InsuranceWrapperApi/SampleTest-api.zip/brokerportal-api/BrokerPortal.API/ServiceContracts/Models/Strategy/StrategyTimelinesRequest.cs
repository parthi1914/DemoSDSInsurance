﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyTimelinesRequest
    {
        public Guid? StrategyTimelineId { get; set; }
        public Guid StrategyId { get; set; }
        public string StepDefId { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? AssignmentDueDate { get; set; }
    }
}
