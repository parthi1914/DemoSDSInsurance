﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Strategy
{
    [ExcludeFromCodeCoverage]
    public class StrategyStaffRequest
    {
        public StaffRequest? StrategyStaff { get; set; }
        public virtual SecurityUserModel SecurityUser { get; set; } = new SecurityUserModel();
    }
}