﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.SagittaRepl
{
    [ExcludeFromCodeCoverage]
    public class SagittaReplStaffModel
    {
        public string StaffId { get; set; } = null!;
        public string? StaffCode { get; set; }
        public string? StaffName { get; set; }
        public string? EmployeeType { get; set; }
        public string? UserId { get; set; }
        public string? StaffEmpCode { get; set; }
        public string? StaffNetworkId { get; set; }
        public string? StaffTitle { get; set; }
        public string? EmailAddress { get; set; }
        public string? SecurityRole { get; set; }
        public string? divisionNo { get; set; }
        public string? dept { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zipcode { get; set; }
        public string? Homephone { get; set; }
        public string? MobilePhone { get; set; }
        public string? Npn { get; set; }
        public DateTime? TermDate { get; set; }
        public bool? isActive { get; set; }
        public DateTime? ActiveByDate { get; set; }
        public int? StaffIndex { get; set; }
        public string? StaffServiceTeamTitle { get; set; }
        public decimal? StaffServiceTeamProdCredit { get; set; }

    }
}
