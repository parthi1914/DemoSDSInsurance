﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.SagittaRepl
{
    [ExcludeFromCodeCoverage]
    public class SagittaReplContactModel
    {
        public string ContactId { get; set; } = null!;
        public string BusinessEmailAddress { get; set; }
        public string BusinessMobilePhone { get; set; }
        public string BusinessPhone { get; set; }
        public string BusPhoneExt { get; set; }
        public decimal? ClientId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? TypeCode { get; set; }
    }
}
