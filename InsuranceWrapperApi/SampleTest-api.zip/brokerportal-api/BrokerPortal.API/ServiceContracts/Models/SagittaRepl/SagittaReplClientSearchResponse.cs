﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.SagittaRepl
{
    [ExcludeFromCodeCoverage]
    public class SagittaReplClientSearchResponse
    {
        public string ClientId { get; set; } = null!;

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public string? Catcode1 { get; set; }

        public string? Catcode2 { get; set; }

        public string? Catcode3 { get; set; }

        public string? Catcode4 { get; set; }

        public string? Catcode5 { get; set; }

        public string? City { get; set; }

        public string? ClientName { get; set; }

        public string? ClientCode { get; set; }

        public string? ClientContactName { get; set; }
        public int? ClientContPersId { get; set; }
        public string? ClientContPersCode { get; set; }
        public string? ClientContPersName { get; set; }
        public string? ClientContPersEmail { get; set; }
        public string? ClientContPersPhone1 { get; set; }

        public decimal? DivisionCode { get; set; }

        public string? Emailaddress { get; set; }

        public string? Fein { get; set; }

        public string? Inspectioncontact { get; set; }

        public string? Prod1 { get; set; }

        public string? Prod2 { get; set; }

        public string? Prod3 { get; set; }

        public string? Serv1 { get; set; }

        public string? Serv2 { get; set; }

        public string? Serv3 { get; set; }

        public string? Siccode1 { get; set; }

        public string? Siccode2 { get; set; }

        public string? Siccode3 { get; set; }

        public string? Source { get; set; }

        public string? State { get; set; }

        public string? Status { get; set; }

        public string? Status1 { get; set; }

        public string? Status2 { get; set; }

        public string? Status3 { get; set; }

        public string? Status4 { get; set; }

        public string? Status5 { get; set; }

        public string? Telephone1 { get; set; }

        public string? Telephone2 { get; set; }

        public string? Zipcode { get; set; }

        public string? Zipcodeext { get; set; }
        public bool? isActive { get; set; }

        public ICollection<SagittaReplStaffModel>? Producers { get; set; }

        public ICollection<SagittaReplStaffModel>? Servicers { get; set; }

        public ICollection<SagittaReplStaffModel>? ServiceTeams { get; set; }

        public ICollection<SagittaReplContactModel>? Contacts { get; set; }
    }
}
