﻿using BrokerPortal.API.Utilities;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.SagittaRepl
{
    [ExcludeFromCodeCoverage]
    public class SagittaReplClientSearchRequest
    {
        public string? searchOption { get; set; } = AppConstants.SEARCH_OPTION_CONTAINS;

        public string? searchCondition { get; set; } = AppConstants.SEARCH_CONDITION_OR;

        [Required(ErrorMessage = AppConstants.MSG_REQUIRED_SEARCH_CRITERIAS)]
        public SagittaReplClientSearchCriterias SearchCriterias { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class SagittaReplClientSearchCriterias
    {
        public string? clientStatusOption { get; set; } = AppConstants.STATUS_OPTION_ACTIVE;
        public string[]? clientIds { get; set; }
        public string? clientCode { get; set; } = string.Empty;
        public string? clientName { get; set; } = string.Empty;
        public string[]? clientAssignedToStaffIds { get; set; }
    }
}
