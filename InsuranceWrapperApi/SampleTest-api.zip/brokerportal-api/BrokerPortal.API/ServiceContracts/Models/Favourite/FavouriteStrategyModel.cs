﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Favourite
{
    [ExcludeFromCodeCoverage]
    public class FavouriteStrategyModel
    {
        public Guid FavouriteStrategyId { get; set; }
        public string SecurityUserId { get; set; } = string.Empty;
        public Guid StrategyId { get; set; }
        public string StrategyName { get; set; } = string.Empty;
        public Guid PlanId { get; set; }
        public string PlanName { get; set; } = string.Empty;
        public string SagittaClientId { get; set; } = string.Empty;
        public string ClientCode { get; set; } = string.Empty;
        public string ClientName { get; set; } = string.Empty;
        public int? ClientContPersId { get; set; }
        public string? ClientContPersCode { get; set; }
        public string? ClientContPersName { get; set; }
        public string? ClientContPersEmail { get; set; }
        public string? ClientContPersPhone1 { get; set; }
        public bool? isDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
