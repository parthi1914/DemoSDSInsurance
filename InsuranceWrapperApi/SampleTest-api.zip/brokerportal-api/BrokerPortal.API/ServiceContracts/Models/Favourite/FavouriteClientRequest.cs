﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Favourite
{
    [ExcludeFromCodeCoverage]
    public class FavouriteClientRequest
    {
        public Guid FavouriteClientId { get; set; }
        public string SagittaClientId { get; set; } = string.Empty;
        public string ClientCode { get; set; } = string.Empty;
        public string ClientName { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string? Emailaddress { get; set; }
        public string? Telephone1 { get; set; }
        public int? ClientContPersId { get; set; }
        public string? ClientContPersCode { get; set; }
        public string? ClientContPersName { get; set; }
        public string? ClientContPersEmail { get; set; }
        public string? ClientContPersPhone1 { get; set; }
        public bool? isDeleted { get; set; }
    }
}
