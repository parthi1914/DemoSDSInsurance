﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.ServiceContracts.Models.Favourite
{
    [ExcludeFromCodeCoverage]
    public class FavouriteStrategyRequest
    {
        public Guid FavouriteStrategyId { get; set; }
        public Guid StrategyId { get; set; }
        public bool? isDeleted { get; set; }
    }
}
