﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;

namespace BrokerPortal.API.ServiceContracts
{
    public interface ISagittaPolicyService
    {
        List<SagittaPolicyModel> GetSagittaPoliciesByStrategyId(Guid? strategyId);
        List<SagittaPolicyModel> BulkMergeSagittaPolicies(string? securityUserId, List<SagittaPolicyModelRequest> sagittaPolicyRequests);
        Task<SagittaPolicyModel> SaveSagittaPolicy(string? securityUserId, SagittaPolicyModelRequest saveSagittaPolicyRequest);
        Task<SagittaPolicyModel> UpdateSagittaPolicy(string? securityUserId, SagittaPolicyModelRequest updateSagittaPolicyRequest);

        Task MergeSagittaPolicy(string? securityUserId, SagittaPolicyModelRequest sagittaPolicyRequest);
    }
}
