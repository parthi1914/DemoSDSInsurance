﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;

namespace BrokerPortal.API.ServiceContracts
{
    public interface ISagittaPayeeService
    {
        List<SagittaPayeeModel> BulkMergeSagittaPayees(string? securityUserId, List<SagittaPayeeRequest> sagittaPolicyRequests);
        void MergeSagittaPayee(string? securityUserId, SagittaPayeeRequest sagittaPayeeRequest);
    }
}
