﻿using BrokerPortal.API.ServiceContracts.Models.Plan;

namespace BrokerPortal.API.ServiceContracts
{
    public interface IPlanService
    {
        Task<List<PlanResponse>> GetAllPlans();
        Task<PlanResponse> GetPlanById(Guid planId);
        Task<PlanResponse> SavePlan(PlanRequest plan);
        Task<PlanResponse> UpdatePlan(PlanRequest plans, Guid planId);        
        Task<bool> RemovePlan(Guid planId, string securityUserId);
        Task<bool> ArchivePlan(Guid planId, string securityUserId);
    }
}
