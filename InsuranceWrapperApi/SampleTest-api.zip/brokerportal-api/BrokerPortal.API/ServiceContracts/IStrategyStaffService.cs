﻿using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;

namespace BrokerPortal.API.ServiceContracts
{
    public interface IStrategyStaffService
    {
        Task<List<StrategyStaffModel>> GetStrategyStaffs(Guid? strategyId);
        Task<List<StrategyStaffModel>> BulkMergeStrategyStaffs(Guid? strategyId, string? securityUserId, List<StaffRequest> strategyStaffRequests);
        Task<bool> DeleteStrategyStaff(string? securityUserId, Guid? strategyStaffId);
        List<StrategyStaffModel> BuildDefaultStrategyStaffsFromClient(Guid? strategyId, List<StrategyTimelineModel>? strategyTimelineList, SagittaStaffResponse securityUserSagittaStaff, SagittaClientResponse? sagittaClientResponse);
    }
}
