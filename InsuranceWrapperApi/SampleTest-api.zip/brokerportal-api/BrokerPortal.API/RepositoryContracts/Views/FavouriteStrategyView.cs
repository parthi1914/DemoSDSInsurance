﻿using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.RepositoryContracts.Views
{
    [ExcludeFromCodeCoverage]
    public class FavouriteStrategyView
    {
        public Guid FavouriteStrategyId { get; set; }
        public string SecurityUserId { get; set; } = string.Empty;
        public Guid StrategyId { get; set; }
        public string StrategyName { get; set; } = string.Empty;
        public Guid PlanId { get; set; }
        public string PlanName { get; set; } = string.Empty;
        public string SagittaClientId { get; set; } = string.Empty;
        public string ClientCode { get; set; } = string.Empty;
        public string ClientName { get; set; } = string.Empty;
        public bool? isDeleted { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
