﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ISagittaStaffRepository
    {
        Task<SagittaStaff?> GetSagittaStaffById(string? sagittaStaffId);
        List<SagittaStaff> GetSagittaStaffsByIds(string[] sagittaStaffIds);
        Task<List<SagittaStaff>> BulkMerge(List<SagittaStaff> sagittaStaffEntityList);
        Task<SagittaStaff?> SaveSagittaStaff(SagittaStaff sagittaStaff);
        Task<SagittaStaff?> UpdateSagittaStaff(SagittaStaff sagittaStaff);
        List<SagittaStaff>? GetSagittaStaffsByAssignedStepIds(List<Guid> taskStepIds);
    }
}
