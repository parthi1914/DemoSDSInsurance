﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts.Views;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IFavouriteStrategyRepository
    {
        Task<List<FavouriteStrategy>> GetAllFavouriteStrategies();
        Task<FavouriteStrategy> GetFavouriteStrategyById(Guid favoriteStrategyId);
        Task<FavouriteStrategy> GetFavouriteStrategyByStrategyId(Guid strategyId, string securityUserId);
        Task<FavouriteStrategy> SaveFavouriteStrategy(FavouriteStrategy favouriteStrategy);
        Task<FavouriteStrategy> UpdateFavouriteStrategy(FavouriteStrategy favouriteStrategy);
        Task<List<FavouriteStrategyView>> GetFavouriteStrategiesByUser(string securityUserId, string[] securityUserSagittaStaffIds);
    }
}
