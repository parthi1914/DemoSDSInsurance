﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ISecurityUserRepository
    {
        Task<string?> GetEmployeeIdBySecurityUserId(string? securityUserId);
        Task<List<string>?> GetSecurityUserMapExternalSystemUserIds(string? securityUserId, string externalSystemId);
        Task<List<SecurityUserMapExternalSystem>?> GetSecurityUserMapExternalSystemUserList(string? securityUserId, string externalSystemId);
        Task<List<string>?> GetSecurityUserIdsByExternalSystemUserIds(string externalSystemId, string[]? externalSystemUserIds);
        Task<List<SecurityUserMapExternalSystem>> BulkSaveSecurityUserMapExternalSystemUserList(List<SecurityUserMapExternalSystem> externalSystemMapEntityList);
    }
}
