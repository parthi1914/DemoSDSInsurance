﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ISagittaClientRepository
    {
        Task<bool> IsSagittaClientExists(long? sagittaClientId);
        Task<SagittaClient> UpdateSagittaClient(SagittaClient sagittaClient);
        Task<SagittaClient> AddSagittaClient(SagittaClient sagittaClient);
        Task<SagittaClient> GetSagittaClient(string sagittaClientId);
    }
}
