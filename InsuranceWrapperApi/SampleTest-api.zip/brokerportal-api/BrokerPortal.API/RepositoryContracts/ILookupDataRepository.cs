﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ILookupDataRepository
    {
        List<StepDef> GetAllStepDefs();
        List<SubStepDef> GetAllSubStepDefs();
        List<SubStepDef> GetAllSubStepDefsByStepDefId(string stepDefId);
        List<string> GetAllStepDefIdsByFlowDef(string flowDefId);
        List<StepDef> GetAllStepDefsByFlowDef(string flowDefId);
        List<StepDef> GetSortedStepsByStrategyFlow(string marketFlowDefId);
        List<string> GetAllBPStatusCodesIds();
        List<BpstatusCode> GetAllBPStatusCodes();
        List<TaskStatusCode> GetAllTaskStatusCodes();
        List<string> GetAllBPStatusCodesIdsByGroupCode(string stepStatusGroupCode);
    }
}
