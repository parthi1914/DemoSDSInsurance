﻿using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ITaskStackRepository
    {
        Task<List<TaskStack>> GetAllTaskStacks();
        Task<TaskStack?> GetTaskStackById(Guid? taskStackId);        
        Task<TaskStack> SaveTaskStack(TaskStack taskStack);
        Task<TaskStack> UpdateTaskStack(TaskStack taskStack);
        Task<bool> DeleteTaskStack(Guid taskStackId, string? securityUserId);
        Task<bool> RemoveTaskStack(Guid taskStackId, string? securityUserId);        
        Task<GenericTask> SaveGenericTask(GenericTask taskRequest);        
        Task<GenericTask> UpdateGenericTask(GenericTask taskRequest);
        Task<List<TaskStack>> UpdateRangeTaskStacks(List<TaskStack> taskStackList);
        Task<List<TaskAssignment>> UpdateRangeTaskAssignments(List<TaskAssignment> taskAssignmentList);
        Task<List<TaskStack>> BulkMergeTaskStacks(List<TaskStack> taskStackList);
        Task<List<TaskAssignment>> BulkMergeTaskAssignments(List<TaskAssignment> taskAssignmentList);
        Task TrackTasksChanges(List<TaskStack> taskStackList);
        Task<List<TaskStack>?> SearchTaskStacks(SearchBaseFilterType baseFilterType, TaskSearchType searchType, TaskSearchCriterias searchCriterias, 
            string? securityUserId, string[] userSagittaStaffIds, string[] teamSecurityUserIds, string[] teamSagittaStaffIds,
            long? sagittaClientId, Guid? strategyId);
        Task<GenericTask?> GetGenericTaskForUpdateByTaskStackId(Guid? taskStackId);
        string[]? FindUserTeamByFilters(SearchBaseFilterType baseFilterType, string[]? userSagittaStaffIds, long? sagittaClientId, Guid? strategyId);
        List<string> GetAllTaskStatusCodesIds();
        List<string> GetAllTaskStatusCodesIdsByGroupCode(string taskStatusGroupCode);
        Task<List<TaskStack>?> GetAllTasksByStrategyInclMarkets(Guid? strategyId);
        Task<List<TaskAssignment>> GetTaskAssignmentByStrategyStaffId(Guid? strategyStaffId);
        List<StepTimelineStaffAssignment>? GetStaffAssignedByStrategyTimelines(List<Guid>? stepTimeLineIds);
        List<StepTimelineStaffAssignment>? GetStaffAssignedByMarketsTimelines(List<Guid>? stepTimeLineIds);
        List<StepTimelineStaffAssignment>? GetStaffAssignedByStrategyAndMarketsTimelines(List<Guid>? stepTimeLineIds);
        List<StepTimelineStaffAssignment>? GetStrategyStaffAssignmentsByStrategy(Guid? strategyId);
    }
}
