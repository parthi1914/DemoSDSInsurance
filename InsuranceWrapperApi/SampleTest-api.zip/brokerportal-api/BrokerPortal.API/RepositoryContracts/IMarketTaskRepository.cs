﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IMarketTaskRepository
    {
        List<MarketTaskMeta> GetAllMarketTask();
        List<MarketTaskMeta> GetMarketTaskById(Guid marketId);
        Task BulkMerge(List<MarketTaskMeta> marketTaskList);

    }
}
