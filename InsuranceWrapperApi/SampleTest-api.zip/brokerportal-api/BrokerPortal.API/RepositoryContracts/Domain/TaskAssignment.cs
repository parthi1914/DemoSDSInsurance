﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("TaskAssignment")]
public partial class TaskAssignment
{
    [Key]
    public Guid TaskAssignmentId { get; set; }

    public Guid? ParentTaskAssignmentId { get; set; }

    [StringLength(100)]
    public string? TaskAssignmentType { get; set; }

    [StringLength(100)]
    public string? TaskAssignTo { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? TaskAssignDate { get; set; }

    public bool? HasLocked { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LockStartDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LockEndDate { get; set; }

    public bool? IsActive { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public bool? IsDelegated { get; set; }

    public Guid? TaskStepId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("TaskAssignmentCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("TaskAssignment")]
    public virtual ICollection<TaskActivity> TaskActivities { get; set; } = new List<TaskActivity>();

    [ForeignKey("TaskStepId")]
    [InverseProperty("TaskAssignments")]
    public virtual TaskStep? TaskStep { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("TaskAssignmentUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
