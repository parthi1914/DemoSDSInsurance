﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("SagittaStaff")]
public partial class SagittaStaff
{
    [Key]
    [StringLength(400)]
    public string SagittaStaffId { get; set; } = null!;

    public string? StaffCode { get; set; }

    public string? StaffName { get; set; }

    public string? StaffTitle { get; set; }

    public string? StaffEmail { get; set; }
    public string? UserId { get; set; }

    public string? StaffEmpCode { get; set; }
    public string? EmployeeType { get; set; }

    public bool? IsDatedOff { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DatedOffDate { get; set; }

    public bool? IsSagSync { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastSagSyncDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [StringLength(50)]
    public string? StaffNetworkId { get; set; }

    [StringLength(25)]
    [Unicode(false)]
    public string? City { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("SagittaStaffCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("SagittaStaff")]
    public virtual ICollection<StrategyStaff> StrategyStaffs { get; set; } = new List<StrategyStaff>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("SagittaStaffUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
