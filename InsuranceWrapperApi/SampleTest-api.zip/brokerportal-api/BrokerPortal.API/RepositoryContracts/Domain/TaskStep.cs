﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class TaskStep
{
    [Key]
    public Guid TaskStepId { get; set; }

    public Guid TaskStackId { get; set; }

    [StringLength(200)]
    public string? StepDefId { get; set; }

    [StringLength(200)]
    public string? SubStepDefId { get; set; }

    [StringLength(200)]
    public string? StatusCodeId { get; set; }

    [StringLength(100)]
    public string? TaskStepRefType { get; set; }

    [StringLength(100)]
    public string? TaskStepRefKey { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastStepStatusUpdatedDate { get; set; }

    [StringLength(100)]
    public string? LastStepStatusUpdatedBy { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("TaskStepCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("LastStepStatusUpdatedBy")]
    [InverseProperty("TaskStepLastStepStatusUpdatedByNavigations")]
    public virtual SecurityUser? LastStepStatusUpdatedByNavigation { get; set; }

    [ForeignKey("StatusCodeId")]
    [InverseProperty("TaskSteps")]
    public virtual BpstatusCode? StatusCode { get; set; }

    [ForeignKey("StepDefId")]
    [InverseProperty("TaskSteps")]
    public virtual StepDef? StepDef { get; set; }

    [ForeignKey("SubStepDefId")]
    [InverseProperty("TaskSteps")]
    public virtual SubStepDef? SubStepDef { get; set; }

    [InverseProperty("TaskStep")]
    public virtual ICollection<TaskActivity> TaskActivities { get; set; } = new List<TaskActivity>();

    [InverseProperty("TaskStep")]
    public virtual ICollection<TaskAssignment> TaskAssignments { get; set; } = new List<TaskAssignment>();

    [ForeignKey("TaskStackId")]
    [InverseProperty("TaskSteps")]
    public virtual TaskStack TaskStack { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("TaskStepUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
