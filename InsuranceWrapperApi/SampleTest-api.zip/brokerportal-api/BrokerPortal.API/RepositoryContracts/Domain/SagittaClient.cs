﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class SagittaClient
{
    [Key]
    public long SagittaClientId { get; set; }

    [StringLength(500)]
    public string ClientCode { get; set; } = null!;

    public string ClientName { get; set; } = null!;

    public int? ClientContPersId { get; set; }

    [StringLength(500)]
    public string? ClientContPersCode { get; set; }

    [StringLength(500)]
    public string? ClientContPersName { get; set; }

    [StringLength(500)]
    public string? ClientContPersEmail { get; set; }

    [StringLength(100)]
    public string? ClientContPersPhone1 { get; set; }

    [StringLength(100)]
    public string? ClientCity { get; set; }

    [StringLength(100)]
    public string? ClientState { get; set; }

    public bool? IsDatedOff { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DatedOffDate { get; set; }

    public bool? IsSagSync { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastSagSyncDate { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("SagittaClientCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("SagittaClient")]
    public virtual ICollection<FavouriteClient> FavouriteClients { get; set; } = new List<FavouriteClient>();

    [InverseProperty("SagittaClient")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("SagittaClient")]
    public virtual ICollection<PlanClient> PlanClients { get; set; } = new List<PlanClient>();

    [InverseProperty("SagittaClient")]
    public virtual ICollection<SagittaPolicy> SagittaPolicies { get; set; } = new List<SagittaPolicy>();

    [InverseProperty("SagittaClient")]
    public virtual ICollection<StrategyClient> StrategyClients { get; set; } = new List<StrategyClient>();

    [InverseProperty("SagittaClient")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("SagittaClientUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
