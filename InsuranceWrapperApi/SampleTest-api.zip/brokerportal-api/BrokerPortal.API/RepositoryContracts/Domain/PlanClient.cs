﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class PlanClient
{
    [Key]
    public Guid PlanClientId { get; set; }

    public Guid PlanId { get; set; }

    public long SagittaClientId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("PlanClientCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("PlanId")]
    [InverseProperty("PlanClients")]
    public virtual Plan Plan { get; set; } = null!;

    [InverseProperty("PlanClient")]
    public virtual ICollection<PlanClientAddlInfo> PlanClientAddlInfos { get; set; } = new List<PlanClientAddlInfo>();

    [ForeignKey("SagittaClientId")]
    [InverseProperty("PlanClients")]
    public virtual SagittaClient SagittaClient { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("PlanClientUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
