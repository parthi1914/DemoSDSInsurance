﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class Strategy
{
    [Key]
    public Guid StrategyId { get; set; }

    public Guid PlanId { get; set; }

    public string StrategyName { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime StrategyEffDate { get; set; }

    [StringLength(200)]
    public string StatusCodeId { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? PrevStatusCodeId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("StrategyCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("Strategy")]
    public virtual ICollection<FavouriteStrategy> FavouriteStrategies { get; set; } = new List<FavouriteStrategy>();

    [InverseProperty("Strategy")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("Strategy")]
    public virtual ICollection<MarketTimeline> MarketTimelines { get; set; } = new List<MarketTimeline>();

    [InverseProperty("Strategy")]
    public virtual ICollection<Market> Markets { get; set; } = new List<Market>();

    [ForeignKey("PlanId")]
    [InverseProperty("Strategies")]
    public virtual Plan Plan { get; set; } = null!;

    [ForeignKey("PrevStatusCodeId")]
    [InverseProperty("StrategyPrevStatusCodes")]
    public virtual BpstatusCode? PrevStatusCode { get; set; }

    [ForeignKey("StatusCodeId")]
    [InverseProperty("StrategyStatusCodes")]
    public virtual BpstatusCode StatusCode { get; set; } = null!;

    [InverseProperty("Strategy")]
    public virtual ICollection<StrategyClient> StrategyClients { get; set; } = new List<StrategyClient>();

    [InverseProperty("Strategy")]
    public virtual ICollection<StrategyStaff> StrategyStaffs { get; set; } = new List<StrategyStaff>();

    [InverseProperty("Strategy")]
    public virtual ICollection<StrategyTaskMeta> StrategyTaskMeta { get; set; } = new List<StrategyTaskMeta>();

    [InverseProperty("Strategy")]
    public virtual ICollection<StrategyTimeline> StrategyTimelines { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("Strategy")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("StrategyUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
