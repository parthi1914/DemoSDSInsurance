﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("MarketAddlCovHistory")]
public partial class MarketAddlCovHistory
{
    [Key]
    public Guid MarketAddlCovHistoryId { get; set; }

    public Guid MarketAddlCovId { get; set; }

    public Guid MarketId { get; set; }

    public Guid MarketHistoryId { get; set; }

    public int? CovId { get; set; }

    [StringLength(255)]
    public string? CovCode { get; set; }

    [StringLength(255)]
    public string? CovDesc { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public int? Version { get; set; }

    [ForeignKey("MarketHistoryId")]
    [InverseProperty("MarketAddlCovHistories")]
    public virtual MarketsHistory MarketHistory { get; set; } = null!;
}
