﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class Underwriter
{
    [Key]
    public Guid UnderwriterId { get; set; }

    [StringLength(50)]
    public string SagittaPayeeId { get; set; } = null!;

    [StringLength(100)]
    public string UnderwriterName { get; set; } = null!;

    [StringLength(100)]
    public string UnderwriterEmail { get; set; } = null!;

    public bool? IsDatedOff { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DatedOffDate { get; set; }

    [StringLength(300)]
    public string? ChangeReason { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    public int? Version { get; set; }

    public int? ReasonCode { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("UnderwriterCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("Underwriter")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("Underwriter")]
    public virtual ICollection<Market> Markets { get; set; } = new List<Market>();

    [ForeignKey("SagittaPayeeId")]
    [InverseProperty("Underwriters")]
    public virtual SagittaPayee SagittaPayee { get; set; } = null!;

    [InverseProperty("Underwriter")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("UnderwriterUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
