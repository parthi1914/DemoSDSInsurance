﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("GenericTask")]
public partial class GenericTask
{
    [Key]
    public Guid GenericTaskId { get; set; }

    [StringLength(100)]
    public string? RequestedByUserId { get; set; }

    public Guid? TaskStackId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("GenericTaskCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("GenericTask")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [ForeignKey("RequestedByUserId")]
    [InverseProperty("GenericTaskRequestedByUsers")]
    public virtual SecurityUser? RequestedByUser { get; set; }

    [InverseProperty("GenericTask")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("TaskStackId")]
    [InverseProperty("GenericTasks")]
    public virtual TaskStack? TaskStack { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("GenericTaskUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
