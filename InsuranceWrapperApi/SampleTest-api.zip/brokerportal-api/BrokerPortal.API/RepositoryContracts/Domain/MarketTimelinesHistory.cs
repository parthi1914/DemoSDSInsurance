﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("MarketTimelinesHistory")]
public partial class MarketTimelinesHistory
{
    [Key]
    public Guid MarketTimelineHistoryId { get; set; }

    public Guid MarketTimelineId { get; set; }

    public Guid MarketHistoryId { get; set; }

    public Guid MarketId { get; set; }

    public Guid StrategyId { get; set; }

    [StringLength(200)]
    public string StepDefId { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? StatusCodeId { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? AssignmentDueDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? AssignmentFollowUpDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastStepStatusUpdatedDate { get; set; }

    [StringLength(100)]
    public string? LastStepStatusUpdatedBy { get; set; }

    public Guid? StrategyTimelineId { get; set; }

    [StringLength(200)]
    public string? PrevStatusCodeId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("MarketHistoryId")]
    [InverseProperty("MarketTimelinesHistories")]
    public virtual MarketsHistory MarketHistory { get; set; } = null!;
}
