﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("AuditLog")]
public partial class AuditLog
{
    [Key]
    public int Id { get; set; }

    public string? Action { get; set; }

    public string? TableName { get; set; }

    public string? OldValues { get; set; }

    public string? NewValues { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime Date { get; set; }

    public string? UserId { get; set; }

    public int? Version { get; set; }
}
