﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("SecurityUser")]
public partial class SecurityUser
{
    [Key]
    [StringLength(100)]
    public string SecurityUserId { get; set; } = null!;

    [StringLength(255)]
    public string UserEmail { get; set; } = null!;

    [StringLength(100)]
    public string? UserFirstName { get; set; }

    [StringLength(100)]
    public string? UserMiddleName { get; set; }

    [StringLength(100)]
    public string? UserLastName { get; set; }

    [StringLength(100)]
    public string? UserFullName { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? EnteredDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<FavouriteClient> FavouriteClientCreatedByNavigations { get; set; } = new List<FavouriteClient>();

    [InverseProperty("SecurityUser")]
    public virtual ICollection<FavouriteClient> FavouriteClientSecurityUsers { get; set; } = new List<FavouriteClient>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<FavouriteClient> FavouriteClientUpdatedByNavigations { get; set; } = new List<FavouriteClient>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<FavouriteStrategy> FavouriteStrategyCreatedByNavigations { get; set; } = new List<FavouriteStrategy>();

    [InverseProperty("SecurityUser")]
    public virtual ICollection<FavouriteStrategy> FavouriteStrategySecurityUsers { get; set; } = new List<FavouriteStrategy>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<FavouriteStrategy> FavouriteStrategyUpdatedByNavigations { get; set; } = new List<FavouriteStrategy>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<GenericTask> GenericTaskCreatedByNavigations { get; set; } = new List<GenericTask>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMetumCreatedByNavigations { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMetumUpdatedByNavigations { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("RequestedByUser")]
    public virtual ICollection<GenericTask> GenericTaskRequestedByUsers { get; set; } = new List<GenericTask>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<GenericTask> GenericTaskUpdatedByNavigations { get; set; } = new List<GenericTask>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<MarketAddlCov> MarketAddlCovCreatedByNavigations { get; set; } = new List<MarketAddlCov>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<MarketAddlCov> MarketAddlCovUpdatedByNavigations { get; set; } = new List<MarketAddlCov>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<Market> MarketCreatedByNavigations { get; set; } = new List<Market>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<MarketTaskMeta> MarketTaskMetumCreatedByNavigations { get; set; } = new List<MarketTaskMeta>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<MarketTaskMeta> MarketTaskMetumUpdatedByNavigations { get; set; } = new List<MarketTaskMeta>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<MarketTimeline> MarketTimelineCreatedByNavigations { get; set; } = new List<MarketTimeline>();

    [InverseProperty("LastStepStatusUpdatedByNavigation")]
    public virtual ICollection<MarketTimeline> MarketTimelineLastStepStatusUpdatedByNavigations { get; set; } = new List<MarketTimeline>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<MarketTimeline> MarketTimelineUpdatedByNavigations { get; set; } = new List<MarketTimeline>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<Market> MarketUpdatedByNavigations { get; set; } = new List<Market>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<PlanClient> PlanClientCreatedByNavigations { get; set; } = new List<PlanClient>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<PlanClient> PlanClientUpdatedByNavigations { get; set; } = new List<PlanClient>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<Plan> PlanCreatedByNavigations { get; set; } = new List<Plan>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<PlanTimeline> PlanTimelineCreatedByNavigations { get; set; } = new List<PlanTimeline>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<PlanTimeline> PlanTimelineUpdatedByNavigations { get; set; } = new List<PlanTimeline>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<Plan> PlanUpdatedByNavigations { get; set; } = new List<Plan>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<SagittaClient> SagittaClientCreatedByNavigations { get; set; } = new List<SagittaClient>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<SagittaClient> SagittaClientUpdatedByNavigations { get; set; } = new List<SagittaClient>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<SagittaStaff> SagittaStaffCreatedByNavigations { get; set; } = new List<SagittaStaff>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<SagittaStaff> SagittaStaffUpdatedByNavigations { get; set; } = new List<SagittaStaff>();

    [InverseProperty("SecurityUser")]
    public virtual ICollection<SecurityTrace> SecurityTraces { get; set; } = new List<SecurityTrace>();

    [InverseProperty("SecurityUser")]
    public virtual ICollection<SecurityUserMapExternalSystem> SecurityUserMapExternalSystems { get; set; } = new List<SecurityUserMapExternalSystem>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<SecurityUserProfile> SecurityUserProfileCreatedByNavigations { get; set; } = new List<SecurityUserProfile>();

    [InverseProperty("SecurityUser")]
    public virtual ICollection<SecurityUserProfile> SecurityUserProfileSecurityUsers { get; set; } = new List<SecurityUserProfile>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<SecurityUserProfile> SecurityUserProfileUpdatedByNavigations { get; set; } = new List<SecurityUserProfile>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<StrategyClient> StrategyClientCreatedByNavigations { get; set; } = new List<StrategyClient>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<StrategyClient> StrategyClientUpdatedByNavigations { get; set; } = new List<StrategyClient>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<Strategy> StrategyCreatedByNavigations { get; set; } = new List<Strategy>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<StrategyStaff> StrategyStaffCreatedByNavigations { get; set; } = new List<StrategyStaff>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<StrategyStaff> StrategyStaffUpdatedByNavigations { get; set; } = new List<StrategyStaff>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<StrategyTaskMeta> StrategyTaskMetumCreatedByNavigations { get; set; } = new List<StrategyTaskMeta>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<StrategyTaskMeta> StrategyTaskMetumUpdatedByNavigations { get; set; } = new List<StrategyTaskMeta>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<StrategyTimeline> StrategyTimelineCreatedByNavigations { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("LastStepStatusUpdatedByNavigation")]
    public virtual ICollection<StrategyTimeline> StrategyTimelineLastStepStatusUpdatedByNavigations { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<StrategyTimeline> StrategyTimelineUpdatedByNavigations { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<Strategy> StrategyUpdatedByNavigations { get; set; } = new List<Strategy>();

    [InverseProperty("TaskSenderNavigation")]
    public virtual ICollection<TaskActivity> TaskActivities { get; set; } = new List<TaskActivity>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<TaskAssignment> TaskAssignmentCreatedByNavigations { get; set; } = new List<TaskAssignment>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<TaskAssignment> TaskAssignmentUpdatedByNavigations { get; set; } = new List<TaskAssignment>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<TaskMeta> TaskMetumCreatedByNavigations { get; set; } = new List<TaskMeta>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<TaskMeta> TaskMetumUpdatedByNavigations { get; set; } = new List<TaskMeta>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<TaskStack> TaskStackCreatedByNavigations { get; set; } = new List<TaskStack>();

    [InverseProperty("LastTaskStatusUpdatedByNavigation")]
    public virtual ICollection<TaskStack> TaskStackLastTaskStatusUpdatedByNavigations { get; set; } = new List<TaskStack>();

    [InverseProperty("TaskSenderNavigation")]
    public virtual ICollection<TaskStack> TaskStackTaskSenderNavigations { get; set; } = new List<TaskStack>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<TaskStack> TaskStackUpdatedByNavigations { get; set; } = new List<TaskStack>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<TaskStep> TaskStepCreatedByNavigations { get; set; } = new List<TaskStep>();

    [InverseProperty("LastStepStatusUpdatedByNavigation")]
    public virtual ICollection<TaskStep> TaskStepLastStepStatusUpdatedByNavigations { get; set; } = new List<TaskStep>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<TaskStep> TaskStepUpdatedByNavigations { get; set; } = new List<TaskStep>();

    [InverseProperty("CreatedByNavigation")]
    public virtual ICollection<Underwriter> UnderwriterCreatedByNavigations { get; set; } = new List<Underwriter>();

    [InverseProperty("UpdatedByNavigation")]
    public virtual ICollection<Underwriter> UnderwriterUpdatedByNavigations { get; set; } = new List<Underwriter>();
}
