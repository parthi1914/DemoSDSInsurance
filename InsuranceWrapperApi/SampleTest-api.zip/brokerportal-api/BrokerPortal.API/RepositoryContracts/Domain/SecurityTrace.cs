﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("SecurityTrace")]
public partial class SecurityTrace
{
    [Key]
    public Guid SecurityTraceId { get; set; }

    [StringLength(100)]
    public string SecurityUserId { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime SignedOn { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime CreatedDate { get; set; }

    [InverseProperty("SecurityTrace")]
    public virtual ICollection<SecurityTraceDetail> SecurityTraceDetails { get; set; } = new List<SecurityTraceDetail>();

    [ForeignKey("SecurityUserId")]
    [InverseProperty("SecurityTraces")]
    public virtual SecurityUser SecurityUser { get; set; } = null!;
}
