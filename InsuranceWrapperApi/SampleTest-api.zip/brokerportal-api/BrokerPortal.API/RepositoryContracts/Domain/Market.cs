﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class Market
{
    [Key]
    public Guid MarketId { get; set; }

    public Guid StrategyId { get; set; }

    [StringLength(200)]
    public string? StepDefId { get; set; }

    [StringLength(200)]
    public string? PrevStepDefId { get; set; }

    [StringLength(200)]
    public string? SubStepDefId { get; set; }

    [StringLength(200)]
    public string? PrevSubStepDefId { get; set; }

    public long? SagittaPolicyId { get; set; }

    public bool? IsSagPol { get; set; }

    public int? CovId { get; set; }

    [StringLength(255)]
    public string? CovCode { get; set; }

    [StringLength(255)]
    public string? CovDesc { get; set; }

    public int? GrpNumber { get; set; }

    [Column(TypeName = "numeric(19, 4)")]
    public decimal? PremiumAmt { get; set; }

    [StringLength(50)]
    public string? SagittaPayeeId { get; set; }

    public Guid? UnderwriterId { get; set; }

    public int? UnderwriterVersion { get; set; }

    public bool? IsIncumbent { get; set; }

    public string? Notes { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? SubmissionSentDateTime { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? QuoteRecievedDateTime { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? StatusCodeId { get; set; }

    [StringLength(200)]
    public string? PrevStatusCodeId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("MarketCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("Market")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("Market")]
    public virtual ICollection<MarketAddlCov> MarketAddlCovs { get; set; } = new List<MarketAddlCov>();

    [InverseProperty("Market")]
    public virtual ICollection<MarketTaskMeta> MarketTaskMeta { get; set; } = new List<MarketTaskMeta>();

    [InverseProperty("Market")]
    public virtual ICollection<MarketTimeline> MarketTimelines { get; set; } = new List<MarketTimeline>();

    [ForeignKey("PrevStatusCodeId")]
    [InverseProperty("MarketPrevStatusCodes")]
    public virtual BpstatusCode? PrevStatusCode { get; set; }

    [ForeignKey("PrevStepDefId")]
    [InverseProperty("MarketPrevStepDefs")]
    public virtual StepDef? PrevStepDef { get; set; }

    [ForeignKey("PrevSubStepDefId")]
    [InverseProperty("MarketPrevSubStepDefs")]
    public virtual SubStepDef? PrevSubStepDef { get; set; }

    [ForeignKey("SagittaPayeeId")]
    [InverseProperty("Markets")]
    public virtual SagittaPayee? SagittaPayee { get; set; }

    [ForeignKey("SagittaPolicyId")]
    [InverseProperty("Markets")]
    public virtual SagittaPolicy? SagittaPolicy { get; set; }

    [ForeignKey("StatusCodeId")]
    [InverseProperty("MarketStatusCodes")]
    public virtual BpstatusCode? StatusCode { get; set; }

    [ForeignKey("StepDefId")]
    [InverseProperty("MarketStepDefs")]
    public virtual StepDef? StepDef { get; set; }

    [ForeignKey("StrategyId")]
    [InverseProperty("Markets")]
    public virtual Strategy Strategy { get; set; } = null!;

    [ForeignKey("SubStepDefId")]
    [InverseProperty("MarketSubStepDefs")]
    public virtual SubStepDef? SubStepDef { get; set; }

    [InverseProperty("Market")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("UnderwriterId")]
    [InverseProperty("Markets")]
    public virtual Underwriter? Underwriter { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("MarketUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
