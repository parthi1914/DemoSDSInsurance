﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("SubStepDef")]
public partial class SubStepDef
{
    [Key]
    [StringLength(200)]
    public string SubStepDefId { get; set; } = null!;

    [StringLength(200)]
    public string StepDefId { get; set; } = null!;

    [StringLength(200)]
    public string SubStepDefCode { get; set; } = null!;

    [StringLength(500)]
    public string SubStepName { get; set; } = null!;

    [StringLength(500)]
    public string SubStepNameDisplay { get; set; } = null!;

    public int SubStepOrder { get; set; }

    public bool? IsActive { get; set; }

    public bool? IsDisplayActive { get; set; }

    public bool? IsCustom { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(500)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(500)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public bool? IsValidForTaskAutoClose { get; set; }

    [InverseProperty("PrevSubStepDef")]
    public virtual ICollection<Market> MarketPrevSubStepDefs { get; set; } = new List<Market>();

    [InverseProperty("SubStepDef")]
    public virtual ICollection<Market> MarketSubStepDefs { get; set; } = new List<Market>();

    [InverseProperty("SubStepDef")]
    public virtual ICollection<TaskActivity> TaskActivities { get; set; } = new List<TaskActivity>();

    [InverseProperty("SubStepDef")]
    public virtual ICollection<TaskStep> TaskSteps { get; set; } = new List<TaskStep>();
}
