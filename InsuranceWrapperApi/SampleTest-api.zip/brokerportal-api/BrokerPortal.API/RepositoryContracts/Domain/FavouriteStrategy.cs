﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class FavouriteStrategy
{
    [Key]
    public Guid FavouriteStrategyId { get; set; }

    [StringLength(100)]
    public string SecurityUserId { get; set; } = null!;

    public Guid? StrategyId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("FavouriteStrategyCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("SecurityUserId")]
    [InverseProperty("FavouriteStrategySecurityUsers")]
    public virtual SecurityUser SecurityUser { get; set; } = null!;

    [ForeignKey("StrategyId")]
    [InverseProperty("FavouriteStrategies")]
    public virtual Strategy? Strategy { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("FavouriteStrategyUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
