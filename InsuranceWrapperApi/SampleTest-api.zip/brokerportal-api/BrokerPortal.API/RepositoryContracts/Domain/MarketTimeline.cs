﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class MarketTimeline
{
    [Key]
    public Guid MarketTimelineId { get; set; }

    public Guid MarketId { get; set; }

    public Guid StrategyId { get; set; }

    [StringLength(200)]
    public string StepDefId { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? StatusCodeId { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? AssignmentDueDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? AssignmentFollowUpDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastStepStatusUpdatedDate { get; set; }

    [StringLength(100)]
    public string? LastStepStatusUpdatedBy { get; set; }

    public Guid? StrategyTimelineId { get; set; }

    [StringLength(200)]
    public string? PrevStatusCodeId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("MarketTimelineCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("LastStepStatusUpdatedBy")]
    [InverseProperty("MarketTimelineLastStepStatusUpdatedByNavigations")]
    public virtual SecurityUser? LastStepStatusUpdatedByNavigation { get; set; }

    [ForeignKey("MarketId")]
    [InverseProperty("MarketTimelines")]
    public virtual Market Market { get; set; } = null!;

    [ForeignKey("PrevStatusCodeId")]
    [InverseProperty("MarketTimelinePrevStatusCodes")]
    public virtual BpstatusCode? PrevStatusCode { get; set; }

    [ForeignKey("StatusCodeId")]
    [InverseProperty("MarketTimelineStatusCodes")]
    public virtual BpstatusCode? StatusCode { get; set; }

    [ForeignKey("StepDefId")]
    [InverseProperty("MarketTimelines")]
    public virtual StepDef StepDef { get; set; } = null!;

    [ForeignKey("StrategyId")]
    [InverseProperty("MarketTimelines")]
    public virtual Strategy Strategy { get; set; } = null!;

    [ForeignKey("StrategyTimelineId")]
    [InverseProperty("MarketTimelines")]
    public virtual StrategyTimeline? StrategyTimeline { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("MarketTimelineUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
