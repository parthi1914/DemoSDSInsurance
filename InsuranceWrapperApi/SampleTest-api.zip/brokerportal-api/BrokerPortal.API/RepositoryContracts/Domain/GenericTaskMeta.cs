﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class GenericTaskMeta
{
    [Key]
    public Guid GenericTaskMetaId { get; set; }

    public Guid GenericTaskId { get; set; }

    public long? SagittaClientId { get; set; }

    public Guid? PlanId { get; set; }

    public Guid? StrategyId { get; set; }

    public Guid? StrategyTimelineId { get; set; }

    public Guid? MarketId { get; set; }

    public long? SagittaPolicyId { get; set; }

    public Guid? UnderwriterId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("GenericTaskMetumCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("GenericTaskId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual GenericTask GenericTask { get; set; } = null!;

    [ForeignKey("MarketId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual Market? Market { get; set; }

    [ForeignKey("PlanId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual Plan? Plan { get; set; }

    [ForeignKey("SagittaClientId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual SagittaClient? SagittaClient { get; set; }

    [ForeignKey("SagittaPolicyId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual SagittaPolicy? SagittaPolicy { get; set; }

    [ForeignKey("StrategyId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual Strategy? Strategy { get; set; }

    [ForeignKey("StrategyTimelineId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual StrategyTimeline? StrategyTimeline { get; set; }

    [ForeignKey("UnderwriterId")]
    [InverseProperty("GenericTaskMeta")]
    public virtual Underwriter? Underwriter { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("GenericTaskMetumUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
