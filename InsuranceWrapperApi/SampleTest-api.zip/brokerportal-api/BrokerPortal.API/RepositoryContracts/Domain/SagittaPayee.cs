﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class SagittaPayee
{
    [Key]
    [StringLength(50)]
    public string SagittaPayeeId { get; set; } = null!;

    [StringLength(50)]
    public string PayeeCode { get; set; } = null!;

    [StringLength(100)]
    public string? PayeeName { get; set; }

    public bool? IsDatedOff { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DatedOffDate { get; set; }

    public bool? IsSagSync { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastSagSyncDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [InverseProperty("SagittaPayee")]
    public virtual ICollection<Market> Markets { get; set; } = new List<Market>();

    [InverseProperty("SagittaPayee")]
    public virtual ICollection<Underwriter> Underwriters { get; set; } = new List<Underwriter>();
}
