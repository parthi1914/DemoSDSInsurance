﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class StrategyTimeline
{
    [Key]
    public Guid StrategyTimelineId { get; set; }

    public Guid StrategyId { get; set; }

    [StringLength(200)]
    public string StepDefId { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? StatusCodeId { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? AssignmentDueDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DueDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastStepStatusUpdatedDate { get; set; }

    [StringLength(100)]
    public string? LastStepStatusUpdatedBy { get; set; }

    [StringLength(200)]
    public string? PrevStatusCodeId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("StrategyTimelineCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("StrategyTimeline")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [ForeignKey("LastStepStatusUpdatedBy")]
    [InverseProperty("StrategyTimelineLastStepStatusUpdatedByNavigations")]
    public virtual SecurityUser? LastStepStatusUpdatedByNavigation { get; set; }

    [InverseProperty("StrategyTimeline")]
    public virtual ICollection<MarketTimeline> MarketTimelines { get; set; } = new List<MarketTimeline>();

    [ForeignKey("PrevStatusCodeId")]
    [InverseProperty("StrategyTimelinePrevStatusCodes")]
    public virtual BpstatusCode? PrevStatusCode { get; set; }

    [ForeignKey("StatusCodeId")]
    [InverseProperty("StrategyTimelineStatusCodes")]
    public virtual BpstatusCode? StatusCode { get; set; }

    [ForeignKey("StepDefId")]
    [InverseProperty("StrategyTimelines")]
    public virtual StepDef StepDef { get; set; } = null!;

    [ForeignKey("StrategyId")]
    [InverseProperty("StrategyTimelines")]
    public virtual Strategy Strategy { get; set; } = null!;

    [InverseProperty("StrategyTimeline")]
    public virtual ICollection<StrategyTaskMeta> StrategyTaskMeta { get; set; } = new List<StrategyTaskMeta>();

    [InverseProperty("StrategyTimeline")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("StrategyTimelineUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
