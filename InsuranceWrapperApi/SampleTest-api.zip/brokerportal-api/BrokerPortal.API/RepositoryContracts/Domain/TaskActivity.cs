﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("TaskActivity")]
public partial class TaskActivity
{
    [Key]
    public Guid TaskActivityId { get; set; }

    public Guid TaskStackId { get; set; }

    public Guid TaskAssignmentId { get; set; }

    public Guid? ParentTaskStackId { get; set; }

    [StringLength(200)]
    public string? StepDefId { get; set; }

    [StringLength(200)]
    public string? SubStepDefId { get; set; }

    [StringLength(500)]
    public string? TaskName { get; set; }

    [StringLength(500)]
    public string? TaskDesc { get; set; }

    public int? TaskProirity { get; set; }

    public string? TaskNotes { get; set; }

    [StringLength(100)]
    public string? TaskSender { get; set; }

    [StringLength(100)]
    public string? TaskSendDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? TaskDueDate { get; set; }

    [StringLength(200)]
    public string? TaskStatusCodeId { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? TaskStatusDate { get; set; }

    public string? TaskStatusReason { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? ActivitiyDate { get; set; }

    public Guid? TaskStepId { get; set; }

    [ForeignKey("ParentTaskStackId")]
    [InverseProperty("TaskActivityParentTaskStacks")]
    public virtual TaskStack? ParentTaskStack { get; set; }

    [ForeignKey("StepDefId")]
    [InverseProperty("TaskActivities")]
    public virtual StepDef? StepDef { get; set; }

    [ForeignKey("SubStepDefId")]
    [InverseProperty("TaskActivities")]
    public virtual SubStepDef? SubStepDef { get; set; }

    [ForeignKey("TaskAssignmentId")]
    [InverseProperty("TaskActivities")]
    public virtual TaskAssignment TaskAssignment { get; set; } = null!;

    [ForeignKey("TaskSender")]
    [InverseProperty("TaskActivities")]
    public virtual SecurityUser? TaskSenderNavigation { get; set; }

    [ForeignKey("TaskStackId")]
    [InverseProperty("TaskActivityTaskStacks")]
    public virtual TaskStack TaskStack { get; set; } = null!;

    [ForeignKey("TaskStatusCodeId")]
    [InverseProperty("TaskActivities")]
    public virtual TaskStatusCode? TaskStatusCode { get; set; }

    [ForeignKey("TaskStepId")]
    [InverseProperty("TaskActivities")]
    public virtual TaskStep? TaskStep { get; set; }
}
