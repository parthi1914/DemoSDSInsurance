﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class MarketTaskMeta
{
    [Key]
    public Guid MarketTaskId { get; set; }

    public Guid MarketId { get; set; }

    public Guid TaskStackId { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public bool? IsDeleted { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("MarketTaskMetumCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("MarketId")]
    [InverseProperty("MarketTaskMeta")]
    public virtual Market Market { get; set; } = null!;

    [ForeignKey("TaskStackId")]
    [InverseProperty("MarketTaskMeta")]
    public virtual TaskStack TaskStack { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("MarketTaskMetumUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
