﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class TaskStack
{
    [Key]
    public Guid TaskStackId { get; set; }

    public Guid? ParentTaskStackId { get; set; }

    [StringLength(500)]
    public string? TaskName { get; set; }

    [StringLength(500)]
    public string? TaskDesc { get; set; }

    [StringLength(100)]
    public string? TaskSender { get; set; }

    public int? TaskProirity { get; set; }

    public string? TaskNotes { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? TaskDueDate { get; set; }

    [StringLength(200)]
    public string? TaskStatusCodeId { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? TaskSendDate { get; set; }

    public string? TaskStatusReason { get; set; }

    public bool? IsDeleted { get; set; }

    public bool? IsSysGen { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastTaskStatusUpdatedDate { get; set; }

    [StringLength(100)]
    public string? LastTaskStatusUpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? TaskFollowUpDate { get; set; }

    [StringLength(100)]
    public string? TaskRefType { get; set; }

    [StringLength(100)]
    public string? TaskRefKey { get; set; }

    [StringLength(200)]
    public string? PrevTaskStatusCodeId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("TaskStackCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("TaskStack")]
    public virtual ICollection<GenericTask> GenericTasks { get; set; } = new List<GenericTask>();

    [ForeignKey("LastTaskStatusUpdatedBy")]
    [InverseProperty("TaskStackLastTaskStatusUpdatedByNavigations")]
    public virtual SecurityUser? LastTaskStatusUpdatedByNavigation { get; set; }

    [InverseProperty("TaskStack")]
    public virtual ICollection<MarketTaskMeta> MarketTaskMeta { get; set; } = new List<MarketTaskMeta>();

    [ForeignKey("PrevTaskStatusCodeId")]
    [InverseProperty("TaskStackPrevTaskStatusCodes")]
    public virtual TaskStatusCode? PrevTaskStatusCode { get; set; }

    [InverseProperty("TaskStack")]
    public virtual ICollection<StrategyTaskMeta> StrategyTaskMeta { get; set; } = new List<StrategyTaskMeta>();

    [InverseProperty("ParentTaskStack")]
    public virtual ICollection<TaskActivity> TaskActivityParentTaskStacks { get; set; } = new List<TaskActivity>();

    [InverseProperty("TaskStack")]
    public virtual ICollection<TaskActivity> TaskActivityTaskStacks { get; set; } = new List<TaskActivity>();

    [InverseProperty("TaskStack")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("TaskSender")]
    [InverseProperty("TaskStackTaskSenderNavigations")]
    public virtual SecurityUser? TaskSenderNavigation { get; set; }

    [ForeignKey("TaskStatusCodeId")]
    [InverseProperty("TaskStackTaskStatusCodes")]
    public virtual TaskStatusCode? TaskStatusCode { get; set; }

    [InverseProperty("TaskStack")]
    public virtual ICollection<TaskStep> TaskSteps { get; set; } = new List<TaskStep>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("TaskStackUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
