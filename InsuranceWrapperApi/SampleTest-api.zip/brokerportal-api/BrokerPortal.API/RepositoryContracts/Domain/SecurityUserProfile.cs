﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class SecurityUserProfile
{
    [Key]
    public Guid SecurityUserProfileId { get; set; }

    [StringLength(100)]
    public string SecurityUserId { get; set; } = null!;

    [StringLength(255)]
    public string? UserPrincipalName { get; set; }

    [StringLength(255)]
    public string? UserObjectId { get; set; }

    [StringLength(255)]
    public string? UserOnPremAccountName { get; set; }

    [StringLength(255)]
    public string? UserOnPremSecurityId { get; set; }

    [StringLength(255)]
    public string? UserOnPremDistName { get; set; }

    public bool? IsActive { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("SecurityUserProfileCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("SecurityUserId")]
    [InverseProperty("SecurityUserProfileSecurityUsers")]
    public virtual SecurityUser SecurityUser { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("SecurityUserProfileUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
