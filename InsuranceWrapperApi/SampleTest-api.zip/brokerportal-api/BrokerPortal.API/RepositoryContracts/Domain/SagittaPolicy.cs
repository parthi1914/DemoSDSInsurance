﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class SagittaPolicy
{
    [Key]
    public long SagittaPolicyId { get; set; }

    public long SagittaClientId { get; set; }

    [StringLength(30)]
    public string? PolicyNumber { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? PolicyEffDate { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? PolicyExpDate { get; set; }

    [StringLength(10)]
    public string? PolicyType { get; set; }

    [StringLength(9)]
    public string? NewRenew { get; set; }

    public int? CovId { get; set; }

    [StringLength(255)]
    public string? CovCode { get; set; }

    public int? InsurorId { get; set; }

    [StringLength(9)]
    public string? InsurorCode { get; set; }

    [StringLength(9)]
    public string? PayeeId { get; set; }

    [StringLength(9)]
    public string? PayeeCode { get; set; }

    [StringLength(40)]
    public string? PayeeName { get; set; }

    [StringLength(9)]
    public string? Prod1Code { get; set; }

    [StringLength(9)]
    public string? Prod2Code { get; set; }

    [StringLength(9)]
    public string? Prod3Code { get; set; }

    [StringLength(40)]
    public string? Prod1Name { get; set; }

    [StringLength(40)]
    public string? Prod2Name { get; set; }

    [StringLength(40)]
    public string? Prod3Name { get; set; }

    [StringLength(9)]
    public string? Serv1Code { get; set; }

    [StringLength(9)]
    public string? Serv2Code { get; set; }

    [StringLength(9)]
    public string? Serv3Code { get; set; }

    [StringLength(40)]
    public string? Serv1Name { get; set; }

    [StringLength(40)]
    public string? Serv2Name { get; set; }

    [StringLength(40)]
    public string? Serv3Name { get; set; }

    [Column(TypeName = "numeric(19, 4)")]
    public decimal? PremiumAmt { get; set; }

    [Column(TypeName = "numeric(19, 4)")]
    public decimal? CommissionAmt { get; set; }

    public bool? IsActive { get; set; }

    public bool? IsSagSync { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastSagSyncDate { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(9)]
    public string? MarketingRepId { get; set; }

    [StringLength(9)]
    public string? MarketingRepCode { get; set; }

    [StringLength(40)]
    public string? MarketingRepName { get; set; }

    [StringLength(9)]
    public string? AccountExecId { get; set; }

    [StringLength(9)]
    public string? AccountExecCode { get; set; }

    [StringLength(40)]
    public string? AccountExecName { get; set; }

    [StringLength(200)]
    public string? PolicyDescription { get; set; }

    [InverseProperty("SagittaPolicy")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("SagittaPolicy")]
    public virtual ICollection<Market> Markets { get; set; } = new List<Market>();

    [ForeignKey("SagittaClientId")]
    [InverseProperty("SagittaPolicies")]
    public virtual SagittaClient SagittaClient { get; set; } = null!;

    [InverseProperty("SagittaPolicy")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();
}
