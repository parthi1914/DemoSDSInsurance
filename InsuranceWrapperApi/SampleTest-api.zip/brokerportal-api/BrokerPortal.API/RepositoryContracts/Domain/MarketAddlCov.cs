﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("MarketAddlCov")]
public partial class MarketAddlCov
{
    [Key]
    public Guid MarketAddlCovId { get; set; }

    public Guid MarketId { get; set; }

    public int? CovId { get; set; }

    [StringLength(255)]
    public string? CovCode { get; set; }

    [StringLength(255)]
    public string? CovDesc { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("MarketAddlCovCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("MarketId")]
    [InverseProperty("MarketAddlCovs")]
    public virtual Market Market { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("MarketAddlCovUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
