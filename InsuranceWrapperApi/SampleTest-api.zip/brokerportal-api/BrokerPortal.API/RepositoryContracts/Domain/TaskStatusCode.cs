﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class TaskStatusCode
{
    [Key]
    [StringLength(200)]
    public string TaskStatusCodeId { get; set; } = null!;

    [Column("TaskStatusCode")]
    [StringLength(200)]
    public string TaskStatusCode1 { get; set; } = null!;

    [StringLength(200)]
    public string TaskStatusName { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(500)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(500)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? TaskStatusGroupCode { get; set; }

    [StringLength(200)]
    public string? TaskStatusGroupCodeName { get; set; }

    [StringLength(200)]
    public string? TaskStatusDesc { get; set; }

    [InverseProperty("TaskStatusCode")]
    public virtual ICollection<TaskActivity> TaskActivities { get; set; } = new List<TaskActivity>();

    [InverseProperty("PrevTaskStatusCode")]
    public virtual ICollection<TaskStack> TaskStackPrevTaskStatusCodes { get; set; } = new List<TaskStack>();

    [InverseProperty("TaskStatusCode")]
    public virtual ICollection<TaskStack> TaskStackTaskStatusCodes { get; set; } = new List<TaskStack>();
}
