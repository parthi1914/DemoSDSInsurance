﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("StrategyClientAddlInfo")]
public partial class StrategyClientAddlInfo
{
    [Key]
    public Guid StrategyClientAddlInfoId { get; set; }

    public Guid StratgeyClientId { get; set; }

    [StringLength(500)]
    public string ClientCode { get; set; } = null!;

    public string ClientName { get; set; } = null!;

    public int ClientContPersId { get; set; }

    [StringLength(500)]
    public string ClientContPersCode { get; set; } = null!;

    public string ClientContPersName { get; set; } = null!;

    public string ClientContPersEmail { get; set; } = null!;

    [StringLength(100)]
    public string ClientContPersPhone1 { get; set; } = null!;

    public bool? IsDatedOff { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DatedOffDate { get; set; }

    public bool? IsSagSync { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LastSagSyncDate { get; set; }

    [ForeignKey("StratgeyClientId")]
    [InverseProperty("StrategyClientAddlInfos")]
    public virtual StrategyClient StratgeyClient { get; set; } = null!;
}
