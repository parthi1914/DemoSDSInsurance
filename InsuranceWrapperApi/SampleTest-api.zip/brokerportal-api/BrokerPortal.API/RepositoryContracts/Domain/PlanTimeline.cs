﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class PlanTimeline
{
    [Key]
    public Guid PlanTimelineId { get; set; }

    public Guid PlanId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? StepDefId { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DueDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("PlanTimelineCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("PlanId")]
    [InverseProperty("PlanTimelines")]
    public virtual Plan Plan { get; set; } = null!;

    [ForeignKey("StepDefId")]
    [InverseProperty("PlanTimelines")]
    public virtual StepDef? StepDef { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("PlanTimelineUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
