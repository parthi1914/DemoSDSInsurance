﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class StrategyTaskMeta
{
    [Key]
    public Guid StrategyTaskId { get; set; }

    public Guid StrategyId { get; set; }

    public Guid? StrategyTimelineId { get; set; }

    public Guid TaskStackId { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public bool? IsDeleted { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("StrategyTaskMetumCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("StrategyId")]
    [InverseProperty("StrategyTaskMeta")]
    public virtual Strategy Strategy { get; set; } = null!;

    [ForeignKey("StrategyTimelineId")]
    [InverseProperty("StrategyTaskMeta")]
    public virtual StrategyTimeline? StrategyTimeline { get; set; }

    [ForeignKey("TaskStackId")]
    [InverseProperty("StrategyTaskMeta")]
    public virtual TaskStack TaskStack { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("StrategyTaskMetumUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
