﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("SecurityUserMapExternalSystem")]
public partial class SecurityUserMapExternalSystem
{
    [Key]
    public Guid MapExternalSystemId { get; set; }

    [StringLength(100)]
    public string SecurityUserId { get; set; } = null!;

    [StringLength(255)]
    public string? ExternalSystemId { get; set; }

    [StringLength(255)]
    public string? ExternalSystemUserId { get; set; }

    public bool? IsActive { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [ForeignKey("SecurityUserId")]
    [InverseProperty("SecurityUserMapExternalSystems")]
    public virtual SecurityUser SecurityUser { get; set; } = null!;
}
