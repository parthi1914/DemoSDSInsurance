﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("StepDef")]
public partial class StepDef
{
    [Key]
    [StringLength(200)]
    public string StepDefId { get; set; } = null!;

    [StringLength(200)]
    public string FlowDefId { get; set; } = null!;

    [StringLength(200)]
    public string StepDefCode { get; set; } = null!;

    [StringLength(500)]
    public string StepName { get; set; } = null!;

    [StringLength(500)]
    public string StepNameDisplay { get; set; } = null!;

    public int StepOrder { get; set; }

    public bool? IsActive { get; set; }

    public bool? IsDisplayActive { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(500)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(500)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public bool? IsCustom { get; set; }

    public bool? IsValidForTaskAutoClose { get; set; }

    [ForeignKey("FlowDefId")]
    [InverseProperty("StepDefs")]
    public virtual FlowDef FlowDef { get; set; } = null!;

    [InverseProperty("PrevStepDef")]
    public virtual ICollection<Market> MarketPrevStepDefs { get; set; } = new List<Market>();

    [InverseProperty("StepDef")]
    public virtual ICollection<Market> MarketStepDefs { get; set; } = new List<Market>();

    [InverseProperty("StepDef")]
    public virtual ICollection<MarketTimeline> MarketTimelines { get; set; } = new List<MarketTimeline>();

    [InverseProperty("StepDef")]
    public virtual ICollection<PlanTimeline> PlanTimelines { get; set; } = new List<PlanTimeline>();

    [InverseProperty("StepDef")]
    public virtual ICollection<StrategyTimeline> StrategyTimelines { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("StepDef")]
    public virtual ICollection<TaskActivity> TaskActivities { get; set; } = new List<TaskActivity>();

    [InverseProperty("StepDef")]
    public virtual ICollection<TaskStep> TaskSteps { get; set; } = new List<TaskStep>();
}
