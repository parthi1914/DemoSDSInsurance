﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class SecurityTraceDetail
{
    [Key]
    public Guid SecurityTraceDetailId { get; set; }

    public Guid SecurityTraceId { get; set; }

    [StringLength(100)]
    public string? UserGroup { get; set; }

    [StringLength(4000)]
    public string? UserRole { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime CreatedDate { get; set; }

    [ForeignKey("SecurityTraceId")]
    [InverseProperty("SecurityTraceDetails")]
    public virtual SecurityTrace SecurityTrace { get; set; } = null!;
}
