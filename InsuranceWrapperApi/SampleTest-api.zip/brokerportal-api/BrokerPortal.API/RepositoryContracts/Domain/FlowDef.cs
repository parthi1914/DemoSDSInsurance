﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("FlowDef")]
public partial class FlowDef
{
    [Key]
    [StringLength(200)]
    public string FlowDefId { get; set; } = null!;

    [StringLength(200)]
    public string FlowDefCode { get; set; } = null!;

    [StringLength(500)]
    public string FlowName { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(500)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(500)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [InverseProperty("FlowDef")]
    public virtual ICollection<StepDef> StepDefs { get; set; } = new List<StepDef>();
}
