﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class TaskMeta
{
    [Key]
    public Guid TaskMetaId { get; set; }

    public Guid TaskStackId { get; set; }

    public Guid? PlanId { get; set; }

    public Guid? StrategyId { get; set; }

    public Guid? StrategyTimelineId { get; set; }

    public Guid? MarketId { get; set; }

    public long? SagittaClientId { get; set; }

    public long? SagittaPolicyId { get; set; }

    public Guid? UnderwriterId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public Guid? GenericTaskId { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("TaskMetumCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("GenericTaskId")]
    [InverseProperty("TaskMeta")]
    public virtual GenericTask? GenericTask { get; set; }

    [ForeignKey("MarketId")]
    [InverseProperty("TaskMeta")]
    public virtual Market? Market { get; set; }

    [ForeignKey("PlanId")]
    [InverseProperty("TaskMeta")]
    public virtual Plan? Plan { get; set; }

    [ForeignKey("SagittaClientId")]
    [InverseProperty("TaskMeta")]
    public virtual SagittaClient? SagittaClient { get; set; }

    [ForeignKey("SagittaPolicyId")]
    [InverseProperty("TaskMeta")]
    public virtual SagittaPolicy? SagittaPolicy { get; set; }

    [ForeignKey("StrategyId")]
    [InverseProperty("TaskMeta")]
    public virtual Strategy? Strategy { get; set; }

    [ForeignKey("StrategyTimelineId")]
    [InverseProperty("TaskMeta")]
    public virtual StrategyTimeline? StrategyTimeline { get; set; }

    [ForeignKey("TaskStackId")]
    [InverseProperty("TaskMeta")]
    public virtual TaskStack TaskStack { get; set; } = null!;

    [ForeignKey("UnderwriterId")]
    [InverseProperty("TaskMeta")]
    public virtual Underwriter? Underwriter { get; set; }

    [ForeignKey("UpdatedBy")]
    [InverseProperty("TaskMetumUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
