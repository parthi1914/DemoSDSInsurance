﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class StrategyClient
{
    [Key]
    public Guid StratgeyClientId { get; set; }

    public Guid StrategyId { get; set; }

    public long SagittaClientId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    public int? Version { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("StrategyClientCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("SagittaClientId")]
    [InverseProperty("StrategyClients")]
    public virtual SagittaClient SagittaClient { get; set; } = null!;

    [ForeignKey("StrategyId")]
    [InverseProperty("StrategyClients")]
    public virtual Strategy Strategy { get; set; } = null!;

    [InverseProperty("StratgeyClient")]
    public virtual ICollection<StrategyClientAddlInfo> StrategyClientAddlInfos { get; set; } = new List<StrategyClientAddlInfo>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("StrategyClientUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
