﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class FavouriteClient
{
    [Key]
    public Guid FavouriteClientId { get; set; }

    [StringLength(100)]
    public string SecurityUserId { get; set; } = null!;

    public long? SagittaClientId { get; set; }

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("FavouriteClientCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [ForeignKey("SagittaClientId")]
    [InverseProperty("FavouriteClients")]
    public virtual SagittaClient? SagittaClient { get; set; }

    [ForeignKey("SecurityUserId")]
    [InverseProperty("FavouriteClientSecurityUsers")]
    public virtual SecurityUser SecurityUser { get; set; } = null!;

    [ForeignKey("UpdatedBy")]
    [InverseProperty("FavouriteClientUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
