﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
public partial class Plan
{
    [Key]
    public Guid PlanId { get; set; }

    public string PlanName { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime PlanEffDate { get; set; }

    [StringLength(200)]
    public string StatusCodeId { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(100)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(100)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? PrevStatusCodeId { get; set; }

    [ForeignKey("CreatedBy")]
    [InverseProperty("PlanCreatedByNavigations")]
    public virtual SecurityUser? CreatedByNavigation { get; set; }

    [InverseProperty("Plan")]
    public virtual ICollection<GenericTaskMeta> GenericTaskMeta { get; set; } = new List<GenericTaskMeta>();

    [InverseProperty("Plan")]
    public virtual ICollection<PlanClient> PlanClients { get; set; } = new List<PlanClient>();

    [InverseProperty("Plan")]
    public virtual ICollection<PlanTimeline> PlanTimelines { get; set; } = new List<PlanTimeline>();

    [ForeignKey("PrevStatusCodeId")]
    [InverseProperty("PlanPrevStatusCodes")]
    public virtual BpstatusCode? PrevStatusCode { get; set; }

    [ForeignKey("StatusCodeId")]
    [InverseProperty("PlanStatusCodes")]
    public virtual BpstatusCode StatusCode { get; set; } = null!;

    [InverseProperty("Plan")]
    public virtual ICollection<Strategy> Strategies { get; set; } = new List<Strategy>();

    [InverseProperty("Plan")]
    public virtual ICollection<TaskMeta> TaskMeta { get; set; } = new List<TaskMeta>();

    [ForeignKey("UpdatedBy")]
    [InverseProperty("PlanUpdatedByNavigations")]
    public virtual SecurityUser? UpdatedByNavigation { get; set; }
}
