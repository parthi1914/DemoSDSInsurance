﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.RepositoryContracts.Domain;
[ExcludeFromCodeCoverage]
[Table("BPStatusCodes")]
public partial class BpstatusCode
{
    [Key]
    [StringLength(200)]
    public string StatusCodeId { get; set; } = null!;

    [StringLength(200)]
    public string StatusCode { get; set; } = null!;

    [StringLength(200)]
    public string StatusName { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    [StringLength(500)]
    public string? CreatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? CreatedDate { get; set; }

    [StringLength(500)]
    public string? UpdatedBy { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? UpdatedDate { get; set; }

    [StringLength(200)]
    public string? StatusGroupCode { get; set; }

    [StringLength(200)]
    public string? StatusGroupCodeName { get; set; }

    [StringLength(200)]
    public string? StatusDesc { get; set; }

    [InverseProperty("PrevStatusCode")]
    public virtual ICollection<Market> MarketPrevStatusCodes { get; set; } = new List<Market>();

    [InverseProperty("StatusCode")]
    public virtual ICollection<Market> MarketStatusCodes { get; set; } = new List<Market>();

    [InverseProperty("PrevStatusCode")]
    public virtual ICollection<MarketTimeline> MarketTimelinePrevStatusCodes { get; set; } = new List<MarketTimeline>();

    [InverseProperty("StatusCode")]
    public virtual ICollection<MarketTimeline> MarketTimelineStatusCodes { get; set; } = new List<MarketTimeline>();

    [InverseProperty("PrevStatusCode")]
    public virtual ICollection<Plan> PlanPrevStatusCodes { get; set; } = new List<Plan>();

    [InverseProperty("StatusCode")]
    public virtual ICollection<Plan> PlanStatusCodes { get; set; } = new List<Plan>();

    [InverseProperty("PrevStatusCode")]
    public virtual ICollection<Strategy> StrategyPrevStatusCodes { get; set; } = new List<Strategy>();

    [InverseProperty("StatusCode")]
    public virtual ICollection<Strategy> StrategyStatusCodes { get; set; } = new List<Strategy>();

    [InverseProperty("PrevStatusCode")]
    public virtual ICollection<StrategyTimeline> StrategyTimelinePrevStatusCodes { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("StatusCode")]
    public virtual ICollection<StrategyTimeline> StrategyTimelineStatusCodes { get; set; } = new List<StrategyTimeline>();

    [InverseProperty("StatusCode")]
    public virtual ICollection<TaskStep> TaskSteps { get; set; } = new List<TaskStep>();
}
