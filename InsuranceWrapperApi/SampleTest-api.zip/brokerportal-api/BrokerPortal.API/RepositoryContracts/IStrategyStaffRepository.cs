﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IStrategyStaffRepository
    {
        List<StrategyStaff> GetStrategyStaffs(Guid? strategyId);
        Task<StrategyStaff?> GetStrategyStaffById(Guid? strategyStaffId);
        Task<List<StrategyStaff>> BulkMergeWithSubEntities(List<StrategyStaff> strategyStaffEntityList);
        Task TrackStaffsChanges(List<StrategyStaff> strategyStaffEntityList);
        Task<bool> DeleteStrategyStaff(string? securityUserId, Guid? strategyStaffId);        
    }
}
