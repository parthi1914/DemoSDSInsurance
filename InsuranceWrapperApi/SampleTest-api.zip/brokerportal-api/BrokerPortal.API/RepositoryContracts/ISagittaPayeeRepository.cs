﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ISagittaPayeeRepository
    {
        List<SagittaPayee> GetSagittaPayeesByIds(string?[] sagittaPayeeIds);
        List<SagittaPayee> BulkMerge(List<SagittaPayee> sagittaPayeeEntityList);
        SagittaPayee GetSagittaPayeeById(string? sagittaPayeeId);
    }
}
