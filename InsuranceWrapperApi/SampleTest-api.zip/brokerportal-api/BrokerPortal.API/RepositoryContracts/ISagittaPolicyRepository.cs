﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface ISagittaPolicyRepository
    {
        Task<SagittaPolicy> GetSagittaPoliciesRepository(long? sagittaPolicyId);
        List<SagittaPolicy> BulkMerge(List<SagittaPolicy> sagittaPolicyEntityList);
        List<SagittaPolicy> GetSagittaPoliciesByIds(long?[] sagittaPolicyIds);
        List<SagittaPolicy> GetSagittaPoliciesByStrategyId(Guid? strategyId);
        Task<SagittaPolicy> SaveSagittaEntity(SagittaPolicy sagittaSaveEntity);
        Task<SagittaPolicy> UpdateSagittaEntity(SagittaPolicy sagittaSaveEntity);
    }
}
