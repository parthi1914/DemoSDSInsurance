﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IStrategyTaskRepository
    {
        Task<List<StrategyTaskMeta?>> GetStrategyTaskByStrategyId(Guid? strategyId);
        Task<StrategyTaskMeta> GetStrategyTimelineByTimelineId(Guid? strategyTimelineId);


    }
}
