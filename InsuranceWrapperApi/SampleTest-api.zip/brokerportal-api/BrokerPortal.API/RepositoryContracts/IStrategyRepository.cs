﻿using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IStrategyRepository
    {
        Task<List<Strategy>> GetAllStrategies();
        Strategy? GetStrategyHeaderById(Guid? strategyId);
        Task<Strategy?> GetStrategyById(Guid? strategyId, bool includeMarkets);

        Task<Guid?> GetStrategyIdByPlanId(Guid planId);
        Task<Strategy?> GetStrategyForUpdate(Guid? strategyId);
        Task<Strategy?> GetStrategyForMarketChanges(Guid? strategyId);
        Task<Strategy?> GetStrategyForUpdateToSyncMarketChanges(Guid? strategyId);
        Task<Strategy> SaveStrategy(Strategy strategy);
        Task<Guid> UpdateStrategy(Strategy strategy);
        Task TrackStrategyChanges(Strategy strategy);
        Task<bool> UpdateStrategyUpdatedBy(Guid strategyId, string? securityUserId);
        Task<bool> RemoveStrategy(Guid strategyId, string securityUserId);
        Task<bool> ArchiveStrategy(Guid strategyId, string securityUserId);
        Task<bool> RemoveStrategyByPlan(Guid planId, string securityUserId);
        Task<bool> ArchiveStrategyByPlan(Guid planId, string securityUserId);
        Task<List<Strategy>?> SearchStrategies(SearchBaseFilterType baseFilterType, StrategySearchType searchType,
            StrategySearchCriterias searchCriterias, string? securityUserId, string[] sagittaStaffIds, string? sagittaClientId);
        
        Task<List<StrategyTimeline>> UpdateRangeStrategyTimelines(List<StrategyTimeline> strategyTimelines);
        Task<string?> GetStrategyClientId(Guid? strategyId);
        Task<List<StrategyTimeline>> GetStrategyTimelines(Guid? strategyId);
        Strategy GetStrategyByStrategyAndStepIds(Guid strategyId, string stepDefId);
        Guid? GetStrategyIdByMarketId(Guid? marketId);
    }
}
