﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IFavouriteClientRepository
    {
        Task<List<FavouriteClient>> GetAllFavouriteClients();
        Task<FavouriteClient?> GetUserFavouriteClientByClientId(string securityUserId, long ClientId);
        Task<List<FavouriteClient>> GetUserFavouriteClients(string? securityUserId);
        Task<FavouriteClient> GetUserFavouriteClientById(string? securityUserId, Guid? favoriteClientId);
        Task<FavouriteClient> SaveUserFavouriteClient(FavouriteClient favouriteClient);
        Task<FavouriteClient> UpdateUserFavouriteClient(FavouriteClient favouriteClient);
        bool IsClientIdExists(long SagittaClientId);
        Task<SagittaClient> AddSagittaClient(SagittaClient sagittaClient);
    }
}
