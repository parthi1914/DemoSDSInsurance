﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IMarketRepository
    {
        List<Market>? GetAllMarketByStrategy(Guid? strategyId);
        List<Market>? GetAllMarketByStrategies(List<Guid>? strategyIdList);
        Task<Market?> GetMarketById(Guid? marketId);
        Task<Guid?> GetStrategyIdByMarketId(Guid? marketId);
        Task<List<Market>?> GetMarketsForUpdateByStrategy(Guid? strategyId);
        Task<Market?> GetMarketForUpdateById(Guid? marketId);
        Task<List<Market>?> GetMarketsForStrategySyncByStrategy(Guid strategyId);
        Task<Market> SaveMarket(Market market);
        Task<Market> UpdateMarket(Market market);
        Task TrackMarketChanges(Market market);
        Task<bool> RemoveMarket(Guid? marketId, string securityUserId);
        Task<bool> ArchiveMarket(Guid? marketId, string securityUserId);
        Task<List<Market>> BulkMergeWithSubEntities(List<Market> strategyStaffEntityList);
    }
}
