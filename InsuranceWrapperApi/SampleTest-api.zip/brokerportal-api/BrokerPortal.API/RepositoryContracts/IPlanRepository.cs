﻿using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.RepositoryContracts
{
    public interface IPlanRepository
    {
        Task<Plan> SavePlan(Plan plan);
        Task<Plan> UpdatePlan(Plan plan);
        Task<bool> RemovePlan(Guid planId, string securityUserId);
        Task<bool> ArchivePlan(Guid planId, string securityUserId);
        Task<List<Plan>> GetAllPlans();
        Task<Plan> GetPlanById(Guid planId);
        Task<Plan> FetchForUpdatePlanAndStrategiesByPlan(Guid planId);        
        bool? DoesValidStratgyStaffExistsOnPlan(Guid? planId);
    }
}
