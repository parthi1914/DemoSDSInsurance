using BrokerPortal.API.Repositories;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.Services;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Microsoft.OpenApi.Models;
using System.Text.Json;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

#region App Configuration
IConfiguration configuration = new ConfigurationBuilder()
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables()
                    .Build();
string SwaggerURL = builder.Configuration["AzureAd:SwaggerUrl"] + "swagger/v1/swagger.json";

if (!builder.Environment.IsDevelopment())
{
    builder.Configuration["LocalSecurityUser"] = "";
    builder.Configuration["AzureAd:ClientSecret"] = builder.Configuration["MICROSOFT_PROVIDER_AUTHENTICATION_SECRET"];
    builder.Configuration["ConnectionStrings:BP_DB_CONNECTION_STRING"] = builder.Configuration["BP_DB_CONNECTION_STRING"];
    builder.Configuration["ApplicationInsights:ConnectionString"] = builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"];
}
#endregion

#region Configure Cors
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy =>
        {

            policy.AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod();
        });
});
#endregion

#region EFCoreExtensionLicenseActivation
string licenseName = builder.Configuration["Z.EntityFramework.Extensions:LicenseName"];
string licenseKey = builder.Configuration["Z.EntityFramework.Extensions:LicenseKey"];

Z.EntityFramework.Extensions.LicenseManager.AddLicense(licenseName, licenseKey);

string licenseErrorMessage;
if (!Z.EntityFramework.Extensions.LicenseManager.ValidateLicense(out licenseErrorMessage))
{
    throw new Exception(licenseErrorMessage);
}



#endregion

#region Configure DataBase
builder.Services.AddDbContext<BrokerPortalApiDBContext>(options =>
    options.UseSqlServer(builder.Configuration["ConnectionStrings:BP_DB_CONNECTION_STRING"]));
#endregion

#region Configure HTTP Services
builder.Services.AddHttpClient<RestServiceClient>();
#endregion

#region Configurate AutoMapper
builder.Services.AddAutoMapper(typeof(Program));
#endregion

#region Adding Dependency Injection
builder.Services.AddScoped<IPlanService, PlanService>();
builder.Services.AddScoped<IPlanRepository, PlanRepository>();

builder.Services.AddScoped<ISagittaClientService, SagittaClientService>();
builder.Services.AddScoped<ISagittaClientRepository, SagittaClientRepository>();

builder.Services.AddScoped<IFavouriteClientService, FavouriteClientService>();
builder.Services.AddScoped<IFavouriteClientRepository, FavouriteClientRepository>();

builder.Services.AddScoped<IFavouriteStrategyService, FavouriteStrategyService>();
builder.Services.AddScoped<IFavouriteStrategyRepository, FavouriteStrategyRepository>();

builder.Services.AddScoped<IStrategyService, StrategyService>();
builder.Services.AddScoped<IStrategyRepository, StrategyRepository>();

builder.Services.AddScoped<IStrategyStaffService, StrategyStaffService>();
builder.Services.AddScoped<IStrategyStaffRepository, StrategyStaffRepository>();

builder.Services.AddScoped<ISagittaStaffService, SagittaStaffService>();
builder.Services.AddScoped<ISagittaStaffRepository, SagittaStaffRepository>();

builder.Services.AddScoped<IMarketService, MarketService>();
builder.Services.AddScoped<IMarketRepository, MarketRepository>();

builder.Services.AddScoped<ITaskStackService, TaskStackService>();
builder.Services.AddScoped<ITaskStackRepository, TaskStackRepository>();

builder.Services.AddScoped<ISagittaPolicyRepository, SagittaPolicyRepository>();
builder.Services.AddScoped<ISagittaPolicyService, SagittaPolicyService>();

builder.Services.AddScoped<IStrategyTaskRepository, StrategyTaskRepository>();
builder.Services.AddScoped<IMarketTaskRepository, MarketTaskRepository>();

builder.Services.AddScoped<ISagittaPayeeRepository, SagittaPayeeRepository>();
builder.Services.AddScoped<ISagittaPayeeService, SagittaPayeeService>();

builder.Services.AddScoped<ISecurityUserRepository, SecurityUserRepository>();
builder.Services.AddScoped<ISecurityUserService, SecurityUserService>();

builder.Services.AddScoped<ILookupDataRepository, LookupDataRepository>();
#endregion

#region Configure Controller and Json Options
builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
});
#endregion

#region Add Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));
#endregion

#region Add Authorization
var section = builder.Configuration.GetSection("BPAccessRoles");
if (section != null)
{
    string[] bpAccessRoles = section.Get<string[]>();
    if (bpAccessRoles != null && bpAccessRoles.Length > 0)
    {
        builder.Services.AddAuthorization(options =>
          options.AddPolicy("BrokerPortal.API",
          policy => policy.RequireRole(bpAccessRoles)));
    }
}
#endregion

#region Configuration for Application Insights
builder.Logging.ClearProviders();
if (builder.Environment.IsDevelopment())
{
    builder.Logging.AddConsole();
    builder.Logging.AddDebug();
}
else
{
    builder.Services.AddApplicationInsightsTelemetry(options =>
    {
        options.ConnectionString = builder.Configuration["ApplicationInsights:ConnectionString"];
    });
}
#endregion

#region Configure Swagger
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Broker Portal API",
        Description = "A .NET API for Broker Portal"
    });

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please Enter a Valid Token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JWT",
        Scheme = "Bearer"
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference=new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id="Bearer"
                }
            },
            new string[]{}
        }
    });

});
#endregion

#region Exception Handler
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
#endregion

#region Configure app
var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint(SwaggerURL, "V1 Docs");
});
app.UseCors(builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

app.UseHttpsRedirection();
app.UseExceptionHandler(opt => { });
app.UseAuthentication();
app.UseAuthorization();

if (builder.Environment.IsDevelopment())
    app.MapControllers().AllowAnonymous();
else
    app.MapControllers();

app.Run();
#endregion