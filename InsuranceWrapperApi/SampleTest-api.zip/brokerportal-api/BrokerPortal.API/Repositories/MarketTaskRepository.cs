﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.Repositories
{
    public class MarketTaskRepository : IMarketTaskRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public MarketTaskRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public List<MarketTaskMeta> GetAllMarketTask()
        {
            throw new NotImplementedException();
        }

        public  List<MarketTaskMeta> GetMarketTaskById(Guid marketId)
        {
            return _context.MarketTaskMeta.AsNoTracking().Where(marketTask => marketTask.MarketId == marketId)
                     .Include(marketTask=>marketTask.TaskStack)
                    .ToList();
              
        }

        public async Task  BulkMerge(List<MarketTaskMeta> marketTaskList)
        {
            try
            {
                 _context.BulkMerge(marketTaskList);
            }
            catch(Exception ex) 
            {
                string exception = ex.Message;
            }
          
        }
    }
}
