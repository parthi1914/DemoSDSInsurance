﻿using Microsoft.EntityFrameworkCore;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.Repositories.DBContext;


namespace BrokerPortal.API.Repositories
{

    public class FavouriteClientRepository : IFavouriteClientRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public FavouriteClientRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<List<FavouriteClient>> GetAllFavouriteClients()
        {
            return await _context.FavouriteClients
                .Include(x => x.SagittaClient)
                .Where(x => x.IsDeleted.Equals(false)).ToListAsync();
        }

        public async Task<List<FavouriteClient>> GetUserFavouriteClients(string? securityUserId)
        {
            return await _context.FavouriteClients
                .Include(x => x.SagittaClient)
                .Where(x => x.IsDeleted.Equals(false) && x.SecurityUserId == securityUserId).ToListAsync();
        }
        public async Task<FavouriteClient?> GetUserFavouriteClientByClientId(string securityUserId, long ClientId)
        {
            return await _context.FavouriteClients.Where(x =>x.SagittaClientId.Equals(ClientId) && x.IsDeleted.Equals(false) && x.SecurityUserId == securityUserId).SingleOrDefaultAsync();
        }
        public async Task<FavouriteClient?> GetUserFavouriteClientById(string? securityUserId, Guid? favoriteClientId)
        {
            return await _context.FavouriteClients.FindAsync(favoriteClientId);
        }

        public async Task<FavouriteClient> SaveUserFavouriteClient(FavouriteClient favouriteClient)
        {
            await _context.FavouriteClients.AddAsync(favouriteClient);
            await _context.SaveChangesAsync();
            return favouriteClient;
        }

        public async Task<FavouriteClient> UpdateUserFavouriteClient(FavouriteClient favouriteClient)
        {
            var fav= await _context.FavouriteClients.FindAsync(favouriteClient.FavouriteClientId);

            if (fav!=null){
                fav.FavouriteClientId = favouriteClient.FavouriteClientId;
                fav.UpdatedBy = favouriteClient.SecurityUserId;
                fav.UpdatedDate = DateTime.Now;
                fav.IsDeleted = true;
                _context.FavouriteClients.Update(fav);
                await _context.SaveChangesAsync();
            }
            
            return fav;
        }       
        
        public bool IsClientIdExists(long SagittaClientId)
        {
            return _context.SagittaClients.Any(e => e.SagittaClientId == Convert.ToInt64(SagittaClientId));
        }
        public async Task<SagittaClient> AddSagittaClient(SagittaClient sagittaClient)
        {
            _context.SagittaClients.Add(sagittaClient);

                await _context.SaveChangesAsync();
          
            

            return sagittaClient;
        }
    }

}
