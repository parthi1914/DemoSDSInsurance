﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.Repositories
{
    public class LookupDataRepository : ILookupDataRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public LookupDataRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }
        public List<StepDef> GetAllStepDefs()
        {
            List<StepDef> stepDefs = _context.StepDefs.Where(x => x.IsDeleted.Equals(false)).ToList();
            return stepDefs;
        }

        public List<SubStepDef> GetAllSubStepDefs()
        {
            List<SubStepDef> subStepDefs = _context.SubStepDefs.Where(x => x.IsDeleted.Equals(false)).ToList();
            return subStepDefs;
        }

        public List<SubStepDef> GetAllSubStepDefsByStepDefId(string stepDefId)
        {
            List<SubStepDef> subStepDefs = _context.SubStepDefs.Where(x => x.IsDeleted.Equals(false) && x.StepDefId.Equals(stepDefId)).ToList();
            return subStepDefs;
        }

        public List<string> GetAllStepDefIdsByFlowDef(string flowDefId)
        {
            List<string> results = new List<string>();
            results = _context.StepDefs
                .Where(x => x.FlowDefId == flowDefId)
                .Select(x => x.StepDefId)
                .ToList();

            return results;
        }

        public List<StepDef> GetAllStepDefsByFlowDef(string flowDefId)
        {
            return _context.StepDefs
                .Where(x => x.FlowDefId == flowDefId)
                .OrderBy(x => x.StepOrder)
                .ToList();
        }

        public List<StepDef> GetSortedStepsByStrategyFlow(string marketFlowDefId)
        {
            return _context.StepDefs
                .Where(x => x.FlowDefId == marketFlowDefId
                && (x.StepDefId.Equals(AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION)
                                || x.StepDefId.Equals(AppConstants.STRATEGY_STEP_STEPDEFID_QUOTE)
                                || x.StepDefId.Equals(AppConstants.STRATEGY_STEP_STEPDEFID_PROPOSAL)
                                || x.StepDefId.Equals(AppConstants.STRATEGY_STEP_STEPDEFID_BIND)
                                ))
                .OrderBy(x => x.StepOrder)
                .ToList();
        }

        public List<string> GetAllBPStatusCodesIds()
        {
            List<string> results = new List<string>();
            results = _context.BpstatusCodes
                .Select(x => x.StatusCodeId)
                .ToList();
            return results;
        }

        public List<BpstatusCode> GetAllBPStatusCodes()
        {
            List<BpstatusCode> results = new List<BpstatusCode>();
            results = _context.BpstatusCodes
                .ToList();
            return results;
        }

        public List<TaskStatusCode> GetAllTaskStatusCodes()
        {
            List<TaskStatusCode> results = new List<TaskStatusCode>();
            results = _context.TaskStatusCodes
                .ToList();
            return results;
        }

        public List<string> GetAllBPStatusCodesIdsByGroupCode(string stepStatusGroupCode)
        {
            List<string> results = new List<string>();
            results = _context.BpstatusCodes.Where(x => x.StatusGroupCode!=null && x.StatusGroupCode.Equals(stepStatusGroupCode))
                .Select(x => x.StatusCodeId)
                .ToList();
            return results;
        }
    }
}