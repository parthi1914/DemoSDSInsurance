﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using System.Data.Entity;
using System.Numerics;


namespace BrokerPortal.API.Repositories
{
    public class SagittaPolicyRepository : ISagittaPolicyRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public SagittaPolicyRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }
        public async Task<SagittaPolicy> GetSagittaPoliciesRepository(long? sagittaPolicyId)
        {
            return await _context.SagittaPolicies.FindAsync(sagittaPolicyId);
        }

        public List<SagittaPolicy> GetSagittaPoliciesByIds(long?[] sagittaPolicyIds)
        {
            return _context.SagittaPolicies.AsNoTracking().Where(staff => sagittaPolicyIds.Contains(staff.SagittaPolicyId)).ToList();
        }

        public List<SagittaPolicy> GetSagittaPoliciesByStrategyId(Guid? strategyId)
        {
            List<long?> strategyPolicyIds = _context.Markets
                .Where(x => x.IsDeleted.Equals(false) && x.StrategyId.Equals(strategyId) && x.IsSagPol.Equals(true))
                .Select(x => x.SagittaPolicyId)
                .ToList();

            if (strategyPolicyIds != null && strategyPolicyIds.Count > 0)
            {
                return _context.SagittaPolicies.AsNoTracking().Where(staff => strategyPolicyIds.Contains(staff.SagittaPolicyId)).ToList();
            }
            else
            {
                return null;
            }
        }

        public List<SagittaPolicy> BulkMerge(List<SagittaPolicy> sagittaPolicyEntityList)
        {
            _context.BulkMerge(sagittaPolicyEntityList);
            return sagittaPolicyEntityList;
        }

        public async Task<SagittaPolicy> SaveSagittaEntity(SagittaPolicy sagittaSaveEntity)
        {
            _context.Add(sagittaSaveEntity);
            _context.SaveChanges();
            return sagittaSaveEntity;
        }

        public async Task<SagittaPolicy> UpdateSagittaEntity(SagittaPolicy updateSaveEntity)
        {
            _context.Update(updateSaveEntity);
            _context.SaveChanges();

            return updateSaveEntity;
        }
    }
}
