﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.Utilities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace BrokerPortal.API.Repositories
{
    public class MarketRepository : IMarketRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public MarketRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public List<Market>? GetAllMarketByStrategy(Guid? strategyId)
        {
            var markets = _context.Markets.AsNoTracking().Where(market => market.IsDeleted == false && market.StrategyId == strategyId)
                                     .Include(market => market.MarketAddlCovs.Where(cov => cov.IsDeleted == false))
                                     .Include(market => market.StepDef)
                                     .Include(market => market.SubStepDef)
                                     .Include(market => market.Underwriter)
                                     .Include(market => market.SagittaPayee)
                                     .Include(market => market.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                                     .ThenInclude(marketTimelines => marketTimelines.StatusCode)
                                     .Include(market => market.SagittaPolicy)
                               .OrderByDescending(market => market.GrpNumber)
                               .ThenByDescending(market => market.StepDef.StepOrder)
                               .ToList();
            return markets;
        }

        public List<Market>? GetAllMarketByStrategies(List<Guid>? strategyIdList)
        {
            var markets = _context.Markets.AsNoTracking().Where(market => strategyIdList.Contains(market.StrategyId) && market.IsDeleted == false)
                                     .Include(market => market.MarketAddlCovs.Where(cov => cov.IsDeleted == false))
                                     .Include(market => market.StepDef)
                                     .Include(market => market.SubStepDef)
                                     .Include(market => market.Underwriter)
                                     .Include(market => market.SagittaPayee)
                                     .Include(market => market.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                                     .ThenInclude(marketTimelines => marketTimelines.StatusCode)
                                     .Include(market => market.SagittaPolicy)
                               .OrderByDescending(market => market.GrpNumber)
                               .ThenByDescending(market => market.StepDef.StepOrder)
                               .ToList();
            return markets;
        }

        public async Task<Market?> GetMarketById(Guid? marketId)
        {
            var market = _context.Markets.AsNoTracking().Where(market => market.IsDeleted == false && market.MarketId == marketId)
                                     .Include(market => market.MarketAddlCovs.Where(cov => cov.IsDeleted == false))
                                     .Include(market => market.StepDef)
                                     .Include(market => market.SubStepDef)
                                     .Include(market => market.Underwriter)
                                     .Include(market => market.SagittaPayee)
                                     .Include(market => market.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                                     .ThenInclude(marketTimelines => marketTimelines.StatusCode)
                                     .Include(market => market.SagittaPolicy)
                                     .FirstOrDefault();
            return market;
        }

        public async Task<List<Market>?> GetMarketsForUpdateByStrategy(Guid? strategyId)
        {
            List<Market>? markets = 
                await _context.Markets.Where(market => market.IsDeleted == false && market.StrategyId == strategyId)
                                     .Include(market => market.StatusCode)
                                     .Include(market => market.MarketAddlCovs.Where(cov => cov.IsDeleted == false))
                                     .Include(market => market.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                                     .Include(market => market.MarketTaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                       .ThenInclude(marketTaskMeta => marketTaskMeta.TaskStack)
                                       .ThenInclude(taskStack => taskStack.TaskMeta)
                                     .Include(market => market.MarketTaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                       .ThenInclude(marketTaskMeta => marketTaskMeta.TaskStack)
                                       .ThenInclude(taskStack => taskStack.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                       .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                               .ToListAsync();
            return markets;
        }
        public async Task<Market?> GetMarketForUpdateById(Guid? marketId)
        {
            Market? market = await _context.Markets.Where(market => market.IsDeleted == false && market.MarketId == marketId)
                                     .Include(market => market.StatusCode)
                                     .Include(market => market.MarketAddlCovs.Where(cov => cov.IsDeleted == false))
                                     .Include(market => market.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                                     .Include(market => market.MarketTaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                       .ThenInclude(marketTaskMeta => marketTaskMeta.TaskStack)
                                       .ThenInclude(taskStack => taskStack.TaskMeta)
                                     .Include(market => market.MarketTaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                       .ThenInclude(marketTaskMeta => marketTaskMeta.TaskStack)
                                       .ThenInclude(taskStack => taskStack.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                       .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                               .SingleOrDefaultAsync();
            return market;
        }

        public async Task<List<Market>?> GetMarketsForStrategySyncByStrategy(Guid strategyId)
        {
            List<Market>? markets = await
                    _context.Markets.AsNoTracking().Where(market => market.IsDeleted == false && market.StrategyId == strategyId)
                    .Include(market => market.StatusCode)
                    .Include(market => market.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                    .ThenInclude(marketTimelines => marketTimelines.StatusCode)
                    .ToListAsync();
            return markets;
        }

        public async Task<Market> SaveMarket(Market market)
        {
            await _context.Markets.AddAsync(market);
            await _context.SaveChangesAsync();
            return market;
        }

        public async Task<Market> UpdateMarket(Market market)
        {
            _context.Markets.Update(market);
            await _context.SaveChangesAsync();
            return market;
        }
        public async Task TrackMarketChanges(Market market)
        {
            try {
                
                if (market != null)
                {
                    // Prepare marketIdTableList Parameter
                    var dtMarketIds = new DataTable();
                    dtMarketIds.Columns.Add("MarketId", typeof(Guid));
                    dtMarketIds.Rows.Add(market.MarketId);
                    
                    var marketIdsParameter = new SqlParameter
                    {
                        ParameterName = "@MarketIDs",
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.MarketIDsType",
                        Value = dtMarketIds
                    };

                    // Prepare taskStackIdTableList Parameter
                    var dtTaskIds = new DataTable();
                    dtTaskIds.Columns.Add("TaskStackId", typeof(Guid));
                    if (market.MarketTaskMeta != null)
                    {
                        MarketTaskMeta? marketTaskMeta = market.MarketTaskMeta.FirstOrDefault();
                        var childEntry = _context.Entry(marketTaskMeta);

                        // Check the EntityState
                        if (childEntry.State == EntityState.Modified)
                            dtTaskIds.Rows.Add(marketTaskMeta.TaskStackId);
                    }
                    var taskIdsParameter = new SqlParameter
                    {
                        ParameterName = "@TaskStackIDs",
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.TaskStackIDsType",
                        Value = dtTaskIds
                    };

                    var parameters = new[] { marketIdsParameter, taskIdsParameter};
                    await _context.Database.ExecuteSqlRawAsync("EXEC SP_History_Markets @MarketIDs, @TaskStackIDs", parameters);
                }
                
            }
            catch (Exception ex) { Console.WriteLine($"Exception occured in TrackMarketChanges: {ex.Message}"); }

        }

        public async Task<bool> RemoveMarket(Guid? marketId, string securityUserId)
        {
            await _context.TaskMeta.Where(x => x.MarketId == marketId)
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketTaskMeta.Where(x => x.Market.MarketId == marketId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskSteps.Where(x => x.TaskStack.TaskMeta.Any(x => x.MarketId == marketId))
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.StatusCodeId, nameof(TaskStatusCodes.REMO))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskStacks.Where(x => x.TaskMeta.Any(x => x.MarketId == marketId))
                            .ExecuteUpdateAsync(update => update                                                    
                                                    .SetProperty(x => x.PrevTaskStatusCodeId, x => x.TaskStatusCodeId)
                                                    .SetProperty(x => x.TaskStatusCodeId, nameof(TaskStatusCodes.REMO))
                                                    .SetProperty(x => x.LastTaskStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketAddlCovs.Where(x => x.Market.MarketId == marketId)
                            .ExecuteUpdateAsync(update => update    
                                                    .SetProperty(x => x.Version, (x => x.Version+1))
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketTimelines.Where(x => x.MarketId == marketId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))                                                    
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.Markets.Where(x => x.MarketId == marketId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))                                                    
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));
            return true;
        }

        public async Task<bool> ArchiveMarket(Guid? marketId, string securityUserId)
        {
           await _context.TaskSteps.Where(x => x.TaskStack.TaskMeta.Any(x => x.MarketId == marketId) && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                      )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskStacks.Where(x => x.TaskMeta.Any(x => x.MarketId == marketId) && ((x.TaskStatusCodeId == null) || (x.TaskStatusCode != null && !x.TaskStatusCode.TaskStatusGroupCode.Equals(nameof(TaskStatusGroupCodes.CLOS))))
                      )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevTaskStatusCodeId, x => x.TaskStatusCodeId)
                                                    .SetProperty(x => x.TaskStatusCodeId, nameof(TaskStatusCodes.ARCH))
                                                   .SetProperty(x => x.LastTaskStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketTimelines.Where(x => x.MarketId == marketId && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.Markets.Where(x => x.MarketId == marketId && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                )
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));
            return true;
        }

        public async Task<List<Market>> BulkMergeWithSubEntities(List<Market> marketEntityList)
        {
            _context.BulkMerge(marketEntityList, options => options.IncludeGraph = true);
            return marketEntityList;
        }

        public async Task<Guid?> GetStrategyIdByMarketId(Guid? marketId)
        {
            var startegyId = _context.Markets.AsNoTracking().Where(market => market.IsDeleted == false && market.MarketId == marketId)
                                    .Select(market => market.StrategyId)
                                    .FirstOrDefault();
            return startegyId;
        }

        
    }
}
