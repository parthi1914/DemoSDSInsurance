﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;


namespace BrokerPortal.API.Repositories
{
    public class SecurityUserRepository : ISecurityUserRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public SecurityUserRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<string?> GetEmployeeIdBySecurityUserId(string? securityUserId)
        {
            string? securityUserOnPremAccountName =
                     _context.SecurityUserProfiles.AsNoTracking()
                           .Where(user => user.SecurityUserId.Equals(securityUserId))
                           .Select(x => x.UserOnPremAccountName).FirstOrDefault();
            return securityUserOnPremAccountName;
        }
        public async Task<List<string>?> GetSecurityUserMapExternalSystemUserIds(string? securityUserId, string externalSystemId)
        {
            List<string?>? securityUserMapExternalSystemUserIds =
                     await _context.SecurityUserMapExternalSystems.AsNoTracking()
                           .Where(user => user.SecurityUserId.Equals(securityUserId) && user.ExternalSystemId.Equals(externalSystemId))
                           .Select(x => x.ExternalSystemUserId)
                           .ToListAsync();
            return securityUserMapExternalSystemUserIds;
        }

        public async Task<List<SecurityUserMapExternalSystem>?> GetSecurityUserMapExternalSystemUserList(string? securityUserId, string externalSystemId)
        {
            List<SecurityUserMapExternalSystem>? securityUserMapExternalSystems =
                     await _context.SecurityUserMapExternalSystems.AsNoTracking()
                           .Where(user => user.SecurityUserId.Equals(securityUserId) && user.ExternalSystemId.Equals(externalSystemId))
                           .ToListAsync();
            return securityUserMapExternalSystems;
        }

        public async Task<List<string>?> GetSecurityUserIdsByExternalSystemUserIds(string externalSystemId, string[]? externalSystemUserIds)
        {
            List<string>? securityUserIds =
                     await _context.SecurityUserMapExternalSystems.AsNoTracking()
                           .Where(user =>   externalSystemUserIds!=null 
                                            && user.ExternalSystemId.Equals(externalSystemId)
                                            && externalSystemUserIds.Contains(user.ExternalSystemUserId))
                           .Select(x => x.SecurityUserId)
                           .ToListAsync();
            if (securityUserIds != null && securityUserIds.Count > 0)
                securityUserIds.Distinct();

            return securityUserIds;
        }

        public async Task<List<SecurityUserMapExternalSystem>> BulkSaveSecurityUserMapExternalSystemUserList(List<SecurityUserMapExternalSystem> externalSystemMapEntityList)
        {
            _context.SecurityUserMapExternalSystems.AddRange(externalSystemMapEntityList);
            await _context.SaveChangesAsync();
            return externalSystemMapEntityList;
        }
    }
}
