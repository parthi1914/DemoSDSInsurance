﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Data.SqlClient;

namespace BrokerPortal.API.Repositories
{
    public class StrategyStaffRepository : IStrategyStaffRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public StrategyStaffRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }
        public List<StrategyStaff> GetStrategyStaffs(Guid? strategyId)
        {
            var strategyStaff = _context.StrategyStaffs.AsNoTracking()
                                      .Where(strategy => strategy.IsDeleted == false && strategy.StrategyId == strategyId)
                                      .Include(strategy => strategy.SagittaStaff)
                                 .ToList();
            return strategyStaff;
        }

        public async Task<StrategyStaff?> GetStrategyStaffById(Guid? strategyStaffId)
        {
            var strategyStaff = _context.StrategyStaffs.AsNoTracking()
                                        .Where(strategyStaff => strategyStaff.IsDeleted == false && strategyStaff.StrategyStaffId == strategyStaffId)
                                      .Include(strategy => strategy.SagittaStaff)
                                       .SingleOrDefault();
            return strategyStaff;
        }

        public async Task<List<StrategyStaff>> BulkMergeWithSubEntities(List<StrategyStaff> strategyStaffEntityList)
        {
            _context.BulkMerge(strategyStaffEntityList, options => options.IncludeGraph = true);
            return strategyStaffEntityList;
        }

        public async Task<bool> DeleteStrategyStaff(string? securityUserId, Guid? strategyStaffId)
        {
            await _context.StrategyStaffs.Where(x => x.StrategyStaffId == strategyStaffId)
                           .ExecuteUpdateAsync(update => update.SetProperty(x => x.IsDeleted, true)
                                                               .SetProperty(x => x.UpdatedBy, securityUserId)
                                                               .SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.Strategies.Where(x => x.StrategyStaffs.Any(x => x.StrategyStaffId == strategyStaffId))
                           .ExecuteUpdateAsync(update => update.SetProperty(x => x.UpdatedBy, securityUserId).
                                                                SetProperty(x => x.UpdatedDate, DateTime.Now));

            return true;
        }
        public async Task TrackStaffsChanges(List<StrategyStaff> strategyStaffEntityList)
        {
            try
            {
                if (strategyStaffEntityList != null && strategyStaffEntityList.Count > 0)
                {
                    var dataTable = new DataTable();
                    dataTable.Columns.Add("StrategyStaffId", typeof(Guid));

                    var changeEntries = _context.ChangeTracker.Entries<StrategyStaff>();
                    foreach( var strategyStaffEntity in strategyStaffEntityList)
                    {
                        var childEntry = _context.Entry(strategyStaffEntity);
                        if (childEntry.State == EntityState.Modified)
                            dataTable.Rows.Add(strategyStaffEntity.StrategyStaffId);
                    }
                    if(dataTable.Rows!=null && dataTable.Rows.Count > 0)
                    {
                        var strategyStaffIdsParameter = new SqlParameter
                        {
                            ParameterName = "@StrategyStaffIDs",
                            SqlDbType = SqlDbType.Structured,
                            TypeName = "dbo.StrategyStaffIDsType",
                            Value = dataTable
                        };
                        await _context.Database.ExecuteSqlRawAsync("EXEC SP_History_StrategyStaffs @StrategyStaffIDs", strategyStaffIdsParameter);
                    }
                }

            }
            catch (Exception ex) { Console.WriteLine($"Exception occured in TrackStaffsChanges: {ex.Message}"); }
        }
    }
}
