﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;


namespace BrokerPortal.API.Repositories
{
    public class SagittaStaffRepository : ISagittaStaffRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public SagittaStaffRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<SagittaStaff?> GetSagittaStaffById(string? sagittaStaffId)
        {
            return await _context.SagittaStaffs.FindAsync(sagittaStaffId);
        }

        public List<SagittaStaff> GetSagittaStaffsByIds(string[] sagittaStaffIds)
        {
            return _context.SagittaStaffs.AsNoTracking().Where(staff => sagittaStaffIds.Contains(staff.SagittaStaffId)).ToList();
        }

        public async Task<List<SagittaStaff>> BulkMerge(List<SagittaStaff> sagittaStaffEntityList)
        {
            _context.BulkMerge(sagittaStaffEntityList);
            return sagittaStaffEntityList;
        }

        public async Task<SagittaStaff> SaveSagittaStaff(SagittaStaff sagittaStaffEntity)
        {
            _context.SagittaStaffs.Add(sagittaStaffEntity);
            await _context.SaveChangesAsync();
            return sagittaStaffEntity;
        }

        public async Task<SagittaStaff> UpdateSagittaStaff(SagittaStaff sagittaStaffEntity)
        {
            _context.SagittaStaffs.Update(sagittaStaffEntity);
            await _context.SaveChangesAsync();
            return sagittaStaffEntity;
        }

        public List<SagittaStaff>? GetSagittaStaffsByAssignedStepIds(List<Guid> taskStepIds)
        {
            List<SagittaStaff>? results =
                (from sagittaStaff in _context.SagittaStaffs
                 join taskAssignments in _context.TaskAssignments on sagittaStaff.SagittaStaffId equals taskAssignments.TaskAssignTo
                 where (taskAssignments.IsDeleted.Equals(false)
                            && taskStepIds.Contains((Guid)taskAssignments.TaskStepId)
                            )
                 select (sagittaStaff)).ToList();
            return results;
        }
    }
}
