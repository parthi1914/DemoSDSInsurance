﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts.Views;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.Repositories
{
    public class FavouriteStrategyRepository : IFavouriteStrategyRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public FavouriteStrategyRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<List<FavouriteStrategy>> GetAllFavouriteStrategies()
        {
            return await _context.FavouriteStrategies.Where(x => x.IsDeleted.Equals(false)).ToListAsync();
        }

        public async Task<FavouriteStrategy> GetFavouriteStrategyById(Guid favoriteStrategyId)
        {
            return await _context.FavouriteStrategies.FindAsync(favoriteStrategyId);
        }
        public async Task<FavouriteStrategy> GetFavouriteStrategyByStrategyId(Guid strategyId,string securityUserId)
        {
            return await _context.FavouriteStrategies.Where(x => x.StrategyId.Equals(strategyId) && x.SecurityUserId.Equals(securityUserId) && x.IsDeleted.Equals(false)).SingleOrDefaultAsync();
        }

        public async Task<FavouriteStrategy> SaveFavouriteStrategy(FavouriteStrategy favouriteStrategy)
        {
            await _context.FavouriteStrategies.AddAsync(favouriteStrategy);
            await _context.SaveChangesAsync();
            return favouriteStrategy;
        }

        public async Task<FavouriteStrategy> UpdateFavouriteStrategy(FavouriteStrategy favouriteStrategy)
        {
            var fav = await _context.FavouriteStrategies.FindAsync(favouriteStrategy.FavouriteStrategyId);
            if (fav != null)
            {
                fav.FavouriteStrategyId = favouriteStrategy.FavouriteStrategyId;
                fav.UpdatedBy = favouriteStrategy.SecurityUserId;
                fav.UpdatedDate = DateTime.Now;
                fav.IsDeleted = true;
                _context.FavouriteStrategies.Update(fav);
                await _context.SaveChangesAsync();
            }

            return fav;
        }

        public async Task<List<FavouriteStrategyView>> GetFavouriteStrategiesByUser(string securityUserId, string[] securityUserSagittaStaffIds)
        {
            List<FavouriteStrategyView> favStrategyViewResults =
                                    (from favouriteStrategies in _context.FavouriteStrategies
                                     join strategy in _context.Strategies on favouriteStrategies.StrategyId equals strategy.StrategyId
                                     join plans in _context.Plans on strategy.PlanId equals plans.PlanId
                                     join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                     join sagittaClients in _context.SagittaClients on strategyClients.SagittaClientId equals sagittaClients.SagittaClientId
                                     join strategyStaffs in _context.StrategyStaffs on strategy.StrategyId equals strategyStaffs.StrategyId
                                       into ss_jointable
                                     from strategyStaffData in ss_jointable.DefaultIfEmpty()
                                     where (
                                            strategy.IsDeleted.Equals(false)
                                            && ((securityUserSagittaStaffIds == null && strategy.CreatedBy != null && strategy.CreatedBy.Equals(securityUserId))
                                                || (securityUserSagittaStaffIds != null && !securityUserSagittaStaffIds.Contains(strategyStaffData.SagittaStaffId)
                                                      && strategy.CreatedBy != null && strategy.CreatedBy.Equals(securityUserId))
                                                || (securityUserSagittaStaffIds != null && strategyStaffData.IsDeleted.Equals(false)
                                                       && securityUserSagittaStaffIds.Contains(strategyStaffData.SagittaStaffId)))
                                            && favouriteStrategies.IsDeleted.Equals(false) && favouriteStrategies.SecurityUserId.Equals(securityUserId)
                                            )
                                     select new FavouriteStrategyView
                                     {
                                         FavouriteStrategyId = favouriteStrategies.FavouriteStrategyId,
                                         SecurityUserId = favouriteStrategies.SecurityUserId,
                                         StrategyId = strategy.StrategyId,
                                         StrategyName = strategy.StrategyName,
                                         PlanId = strategy.PlanId,
                                         PlanName = plans.PlanName,
                                         SagittaClientId = strategyClients.SagittaClientId.ToString(),
                                         ClientCode = sagittaClients.ClientCode,
                                         ClientName = sagittaClients.ClientName,
                                         isDeleted = favouriteStrategies.IsDeleted,
                                         CreatedBy = favouriteStrategies.CreatedBy,
                                         CreatedDate = favouriteStrategies.CreatedDate,
                                         UpdatedBy = favouriteStrategies.UpdatedBy,
                                         UpdatedDate = favouriteStrategies.UpdatedDate
                                     }
                                      ).Distinct().ToList();
            return favStrategyViewResults;
        }
    }

}
