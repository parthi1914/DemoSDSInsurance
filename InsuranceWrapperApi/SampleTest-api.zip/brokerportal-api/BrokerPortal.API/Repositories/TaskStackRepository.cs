﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data;
using System.Text.Json;

namespace BrokerPortal.API.Repositories
{
    public class TaskStackRepository : ITaskStackRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public TaskStackRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<List<TaskStack>> GetAllTaskStacks()
        {
            List<TaskStack>? taskStackList =
               await _context.TaskStacks.Where(s => s.IsDeleted != true && s.IsSysGen.Equals(false))
                               .Include(task => task.TaskSenderNavigation)
                                .Include(task => task.CreatedByNavigation)
                                .Include(task => task.UpdatedByNavigation)
                                .Include(task => task.LastTaskStatusUpdatedByNavigation)
                                .Include(task => task.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(task => task.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.Strategy)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.SagittaClient)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.GenericTask)
                                .ThenInclude(genericTask => genericTask.GenericTaskMeta)
                                .ToListAsync();
            return taskStackList;
        }
        public async Task<TaskStack?> GetTaskStackById(Guid? taskStackId)
        {
            TaskStack? task =
               await _context.TaskStacks.Where(s => s.TaskStackId.Equals(taskStackId) && s.IsDeleted != true)
                                .Include(task => task.TaskSenderNavigation)
                                .Include(task => task.CreatedByNavigation)
                                .Include(task => task.UpdatedByNavigation)
                                .Include(task => task.LastTaskStatusUpdatedByNavigation)
                                .Include(task => task.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted != true))
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.Strategy)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.SagittaClient)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.GenericTask)
                                .ThenInclude(genericTask => genericTask.GenericTaskMeta)
                                .SingleOrDefaultAsync();
            return task;
        }
        public async Task<TaskStack> SaveTaskStack(TaskStack taskStack)
        {
            _context.TaskStacks.Add(taskStack);
            await _context.SaveChangesAsync();
            return taskStack;
        }
        public async Task<TaskStack> UpdateTaskStack(TaskStack taskStack)
        {
            _context.TaskStacks.Update(taskStack);
            await _context.SaveChangesAsync();
            return taskStack;
        }
        public async Task<bool> DeleteTaskStack(Guid taskStackId, string? securityUserId)
        {
            await _context.TaskMeta.Where(x => x.TaskStackId == taskStackId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.GenericTaskMeta.Where(x => x.GenericTask.TaskStackId == taskStackId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.GenericTasks.Where(x => x.TaskStackId == taskStackId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskAssignments.Where(x => x.TaskStep.TaskStackId == taskStackId)
                        .ExecuteUpdateAsync(update => update.SetProperty(x => x.IsDeleted, true)
                                                .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskSteps.Where(x => x.TaskStack.TaskMeta.Any(x => x.TaskStackId == taskStackId))
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskStacks.Where(x => x.TaskMeta.Any(x => x.TaskStackId == taskStackId))
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevTaskStatusCodeId, x => x.TaskStatusCodeId)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            return true;
        }
        public async Task<bool> RemoveTaskStack(Guid taskStackId, string? securityUserId)
        {
            await _context.TaskMeta.Where(x => x.TaskStackId == taskStackId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.GenericTaskMeta.Where(x => x.GenericTask.TaskStackId == taskStackId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.GenericTasks.Where(x => x.TaskStackId == taskStackId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskAssignments.Where(x => x.TaskStep.TaskStackId == taskStackId)
                        .ExecuteUpdateAsync(update => update.SetProperty(x => x.IsDeleted, true)
                                                .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskSteps.Where(x => x.TaskStack.TaskMeta.Any(x => x.TaskStackId == taskStackId))
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.StatusCodeId, nameof(TaskStatusCodes.REMO))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskStacks.Where(x => x.TaskMeta.Any(x => x.TaskStackId == taskStackId))
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevTaskStatusCodeId, x => x.TaskStatusCodeId)
                                                    .SetProperty(x => x.TaskStatusCodeId, nameof(TaskStatusCodes.REMO))
                                                    .SetProperty(x => x.LastTaskStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            return true;
        }
        public async Task<GenericTask> SaveGenericTask(GenericTask genericTask)
        {
            _context.GenericTasks.Add(genericTask);
            await _context.SaveChangesAsync();
            return genericTask;
        }
        public async Task<GenericTask> UpdateGenericTask(GenericTask genericTask)
        {

            _context.GenericTasks.Update(genericTask);
            _context.SaveChanges();
            return genericTask;
        }
        public async Task<List<TaskStack>> UpdateRangeTaskStacks(List<TaskStack> taskStackList)
        {
            _context.TaskStacks.UpdateRange(taskStackList);
            await _context.SaveChangesAsync();
            return taskStackList;
        }
        public async Task<List<TaskAssignment>> UpdateRangeTaskAssignments(List<TaskAssignment> taskAssignmentList)
        {
            _context.TaskAssignments.UpdateRange(taskAssignmentList);
            await _context.SaveChangesAsync();
            return taskAssignmentList;
        }
        public async Task<List<TaskStack>> BulkMergeTaskStacks(List<TaskStack> taskStackList)
        {
            _context.BulkMerge(taskStackList, options => options.IncludeGraph = true);
            return taskStackList;
        }
        public async Task TrackTasksChanges(List<TaskStack> taskStackList)
        {
            try
            {
                if (taskStackList != null && taskStackList.Count > 0)
                {
                    var dataTable = new DataTable();
                    dataTable.Columns.Add("TaskStackId", typeof(Guid));

                    var changeEntries = _context.ChangeTracker.Entries<TaskStack>();
                    foreach (var taskStack in taskStackList)
                    {
                        var childEntry = _context.Entry(taskStack);
                        if (childEntry.State == EntityState.Modified)
                            dataTable.Rows.Add(taskStack.TaskStackId);
                    }
                    if (dataTable.Rows != null && dataTable.Rows.Count > 0)
                    {
                        var taskStackIdsParameter = new SqlParameter
                        {
                            ParameterName = "@TaskStackIDs",
                            SqlDbType = SqlDbType.Structured,
                            TypeName = "dbo.TaskStackIDsType",
                            Value = dataTable
                        };
                        await _context.Database.ExecuteSqlRawAsync("EXEC SP_History_TaskStacks @TaskStackIDs", taskStackIdsParameter);
                    }
                }

            }
            catch (Exception ex) { Console.WriteLine($"Exception occured in TrackTasksChanges: {ex.Message}"); }
        }
        public async Task<List<TaskAssignment>> BulkMergeTaskAssignments(List<TaskAssignment> taskAssignmentList)
        {
            _context.BulkMerge(taskAssignmentList);
            return taskAssignmentList;
        }
        public async Task<List<TaskStack>?> SearchTaskStacks(SearchBaseFilterType baseFilterType, TaskSearchType searchType, TaskSearchCriterias searchCriterias,
            string? securityUserId, string[] userSagittaStaffIds, string[] teamSecurityUserIds, string[] teamSagittaStaffIds,
            long? sagittaClientId, Guid? strategyId)
        {
            List<TaskStack>? taskList = null;
            List<Guid>? matchedTaskIds = null;

            string[] taskStatusCodes = searchCriterias.TaskStatusCodes;
            string? taskCategory = searchCriterias.TaskCategory ?? nameof(TaskCategorySearchCriteria.GENERIC);
            string? taskAssignType = searchCriterias.TaskAssignType ?? nameof(TaskAssignTypeSearchCriteria.ALL);
            taskAssignType = taskAssignType.ToUpper();
            taskCategory = taskCategory.ToUpper();

            switch (baseFilterType)
            {
                case SearchBaseFilterType.ALL:
                    matchedTaskIds =
                        SearchTaskIdsByAllFilters(searchType, taskStatusCodes, taskCategory, taskAssignType,
                        securityUserId, userSagittaStaffIds, teamSecurityUserIds, teamSagittaStaffIds);
                    break;

                case SearchBaseFilterType.USER_SPECIFIC:
                    matchedTaskIds =
                        SearchTaskIdsByUserFilters(searchType, taskStatusCodes, taskCategory, taskAssignType,
                        securityUserId, userSagittaStaffIds, teamSecurityUserIds, teamSagittaStaffIds);
                    break;

                case SearchBaseFilterType.CLIENT_SPECIFIC:
                    matchedTaskIds =
                        SearchTaskIdsByClientFilters(searchType, taskStatusCodes, taskCategory, taskAssignType,
                        securityUserId, userSagittaStaffIds, teamSecurityUserIds, teamSagittaStaffIds,
                        sagittaClientId);
                    break;

                case SearchBaseFilterType.STRATEGY_SPECIFIC:
                    matchedTaskIds =
                        SearchTaskIdsByStrategyFilters(searchType, taskStatusCodes, taskCategory, taskAssignType,
                        securityUserId, userSagittaStaffIds, teamSecurityUserIds, teamSagittaStaffIds,
                        strategyId);
                    break;
            }
            if (matchedTaskIds != null && matchedTaskIds.Count > 0)
                taskList = await GetTaskStacksByIds(matchedTaskIds);

            return taskList;
        }
        public async Task<GenericTask?> GetGenericTaskForUpdateByTaskStackId(Guid? taskStackId)
        {
            GenericTask? genericTask =
               await _context.GenericTasks.Where(s => s.TaskStackId.Equals(taskStackId) && s.IsDeleted != true)
                                .Include(genericTask => genericTask.GenericTaskMeta)
                                .Include(genericTask => genericTask.TaskStack)
                                    .ThenInclude(taskStack => taskStack.TaskMeta)
                                .Include(genericTask => genericTask.TaskStack)
                                    .ThenInclude(taskStack => taskStack.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                    .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                                .SingleOrDefaultAsync();
            return genericTask;
        }
        public string[]? FindUserTeamByFilters(SearchBaseFilterType baseFilterType, string[]? userSagittaStaffIds,
            long? sagittaClientId, Guid? strategyId)
        {
            string[]? teamSagittaStaffIds = null;
            if (userSagittaStaffIds != null && userSagittaStaffIds.Length > 0)
            {
                string jsonGuids = JsonSerializer.Serialize(userSagittaStaffIds);

                switch (baseFilterType)
                {
                    case SearchBaseFilterType.ALL:
                    case SearchBaseFilterType.USER_SPECIFIC:
                        teamSagittaStaffIds = _context.StrategyStaffs
                           .FromSqlRaw(
                               @$"SELECT	DISTINCT 
		                                    SagittaStaffId
                                    FROM	[dbo].[StrategyStaffs]
                                    WHERE	IsDeleted <> 1
		                                    AND SagittaStaffId NOT IN (SELECT value FROM OPENJSON({{0}}))
		                                    AND StrategyId IN (
								                                SELECT	DISTINCT S.StrategyId
								                                FROM	[dbo].[Strategies] S
										                                INNER JOIN [dbo].[StrategyStaffs] SS  ON S.[StrategyId] = SS.[StrategyId] AND SS.IsDeleted <> 1
								                                WHERE	S.IsDeleted <> 1
										                                AND SS.SagittaStaffId IN (SELECT value FROM OPENJSON({{0}}))
							                                )", jsonGuids
                           )
                           .Select(x => x.SagittaStaffId)
                           .ToArray();
                        break;
                    case SearchBaseFilterType.CLIENT_SPECIFIC:
                        teamSagittaStaffIds = _context.StrategyStaffs
                           .FromSqlRaw(
                               @$"SELECT	DISTINCT 
		                                SagittaStaffId
                                FROM	[dbo].[StrategyStaffs]
                                WHERE	IsDeleted <> 1
		                                AND SagittaStaffId NOT IN (SELECT value FROM OPENJSON({{0}}))
		                                AND StrategyId IN (
								                                SELECT	DISTINCT S.StrategyId
								                                FROM	[dbo].[Strategies] S
										                                INNER JOIN [dbo].[StrategyClients] SC  ON S.[StrategyId] = SC.[StrategyId] AND SC.IsDeleted <> 1
										                                INNER JOIN [dbo].[StrategyStaffs] SS  ON S.[StrategyId] = SS.[StrategyId] AND SS.IsDeleted <> 1
								                                WHERE	S.IsDeleted <> 1
										                                AND SC.SagittaClientId = {sagittaClientId}
										                                AND SS.SagittaStaffId IN (SELECT value FROM OPENJSON({{0}}))
							                                )", jsonGuids
                           )
                           .Select(x => x.SagittaStaffId)
                           .ToArray();
                        break;
                    case SearchBaseFilterType.STRATEGY_SPECIFIC:
                        teamSagittaStaffIds = _context.StrategyStaffs
                           .FromSqlRaw(
                               @$"SELECT	DISTINCT 
		                                SagittaStaffId
                                FROM	[dbo].[StrategyStaffs]
                                WHERE	IsDeleted <> 1
		                                AND SagittaStaffId NOT IN (SELECT value FROM OPENJSON({{0}}))
		                                AND StrategyId IN (
								                                SELECT	DISTINCT S.StrategyId
								                                FROM	[dbo].[Strategies] S
										                                INNER JOIN [dbo].[StrategyStaffs] SS  ON S.[StrategyId] = SS.[StrategyId] AND SS.IsDeleted <> 1
								                                WHERE	S.IsDeleted <> 1
										                                AND S.StrategyId = '{strategyId}'
										                                AND SS.SagittaStaffId IN (SELECT value FROM OPENJSON({{0}}))
							                                )", jsonGuids
                           )
                           .Select(x => x.SagittaStaffId)
                           .ToArray();
                        break;
                }
            }
            return teamSagittaStaffIds;
        }

        public List<string> GetAllTaskStatusCodesIds()
        {
            List<string> results = new List<string>();
            results = _context.TaskStatusCodes
                .Select(x => x.TaskStatusCodeId)
                .ToList();
            return results;
        }

        public List<string> GetAllTaskStatusCodesIdsByGroupCode(string taskStatusGroupCode)
        {
            List<string> results = new List<string>();
            results = _context.TaskStatusCodes
                .Where(x => x.TaskStatusGroupCode.Equals(taskStatusGroupCode))
                .Select(x => x.TaskStatusCodeId)
                .ToList();
            return results;
        }
        public async Task<List<TaskStack>?> GetAllTasksByStrategyInclMarkets(Guid? strategyId)
        {
            List<TaskStack>? results = null;
            List<Guid>? taskIds = null;
            FormattableString query = @$"SELECT TaskStackId FROM [dbo].[StrategyTaskMeta] WHERE StrategyId = {strategyId}
                                        UNION ALL
                                        SELECT	DISTINCT MTM.TaskStackId
                                        FROM	[dbo].[Markets] M
		                                        INNER JOIN [dbo].[MarketTaskMeta] MTM ON M.MarketId = MTM.MarketId AND MTM.IsDeleted <> 1
                                        WHERE	M.StrategyId = {strategyId}";

            taskIds = _context.TaskStacks.FromSqlInterpolated(query)
                                                   .Select(x => x.TaskStackId)
                                                    .ToList();
            if (taskIds != null && taskIds.Count > 0)
            {
                results = new List<TaskStack>();
                results = await _context.TaskStacks.Where(s => taskIds.Contains(s.TaskStackId) && s.IsDeleted != true)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .Include(task => task.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(task => task.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                                    .ToListAsync();
            }
            return results;
        }
        public async Task<List<TaskAssignment>> GetTaskAssignmentByStrategyStaffId(Guid? strategyStaffId)
        {
            FormattableString query = @$"SELECT	DISTINCT TA.*
                                        FROM	[dbo].[TaskAssignment] TA
		                                        INNER JOIN [dbo].[TaskSteps] TS ON TA.[TaskStepId] = TS.[TaskStepId] AND TS.IsDeleted<>1
	                                            INNER JOIN [dbo].[TaskStacks] T ON TS.[TaskStackId] = T.[TaskStackId] AND T.IsDeleted<>1
	                                            INNER JOIN [dbo].[TaskMeta] TM ON T.[TaskStackId] = TM.[TaskStackId] AND TM.IsDeleted<>1
	                                            INNER JOIN  [dbo].[StrategyStaffs] SS ON TM.[StrategyId] = SS.[StrategyId] 
                                                                                        AND TA.[TaskAssignTo] = SS.SagittaStaffId
                                        WHERE	TA.IsDeleted<>1
		                                        AND SS.StrategyStaffId={strategyStaffId}";

            List<TaskAssignment> taskAssignmentList = _context.TaskAssignments
                .FromSqlInterpolated(query)
                .ToList();
            return taskAssignmentList;
        }
        public List<StepTimelineStaffAssignment>? GetStaffAssignedByStrategyTimelines(List<Guid>? stepTimeLineIds)
        {
            string jsonGuids = JsonSerializer.Serialize(stepTimeLineIds);
            var results = _context.StrategyStaffAssignments
               .FromSqlRaw(
                   @$"SELECT  DISTINCT TA.TaskAssignmentId,
		                    SS.StrategyStaffId,
		                    SS.SagittaStaffId,
		                    SagS.StaffName,
		                    TS.StepDefId,
		                    STM.StrategyTimelineId as StepTimelineId,
		                    TS.TaskStackId,
		                    TS.TaskStepId, 
							TS.TaskStepRefType,
							TS.TaskStepRefKey,        
		                    TA.IsDeleted,
		                    TA.CreatedBy,
		                    TA.CreatedDate,
		                    TA.UpdatedBy,
		                    TA.UpdatedDate
                    FROM	[dbo].[Strategies] S		
                            INNER JOIN [dbo].[StrategyStaffs] SS ON S.StrategyId = SS.StrategyId AND SS.IsDeleted <> 1
                            INNER JOIN [dbo].[SagittaStaff] SagS ON SS.SagittaStaffId = SagS.SagittaStaffId
                            INNER JOIN [dbo].[StrategyTimelines] STL ON S.StrategyId = STL.StrategyId AND STL.IsDeleted <> 1
                            INNER JOIN [dbo].[StrategyTaskMeta] STM ON	STL.StrategyTimelineId = STM.StrategyTimelineId AND STM.IsDeleted <> 1
							INNER JOIN [dbo].[TaskStacks] TaskS ON	STM.TaskStackId = TaskS.TaskStackId AND TaskS.IsDeleted <> 1
						    INNER JOIN [dbo].[TaskSteps] TS ON TaskS.TaskStackId = TS.TaskStackId
																AND TS.IsDeleted <> 1
																AND TS.TaskStepRefType = 'STRATEGY_TIMELINE'
																AND TS.TaskStepRefKey = STM.StrategyTimelineId
                            INNER JOIN [dbo].[TaskAssignment] TA ON TS.[TaskStepId] = TA.[TaskStepId] 
							AND SS.SagittaStaffId = TA.TaskAssignTo 
							AND TA.IsDeleted<>1
                    WHERE	S.IsDeleted <> 1 AND STL.StrategyTimelineId IS NOT NULL
                            AND STL.StrategyTimelineId IN (SELECT CAST(value AS UNIQUEIDENTIFIER) FROM OPENJSON({{0}}))",
                   jsonGuids
               )
               .ToList();
            return results;
        }
        public List<StepTimelineStaffAssignment>? GetStaffAssignedByMarketsTimelines(List<Guid>? stepTimeLineIds)
        {
            string jsonGuids = JsonSerializer.Serialize(stepTimeLineIds);
            var results = _context.StrategyStaffAssignments
               .FromSqlRaw(
                   @$"SELECT  DISTINCT TA.TaskAssignmentId,
                       SS.StrategyStaffId,
                       SS.SagittaStaffId,
                       SagS.StaffName,
                       TS.StepDefId,
                       MTL.MarketTimelineId as StepTimelineId,
                       TS.TaskStackId,
                       TS.TaskStepId, 
        TS.TaskStepRefType,
        TS.TaskStepRefKey,        
                       TA.IsDeleted,
                       TA.CreatedBy,
                       TA.CreatedDate,
                       TA.UpdatedBy,
                       TA.UpdatedDate
                     FROM	[dbo].[Strategies] S		
                       INNER JOIN [dbo].[StrategyStaffs] SS ON S.StrategyId = SS.StrategyId AND SS.IsDeleted <> 1
                       INNER JOIN [dbo].[SagittaStaff] SagS ON SS.SagittaStaffId = SagS.SagittaStaffId
                       INNER JOIN [dbo].[Markets] M ON S.StrategyId = M.StrategyId AND M.IsDeleted <> 1
                       INNER JOIN [dbo].[MarketTimelines] MTL ON M.MarketId = MTL.MarketId AND MTL.IsDeleted <> 1
                       INNER JOIN [dbo].[MarketTaskMeta] MTM ON M.MarketId = MTM.MarketId AND MTM.IsDeleted <> 1
        INNER JOIN [dbo].[TaskStacks] TaskS ON	MTM.TaskStackId = TaskS.TaskStackId AND TaskS.IsDeleted <> 1
                       INNER JOIN [dbo].[TaskSteps] TS ON TaskS.TaskStackId = TS.TaskStackId
        									AND TS.IsDeleted <> 1
        									AND TS.TaskStepRefType = 'MARKET_TIMELINE'
        									AND TS.TaskStepRefKey = MTL.MarketTimelineId
                       INNER JOIN [dbo].[TaskAssignment] TA ON TS.[TaskStepId] = TA.[TaskStepId] 
                                 AND SS.SagittaStaffId = TA.TaskAssignTo AND TA.IsDeleted<>1
                     WHERE	S.IsDeleted <> 1 AND MTL.MarketTimelineId IS NOT NULL
                       AND MTL.MarketTimelineId IN (SELECT CAST(value AS UNIQUEIDENTIFIER) FROM OPENJSON({{0}}))",
                   jsonGuids
               )
               .ToList();
            return results;
        }
        public List<StepTimelineStaffAssignment>? GetStaffAssignedByStrategyAndMarketsTimelines(List<Guid>? stepTimeLineIds)
        {
            string jsonGuids = JsonSerializer.Serialize(stepTimeLineIds);
            var results = _context.StrategyStaffAssignments
               .FromSqlRaw(
                   @$"SELECT  DISTINCT TA.TaskAssignmentId,
                                       SS.StrategyStaffId,
                                       SS.SagittaStaffId,
                                       SagS.StaffName,
                                       TS.StepDefId,
                                       STM.StrategyTimelineId as StepTimelineId,
                                       TS.TaskStackId,
                                       TS.TaskStepId, 
                                       TS.TaskStepRefType,
                                       TS.TaskStepRefKey,        
                                       TA.IsDeleted,
                                       TA.CreatedBy,
                                       TA.CreatedDate,
                                       TA.UpdatedBy,
                                       TA.UpdatedDate
                     FROM	[dbo].[Strategies] S		
                             INNER JOIN [dbo].[StrategyStaffs] SS ON S.StrategyId = SS.StrategyId AND SS.IsDeleted <> 1
                             INNER JOIN [dbo].[SagittaStaff] SagS ON SS.SagittaStaffId = SagS.SagittaStaffId
                             INNER JOIN [dbo].[StrategyTimelines] STL ON S.StrategyId = STL.StrategyId AND STL.IsDeleted <> 1
                             INNER JOIN [dbo].[StrategyTaskMeta] STM ON	STL.StrategyTimelineId = STM.StrategyTimelineId AND STM.IsDeleted <> 1
                            INNER JOIN [dbo].[TaskStacks] TaskS ON	STM.TaskStackId = TaskS.TaskStackId AND TaskS.IsDeleted <> 1
                            INNER JOIN [dbo].[TaskSteps] TS ON TaskS.TaskStackId = TS.TaskStackId
        									AND TS.IsDeleted <> 1
        									AND TS.TaskStepRefType = 'STRATEGY_TIMELINE'
        									AND TS.TaskStepRefKey = STM.StrategyTimelineId
                             INNER JOIN [dbo].[TaskAssignment] TA ON TS.[TaskStepId] = TA.[TaskStepId] 
                                                                    AND SS.SagittaStaffId = TA.TaskAssignTo 
                                                                    AND TA.IsDeleted<>1
                     WHERE	S.IsDeleted <> 1 AND STL.StrategyTimelineId IS NOT NULL
                             AND STL.StrategyTimelineId IN (SELECT CAST(value AS UNIQUEIDENTIFIER) FROM OPENJSON({{0}}))
                     UNION ALL
                     SELECT  DISTINCT TA.TaskAssignmentId,
                                       SS.StrategyStaffId,
                                       SS.SagittaStaffId,
                                       SagS.StaffName,
                                       TS.StepDefId,
                                       MTL.MarketTimelineId as StepTimelineId,
                                       TS.TaskStackId,
                                       TS.TaskStepId, 
                                        TS.TaskStepRefType,
                                        TS.TaskStepRefKey,        
                                       TA.IsDeleted,
                                       TA.CreatedBy,
                                       TA.CreatedDate,
                                       TA.UpdatedBy,
                                       TA.UpdatedDate
                     FROM	[dbo].[Strategies] S		
                           INNER JOIN [dbo].[StrategyStaffs] SS ON S.StrategyId = SS.StrategyId AND SS.IsDeleted <> 1
                           INNER JOIN [dbo].[SagittaStaff] SagS ON SS.SagittaStaffId = SagS.SagittaStaffId
                           INNER JOIN [dbo].[Markets] M ON S.StrategyId = M.StrategyId AND M.IsDeleted <> 1
                           INNER JOIN [dbo].[MarketTimelines] MTL ON M.MarketId = MTL.MarketId AND MTL.IsDeleted <> 1
                           INNER JOIN [dbo].[MarketTaskMeta] MTM ON M.MarketId = MTM.MarketId AND MTM.IsDeleted <> 1
                            INNER JOIN [dbo].[TaskStacks] TaskS ON	MTM.TaskStackId = TaskS.TaskStackId AND TaskS.IsDeleted <> 1
                            INNER JOIN [dbo].[TaskSteps] TS ON TaskS.TaskStackId = TS.TaskStackId
        									AND TS.IsDeleted <> 1
        									AND TS.TaskStepRefType = 'MARKET_TIMELINE'
        									AND TS.TaskStepRefKey = MTL.MarketTimelineId
                            INNER JOIN [dbo].[TaskAssignment] TA ON TS.[TaskStepId] = TA.[TaskStepId] 
                                 AND SS.SagittaStaffId = TA.TaskAssignTo AND TA.IsDeleted<>1
                     WHERE	S.IsDeleted <> 1 AND MTL.MarketTimelineId IS NOT NULL
                            AND MTL.MarketTimelineId IN (SELECT CAST(value AS UNIQUEIDENTIFIER) FROM OPENJSON({{0}}))",
                   jsonGuids
               )
               .ToList();
            return results;
        }
        public List<StepTimelineStaffAssignment>? GetStrategyStaffAssignmentsByStrategy(Guid? strategyId)
        {
            FormattableString query = @$"SELECT  DISTINCT TA.TaskAssignmentId,
                                           SS.StrategyStaffId,
                                           SS.SagittaStaffId,
                                           SagS.StaffName,
                                           TS.StepDefId,
                                           STM.StrategyTimelineId as StepTimelineId,
                                           TS.TaskStackId,
                                           TS.TaskStepId, 
                                            TS.TaskStepRefType,
                                            TS.TaskStepRefKey,        
                                           TA.IsDeleted,
                                           TA.CreatedBy,
                                           TA.CreatedDate,
                                           TA.UpdatedBy,
                                           TA.UpdatedDate
                                         FROM	[dbo].[Strategies] S		
                                                 INNER JOIN [dbo].[StrategyStaffs] SS ON S.StrategyId = SS.StrategyId AND SS.IsDeleted <> 1
                                                 INNER JOIN [dbo].[SagittaStaff] SagS ON SS.SagittaStaffId = SagS.SagittaStaffId
                                                 INNER JOIN [dbo].[StrategyTimelines] STL ON S.StrategyId = STL.StrategyId AND STL.IsDeleted <> 1
                                                 INNER JOIN [dbo].[StrategyTaskMeta] STM ON	STL.StrategyTimelineId = STM.StrategyTimelineId AND STM.IsDeleted <> 1
                                                INNER JOIN [dbo].[TaskStacks] TaskS ON	STM.TaskStackId = TaskS.TaskStackId AND TaskS.IsDeleted <> 1
                                                   INNER JOIN [dbo].[TaskSteps] TS ON TaskS.TaskStackId = TS.TaskStackId
        									                    AND TS.IsDeleted <> 1
        									                    AND TS.TaskStepRefType = 'STRATEGY_TIMELINE'
        									                    AND TS.TaskStepRefKey = STM.StrategyTimelineId
                                                 INNER JOIN [dbo].[TaskAssignment] TA ON TS.[TaskStepId] = TA.[TaskStepId] 
                                                                                        AND SS.SagittaStaffId = TA.TaskAssignTo 
                                                                                        AND TA.IsDeleted<>1
                                         WHERE	S.IsDeleted <> 1 AND STL.StrategyTimelineId IS NOT NULL
                                                 AND S.StrategyId = {strategyId}";

            List<StepTimelineStaffAssignment> results =
                _context.StrategyStaffAssignments.FromSqlInterpolated(query).ToList();
            return results;
        }

        #region PRIVATE        
        private List<Guid>? SearchTaskIdsByAllFilters(TaskSearchType searchType, string[] taskStatusCodes, string taskCategory, string taskAssignType,
                string? securityUserId, string[] userSagittaStaffIds, string[] teamSecurityUserIds, string[] teamSagittaStaffIds)
        {
            List<Guid>? matchedTaskIds = null;
            switch (taskCategory)
            {
                case nameof(TaskCategorySearchCriteria.GENERIC):
                    if (taskAssignType.Equals(TaskAssignTypeSearchCriteria.MYASSIGNMENT))
                    {
                        //PICK ALL TASKS WHICH ARE GENERIC AND ASSIGNED TO REQUESTED USER
                        matchedTaskIds = (from taskStacks in _context.TaskStacks
                                          join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                          join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                          where (taskStacks.IsDeleted.Equals(false)
                                                    && taskStacks.TaskRefType.Equals(nameof(TaskCategorySearchCriteria.GENERIC)) && taskStacks.IsSysGen.Equals(false)
                                                     && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                     && taskSteps.IsDeleted.Equals(false)
                                                     && taskAssignments.IsDeleted.Equals(false)
                                                     && userSagittaStaffIds != null && userSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                     )
                                          select (taskStacks.TaskStackId)).ToList();
                        break;
                    }
                    else if (taskAssignType.Equals(TaskAssignTypeSearchCriteria.MYREQUEST))
                    {
                        //PICK ALL TASKS WHICH ARE GENERIC AND CREATED BY REQUESTED USER
                        matchedTaskIds = (from taskStacks in _context.TaskStacks
                                          where (taskStacks.IsDeleted.Equals(false)
                                                    && taskStacks.TaskRefType.Equals(nameof(TaskCategorySearchCriteria.GENERIC)) && taskStacks.IsSysGen.Equals(false)
                                                    && taskStacks.CreatedBy.Equals(securityUserId)
                                                    && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                     )
                                          select (taskStacks.TaskStackId)).ToList();
                        break;
                    }
                    else
                    {
                        //PICK ALL TASKS WHICH ARE GENERIC
                        matchedTaskIds = (from taskStacks in _context.TaskStacks
                                          where (taskStacks.IsDeleted.Equals(false)
                                                    && taskStacks.TaskRefType.Equals(nameof(TaskCategorySearchCriteria.GENERIC))
                                                    && taskStacks.IsSysGen.Equals(false)
                                                     && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                     )
                                          select (taskStacks.TaskStackId)).ToList();
                    }
                    break;

                case nameof(TaskCategorySearchCriteria.SYSTEM):
                    if (taskAssignType.Equals(TaskAssignTypeSearchCriteria.MYASSIGNMENT))
                    {
                        //PICK ALL TASKS WHICH ARE SYSTEM GENERATED AND ASSIGNED TO REQUESTED USER
                        matchedTaskIds = (from taskStacks in _context.TaskStacks
                                          join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                          join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                          where (taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen.Equals(true)
                                                 && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                     && taskSteps.IsDeleted.Equals(false)
                                                     && taskAssignments.IsDeleted.Equals(false)
                                                     && userSagittaStaffIds != null && userSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                     )
                                          select (taskStacks.TaskStackId)).ToList();
                        break;
                    }
                    else if (taskAssignType.Equals(TaskAssignTypeSearchCriteria.MYREQUEST))
                    {
                        //SYSTEM GENERATED TASK IS NOT USER GENERATED HENCE NOT APPLICABLE THIS FILTER
                        matchedTaskIds = null;
                        break;
                    }
                    else
                    {
                        //PICK ALL TASKS WHICH ARE SYSTEM GENERATED
                        matchedTaskIds = (from taskStacks in _context.TaskStacks
                                          where (taskStacks.IsDeleted.Equals(false)
                                                    && taskStacks.IsSysGen.Equals(true)
                                                     && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                     )
                                          select (taskStacks.TaskStackId)).ToList();
                    }
                    break;
                default:
                    //PICK ALL TASKS WHICH ARE EITHER GENERIC / SYSTEM GENERATED
                    matchedTaskIds = (from taskStacks in _context.TaskStacks
                                      where (taskStacks.IsDeleted.Equals(false)
                                                && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                )
                                      select (taskStacks.TaskStackId)).ToList();
                    break;
            }
            return matchedTaskIds;
        }

        private List<Guid>? SearchTaskIdsByUserFilters(TaskSearchType searchType, string[] taskStatusCodes, string taskCategory, string taskAssignType,
                string? securityUserId, string[] userSagittaStaffIds, string[] teamSecurityUserIds, string[] teamSagittaStaffIds)
        {
            List<Guid>? matchedTaskIds = null;
            string[]? userAndTeamSecurityUserIds = null;
            string[]? userAndTeamSagittaStaffIds = null;

            if (!string.IsNullOrEmpty(securityUserId))
            {
                List<string> allSecurityUserIds = new List<string>();
                allSecurityUserIds.Add(securityUserId);
                if (teamSecurityUserIds != null && teamSecurityUserIds.Length > 0)
                    allSecurityUserIds.AddRange(teamSecurityUserIds);
                userAndTeamSecurityUserIds = allSecurityUserIds.ToArray();
            }

            if (userSagittaStaffIds != null && userSagittaStaffIds.Length > 0)
            {
                List<string> allSagittaStaffIds = userSagittaStaffIds.ToList();
                if (teamSagittaStaffIds != null && teamSagittaStaffIds.Length > 0)
                    allSagittaStaffIds.AddRange(teamSagittaStaffIds);
                userAndTeamSagittaStaffIds = allSagittaStaffIds.ToArray();
            }

            //Based on business requirements - USER STORY 536908 (Dashboard by User)
            //SearchType: 
            //  ALL/MYTEAMASSIGNMENT (My Team) - ALL tasks assignedto/requested by user and his team
            //  MYASSIGNMENT (My Work) - ALL tasks assignedTo/requested by user
            switch (searchType)
            {
                //Find All Tasks based on filter task type - generic/system/all: 
                //And filter the tasks assigned to user & his team + tasks requested by user & his team
                case TaskSearchType.ALL:
                case TaskSearchType.MYTEAMASSIGNMENT:

                    switch (taskCategory)
                    {
                        //Generic Tasks
                        //And filter the tasks assigned to user & his team + tasks requested by user & his team                
                        case nameof(TaskCategorySearchCriteria.GENERIC):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join genericTasks in _context.GenericTasks on taskStacks.TaskStackId equals genericTasks.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(false)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && ((genericTasks.RequestedByUserId != null && userAndTeamSecurityUserIds.Contains(genericTasks.RequestedByUserId))
                                                    || (userAndTeamSagittaStaffIds != null
                                                        && userAndTeamSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                        )
                                                  )
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //SYSTEM Tasks
                        //And filter the tasks assigned to user & his team + tasks requested by user & his team  
                        case nameof(TaskCategorySearchCriteria.SYSTEM):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(true)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && (userAndTeamSagittaStaffIds != null
                                                        && userAndTeamSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                        )
                                           )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //ALL Tasks (SYSTEM + GENERIC)
                        //And filter the tasks assigned to user & his team + tasks requested by user & his team  
                        default:
                            matchedTaskIds
                                   = (from taskStacks in _context.TaskStacks
                                      join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                      join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                      where (
                                                 taskStacks.IsDeleted.Equals(false)
                                                 && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                 && taskSteps.IsDeleted.Equals(false)
                                                 && taskAssignments.IsDeleted.Equals(false)
                                                 && (taskStacks.CreatedBy.Equals(securityUserId) || taskStacks.TaskSender.Equals(securityUserId)
                                                       || (userAndTeamSagittaStaffIds != null
                                                           && userAndTeamSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                           )
                                                     )
                                                 )
                                      select (taskStacks.TaskStackId)).ToList();
                            break;
                    }
                    break;

                //Find All Tasks based on filter task type - generic/system/all: 
                //And filter the tasks assigned to user + tasks requested by user
                case TaskSearchType.MYASSIGNMENT:
                    switch (taskCategory)
                    {
                        //Generic Tasks
                        //And filter the tasks assigned to user + tasks requested by user                      
                        case nameof(TaskCategorySearchCriteria.GENERIC):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join genericTasks in _context.GenericTasks on taskStacks.TaskStackId equals genericTasks.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(false)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && ((genericTasks.RequestedByUserId != null && genericTasks.RequestedByUserId.Equals(securityUserId))
                                                    || (userSagittaStaffIds != null
                                                        && userSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                        )
                                                  )
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //SYSTEM Tasks
                        //And filter the tasks assigned to user + tasks requested by user   
                        case nameof(TaskCategorySearchCriteria.SYSTEM):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(true)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && (userSagittaStaffIds != null
                                                        && userSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                        )
                                           )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //ALL Tasks (SYSTEM + GENERIC)
                        //And filter the tasks assigned to user + tasks requested by user 
                        default:
                            matchedTaskIds
                                   = (from taskStacks in _context.TaskStacks
                                      join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                      join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                      where (
                                                 taskStacks.IsDeleted.Equals(false)
                                                 && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                                 && taskSteps.IsDeleted.Equals(false)
                                                 && taskAssignments.IsDeleted.Equals(false)
                                                 && (taskStacks.CreatedBy.Equals(securityUserId) || taskStacks.TaskSender.Equals(securityUserId)
                                                       || (userSagittaStaffIds != null
                                                           && userSagittaStaffIds.Contains(taskAssignments.TaskAssignTo)
                                                           )
                                                     )
                                                 )
                                      select (taskStacks.TaskStackId)).ToList();
                            break;
                    }
                    break;
            }
            return matchedTaskIds;
        }
        private List<Guid>? SearchTaskIdsByClientFilters(TaskSearchType searchType, string[] taskStatusCodes, string taskCategory, string taskAssignType,
            string? securityUserId, string[] userSagittaStaffIds, string[] teamSecurityUserIds, string[] teamSagittaStaffIds,
                long? sagittaClientId)
        {
            List<Guid>? matchedTaskIds = null;

            //SearchType: 
            //  ALL - ALL tasks linked to this client by any user
            //  MYTEAMASSIGNMENT (My Team) - ALL tasks linked to this client and assignedto/requested by user and his team
            //  MYASSIGNMENT (My Work) - ALL tasks linked to this client and assignedto/requested by user
            switch (searchType)
            {
                //Find All Tasks linked to client based on filter task type - generic/system/all: 
                case TaskSearchType.ALL:
                    switch (taskCategory)
                    {
                        //all Generic Tasks linked to client by any user
                        case nameof(TaskCategorySearchCriteria.GENERIC):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join genericTasks in _context.GenericTasks on taskStacks.TaskStackId equals genericTasks.TaskStackId
                                   join taskMeta in _context.TaskMeta on taskStacks.TaskStackId equals taskMeta.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(false)
                                              && genericTasks.RequestedByUserId != null
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && taskMeta.IsDeleted.Equals(false)
                                              && taskMeta.SagittaClientId != null && taskMeta.SagittaClientId.Equals(sagittaClientId)
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //all System Tasks linked to client by any user
                        case nameof(TaskCategorySearchCriteria.SYSTEM):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join taskMeta in _context.TaskMeta on taskStacks.TaskStackId equals taskMeta.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(true)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && taskMeta.IsDeleted.Equals(false)
                                              && taskMeta.SagittaClientId != null && taskMeta.SagittaClientId.Equals(sagittaClientId)
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //all System + Generic Tasks linked to client by any user
                        default:
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join taskMeta in _context.TaskMeta on taskStacks.TaskStackId equals taskMeta.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && taskMeta.IsDeleted.Equals(false)
                                              && taskMeta.SagittaClientId != null && taskMeta.SagittaClientId.Equals(sagittaClientId)
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;
                    }
                    break;

                //Find All Tasks linked to client based on filter task type - generic/system/all: 
                //And filter the tasks assigned to user & his team + tasks requested by user & his team
                case TaskSearchType.MYTEAMASSIGNMENT:
                //TODO: FUTURE

                //Find All Tasks linked to client based on filter task type - generic/system/all: 
                //And filter the tasks assigned to user + tasks requested by user
                case TaskSearchType.MYASSIGNMENT:
                    //TODO: FUTURE
                    break;
            }
            return matchedTaskIds;
        }
        private List<Guid>? SearchTaskIdsByStrategyFilters(TaskSearchType searchType, string[] taskStatusCodes, string taskCategory, string taskAssignType,
                string? securityUserId, string[] userSagittaStaffIds, string[] teamSecurityUserIds, string[] teamSagittaStaffIds,
                Guid? strategyId)
        {
            List<Guid>? matchedTaskIds = null;

            //SearchType: 
            //  ALL - ALL tasks linked to this strategy by any user
            //  MYTEAMASSIGNMENT (My Team) - ALL tasks linked to this strategy and assignedto/requested by user and his team
            //  MYASSIGNMENT (My Work) - ALL tasks linked to this strategy and assignedto/requested by user
            switch (searchType)
            {
                //Find All Tasks linked to strategy based on filter task type - generic/system/all: 
                case TaskSearchType.ALL:
                    switch (taskCategory)
                    {
                        //all Generic Tasks linked to strategy by any user
                        case nameof(TaskCategorySearchCriteria.GENERIC):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join genericTasks in _context.GenericTasks on taskStacks.TaskStackId equals genericTasks.TaskStackId
                                   join taskMeta in _context.TaskMeta on taskStacks.TaskStackId equals taskMeta.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(false)
                                              && genericTasks.RequestedByUserId != null
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && taskMeta.IsDeleted.Equals(false)
                                              && taskMeta.StrategyId != null && taskMeta.StrategyId.Equals(strategyId)
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //all System Tasks linked to strategy by any user
                        case nameof(TaskCategorySearchCriteria.SYSTEM):
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join taskMeta in _context.TaskMeta on taskStacks.TaskStackId equals taskMeta.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false) && taskStacks.IsSysGen != null && taskStacks.IsSysGen.Equals(true)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && taskMeta.IsDeleted.Equals(false)
                                              && taskMeta.StrategyId != null && taskMeta.StrategyId.Equals(strategyId)
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;

                        //all System + Generic Tasks linked to strategy by any user
                        default:
                            matchedTaskIds
                                = (from taskStacks in _context.TaskStacks
                                   join taskMeta in _context.TaskMeta on taskStacks.TaskStackId equals taskMeta.TaskStackId
                                   join taskSteps in _context.TaskSteps on taskStacks.TaskStackId equals taskSteps.TaskStackId
                                   join taskAssignments in _context.TaskAssignments on taskSteps.TaskStepId equals taskAssignments.TaskStepId
                                   where (
                                              taskStacks.IsDeleted.Equals(false)
                                              && taskStatusCodes.Contains(taskStacks.TaskStatusCodeId)
                                              && taskSteps.IsDeleted.Equals(false)
                                              && taskAssignments.IsDeleted.Equals(false)
                                              && taskMeta.IsDeleted.Equals(false)
                                              && taskMeta.StrategyId != null && taskMeta.StrategyId.Equals(strategyId)
                                              )
                                   select (taskStacks.TaskStackId)).ToList();
                            break;
                    }
                    break;

                //Find All Tasks linked to strategy based on filter task type - generic/system/all: 
                //And filter the tasks assigned to user & his team + tasks requested by user & his team
                case TaskSearchType.MYTEAMASSIGNMENT:
                //TODO: FUTURE

                //Find All Tasks linked to strategy based on filter task type - generic/system/all: 
                //And filter the tasks assigned to user + tasks requested by user
                case TaskSearchType.MYASSIGNMENT:
                    //TODO: FUTURE
                    break;
            }
            return matchedTaskIds;
        }
        private async Task<List<TaskStack>> GetTaskStacksByIds(List<Guid>? taskStackIds)
        {
            List<TaskStack>? taskStackList =
               await _context.TaskStacks.Where(task => taskStackIds.Contains(task.TaskStackId))
                                .Include(task => task.TaskSenderNavigation)
                                .Include(task => task.CreatedByNavigation)
                                .Include(task => task.UpdatedByNavigation)
                                .Include(task => task.LastTaskStatusUpdatedByNavigation)
                                .Include(task => task.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.Strategy)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.SagittaClient)
                                .Include(task => task.TaskMeta.Where(x => x.IsDeleted.Equals(false)))
                                .ThenInclude(taskMeta => taskMeta.GenericTask)
                                .ThenInclude(genericTask => genericTask.GenericTaskMeta)
                                .ToListAsync();
            return taskStackList;
        }

        

        #endregion

    }
}
