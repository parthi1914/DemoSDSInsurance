﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using System.Data.Entity;

namespace BrokerPortal.API.Repositories
{
    public class SagittaPayeeRepository : ISagittaPayeeRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public SagittaPayeeRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }
       

        public List<SagittaPayee> GetSagittaPayeesByIds(string?[] sagittaPayeeIds)
        {
            return _context.SagittaPayees.AsNoTracking().Where(staff => sagittaPayeeIds.Contains(staff.SagittaPayeeId)).ToList();
        }

        public SagittaPayee GetSagittaPayeeById(string? sagittaPayeeId)
        {
            return _context.SagittaPayees.AsNoTracking().Where(staff => staff.SagittaPayeeId == sagittaPayeeId).SingleOrDefault();
        }


        public List<SagittaPayee> BulkMerge(List<SagittaPayee> sagittaPayeeEntityList)
        {
            _context.BulkMerge(sagittaPayeeEntityList);
            return sagittaPayeeEntityList;
        }
    }
}