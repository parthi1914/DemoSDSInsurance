﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using System.Data;

namespace BrokerPortal.API.Repositories
{
    public class StrategyRepository : IStrategyRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public StrategyRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<List<Strategy>> GetAllStrategies()
        {
            var strategyList = await _context.Strategies.AsNoTracking().Where(strategy => strategy.IsDeleted == false)
                                .Include(strategy => strategy.StatusCode)
                                .Include(strategy => strategy.UpdatedByNavigation)
                                .Include(strategy => strategy.Plan).Where(strategy => strategy.Plan.IsDeleted == false)

                                .Include(strategy => strategy.StrategyClients.Where(x => x.IsDeleted == false))
                                    .ThenInclude(strategyClient => strategyClient.SagittaClient)

                                .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted == false))
                                    .ThenInclude(strategyTimelines => strategyTimelines.StatusCode)
                                .Include(strategy => strategy.StrategyTimelines)
                                    .ThenInclude(strategyTimelines => strategyTimelines.StepDef)

                                .Include(strategy => strategy.StrategyStaffs.Where(x => x.IsDeleted == false))
                                    .ThenInclude(strategyStaffs => strategyStaffs.SagittaStaff)
                       .ToListAsync();
            return strategyList;
        }

        public Strategy? GetStrategyHeaderById(Guid? strategyId)
        {
            Strategy? strategy =
                _context.Strategies.AsNoTracking().Where(strategy => strategy.StrategyId == strategyId)
                            .SingleOrDefault();
            return strategy;
        }

        public async Task<Strategy?> GetStrategyById(Guid? strategyId, bool includeMarkets)
        {
            Strategy? strategy =
                await _context.Strategies.AsNoTracking().Where(strategy => strategy.StrategyId == strategyId && strategy.IsDeleted == false)
                                .Include(strategy => strategy.StatusCode)
                                .Include(strategy => strategy.UpdatedByNavigation)
                                .Include(strategy => strategy.Plan).Where(strategy => strategy.Plan.IsDeleted == false)

                                .Include(strategy => strategy.StrategyClients.Where(x => x.IsDeleted == false))
                                    .ThenInclude(strategyClient => strategyClient.SagittaClient)

                                .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted == false))
                                    .ThenInclude(strategyTimelines => strategyTimelines.StatusCode)
                                .Include(strategy => strategy.StrategyTimelines)
                                    .ThenInclude(strategyTimelines => strategyTimelines.StepDef)

                                .Include(strategy => strategy.StrategyStaffs.Where(x => x.IsDeleted == false))
                                    .ThenInclude(strategyStaffs => strategyStaffs.SagittaStaff)

                            .SingleOrDefaultAsync();
            return strategy;
        }

        public async Task<Strategy?> GetStrategyForUpdate(Guid? strategyId)
        {
            Strategy? strategy = await _context.Strategies.AsNoTracking().Where(strategy => strategy.StrategyId == strategyId && strategy.IsDeleted == false)
                           .Include(strategy => strategy.StrategyClients).Where(x => x.IsDeleted.Equals(false))
                           .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(strategyTimelines => strategyTimelines.StrategyTaskMeta.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(strategyTaskMeta => strategyTaskMeta.TaskStack)
                           .ThenInclude(taskStack => taskStack.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                           .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(strategyTimelines => strategyTimelines.MarketTimelines.Where(x => x.IsDeleted.Equals(false)))
                            .SingleOrDefaultAsync();
            return strategy;
        }
        public async Task<Strategy?> GetStrategyForUpdateToSyncMarketChanges(Guid? strategyId)
        {
            Strategy? strategy = await
                _context.Strategies.Where(strategy => strategy.StrategyId == strategyId && strategy.IsDeleted == false)
                        .Include(strategy => strategy.StrategyStaffs.Where(x => x.IsDeleted.Equals(false)))
                        .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(strategyTimelines => strategyTimelines.StrategyTaskMeta.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(strategyTaskMeta => strategyTaskMeta.TaskStack)
                           .ThenInclude(taskStack => taskStack.TaskSteps.Where(x => x.IsDeleted.Equals(false)))
                           .ThenInclude(taskSteps => taskSteps.TaskAssignments.Where(x => x.IsDeleted.Equals(false)))
                            .SingleOrDefaultAsync();
            return strategy;
        }

        public async Task<Strategy?> GetStrategyForMarketChanges(Guid? strategyId)
        {
            Strategy? strategy = await _context.Strategies.AsNoTracking().Where(strategy => strategy.StrategyId == strategyId && strategy.IsDeleted == false)
                        .Include(strategy => strategy.StrategyStaffs.Where(x => x.IsDeleted.Equals(false)))
                        .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted.Equals(false)))
                            .SingleOrDefaultAsync();
            return strategy;
        }

        public Strategy GetStrategyByStrategyAndStepIds(Guid strategyId, string stepDefId)
        {
            Strategy? strategy = new Strategy();
            strategy = _context.Strategies.AsNoTracking().Where(strategy => strategy.StrategyId == strategyId && strategy.IsDeleted == false)
                            .Include(strategy => strategy.StrategyTimelines.Where(t => t.StepDefId == stepDefId))
                             .SingleOrDefault();
            return strategy;
        }

        public async Task<Strategy> SaveStrategy(Strategy strategy)
        {
            await _context.Strategies.AddAsync(strategy);
            await _context.SaveChangesAsync();
            return strategy;
        }

        public async Task<Guid> UpdateStrategy(Strategy strategy)
        {
            _context.Strategies.Update(strategy);
            await _context.SaveChangesAsync();
            return strategy.StrategyId;
        }
        public async Task TrackStrategyChanges(Strategy strategy)
        {
            try
            {

                if (strategy != null)
                {
                    // Prepare strategyIdTable Parameter
                    var dtStrategyIds = new DataTable();
                    dtStrategyIds.Columns.Add("MarketId", typeof(Guid));
                    dtStrategyIds.Rows.Add(strategy.StrategyId);

                    var strategyIdsParameter = new SqlParameter
                    {
                        ParameterName = "@StrategyIDs",
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.StrategyIDsType",
                        Value = dtStrategyIds
                    };

                    // Prepare taskStackIdTableList Parameter
                    var dtTaskIds = new DataTable();
                    dtTaskIds.Columns.Add("TaskStackId", typeof(Guid));
                    if (strategy.StrategyTaskMeta != null)
                    {
                        List<StrategyTaskMeta> strategyTaskMetas = strategy.StrategyTaskMeta.ToList();
                        foreach(var taskMeta in strategyTaskMetas)
                        {
                            var childEntry = _context.Entry(taskMeta);
                            // Check the EntityState
                            if (childEntry.State == EntityState.Modified)
                                dtTaskIds.Rows.Add(taskMeta.TaskStackId);
                        }
                        
                    }
                    var taskIdsParameter = new SqlParameter
                    {
                        ParameterName = "@TaskStackIDs",
                        SqlDbType = SqlDbType.Structured,
                        TypeName = "dbo.TaskStackIDsType",
                        Value = dtTaskIds
                    };

                    var parameters = new[] { strategyIdsParameter, taskIdsParameter };
                    await _context.Database.ExecuteSqlRawAsync("SP_History_Strategies @StrategyIDs, @TaskStackIDs", parameters);
                }
            }
            catch (Exception ex) { Console.WriteLine($"Exception occured in TrackStrategyChanges: {ex.Message}"); }

        }
        public async Task<bool> UpdateStrategyUpdatedBy(Guid strategyId, string? securityUserId)
        {
            await _context.Strategies.Where(x => x.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update.SetProperty(x => x.UpdatedBy, securityUserId).
                                                                 SetProperty(x => x.UpdatedDate, DateTime.Now));
            return true;
        }
        //THIS WILL REMOVE STRATEGY AND ASSOCIATED MARKETS
        public async Task<bool> RemoveStrategy(Guid strategyId, string securityUserId)
        {
            await _context.TaskMeta.Where(x => x.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketTaskMeta.Where(x => x.Market.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.StrategyTaskMeta.Where(x => x.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskSteps.Where(x => x.TaskStack.TaskMeta.Any(x => x.StrategyId == strategyId))
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.StatusCodeId, nameof(TaskStatusCodes.REMO))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskStacks.Where(x => x.TaskMeta.Any(x => x.StrategyId == strategyId))
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevTaskStatusCodeId, x => x.TaskStatusCodeId)
                                                    .SetProperty(x => x.TaskStatusCodeId, nameof(TaskStatusCodes.REMO))
                                                    .SetProperty(x => x.LastTaskStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketAddlCovs.Where(x => x.Market.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketTimelines.Where(x => x.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.Markets.Where(x => x.StrategyId == strategyId)
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));


            await _context.StrategyStaffs.Where(x => x.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                   .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));


            await _context.StrategyTimelines.Where(x => x.StrategyId == strategyId)
                            .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.StrategyClients.Where(x => x.StrategyId == strategyId)
                           .ExecuteUpdateAsync(update => update
                                                   .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.Strategies.Where(x => x.StrategyId == strategyId)
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            return true;
        }
        //THIS WILL ARCHIVE STRATEGY AND ASSOCIATED MARKETS
        public async Task<bool> ArchiveStrategy(Guid strategyId, string securityUserId)
        {
            await _context.TaskSteps
                .Where(x => x.TaskStack.TaskMeta.Any(x => x.StrategyId == strategyId)
                            && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                      )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.TaskStacks
                .Where(x => x.TaskMeta.Any(x => x.StrategyId == strategyId)
                            && ((x.TaskStatusCodeId == null) || (x.TaskStatusCode != null && !x.TaskStatusCode.TaskStatusGroupCode.Equals(nameof(TaskStatusGroupCodes.CLOS))))
                      )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevTaskStatusCodeId, x => x.TaskStatusCodeId)
                                                    .SetProperty(x => x.TaskStatusCodeId, nameof(TaskStatusCodes.ARCH))
                                                   .SetProperty(x => x.LastTaskStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastTaskStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.MarketTimelines
                .Where(x => x.StrategyId == strategyId
                        && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.Markets.Where(x => x.StrategyId == strategyId
                        && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                )
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.Version, (x => x.Version + 1))
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            await _context.StrategyTimelines.Where(x => x.StrategyId == strategyId
                        && ((x.StatusCodeId == null) || (x.StatusCode != null && !x.StatusCode.StatusGroupCode.Equals(nameof(GenericStatusGroupCodes.COMP))))
                )
                .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.LastStepStatusUpdatedDate, DateTime.Now)
                                                    .SetProperty(x => x.LastStepStatusUpdatedBy, securityUserId)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));


            await _context.Strategies.Where(x => x.StrategyId == strategyId)
                           .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));

            return true;
        }

        public async Task<bool> RemoveStrategyByPlan(Guid planId, string securityUserId)
        {
            List<Guid> strategyIdList = _context.Strategies.Where(x => x.PlanId == planId).Select(x => x.StrategyId).ToList();
            if (strategyIdList != null && strategyIdList.Count > 0)
            {
                foreach (var strategyId in strategyIdList)
                {
                    await RemoveStrategy(strategyId, securityUserId);
                }
            }
            return true;
        }

        public async Task<bool> ArchiveStrategyByPlan(Guid planId, string securityUserId)
        {
            List<Guid> strategyIdList = _context.Strategies.Where(x => x.PlanId == planId).Select(x => x.StrategyId).ToList();
            if (strategyIdList != null && strategyIdList.Count > 0)
            {
                foreach (var strategyId in strategyIdList)
                {
                    await ArchiveStrategy(strategyId, securityUserId);
                }
            }
            return true;
        }

        public async Task<List<Strategy>?> SearchStrategies(SearchBaseFilterType baseFilterType, StrategySearchType searchType,
            StrategySearchCriterias searchCriterias, string? securityUserId, string[] sagittaStaffIds, string? sagittaClientId)
        {
            List<Strategy>? strategyList = null;
            List<Guid>? matchedStrategyIds = null;
            string[] strategyStatusCodes = searchCriterias.strategyStatusCodes;

            switch (baseFilterType)
            {
                case SearchBaseFilterType.ALL:
                    matchedStrategyIds = GetMatchingStrategyIdsByFilters(searchType, strategyStatusCodes);
                    break;
                case SearchBaseFilterType.CLIENT_SPECIFIC:
                    long? sagittaClientIdConverted = Convert.ToInt64(sagittaClientId);
                    matchedStrategyIds = GetMatchingStrategyIdsClientByUserFilters(searchType, strategyStatusCodes, sagittaClientIdConverted, securityUserId, sagittaStaffIds);
                    break;
                case SearchBaseFilterType.USER_SPECIFIC:
                    matchedStrategyIds = GetMatchingStrategyIdsByUserFilters(searchType, strategyStatusCodes, securityUserId, sagittaStaffIds);
                    break;
            }

            if (matchedStrategyIds != null && matchedStrategyIds.Count > 0)
            {
                matchedStrategyIds = matchedStrategyIds.Distinct().ToList();

                strategyList = await _context.Strategies.Where(s => matchedStrategyIds.Contains(s.StrategyId)
                                    && strategyStatusCodes.Contains(s.StatusCodeId) && s.IsDeleted == false)

                                .Include(strategy => strategy.StatusCode).Where(strategy => strategy.StatusCode.IsDeleted == false)
                                .Include(strategy => strategy.UpdatedByNavigation)
                                .Include(strategy => strategy.Plan).Where(strategy => strategy.Plan.IsDeleted == false)

                                .Include(strategy => strategy.StrategyClients.Where(x => x.IsDeleted == false))
                                .ThenInclude(strategyClient => strategyClient.SagittaClient)

                                .Include(strategy => strategy.StrategyTimelines.Where(x => x.IsDeleted == false))
                                .ThenInclude(strategyTimelines => strategyTimelines.StatusCode)
                                .Include(strategy => strategy.StrategyTimelines)
                                .ThenInclude(strategyTimelines => strategyTimelines.StepDef)

                                .Include(strategy => strategy.StrategyStaffs.Where(x => x.IsDeleted == false))
                                .ThenInclude(strategyStaffs => strategyStaffs.SagittaStaff)
                                .OrderBy(x => x.StrategyEffDate)
                                .ToListAsync();
            }
            return strategyList;
        }

        public async Task<Guid?> GetStrategyIdByPlanId(Guid planId)
        {
            Guid? strategyId = await _context.Strategies.AsNoTracking()
                                .Where(x => x.PlanId == planId && x.IsDeleted == false)
                                .Select(x => x.StrategyId)
                                .SingleOrDefaultAsync();
            return strategyId;
        }

        public async Task<List<StrategyTimeline>> UpdateRangeStrategyTimelines(List<StrategyTimeline> strategyTimelines)
        {
            _context.StrategyTimelines.UpdateRange(strategyTimelines);
            await _context.SaveChangesAsync();
            return strategyTimelines;
        }

        public async Task<string?> GetStrategyClientId(Guid? strategyId)
        {
            var client = from strategies in _context.Strategies
                         join planClients in _context.PlanClients on strategies.PlanId equals planClients.PlanId
                         where (strategies.StrategyId == strategyId && strategies.IsDeleted == false)
                         select planClients.SagittaClientId;

            return Convert.ToString(client.FirstOrDefaultAsync().Result);
        }

        public async Task<List<StrategyTimeline>> GetStrategyTimelines(Guid? strategyId)
        {
            var strategyTimelines = await _context.StrategyTimelines.AsNoTracking().Where(stf => stf.IsDeleted == false && stf.StrategyId == strategyId)
                                .ToListAsync();
            return strategyTimelines;
        }

        public Guid? GetStrategyIdByMarketId(Guid? marketId)
        {
            var strategyId = from strategies in _context.Strategies
                             join markets in _context.Markets on strategies.StrategyId equals markets.StrategyId
                             where (markets.MarketId.Equals(marketId))
                             select strategies.StrategyId;
            return strategyId.FirstOrDefaultAsync().Result;
        }

        #region PRIVATE
        private List<Guid>? GetMatchingStrategyIdsByFilters(StrategySearchType searchType, string[] strategyStatusCodes)
        {
            List<Guid>? matchedStrategyIds = null;

            switch (searchType)
            {
                case StrategySearchType.ALL:
                    matchedStrategyIds = (from strategy in _context.Strategies
                                          where (
                                                 strategy.IsDeleted.Equals(false)
                                                 && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                 )
                                          select (strategy.StrategyId)).ToList();
                    break;
            }
            return matchedStrategyIds;
        }

        private List<Guid>? GetMatchingStrategyIdsByUserFilters(StrategySearchType searchType,
            string[] strategyStatusCodes, string? securityUserId, string[] sagittaStaffIds)
        {
            List<Guid>? matchedStrategyIds = null;

            switch (searchType)
            {
                case StrategySearchType.ALL:
                case StrategySearchType.MYACCESS:
                    //IF WE ARE ABLE TO IDENTIFY USER IN SAGITTA
                    if (sagittaStaffIds != null && sagittaStaffIds.Length > 0)
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join strategyStaffs in _context.StrategyStaffs on strategy.StrategyId equals strategyStaffs.StrategyId
                                              where (
                                                     strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategyStaffs.IsDeleted.Equals(false)
                                                     && sagittaStaffIds.Contains(strategyStaffs.SagittaStaffId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }
                    //ELSE JUST CHECK STRATEGY CREATED BY SECURITY USER
                    else
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              where (
                                                     strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategy.CreatedBy != null && strategy.CreatedBy.Equals(securityUserId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }
                    break;
                //ONLY IF WE ARE ABLE TO IDENTIFY USER IN SAGITTA
                case StrategySearchType.MYASSIGNMENT:
                    matchedStrategyIds = (from strategy in _context.Strategies
                                          join strategyTimelines in _context.StrategyTimelines on strategy.StrategyId equals strategyTimelines.StrategyId
                                          join strategyStaff in _context.StrategyStaffs on strategy.StrategyId equals strategyStaff.StrategyId
                                          join strategyTaskMeta in _context.StrategyTaskMeta on strategy.StrategyId equals strategyTaskMeta.StrategyId
                                          join taskStep in _context.TaskSteps on strategyTaskMeta.TaskStackId equals taskStep.TaskStackId
                                          join taskAssignment in _context.TaskAssignments on taskStep.TaskStepId equals taskAssignment.TaskStepId
                                          where (
                                                    strategy.IsDeleted.Equals(false)
                                                 && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                 && strategyStaff.IsDeleted.Equals(false)
                                                 && taskAssignment.IsDeleted.Equals(false)
                                                 && sagittaStaffIds != null
                                                    && sagittaStaffIds.Contains(strategyStaff.SagittaStaffId)
                                                    && sagittaStaffIds.Contains(taskAssignment.TaskAssignTo)
                                                 )
                                          select (strategy.StrategyId)).ToList();
                    break;

                case StrategySearchType.MYFAVORITE:
                    //IF WE ARE ABLE TO IDENTIFY USER IN SAGITTA
                    if (sagittaStaffIds != null && sagittaStaffIds.Length > 0)
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join strategyStaffs in _context.StrategyStaffs on strategy.StrategyId equals strategyStaffs.StrategyId
                                              join favouriteStrategies in _context.FavouriteStrategies on strategy.StrategyId equals favouriteStrategies.StrategyId
                                              where (
                                                        strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategyStaffs.IsDeleted.Equals(false)
                                                     && sagittaStaffIds.Contains(strategyStaffs.SagittaStaffId)
                                                     && favouriteStrategies.IsDeleted.Equals(false) && favouriteStrategies.SecurityUserId.Equals(securityUserId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }
                    //ELSE JUST CHECK STRATEGY CREATED BY SECURITY USER
                    else
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join favouriteStrategies in _context.FavouriteStrategies on strategy.StrategyId equals favouriteStrategies.StrategyId
                                              where (
                                                     strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && (strategy.CreatedBy != null && strategy.CreatedBy.Equals(securityUserId))
                                                     && favouriteStrategies.IsDeleted.Equals(false) && favouriteStrategies.SecurityUserId.Equals(securityUserId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }

                    break;
            }
            return matchedStrategyIds;
        }

        private List<Guid>? GetMatchingStrategyIdsClientByUserFilters(StrategySearchType searchType,
            string[] strategyStatusCodes, long? sagittaClientId, string? securityUserId, string[] sagittaStaffIds)
        {
            List<Guid>? matchedStrategyIds = null;
            string? securityUserStaffId = securityUserId;

            switch (searchType)
            {
                case StrategySearchType.ALL:
                    matchedStrategyIds = (from strategy in _context.Strategies
                                          join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                          where (
                                                 strategy.IsDeleted.Equals(false)
                                                 && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                 && strategyClients.IsDeleted.Equals(false)
                                                 && strategyClients.SagittaClientId.Equals(sagittaClientId)
                                                 )
                                          select (strategy.StrategyId)).ToList();
                    break;
                case StrategySearchType.MYACCESS:
                    //IF WE ARE ABLE TO IDENTIFY USER IN SAGITTA
                    if (sagittaStaffIds != null && sagittaStaffIds.Length > 0)
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                              join strategyStaffs in _context.StrategyStaffs on strategy.StrategyId equals strategyStaffs.StrategyId
                                              where (
                                                     strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategyClients.IsDeleted.Equals(false)
                                                     && strategyClients.SagittaClientId.Equals(sagittaClientId)
                                                     && strategyStaffs.IsDeleted.Equals(false)
                                                     && sagittaStaffIds.Contains(strategyStaffs.SagittaStaffId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }
                    //ELSE JUST CHECK STRATEGY CREATED BY SECURITY USER
                    else
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                              where (
                                                     strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategyClients.IsDeleted.Equals(false)
                                                     && strategyClients.SagittaClientId.Equals(sagittaClientId)
                                                     && (strategy.CreatedBy != null && strategy.CreatedBy.Equals(securityUserId))
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }

                    break;

                case StrategySearchType.MYASSIGNMENT://ONLY IF WE ARE ABLE TO IDENTIFY USER IN SAGITTA
                    matchedStrategyIds = (from strategy in _context.Strategies
                                          join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                          join strategyStaff in _context.StrategyStaffs on strategy.StrategyId equals strategyStaff.StrategyId
                                          join strategyTaskMeta in _context.StrategyTaskMeta on strategy.StrategyId equals strategyTaskMeta.StrategyId
                                          join taskStep in _context.TaskSteps on strategyTaskMeta.TaskStackId equals taskStep.TaskStackId
                                          join taskAssignment in _context.TaskAssignments on taskStep.TaskStepId equals taskAssignment.TaskStepId
                                          where (
                                                 strategy.IsDeleted.Equals(false)
                                                 && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                 && strategyClients.IsDeleted.Equals(false)
                                                 && strategyClients.SagittaClientId.Equals(sagittaClientId)
                                                 && strategyStaff.IsDeleted.Equals(false)
                                                 && taskAssignment.IsDeleted.Equals(false)
                                                 && sagittaStaffIds != null
                                                    && sagittaStaffIds.Contains(strategyStaff.SagittaStaffId)
                                                    && sagittaStaffIds.Contains(taskAssignment.TaskAssignTo)
                                                 )
                                          select (strategy.StrategyId)).ToList();
                    break;

                case StrategySearchType.MYFAVORITE:
                    //IF WE ARE ABLE TO IDENTIFY USER IN SAGITTA
                    if (sagittaStaffIds != null && sagittaStaffIds.Length > 0)
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                              join strategyStaffs in _context.StrategyStaffs on strategy.StrategyId equals strategyStaffs.StrategyId
                                              join favouriteStrategies in _context.FavouriteStrategies on strategy.StrategyId equals favouriteStrategies.StrategyId
                                              where (
                                                    strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategyClients.IsDeleted.Equals(false)
                                                     && strategyClients.SagittaClientId.Equals(sagittaClientId)
                                                     && strategyStaffs.IsDeleted.Equals(false)
                                                     && sagittaStaffIds.Contains(strategyStaffs.SagittaStaffId)
                                                     && favouriteStrategies.IsDeleted.Equals(false) && favouriteStrategies.SecurityUserId.Equals(securityUserId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }
                    //ELSE JUST CHECK STRATEGY CREATED BY SECURITY USER
                    else
                    {
                        matchedStrategyIds = (from strategy in _context.Strategies
                                              join strategyClients in _context.StrategyClients on strategy.StrategyId equals strategyClients.StrategyId
                                              join favouriteStrategies in _context.FavouriteStrategies on strategy.StrategyId equals favouriteStrategies.StrategyId
                                              where (
                                                    strategy.IsDeleted.Equals(false)
                                                     && strategyStatusCodes.Contains(strategy.StatusCodeId)
                                                     && strategyClients.IsDeleted.Equals(false)
                                                     && strategyClients.SagittaClientId.Equals(sagittaClientId)
                                                     && (strategy.CreatedBy != null && strategy.CreatedBy.Equals(securityUserId))
                                                     && favouriteStrategies.IsDeleted.Equals(false) && favouriteStrategies.SecurityUserId.Equals(securityUserId)
                                                     )
                                              select (strategy.StrategyId)).ToList();
                    }

                    break;
            }

            return matchedStrategyIds;
        }        
        #endregion


    }
}
