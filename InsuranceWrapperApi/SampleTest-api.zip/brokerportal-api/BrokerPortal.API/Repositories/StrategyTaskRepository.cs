﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;





namespace BrokerPortal.API.Repositories
{
    public class StrategyTaskRepository : IStrategyTaskRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public StrategyTaskRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<List<StrategyTaskMeta?>> GetStrategyTaskByStrategyId(Guid? strategyId)
        {
            List<StrategyTaskMeta> strategyTasks = null;
            try
            {
                strategyTasks = await _context.StrategyTaskMeta.Where(st => st.StrategyId == strategyId).ToListAsync();
            }
            catch (Exception ex)
            {

            }

            return strategyTasks;

        }

        public async Task<StrategyTaskMeta> GetStrategyTimelineByTimelineId(Guid? strategyTimelineId)
        {
            StrategyTaskMeta strategyTask = null;
            try
            {
                strategyTask = _context.StrategyTaskMeta.Where(st => st.StrategyTimelineId == strategyTimelineId).SingleOrDefault();
            }
            catch (Exception ex)
            {

            }
            return strategyTask;

        }



    }
}
