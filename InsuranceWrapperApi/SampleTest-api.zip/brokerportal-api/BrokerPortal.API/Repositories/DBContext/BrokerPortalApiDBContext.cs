﻿using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.Repositories.DBContext;

public partial class BrokerPortalApiDBContext : DbContext
{
    public BrokerPortalApiDBContext()
    {
    }

    public BrokerPortalApiDBContext(DbContextOptions<BrokerPortalApiDBContext> options)
        : base(options)
    {
    }

    public override void Dispose()
    {
        base.Dispose();
    }

    //THIS IS CUSTOM ENTITY (DOES NOT EXIST IN DB) DO NOT REMOVE THIS
    public virtual DbSet<StepTimelineStaffAssignment> StrategyStaffAssignments { get; set; }


    public virtual DbSet<AuditLog> AuditLogs { get; set; }

    public virtual DbSet<BpstatusCode> BpstatusCodes { get; set; }

    public virtual DbSet<FavouriteClient> FavouriteClients { get; set; }

    public virtual DbSet<FavouriteStrategy> FavouriteStrategies { get; set; }

    public virtual DbSet<FlowDef> FlowDefs { get; set; }

    public virtual DbSet<GenericTask> GenericTasks { get; set; }

    public virtual DbSet<GenericTaskMeta> GenericTaskMeta { get; set; }

    public virtual DbSet<Market> Markets { get; set; }

    public virtual DbSet<MarketAddlCov> MarketAddlCovs { get; set; }

    public virtual DbSet<MarketAddlCovHistory> MarketAddlCovHistories { get; set; }

    public virtual DbSet<MarketTaskMeta> MarketTaskMeta { get; set; }

    public virtual DbSet<MarketTimeline> MarketTimelines { get; set; }

    public virtual DbSet<MarketTimelinesHistory> MarketTimelinesHistories { get; set; }

    public virtual DbSet<MarketsHistory> MarketsHistories { get; set; }

    public virtual DbSet<Plan> Plans { get; set; }

    public virtual DbSet<PlanClient> PlanClients { get; set; }

    public virtual DbSet<PlanClientAddlInfo> PlanClientAddlInfos { get; set; }

    public virtual DbSet<PlanTimeline> PlanTimelines { get; set; }

    public virtual DbSet<SagittaClient> SagittaClients { get; set; }

    public virtual DbSet<SagittaPayee> SagittaPayees { get; set; }

    public virtual DbSet<SagittaPolicy> SagittaPolicies { get; set; }

    public virtual DbSet<SagittaStaff> SagittaStaffs { get; set; }

    public virtual DbSet<SecurityTrace> SecurityTraces { get; set; }

    public virtual DbSet<SecurityTraceDetail> SecurityTraceDetails { get; set; }

    public virtual DbSet<SecurityUser> SecurityUsers { get; set; }

    public virtual DbSet<SecurityUserMapExternalSystem> SecurityUserMapExternalSystems { get; set; }

    public virtual DbSet<SecurityUserProfile> SecurityUserProfiles { get; set; }

    public virtual DbSet<StepDef> StepDefs { get; set; }

    public virtual DbSet<Strategy> Strategies { get; set; }

    public virtual DbSet<StrategyClient> StrategyClients { get; set; }

    public virtual DbSet<StrategyClientAddlInfo> StrategyClientAddlInfos { get; set; }

    public virtual DbSet<StrategyStaff> StrategyStaffs { get; set; }

    public virtual DbSet<StrategyTaskMeta> StrategyTaskMeta { get; set; }

    public virtual DbSet<StrategyTimeline> StrategyTimelines { get; set; }

    public virtual DbSet<SubStepDef> SubStepDefs { get; set; }

    public virtual DbSet<TaskActivity> TaskActivities { get; set; }

    public virtual DbSet<TaskAssignment> TaskAssignments { get; set; }

    public virtual DbSet<TaskMeta> TaskMeta { get; set; }

    public virtual DbSet<TaskStack> TaskStacks { get; set; }

    public virtual DbSet<TaskStatusCode> TaskStatusCodes { get; set; }

    public virtual DbSet<TaskStep> TaskSteps { get; set; }

    public virtual DbSet<Underwriter> Underwriters { get; set; }

    public virtual DbSet<UnderwriterChange> UnderwriterChanges { get; set; }

    public virtual DbSet<UnderwriterChangesReason> UnderwriterChangesReasons { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //THIS IS CUSTOM ENTITY (DOES NOT EXIST IN DB) DO NOT REMOVE THIS
        modelBuilder.Entity<StepTimelineStaffAssignment>(entity =>
        {
            entity.Property(e => e.TaskAssignmentId).ValueGeneratedNever();
        });



        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_dbo.AuditLog");
        });

        modelBuilder.Entity<FavouriteClient>(entity =>
        {
            entity.Property(e => e.FavouriteClientId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.FavouriteClientCreatedByNavigations).HasConstraintName("FK_FavClient_CreatedBy_SecurityUser_SecurityUserId");

            entity.HasOne(d => d.SagittaClient).WithMany(p => p.FavouriteClients).HasConstraintName("FK_FavClient_SagittaClientId_SagittaClients_SagittaClientId");

            entity.HasOne(d => d.SecurityUser).WithMany(p => p.FavouriteClientSecurityUsers)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FavClient_SecurityUserId_SecurityUser_SecurityUserId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.FavouriteClientUpdatedByNavigations).HasConstraintName("FK_FavClient_UpdatedBy_SecurityUser_SecurityUserId");
        });

        modelBuilder.Entity<FavouriteStrategy>(entity =>
        {
            entity.Property(e => e.FavouriteStrategyId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.FavouriteStrategyCreatedByNavigations).HasConstraintName("FK_FavStrat_CreatedBy_SecurityUser_SecurityUserId");

            entity.HasOne(d => d.SecurityUser).WithMany(p => p.FavouriteStrategySecurityUsers)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FavStrat_SecurityUserId_SecurityUser_SecurityUserId");

            entity.HasOne(d => d.Strategy).WithMany(p => p.FavouriteStrategies).HasConstraintName("FK_FavStrat_StrategyId_Strategies_StrategyId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.FavouriteStrategyUpdatedByNavigations).HasConstraintName("FK_FavStrat_UpdatedBy_SecurityUser_SecurityUserId");
        });

        modelBuilder.Entity<GenericTask>(entity =>
        {
            entity.Property(e => e.GenericTaskId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.GenericTaskCreatedByNavigations).HasConstraintName("FK_SecurityUser_GenericTask_CreatedBy");

            entity.HasOne(d => d.RequestedByUser).WithMany(p => p.GenericTaskRequestedByUsers).HasConstraintName("FK_SecurityUser_GenericTask_RequestedByUserId");

            entity.HasOne(d => d.TaskStack).WithMany(p => p.GenericTasks).HasConstraintName("FK_TaskStacks_GenericTask_TaskStackId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.GenericTaskUpdatedByNavigations).HasConstraintName("FK_SecurityUser_GenericTask_UpdatedBy");
        });

        modelBuilder.Entity<GenericTaskMeta>(entity =>
        {
            entity.Property(e => e.GenericTaskMetaId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.GenericTaskMetumCreatedByNavigations).HasConstraintName("FK_SecurityUser_GenericTaskMeta_CreatedBy");

            entity.HasOne(d => d.GenericTask).WithMany(p => p.GenericTaskMeta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_GenericTask_GenericTaskMeta_GenericTaskId");

            entity.HasOne(d => d.Market).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_Markets_GenericTaskMeta_MarketId");

            entity.HasOne(d => d.Plan).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_Plans_GenericTaskMeta_PlanId");

            entity.HasOne(d => d.SagittaClient).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_SagittaClients_GenericTaskMeta_SagittaClientId");

            entity.HasOne(d => d.SagittaPolicy).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_SagittaPolicies_GenericTaskMeta_SagittaPolicyId");

            entity.HasOne(d => d.Strategy).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_Strategies_GenericTaskMeta_StrategyId");

            entity.HasOne(d => d.StrategyTimeline).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_StrategyTimelines_GenericTaskMeta_StrategyTimelineId");

            entity.HasOne(d => d.Underwriter).WithMany(p => p.GenericTaskMeta).HasConstraintName("FK_Underwriters_GenericTaskMeta_UnderwriterId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.GenericTaskMetumUpdatedByNavigations).HasConstraintName("FK_SecurityUser_GenericTaskMeta_UpdatedBy");
        });

        modelBuilder.Entity<Market>(entity =>
        {
            entity.Property(e => e.MarketId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.MarketCreatedByNavigations).HasConstraintName("FK_SecurityUser_Markets_CreatedBy");

            entity.HasOne(d => d.PrevStatusCode).WithMany(p => p.MarketPrevStatusCodes).HasConstraintName("FK_BPStatusCodes_Markets_PrevStatusCodeId");

            entity.HasOne(d => d.PrevStepDef).WithMany(p => p.MarketPrevStepDefs).HasConstraintName("FK_StepDef_Markets_PrevStepDefId");

            entity.HasOne(d => d.PrevSubStepDef).WithMany(p => p.MarketPrevSubStepDefs).HasConstraintName("FK_SubStepDef_Markets_PrevSubStepDefId");

            entity.HasOne(d => d.SagittaPayee).WithMany(p => p.Markets).HasConstraintName("FK_SagittaPayees_Markets_SagittaPayeeId");

            entity.HasOne(d => d.SagittaPolicy).WithMany(p => p.Markets).HasConstraintName("FK_SagittaPolicies_Markets_SagittaPolicyId");

            entity.HasOne(d => d.StatusCode).WithMany(p => p.MarketStatusCodes).HasConstraintName("FK_BPStatusCodes_Markets_StatusCodeId");

            entity.HasOne(d => d.StepDef).WithMany(p => p.MarketStepDefs).HasConstraintName("FK_StepDef_Markets_StepDefId");

            entity.HasOne(d => d.Strategy).WithMany(p => p.Markets)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Strategies_Markets_StrategyId");

            entity.HasOne(d => d.SubStepDef).WithMany(p => p.MarketSubStepDefs).HasConstraintName("FK_SubStepDef_Markets_SubStepDefId");

            entity.HasOne(d => d.Underwriter).WithMany(p => p.Markets).HasConstraintName("FK_Underwriters_Markets_UnderwriterId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.MarketUpdatedByNavigations).HasConstraintName("FK_SecurityUser_Markets_UpdatedBy");
        });

        modelBuilder.Entity<MarketAddlCov>(entity =>
        {
            entity.Property(e => e.MarketAddlCovId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.MarketAddlCovCreatedByNavigations).HasConstraintName("FK_SecurityUser_MarketAddlCov_CreatedBy");

            entity.HasOne(d => d.Market).WithMany(p => p.MarketAddlCovs)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Markets_MarketAddlCov_MarketId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.MarketAddlCovUpdatedByNavigations).HasConstraintName("FK_SecurityUser_MarketAddlCov_UpdatedBy");
        });

        modelBuilder.Entity<MarketAddlCovHistory>(entity =>
        {
            entity.Property(e => e.MarketAddlCovHistoryId).ValueGeneratedNever();

            entity.HasOne(d => d.MarketHistory).WithMany(p => p.MarketAddlCovHistories)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MarketsHistory_MarketAddlCovHistory_MarketHistoryId");
        });

        modelBuilder.Entity<MarketTaskMeta>(entity =>
        {
            entity.HasKey(e => e.MarketTaskId).HasName("PK_MarketTask");

            entity.Property(e => e.MarketTaskId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.MarketTaskMetumCreatedByNavigations).HasConstraintName("FK_SecurityUser_MarketTask_CreatedBy");

            entity.HasOne(d => d.Market).WithMany(p => p.MarketTaskMeta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Markets_MarketTask_MarketId");

            entity.HasOne(d => d.TaskStack).WithMany(p => p.MarketTaskMeta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskStacks_MarketTask_TaskStackId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.MarketTaskMetumUpdatedByNavigations).HasConstraintName("FK_SecurityUser_MarketTask_UpdatedBy");
        });

        modelBuilder.Entity<MarketTimeline>(entity =>
        {
            entity.Property(e => e.MarketTimelineId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.MarketTimelineCreatedByNavigations).HasConstraintName("FK__MarketTim__Creat__6FD49106");

            entity.HasOne(d => d.LastStepStatusUpdatedByNavigation).WithMany(p => p.MarketTimelineLastStepStatusUpdatedByNavigations).HasConstraintName("FK_SecurityUser_MarketTimelines_LastStepStatusUpdatedBy");

            entity.HasOne(d => d.Market).WithMany(p => p.MarketTimelines)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Markets_MarketTimelines");

            entity.HasOne(d => d.PrevStatusCode).WithMany(p => p.MarketTimelinePrevStatusCodes).HasConstraintName("FK_BPStatusCodes_MarketTimelines_PrevStatusCodeId");

            entity.HasOne(d => d.StatusCode).WithMany(p => p.MarketTimelineStatusCodes).HasConstraintName("FK_BPStatusCodes_MarketTimelines");

            entity.HasOne(d => d.StepDef).WithMany(p => p.MarketTimelines)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_StepDef_MarketTimelines");

            entity.HasOne(d => d.Strategy).WithMany(p => p.MarketTimelines)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Strategies_MarketTimelines");

            entity.HasOne(d => d.StrategyTimeline).WithMany(p => p.MarketTimelines).HasConstraintName("FK_StrategyTimelines_MarketTimelines_StrategyTimelineId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.MarketTimelineUpdatedByNavigations).HasConstraintName("FK__MarketTim__Updat__70C8B53F");
        });

        modelBuilder.Entity<MarketTimelinesHistory>(entity =>
        {
            entity.Property(e => e.MarketTimelineHistoryId).ValueGeneratedNever();

            entity.HasOne(d => d.MarketHistory).WithMany(p => p.MarketTimelinesHistories)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MarketsHistory_MarketTimelinesHistory");
        });

        modelBuilder.Entity<MarketsHistory>(entity =>
        {
            entity.Property(e => e.MarketHistoryId).ValueGeneratedNever();
        });

        modelBuilder.Entity<Plan>(entity =>
        {
            entity.Property(e => e.PlanId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.PlanCreatedByNavigations).HasConstraintName("FK__Plans__CreatedBy__725BF7F6");

            entity.HasOne(d => d.PrevStatusCode).WithMany(p => p.PlanPrevStatusCodes).HasConstraintName("FK_BPStatusCodes_Plans_PrevStatusCodeId");

            entity.HasOne(d => d.StatusCode).WithMany(p => p.PlanStatusCodes)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_StatusCode_Plans");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.PlanUpdatedByNavigations).HasConstraintName("FK__Plans__UpdatedBy__00AA174D");
        });

        modelBuilder.Entity<PlanClient>(entity =>
        {
            entity.Property(e => e.PlanClientId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.PlanClientCreatedByNavigations).HasConstraintName("FK__PlanClien__Creat__02925FBF");

            entity.HasOne(d => d.Plan).WithMany(p => p.PlanClients)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PlanClien__PlanI__1C5231C2");

            entity.HasOne(d => d.SagittaClient).WithMany(p => p.PlanClients)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SagittaClient_PlanClients");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.PlanClientUpdatedByNavigations).HasConstraintName("FK__PlanClien__Updat__019E3B86");
        });

        modelBuilder.Entity<PlanClientAddlInfo>(entity =>
        {
            entity.HasKey(e => e.PlanClientAddlInfoId).HasName("PK__PlanClie__D9378DA5EC594D10");

            entity.Property(e => e.PlanClientAddlInfoId).ValueGeneratedNever();

            entity.HasOne(d => d.PlanClient).WithMany(p => p.PlanClientAddlInfos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PlanClient_PlanClientAddlInfo");
        });

        modelBuilder.Entity<PlanTimeline>(entity =>
        {
            entity.Property(e => e.PlanTimelineId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.PlanTimelineCreatedByNavigations).HasConstraintName("FK__PlanTimel__Creat__14B10FFA");

            entity.HasOne(d => d.Plan).WithMany(p => p.PlanTimelines)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("PlanId");

            entity.HasOne(d => d.StepDef).WithMany(p => p.PlanTimelines).HasConstraintName("FK__PlanTimel__StepD__6F7F8B4B");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.PlanTimelineUpdatedByNavigations).HasConstraintName("FK__PlanTimel__Updat__15A53433");
        });

        modelBuilder.Entity<SagittaClient>(entity =>
        {
            entity.HasKey(e => e.SagittaClientId).HasName("PK__SagittaC__7E76BB73D0426A68");

            entity.Property(e => e.SagittaClientId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.SagittaClientCreatedByNavigations).HasConstraintName("FK__SagittaCl__Creat__047AA831");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.SagittaClientUpdatedByNavigations).HasConstraintName("FK__SagittaCl__Updat__038683F8");
        });

        modelBuilder.Entity<SagittaPolicy>(entity =>
        {
            entity.HasKey(e => e.SagittaPolicyId).HasName("PK_SagittaPolicies_SagittaPolicyId");

            entity.Property(e => e.SagittaPolicyId).ValueGeneratedNever();

            entity.HasOne(d => d.SagittaClient).WithMany(p => p.SagittaPolicies)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SagittaClients_SagittaPolicies_SagittaClientId");
        });

        modelBuilder.Entity<SagittaStaff>(entity =>
        {
            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.SagittaStaffCreatedByNavigations).HasConstraintName("FK__SagittaSt__Creat__26CFC035");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.SagittaStaffUpdatedByNavigations).HasConstraintName("FK__SagittaSt__Updat__25DB9BFC");
        });

        modelBuilder.Entity<SecurityTrace>(entity =>
        {
            entity.HasKey(e => e.SecurityTraceId).HasName("PK__Security__9257B5E158160859");

            entity.Property(e => e.SecurityTraceId).ValueGeneratedNever();

            entity.HasOne(d => d.SecurityUser).WithMany(p => p.SecurityTraces)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SecurityUser_SecurityTrace");
        });

        modelBuilder.Entity<SecurityTraceDetail>(entity =>
        {
            entity.HasKey(e => e.SecurityTraceDetailId).HasName("PK__Security__1DDCB9F00171A201");

            entity.Property(e => e.SecurityTraceDetailId).ValueGeneratedNever();

            entity.HasOne(d => d.SecurityTrace).WithMany(p => p.SecurityTraceDetails)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SecurityTraceDetails_SecurityTrace");
        });

        modelBuilder.Entity<SecurityUser>(entity =>
        {
            entity.HasKey(e => e.SecurityUserId).HasName("PK__Security__AF007F4A33F23418");
        });

        modelBuilder.Entity<SecurityUserMapExternalSystem>(entity =>
        {
            entity.Property(e => e.MapExternalSystemId).ValueGeneratedNever();

            entity.HasOne(d => d.SecurityUser).WithMany(p => p.SecurityUserMapExternalSystems)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SecurityUser_SecurityUserMapExternalSystem_SecurityUserId");
        });

        modelBuilder.Entity<SecurityUserProfile>(entity =>
        {
            entity.Property(e => e.SecurityUserProfileId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.SecurityUserProfileCreatedByNavigations).HasConstraintName("FK_SecurityUser_SecurityUserProfiles_CreatedBy");

            entity.HasOne(d => d.SecurityUser).WithMany(p => p.SecurityUserProfileSecurityUsers)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SecurityUser_SecurityUserProfiles_SecurityUserId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.SecurityUserProfileUpdatedByNavigations).HasConstraintName("FK_SecurityUser_SecurityUserProfiles_UpdatedBy");
        });

        modelBuilder.Entity<StepDef>(entity =>
        {
            entity.HasOne(d => d.FlowDef).WithMany(p => p.StepDefs)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FlowDef_StepDef");
        });

        modelBuilder.Entity<Strategy>(entity =>
        {
            entity.Property(e => e.StrategyId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.StrategyCreatedByNavigations).HasConstraintName("FK__Strategie__Creat__093F5D4E");

            entity.HasOne(d => d.Plan).WithMany(p => p.Strategies)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Strategie__PlanI__075714DC");

            entity.HasOne(d => d.PrevStatusCode).WithMany(p => p.StrategyPrevStatusCodes).HasConstraintName("FK_BPStatusCodes_Strategies_PrevStatusCodeId");

            entity.HasOne(d => d.StatusCode).WithMany(p => p.StrategyStatusCodes)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_StatusCode_Strategies");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.StrategyUpdatedByNavigations).HasConstraintName("FK__Strategie__Updat__0A338187");
        });

        modelBuilder.Entity<StrategyClient>(entity =>
        {
            entity.Property(e => e.StratgeyClientId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.StrategyClientCreatedByNavigations).HasConstraintName("FK__StrategyC__Creat__0B27A5C0");

            entity.HasOne(d => d.SagittaClient).WithMany(p => p.StrategyClients)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SagittaClients_StrategyClients");

            entity.HasOne(d => d.Strategy).WithMany(p => p.StrategyClients)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Strategies_StrategyClients");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.StrategyClientUpdatedByNavigations).HasConstraintName("FK__StrategyC__Updat__0C1BC9F9");
        });

        modelBuilder.Entity<StrategyClientAddlInfo>(entity =>
        {
            entity.HasKey(e => e.StrategyClientAddlInfoId).HasName("PK__Strategy__8F01B9A88D0BF5BD");

            entity.Property(e => e.StrategyClientAddlInfoId).ValueGeneratedNever();

            entity.HasOne(d => d.StratgeyClient).WithMany(p => p.StrategyClientAddlInfos)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_StrategyClients_StrategyClientAddlInfo");
        });

        modelBuilder.Entity<StrategyStaff>(entity =>
        {
            entity.HasKey(e => e.StrategyStaffId).HasName("PK__StrategyStaff");

            entity.Property(e => e.StrategyStaffId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.StrategyStaffCreatedByNavigations).HasConstraintName("FK__StrategyS__Creat__0EF836A4");

            entity.HasOne(d => d.SagittaStaff).WithMany(p => p.StrategyStaffs)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_StrategyStaffs_SagittaStaff");

            entity.HasOne(d => d.Strategy).WithMany(p => p.StrategyStaffs).HasConstraintName("FK__StrategyS__Strat__23F3538A");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.StrategyStaffUpdatedByNavigations).HasConstraintName("FK__StrategyS__Updat__0FEC5ADD");
        });

        modelBuilder.Entity<StrategyTaskMeta>(entity =>
        {
            entity.HasKey(e => e.StrategyTaskId).HasName("PK_StrategyTask");

            entity.Property(e => e.StrategyTaskId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.StrategyTaskMetumCreatedByNavigations).HasConstraintName("FK_SecurityUser_StrategyTask_CreatedBy");

            entity.HasOne(d => d.Strategy).WithMany(p => p.StrategyTaskMeta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Strategies_StrategyTask_StrategyId");

            entity.HasOne(d => d.StrategyTimeline).WithMany(p => p.StrategyTaskMeta).HasConstraintName("FK_StrategyTimelines_StrategyTask_StrategyTimelineId");

            entity.HasOne(d => d.TaskStack).WithMany(p => p.StrategyTaskMeta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskStacks_StrategyTask_TaskStackId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.StrategyTaskMetumUpdatedByNavigations).HasConstraintName("FK_SecurityUser_StrategyTask_UpdatedBy");
        });

        modelBuilder.Entity<StrategyTimeline>(entity =>
        {
            entity.Property(e => e.StrategyTimelineId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.StrategyTimelineCreatedByNavigations).HasConstraintName("FK__StrategyT__Creat__12C8C788");

            entity.HasOne(d => d.LastStepStatusUpdatedByNavigation).WithMany(p => p.StrategyTimelineLastStepStatusUpdatedByNavigations).HasConstraintName("FK_SecurityUser_StrategyTimelines_LastStepStatusUpdatedBy");

            entity.HasOne(d => d.PrevStatusCode).WithMany(p => p.StrategyTimelinePrevStatusCodes).HasConstraintName("FK_BPStatusCodes_StrategyTimelines_PrevStatusCodeId");

            entity.HasOne(d => d.StatusCode).WithMany(p => p.StrategyTimelineStatusCodes).HasConstraintName("FK_BPStatusCodes_StrategyTimelines");

            entity.HasOne(d => d.StepDef).WithMany(p => p.StrategyTimelines)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_StepDef_StrategyTimelines");

            entity.HasOne(d => d.Strategy).WithMany(p => p.StrategyTimelines)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Strategies_StrategyTimelines");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.StrategyTimelineUpdatedByNavigations).HasConstraintName("FK__StrategyT__Updat__13BCEBC1");
        });

        modelBuilder.Entity<SubStepDef>(entity =>
        {
            entity.HasKey(e => e.SubStepDefId).HasName("PK_SubStepDef_New");
        });

        modelBuilder.Entity<TaskActivity>(entity =>
        {
            entity.Property(e => e.TaskActivityId).ValueGeneratedNever();

            entity.HasOne(d => d.ParentTaskStack).WithMany(p => p.TaskActivityParentTaskStacks).HasConstraintName("FK_TaskStacks_TaskActivity_ParentTaskStackId");

            entity.HasOne(d => d.StepDef).WithMany(p => p.TaskActivities).HasConstraintName("FK_StepDef_TaskActivity_StepDefId");

            entity.HasOne(d => d.SubStepDef).WithMany(p => p.TaskActivities).HasConstraintName("FK_SubStepDef_TaskActivity_SubStepDefId");

            entity.HasOne(d => d.TaskAssignment).WithMany(p => p.TaskActivities)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskAssignment_TaskActivity_TaskAssignmentId");

            entity.HasOne(d => d.TaskSenderNavigation).WithMany(p => p.TaskActivities).HasConstraintName("FK_SecurityUser_TaskActivity_TaskSender");

            entity.HasOne(d => d.TaskStack).WithMany(p => p.TaskActivityTaskStacks)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskStacks_TaskActivity_TaskStackId");

            entity.HasOne(d => d.TaskStatusCode).WithMany(p => p.TaskActivities).HasConstraintName("FK_TaskStatusCodes_TaskActivity_TaskStatusCodeId");

            entity.HasOne(d => d.TaskStep).WithMany(p => p.TaskActivities).HasConstraintName("FK_TaskSteps_TaskActivity_TaskStepId");
        });

        modelBuilder.Entity<TaskAssignment>(entity =>
        {
            entity.Property(e => e.TaskAssignmentId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TaskAssignmentCreatedByNavigations).HasConstraintName("FK_SecurityUser_TaskAssignment_CreatedBy");

            entity.HasOne(d => d.TaskStep).WithMany(p => p.TaskAssignments).HasConstraintName("FK_TaskSteps_TaskAssignment_TaskStepId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.TaskAssignmentUpdatedByNavigations).HasConstraintName("FK_SecurityUser_TaskAssignment_UpdatedBy");
        });

        modelBuilder.Entity<TaskMeta>(entity =>
        {
            entity.Property(e => e.TaskMetaId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TaskMetumCreatedByNavigations).HasConstraintName("FK_SecurityUser_TaskMeta_CreatedBy");

            entity.HasOne(d => d.GenericTask).WithMany(p => p.TaskMeta).HasConstraintName("FK_GenericTask_TaskMeta_GenericTaskId");

            entity.HasOne(d => d.Market).WithMany(p => p.TaskMeta).HasConstraintName("FK_Markets_TaskMeta_MarketId");

            entity.HasOne(d => d.Plan).WithMany(p => p.TaskMeta).HasConstraintName("FK_Plans_TaskMeta_PlanId");

            entity.HasOne(d => d.SagittaClient).WithMany(p => p.TaskMeta).HasConstraintName("FK_SagittaClients_TaskMeta_SagittaClientId");

            entity.HasOne(d => d.SagittaPolicy).WithMany(p => p.TaskMeta).HasConstraintName("FK_SagittaPolicies_TaskMeta_SagittaPolicyId");

            entity.HasOne(d => d.Strategy).WithMany(p => p.TaskMeta).HasConstraintName("FK_Strategies_TaskMeta_StrategyId");

            entity.HasOne(d => d.StrategyTimeline).WithMany(p => p.TaskMeta).HasConstraintName("FK_StrategyTimelines_TaskMeta_StrategyTimelineId");

            entity.HasOne(d => d.TaskStack).WithMany(p => p.TaskMeta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskStacks_TaskMeta_TaskStackId");

            entity.HasOne(d => d.Underwriter).WithMany(p => p.TaskMeta).HasConstraintName("FK_Underwriters_TaskMeta_UnderwriterId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.TaskMetumUpdatedByNavigations).HasConstraintName("FK_SecurityUser_TaskMeta_UpdatedBy");
        });

        modelBuilder.Entity<TaskStack>(entity =>
        {
            entity.Property(e => e.TaskStackId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TaskStackCreatedByNavigations).HasConstraintName("FK_SecurityUser_TaskStacks_CreatedBy");

            entity.HasOne(d => d.LastTaskStatusUpdatedByNavigation).WithMany(p => p.TaskStackLastTaskStatusUpdatedByNavigations).HasConstraintName("FK_SecurityUser_TaskStacks_LastTaskStatusUpdatedBy");

            entity.HasOne(d => d.PrevTaskStatusCode).WithMany(p => p.TaskStackPrevTaskStatusCodes).HasConstraintName("FK_TaskStatusCodes_TaskStacks_PrevTaskStatusCodeId");

            entity.HasOne(d => d.TaskSenderNavigation).WithMany(p => p.TaskStackTaskSenderNavigations).HasConstraintName("FK_SecurityUser_TaskStacks_TaskSender");

            entity.HasOne(d => d.TaskStatusCode).WithMany(p => p.TaskStackTaskStatusCodes).HasConstraintName("FK_TaskStatusCodes_TaskStacks_TaskStatusCodeId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.TaskStackUpdatedByNavigations).HasConstraintName("FK_SecurityUser_TaskStacks_UpdatedBy");
        });

        modelBuilder.Entity<TaskStatusCode>(entity =>
        {
            entity.HasKey(e => e.TaskStatusCodeId).HasName("PK__TaskStat__E1C886D12C0D4BDA");
        });

        modelBuilder.Entity<TaskStep>(entity =>
        {
            entity.Property(e => e.TaskStepId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TaskStepCreatedByNavigations).HasConstraintName("FK_SecurityUser_TaskSteps_CreatedBy");

            entity.HasOne(d => d.LastStepStatusUpdatedByNavigation).WithMany(p => p.TaskStepLastStepStatusUpdatedByNavigations).HasConstraintName("FK_SecurityUser_TaskSteps_LastStepStatusUpdatedBy");

            entity.HasOne(d => d.StatusCode).WithMany(p => p.TaskSteps).HasConstraintName("FK_BPStatusCodes_TaskSteps_StatusCodeId");

            entity.HasOne(d => d.StepDef).WithMany(p => p.TaskSteps).HasConstraintName("FK_StepDef_TaskSteps_StepDefId");

            entity.HasOne(d => d.SubStepDef).WithMany(p => p.TaskSteps).HasConstraintName("FK_SubStepDef_TaskSteps_SubStepDefId");

            entity.HasOne(d => d.TaskStack).WithMany(p => p.TaskSteps)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TaskStacks_TaskSteps_TaskStackId");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.TaskStepUpdatedByNavigations).HasConstraintName("FK_SecurityUser_TaskSteps_UpdatedBy");
        });

        modelBuilder.Entity<Underwriter>(entity =>
        {
            entity.Property(e => e.UnderwriterId).ValueGeneratedNever();

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.UnderwriterCreatedByNavigations).HasConstraintName("FK__Underwrit__Creat__1A69E950");

            entity.HasOne(d => d.SagittaPayee).WithMany(p => p.Underwriters)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_SagittaPayees");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.UnderwriterUpdatedByNavigations).HasConstraintName("FK__Underwrit__Updat__1B5E0D89");
        });

        modelBuilder.Entity<UnderwriterChange>(entity =>
        {
            entity.Property(e => e.UnderwriterChangeId).ValueGeneratedNever();
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
