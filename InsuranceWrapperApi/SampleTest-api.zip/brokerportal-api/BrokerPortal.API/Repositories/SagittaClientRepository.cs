﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.Repositories
{
    public class SagittaClientRepository : ISagittaClientRepository
    {
        private readonly BrokerPortalApiDBContext _context;

        public SagittaClientRepository(BrokerPortalApiDBContext context)
        {
            _context = context;
        }

        public async Task<bool> IsSagittaClientExists(long? sagittaClientId)
        {
            bool isExist = _context.SagittaClients.Any(x => x.SagittaClientId == sagittaClientId);
            return isExist;
        }

        public async Task<SagittaClient> UpdateSagittaClient(SagittaClient sagittaClient)
        {
            _context.SagittaClients.Update(sagittaClient);
            await _context.SaveChangesAsync();

            return sagittaClient;
        }
        public async Task<SagittaClient> AddSagittaClient(SagittaClient sagittaClient)
        {
                _context.SagittaClients.Add(sagittaClient);
                await _context.SaveChangesAsync();
            return sagittaClient;
        }

        public async Task<SagittaClient> GetSagittaClient(string sagittaClientId)
        {
            SagittaClient? sagittaClient = new SagittaClient();
            long clientId = Convert.ToInt64(sagittaClientId);
            sagittaClient = _context.SagittaClients
               .SingleOrDefault(client => client.SagittaClientId == clientId && (client.IsDeleted ==null || client.IsDeleted == false));

            return sagittaClient;
        }
    }
}