﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.Utilities;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.Repositories;

public class PlanRepository : IPlanRepository
{
    private readonly BrokerPortalApiDBContext _context;

    public PlanRepository(BrokerPortalApiDBContext context)
    {
        _context = context;
    }

    public async Task<List<Plan>> GetAllPlans()
    {
        var planList = await _context.Plans.AsNoTracking().Where(plan => plan.IsDeleted == false)
                       .Include(plan => plan.PlanClients)
                       .ThenInclude(sagitta => sagitta.SagittaClient)
                       .Include(plan => plan.PlanTimelines)
                       .ToListAsync();
        return planList;
    }

    public async Task<Plan> GetPlanById(Guid planId)
    {
        Plan? plan = await _context.Plans.AsNoTracking()
               .Include(plan => plan.PlanClients)
               .ThenInclude(sagitta => sagitta.SagittaClient)
                .Include(plan => plan.PlanTimelines)
               .SingleOrDefaultAsync(plan => plan.PlanId == planId && plan.IsDeleted == false);
        return plan;
    }

    public async Task<Plan> FetchForUpdatePlanAndStrategiesByPlan(Guid planId)
    {
        Plan? plan = await _context.Plans
                            .Include(plan => plan.PlanClients)
                            .ThenInclude(planClients => planClients.SagittaClient)
                            .Include(plan => plan.PlanTimelines.Where(x => x.IsDeleted.Equals(false)))
                            .Include(plan => plan.Strategies.Where(x => x.IsDeleted.Equals(false)))
                            .ThenInclude(strategies => strategies.StrategyClients.Where(x => x.IsDeleted.Equals(false)))
                            .Include(plan => plan.Strategies.Where(x => x.IsDeleted.Equals(false)))
                            .ThenInclude(strategies => strategies.StrategyTimelines.Where(x => x.IsDeleted.Equals(false)))
                            .SingleOrDefaultAsync(plan => plan.PlanId == planId
                                                            && plan.IsDeleted.Equals(false)
                                                            && plan.PlanClients.Any(x => x.IsDeleted.Equals(false)));
        return plan;
    }

    public async Task<Plan> SavePlan(Plan plan)
    {
        await _context.Plans.AddAsync(plan);
        foreach (var planClient in plan.PlanClients)
        {
            if (_context.SagittaClients.Any(c => c.SagittaClientId == planClient.SagittaClientId))
            {
                _context.SagittaClients.Update(planClient.SagittaClient);
            }
            else
            {
                _context.SagittaClients.Add(planClient.SagittaClient);
            }
        }
        await _context.SaveChangesAsync();
        return plan;
    }


    public async Task<Plan> UpdatePlan(Plan existingPlan)
    {
        var planClientList = existingPlan.PlanClients;

        _context.Plans.Update(existingPlan);
        _context.PlanClients.UpdateRange(existingPlan.PlanClients);
        _context.PlanTimelines.UpdateRange(existingPlan.PlanTimelines);
        foreach (var planClient in planClientList)
        {
            if (_context.SagittaClients.Any(c => c.SagittaClientId == planClient.SagittaClientId))
            {
                _context.SagittaClients.Update(planClient.SagittaClient);
            }
            else
            {
                _context.SagittaClients.Add(planClient.SagittaClient);
            }
        }
        await _context.SaveChangesAsync();
        return existingPlan;
    }
    public async Task<bool> RemovePlan(Guid planId, string securityUserId)
    {
        await _context.PlanTimelines.Where(x => x.PlanId == planId)
                        .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));
        
        await _context.PlanClients.Where(x => x.PlanId == planId)
                        .ExecuteUpdateAsync(update => update.SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));
        
        await _context.Plans.Where(x => x.PlanId == planId)
                        .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.REMO))
                                                    .SetProperty(x => x.IsDeleted, true)
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));
        return true;
    }

    public async Task<bool> ArchivePlan(Guid planId, string securityUserId)
    {
        await _context.Plans.Where(x => x.PlanId == planId)
                        .ExecuteUpdateAsync(update => update
                                                    .SetProperty(x => x.PrevStatusCodeId, x => x.StatusCodeId)
                                                    .SetProperty(x => x.StatusCodeId, nameof(GenericStatusCodes.ARCH))
                                                    .SetProperty(x => x.UpdatedBy, securityUserId).SetProperty(x => x.UpdatedDate, DateTime.Now));
        return true;
    }

    public bool? DoesValidStratgyStaffExistsOnPlan(Guid? planId)
    {
        int? count = (from plan in _context.Plans
                      join strategy in _context.Strategies on plan.PlanId equals strategy.PlanId
                      join strategyStaffs in _context.StrategyStaffs on strategy.StrategyId equals strategyStaffs.StrategyId
                      //join strategyStaffAssignment in _context.StrategyStaffAssignments on strategyStaffs.StrategyStaffId equals strategyStaffAssignment.StrategyStaffId
                      where (
                                plan.PlanId.Equals(planId)
                            && strategy.IsDeleted.Equals(false)
                            && strategyStaffs.IsDeleted.Equals(false)
                            && strategyStaffs.IsMae.Equals(true)
                             //&& strategyStaffAssignment.IsDeleted.Equals(true)
                            )
                      select plan.PlanId).Count();

        if (count != null && count > 0)
            return true;
        else
            return false;
    }
}
