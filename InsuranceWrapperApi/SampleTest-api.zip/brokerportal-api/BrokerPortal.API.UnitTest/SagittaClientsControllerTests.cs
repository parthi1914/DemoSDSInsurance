using BrokerPortal.API.Controllers;
using BrokerPortal.API.Controllers.Aggregate;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Services;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using Moq;
using System.Reflection.PortableExecutable;
using System.Security.Claims;

namespace BrokerPortal.API.UnitTest
{
    public class SagittaClientsControllerTests
    {
        private readonly Mock<ILogger<SagittaClientsController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<ISagittaClientService> _mockService;
        private readonly Mock<IFavouriteClientService> _mockFCService;
        private readonly Mock<ISagittaStaffService> _mockSagStaffService;
        private readonly SagittaClientsController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;
        private readonly Mock<IConfiguration> _configMock;

        public SagittaClientsControllerTests()
        {
            _mockLogger = new Mock<ILogger<SagittaClientsController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
            _mockService = new Mock<ISagittaClientService>();
            _mockFCService = new Mock<IFavouriteClientService>();
            _mockSagStaffService = new Mock<ISagittaStaffService>();
            _configMock = new Mock<IConfiguration>();
            _controller = new SagittaClientsController(_mockLogger.Object, _mockService.Object, _mockFCService.Object, _mockSagStaffService.Object, _configMock.Object);

        }

        [Fact]
        public async Task GetSagittaClientFromReplById_ReturnsBadRequest_WhenSagittaClientIdIsNullOrEmpty()
        {
            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetSagittaClientFromReplById(null));
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetSagittaClientFromReplById(string.Empty));
        }

        [Fact]
        public async Task GetSagittaClientFromReplById_ShouldReturnOk_WhenClientFound()
        {
            // Arrange
            var context = new DefaultHttpContext();
            context.Request.Headers["Authorization"] = "Bearer token";
            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = context
            };
            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns("user@example.com");
            _configMock.Setup(x => x.GetSection("SecurityUser")).Returns(mockConfigSection.Object);

            var response = new SagittaClientResponse { SagittaClientId="123",FavoriteClientId=Guid.NewGuid()};
            _mockService.Setup(s => s.GetSagittaClientByIdFromRepl(It.IsAny<string>(), "123"))
            .ReturnsAsync(response);

            _mockFCService.Setup(f => f.GetUserFavouriteClients("user@example.com"))
            .ReturnsAsync(new List<FavouriteClientModel> { new FavouriteClientModel { FavouriteClientId=Guid.NewGuid(),SagittaClientId="123"} });

            // Act
            var result = await _controller.GetSagittaClientFromReplById("123");

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(response, okResult.Value);
        }
       
        [Fact]
        public async Task GetSagittaClientFromReplById_ShouldReturnEmptyList_WhenSagittaClientResponseIsNull()
        {
            // Arrange
            var context = new DefaultHttpContext();
            context.Request.Headers["Authorization"] = "Bearer token";
            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = context
            };
            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns("user@example.com");
            _configMock.Setup(x => x.GetSection("SecurityUser")).Returns(mockConfigSection.Object);

            _mockService.Setup(s => s.GetSagittaClientByIdFromRepl(It.IsAny<string>(), It.IsAny<string>()))
                       .ReturnsAsync((SagittaClientResponse)null);

            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            };
            _controller.Request.Headers[HeaderNames.Authorization] = "Bearer token";

            // Act
            var result = await _controller.GetSagittaClientFromReplById("valid-id");

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<List<SagittaClientResponse>>(okResult.Value);
            Assert.Empty(response);
        }
        [Fact]
        public async Task GetSagittaClientFromReplById_Exception_WhenSagittaClientResponseIsNull()
        {
            // Arrange
            var context = new DefaultHttpContext();
            context.Request.Headers["Authorization"] = "Bearer token";
            _controller.ControllerContext = new ControllerContext()
            {
                HttpContext = context
            };
            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns("");
            _configMock.Setup(x => x.GetSection("SecurityUser")).Returns(mockConfigSection.Object);

            _mockService.Setup(s => s.GetSagittaClientByIdFromRepl(It.IsAny<string>(), It.IsAny<string>()))
                       .ReturnsAsync((SagittaClientResponse)null);

            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            };
            _controller.Request.Headers[HeaderNames.Authorization] = "Bearer token";

            // Act
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetSagittaClientFromReplById("valid-id"));
        }





        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_ReturnsClients()
        {
            // Arrange
            var request = new SagittaClientSearchRequest { searchType = "ALL" ,
                SecurityUser = new SecurityUserModel { SecurityUserId = "user1" },
                SearchCriterias = new SearchClientCriterias
                { 
                clientCode="test",
                clientName="testname"
                }


            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here",request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.SearchSagittaClientsFromRepl(request) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedResponse, result.Value);
        }

        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_Exception()
        {
            // Arrange
            var request = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                SecurityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here", request)).ReturnsAsync(expectedResponse);
            _controller.ModelState.AddModelError("search","error");

            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() =>  _controller.SearchSagittaClientsFromRepl(request));
        }
        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_SearchTypeException()
        {
            // Arrange
            var request = new SagittaClientSearchRequest
            {
                searchType = "ALLL",
                SecurityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here", request)).ReturnsAsync(expectedResponse);
            

            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchSagittaClientsFromRepl(request));
        }
        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_SearchOptionException()
        {
            // Arrange
            var request = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                searchOption="START",
                SecurityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here", request)).ReturnsAsync(expectedResponse);


            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchSagittaClientsFromRepl(request));
        }
        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_SearchConditionException()
        {
            // Arrange
            var request = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                searchOption = "STARTSWITH",
                searchCondition="AMP",
                SecurityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here", request)).ReturnsAsync(expectedResponse);


            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchSagittaClientsFromRepl(request));
        }
        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_SearchCriteriaException()
        {
            // Arrange
            var request = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                searchOption = "STARTSWITH",
                searchCondition = "ALL",
                SearchCriterias=new SearchClientCriterias { clientCode=null,clientName=null},
                SecurityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here", request)).ReturnsAsync(expectedResponse);


            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchSagittaClientsFromRepl(request));
        }
        [Fact]
        public async Task SearchSagittaClientsFromRepl_OptionAll_SearchCriteriaOptionsException()
        {
            // Arrange
            var request = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                searchOption = "STARTSWITH",
                searchCondition = "ALL",
                SearchCriterias = new SearchClientCriterias { clientCode = "test", clientName = "test",clientStatusOption="Invalid" },
                SecurityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
            };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };

            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here", request)).ReturnsAsync(expectedResponse);


            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchSagittaClientsFromRepl(request));
        }
        [Fact]
        public async Task SearchSagittaClientsFromRepl_Favourite_ReturnsFavouriteClients()
        {
            // Arrange
            var request = new SagittaClientSearchRequest { searchType = "FAVORITE", searchCondition="OR", searchOption="CONTAINS",  SecurityUser = new SecurityUserModel { SecurityUserId = "user1" },
                SearchCriterias = new SearchClientCriterias
                {
                    clientCode = "test",
                    clientName = "testname"
                }
            };
            var favClientList = new List<FavouriteClientModel> { new FavouriteClientModel { SagittaClientId="1212122"} };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse { SagittaClientId = "1212122" } };

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };



            _mockFCService.Setup(f => f.GetUserFavouriteClients("user1")).ReturnsAsync(favClientList);
            _mockService.Setup(s => s.SearchFavSagittaClientsFromRepl("your_token_here",favClientList, request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.SearchSagittaClientsFromRepl(request) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedResponse, result.Value);
        }

        [Fact]
        public async Task SearchSagittaClientsFromRepl_AssignedToMe_ReturnsAssignedClients()
        {
            // Arrange
            var request = new SagittaClientSearchRequest { searchType = "ASSIGNEDTOME", SecurityUser = new SecurityUserModel { SecurityUserId = "user1" } ,
                SearchCriterias = new SearchClientCriterias
                {
                    clientCode = "test",
                    clientName = "testname"
                }
            };
            var sagittaStaffIds = new List<string> { "staff1" };
            var expectedResponse = new List<SagittaClientResponse> { new SagittaClientResponse() };


            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };


            _mockSagStaffService.Setup(s => s.GetSagittaStaffIdsBySecurityUserId("user1")).ReturnsAsync(sagittaStaffIds);
            _mockService.Setup(s => s.SearchSagittaClientsFromRepl("your_token_here",request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.SearchSagittaClientsFromRepl(request) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedResponse, result.Value);
        }

        [Fact]
        public async Task SyncSagittaClientFromRepl_InvalidSagittaClientId_ReturnsBadRequest()
        {
            // Arrange
            string invalidSagittaClientId = null;
            var requestBodyJson = new SecurityUserModel();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SyncSagittaClientFromRepl(invalidSagittaClientId, requestBodyJson));
        }
        [Fact]
        public async Task SyncSagittaClientFromRepl_InvalidSagittaClientId_Exception()
        {
            // Arrange
            string invalidSagittaClientId = null;
            var requestBodyJson = new SecurityUserModel { SecurityUserId=null};

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SyncSagittaClientFromRepl("UserId", requestBodyJson));
        }

        [Fact]
        public async Task SyncSagittaClientFromRepl_ValidRequest_ReturnsUpdatedClient()
        {
            // Arrange
            string sagittaClientId = "validId";
            var requestBodyJson = new SecurityUserModel { SecurityUserId = "user1" };
            var sagittaClientReplResponse = new SagittaClientResponse();
            var updateResponse = new SagittaClientModel();

            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };


            _mockService.Setup(s => s.GetSagittaClientByIdFromRepl("your_token_here",sagittaClientId)).ReturnsAsync(sagittaClientReplResponse);
            _mockService.Setup(s => s.UpdateSagittaClientFromRepl("user1", "your_token_here",sagittaClientId)).ReturnsAsync(updateResponse);

            // Act
            var result = await _controller.SyncSagittaClientFromRepl(sagittaClientId, requestBodyJson) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(updateResponse, result.Value);
        }

        [Fact]
        public async Task SaveSagittaClientFromRepl_ValidInput_ReturnsOkResult()
        {
            // Arrange
            var sagittaClientId = "client123";
            var securityUserId = "user456";
            var requestBody = new SecurityUserModel { SecurityUserId = securityUserId };
            var expectedResponse = new SagittaClientModel();
            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };

            _mockService
            .Setup(s => s.SaveSagittaClientFromReplIfNotExist(securityUserId, " test-token", sagittaClientId))
            .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.SaveSagittaClientFromRepl(sagittaClientId, requestBody);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedResponse, okResult.Value);
        }
        [Fact]
        public async Task SaveSagittaClientFromRepl_Exception_ReturnsOkResult()
        {
            // Arrange
            var sagittaClientId ="";
            var securityUserId = "user456";
            var requestBody = new SecurityUserModel { SecurityUserId = securityUserId };
            var expectedResponse = new SagittaClientModel();
            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };

            _mockService
            .Setup(s => s.SaveSagittaClientFromReplIfNotExist(securityUserId, " test-token", sagittaClientId))
            .ReturnsAsync(expectedResponse);

            
            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveSagittaClientFromRepl(sagittaClientId, requestBody));
        }
        [Fact]
        public async Task SaveSagittaClientFromRepl_Exception2_ReturnsOkResult()
        {
            // Arrange
            var sagittaClientId = "1007";
            var securityUserId = "user456";
            var requestBody = new SecurityUserModel { SecurityUserId = null };
            var expectedResponse = new SagittaClientModel();
            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };

            _mockService
            .Setup(s => s.SaveSagittaClientFromReplIfNotExist(securityUserId, " test-token", sagittaClientId))
            .ReturnsAsync(expectedResponse);


            // Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveSagittaClientFromRepl(sagittaClientId, requestBody));
        }

        [Fact]
        public async Task SyncSagittaClientFromRepl_ClientNotFound_ReturnsOkWithNull()
        {
            // Arrange
            string sagittaClientId = "validId";
            var requestBodyJson = new SecurityUserModel { SecurityUserId = "user1" };
            SagittaClientResponse sagittaClientReplResponse = null;


            var headers = new HeaderDictionary
        {
            { "Authorization", new StringValues("your_token_here") }
        };
            var mockHttpContext = new Mock<HttpContext>();
            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(r => r.Headers).Returns(headers);
            mockHttpContext.Setup(c => c.Request).Returns(mockRequest.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };


            _mockService.Setup(s => s.GetSagittaClientByIdFromRepl("your_token_here", sagittaClientId)).ReturnsAsync(sagittaClientReplResponse);

            // Act
            var result = await _controller.SyncSagittaClientFromRepl(sagittaClientId, requestBodyJson) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Null(result.Value);
        }


    }
}