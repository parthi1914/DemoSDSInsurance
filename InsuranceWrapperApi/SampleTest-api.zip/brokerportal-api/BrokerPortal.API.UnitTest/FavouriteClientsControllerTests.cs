using BrokerPortal.API.Controllers;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;

namespace BrokerPortal.API.UnitTest
{
    public class FavouriteClientsControllerTests
    {

        private readonly Mock<ILogger<FavouriteClientsController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<IFavouriteClientService> _mockFService;
        private readonly FavouriteClientsController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public FavouriteClientsControllerTests()
        {
            _mockLogger = new Mock<ILogger<FavouriteClientsController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
            _mockFService = new Mock<IFavouriteClientService>();
            _controller = new FavouriteClientsController(_mockFService.Object, _mockLogger.Object);

        }

        [Fact]
        public async Task Get_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("userId", "Invalid userId");

            // Act
            var result = await _controller.Get("invalidUserId");

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<UnprocessableEntityObjectResult>(badRequestResult.Value);
        }

        [Fact]
        public async Task Get_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        {
            // Arrange
            var userId = "test@test.com";
            //var favouriteClients = new List<FavouriteClientModel>
            //{
            //new FavouriteClientModel
            //{ FavouriteClientId = Guid.NewGuid(), SecurityUserId = "test@test.com",SagittaClientId = "121212", isDeleted=false  },
            // new FavouriteClientModel
            //{ FavouriteClientId = Guid.NewGuid(), SecurityUserId = "test2@test.com",SagittaClientId = "121213",isDeleted=true   },
            //  new FavouriteClientModel
            //{ FavouriteClientId = Guid.NewGuid(), SecurityUserId = "test@test.com",SagittaClientId = "121214" ,isDeleted=false  }
            //};

            var favouriteClients = new List<FavouriteClientModel> { new FavouriteClientModel() };
            _mockFService.Setup(service => service.GetUserFavouriteClients(userId))
                        .ReturnsAsync(favouriteClients);

            // Act
            var result = await _controller.Get(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteClientModel>>(okResult.Value);
            Assert.NotEmpty(returnValue);
        }

        [Fact]
        public async Task Get_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            var userId = "test@test.com";
            _mockFService.Setup(service => service.GetUserFavouriteClients(userId))
                        .ReturnsAsync(new List<FavouriteClientModel>());

            // Act
            var result = await _controller.Get(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteClientModel>>(okResult.Value);
            Assert.Empty(returnValue);
        }

        [Fact]
        public async Task SetFavouriteClient_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("userId", "Invalid userId");
            var favoriteClientRequest = new FavouriteClientRequest();

            // Act
            var result = await _controller.SetFavouriteClient("invalidUserId", favoriteClientRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<UnprocessableEntityObjectResult>(badRequestResult.Value);
        }

        [Fact]
        public async Task SetFavouriteClient_ReturnsOk_WithMessage_WhenResultIsNull()
        {
            // Arrange
            var userId = "test@test.com";
            var favoriteClientRequest = new FavouriteClientRequest();
            _mockFService.Setup(service => service.SaveUserFavouriteClient(userId, favoriteClientRequest))
                        .ReturnsAsync((FavouriteClientModel)null);

            // Act
            var result = await _controller.SetFavouriteClient(userId, favoriteClientRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Favorite Client is not created. Check input Data .", okResult.Value);
        }

        [Fact]
        public async Task SetFavouriteClient_ReturnsOk_WithResult_WhenResultIsNotNull()
        {
            // Arrange
            var userId = "test@test.com";
            var favoriteClientRequest = new FavouriteClientRequest();
            var favoriteClientModel = new FavouriteClientModel();
            _mockFService.Setup(service => service.SaveUserFavouriteClient(userId, favoriteClientRequest))
                        .ReturnsAsync(favoriteClientModel);

            // Act
            var result = await _controller.SetFavouriteClient(userId, favoriteClientRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(favoriteClientModel, okResult.Value);
        }

        [Fact]
        public async Task RemoveFavoriteClient_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("userId", "Invalid userId");
            var favoriteClientRequest = new FavouriteClientRequest();

            // Act
            var result = await _controller.RemoveFavoriteClient("invalidUserId", Guid.NewGuid(), favoriteClientRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<UnprocessableEntityObjectResult>(badRequestResult.Value);
        }

        [Fact]
        public async Task RemoveFavoriteClient_ReturnsOk_WithResult()
        {
            // Arrange
            var userId = "test@test.com";
            var favouriteClientid = Guid.NewGuid();
            var favoriteClientRequest = new FavouriteClientRequest();
            var favoriteClientModel = new FavouriteClientModel();
            _mockFService.Setup(service => service.UpdateUserFavouriteClient(userId, favouriteClientid, favoriteClientRequest))
                        .ReturnsAsync(favoriteClientModel);

            // Act
            var result = await _controller.RemoveFavoriteClient(userId, favouriteClientid, favoriteClientRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(favoriteClientModel, okResult.Value);
        }

        [Fact]
        public async Task GetAllFavouriteClients_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        {
            // Arrange
            var favouriteClients = new List<FavouriteClientModel> { new FavouriteClientModel() };
            _mockFService.Setup(service => service.GetAllFavouriteClients())
                        .ReturnsAsync(favouriteClients);

            // Act
            var result = await _controller.GetAllFavouriteClients();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteClientModel>>(okResult.Value);
            Assert.NotEmpty(returnValue);
        }

        [Fact]
        public async Task GetAllFavouriteClients_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            _mockFService.Setup(service => service.GetAllFavouriteClients())
                        .ReturnsAsync(new List<FavouriteClientModel>());

            // Act
            var result = await _controller.GetAllFavouriteClients();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteClientModel>>(okResult.Value);
            Assert.Empty(returnValue);
        }
    }
}