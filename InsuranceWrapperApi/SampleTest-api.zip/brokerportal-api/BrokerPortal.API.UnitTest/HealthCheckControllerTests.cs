﻿using Xunit;
using Moq;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading;
using System;
using BrokerPortal.API.Controllers;
using Moq.Protected;

namespace BrokerPortal.API.UnitTest
{
    public class HealthCheckControllerTests
    {
        private readonly Mock<IConfiguration> _mockConfig;
        private readonly HealthCheckController _controller;

        public HealthCheckControllerTests()
        {
            _mockConfig = new Mock<IConfiguration>();
            _mockConfig.Setup(c => c.GetSection("AccessGuardApiURL").Value).Returns("http://fake-accessguard/");
            _mockConfig.Setup(c => c.GetSection("ManageApiURL").Value).Returns("http://fake-manage/");
            _mockConfig.Setup(c => c.GetSection("SagittaURL").Value).Returns("http://fake-sagitta/");

            _controller = new HealthCheckController(_mockConfig.Object);
        }

        [Fact]
        public async Task GetHealthCheckTemp2_ReturnsHealthy()
        {
            var result = await _controller.GetHealthCheckTemp2();
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Healthy", okResult.Value);
        }
      

    }
}