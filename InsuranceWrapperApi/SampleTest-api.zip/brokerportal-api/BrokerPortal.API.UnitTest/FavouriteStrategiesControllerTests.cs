using BrokerPortal.API.Controllers;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;

namespace BrokerPortal.API.UnitTest
{
    public class FavouriteStrategiesControllerTests
    {

        private readonly Mock<ILogger<FavouriteStrategiesController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<IFavouriteStrategyService> _mockFService;
        private readonly FavouriteStrategiesController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public FavouriteStrategiesControllerTests()
        {
            _mockLogger = new Mock<ILogger<FavouriteStrategiesController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
            _mockFService = new Mock<IFavouriteStrategyService>();
            _controller = new FavouriteStrategiesController(_mockFService.Object, _mockLogger.Object);

        }

        [Fact]
        public async Task GetAllFavoriteStrategies_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        {
            // Arrange
            var favouriteStrategies = new List<FavouriteStrategyModel> { new FavouriteStrategyModel() };
            _mockFService.Setup(service => service.GetAllFavouriteStrategies())
                        .ReturnsAsync(favouriteStrategies);

            // Act
            var result = await _controller.GetAllFavoriteStrategies();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteStrategyModel>>(okResult.Value);
            Assert.NotEmpty(returnValue);
        }

        [Fact]
        public async Task GetAllFavoriteStrategies_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            _mockFService.Setup(service => service.GetAllFavouriteStrategies())
                        .ReturnsAsync(new List<FavouriteStrategyModel>());

            // Act
            var result = await _controller.GetAllFavoriteStrategies();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteStrategyModel>>(okResult.Value);
            Assert.Empty(returnValue);
        }

        [Fact]
        public async Task GetFavouriteStrategyById_ReturnsOk_WithResult_WhenResultIsNotNull()
        {
            // Arrange
            var favouriteStrategyId = Guid.NewGuid();
            var favouriteStrategy = new FavouriteStrategyModel();
            _mockFService.Setup(service => service.GetFavouriteStrategyById(favouriteStrategyId))
                        .ReturnsAsync(favouriteStrategy);

            // Act
            var result = await _controller.GetFavouriteStrategyById(favouriteStrategyId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(favouriteStrategy, okResult.Value);
        }

        [Fact]
        public async Task GetFavouriteStrategyById_ReturnsOk_WithEmptyList_WhenResultIsNull()
        {
            // Arrange
            var favouriteStrategyId = Guid.NewGuid();
            _mockFService.Setup(service => service.GetFavouriteStrategyById(favouriteStrategyId))
                        .ReturnsAsync((FavouriteStrategyModel)null);

            // Act
            var result = await _controller.GetFavouriteStrategyById(favouriteStrategyId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteStrategyModel>>(okResult.Value);
            Assert.Empty(returnValue);
        }

        [Fact]
        public async Task GetFavouriteStrategiesByUser_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("userId", "Invalid userId");

            // Act
            var result = await _controller.GetFavouriteStrategiesByUser("invalidUserId");

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<UnprocessableEntityObjectResult>(badRequestResult.Value);
        }

        [Fact]
        public async Task GetFavouriteStrategiesByUser_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        {
            // Arrange
            var userId = "validUserId";
            var favouriteStrategies = new List<FavouriteStrategyModel> { new FavouriteStrategyModel() };
            _mockFService.Setup(service => service.GetFavouriteStrategiesByUser(userId))
                        .ReturnsAsync(favouriteStrategies);

            // Act
            var result = await _controller.GetFavouriteStrategiesByUser(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteStrategyModel>>(okResult.Value);
            Assert.NotEmpty(returnValue);
        }

        [Fact]
        public async Task GetFavouriteStrategiesByUser_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            var userId = "validUserId";
            _mockFService.Setup(service => service.GetFavouriteStrategiesByUser(userId))
                        .ReturnsAsync(new List<FavouriteStrategyModel>());

            // Act
            var result = await _controller.GetFavouriteStrategiesByUser(userId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<FavouriteStrategyModel>>(okResult.Value);
            Assert.Empty(returnValue);
        }

        [Fact]
        public async Task RemoveFavoriteStrategy_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("userId", "Invalid userId");
            var favouriteStrategyRequest = new FavouriteStrategyRequest();

            // Act
            var result = await _controller.RemoveFavoriteStrategy("invalidUserId", Guid.NewGuid(), favouriteStrategyRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<UnprocessableEntityObjectResult>(badRequestResult.Value);
        }

        [Fact]
        public async Task RemoveFavoriteStrategy_ReturnsOk_WithResult()
        {
            // Arrange
            var userId = "validUserId";
            var favouriteStrategyId = Guid.NewGuid();
            var favouriteStrategyRequest = new FavouriteStrategyRequest();
            var favouriteStrategyModel = new FavouriteStrategyModel();
            _mockFService.Setup(service => service.UpdateFavouriteStrategy(userId, favouriteStrategyId, favouriteStrategyRequest))
                        .ReturnsAsync(favouriteStrategyModel);

            // Act
            var result = await _controller.RemoveFavoriteStrategy(userId, favouriteStrategyId, favouriteStrategyRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(favouriteStrategyModel, okResult.Value);
        }


        [Fact]
        public async Task SetFavouriteStrategy_ReturnsOkResult_WithValidRequest()
        {
            // Arrange
            var userId = "testUserId";
            var favouriteStrategyRequest = new FavouriteStrategyRequest();
            var favouriteStrategyModel = new FavouriteStrategyModel();
            _mockFService.Setup(s => s.SaveFavouriteStrategy(userId, favouriteStrategyRequest)).ReturnsAsync(favouriteStrategyModel);

            // Act
            var result = await _controller.SetFavouriteStrategy(userId, favouriteStrategyRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(favouriteStrategyModel, okResult.Value);
        }

        [Fact]
        public async Task SetFavouriteStrategy_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("Error", "Invalid model state");
            var userId = "testUserId";
            var favouriteStrategyRequest = new FavouriteStrategyRequest();

            // Act
            var result = await _controller.SetFavouriteStrategy(userId, favouriteStrategyRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task SetFavouriteStrategy_ReturnsOkResult_WithNullServiceResult()
        {
            // Arrange
            var userId = "testUserId";
            var favouriteStrategyRequest = new FavouriteStrategyRequest ();
            _mockFService.Setup(s => s.SaveFavouriteStrategy(userId, favouriteStrategyRequest)).ReturnsAsync((FavouriteStrategyModel)null);

            // Act
            var result = await _controller.SetFavouriteStrategy(userId, favouriteStrategyRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Favorite Client is not created. Check input Data .", okResult.Value);
        }





    }
}