﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.Repositories.DBContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace BrokerPortal.API.UnitTest.Services
{
    public class FavouriteClientServiceTests
    {
        private readonly Mock<IFavouriteClientRepository> _repositoryMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly FavouriteClientService _service;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public FavouriteClientServiceTests()
        {
            _repositoryMock = new Mock<IFavouriteClientRepository>();
            _mapperMock = new Mock<IMapper>();
            _service = new FavouriteClientService(_repositoryMock.Object, _mapperMock.Object);
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
         .UseInMemoryDatabase(databaseName: "TestDatabase")
          .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
          .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
        }

        [Fact]
        public async Task GetAllFavouriteClients_ReturnsNull_WhenEntityListIsNull()
        {
            // Arrange
            _repositoryMock.Setup(repo => repo.GetAllFavouriteClients()).ReturnsAsync((List<FavouriteClient>)null);

            // Act
            var result = await _service.GetAllFavouriteClients();

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAllFavouriteClients_ReturnsNull_WhenEntityListIsEmpty()
        {
            // Arrange
            _repositoryMock.Setup(repo => repo.GetAllFavouriteClients()).ReturnsAsync(new List<FavouriteClient>());

            // Act
            var result = await _service.GetAllFavouriteClients();

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAllFavouriteClients_ReturnsMappedList_WhenEntityListIsNotEmpty()
        {
            // Arrange
            var entityList = new List<FavouriteClient> { new FavouriteClient() };
            var modelList = new List<FavouriteClientModel> { new FavouriteClientModel() };

            _repositoryMock.Setup(repo => repo.GetAllFavouriteClients()).ReturnsAsync(entityList);
            _mapperMock.Setup(mapper => mapper.Map<List<FavouriteClientModel>>(entityList)).Returns(modelList);

            // Act
            var result = await _service.GetAllFavouriteClients();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(modelList, result);
        }
        [Fact]
        public async Task GetUserFavouriteClients_ReturnsNull_WhenEntityListIsNull()
        {
            // Arrange
            string securityUserId = "testUserId";
            _repositoryMock.Setup(repo => repo.GetUserFavouriteClients(securityUserId)).ReturnsAsync((List<FavouriteClient>)null);

            // Act
            var result = await _service.GetUserFavouriteClients(securityUserId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserFavouriteClients_ReturnsNull_WhenEntityListIsEmpty()
        {
            // Arrange
            string securityUserId = "testUserId";
            _repositoryMock.Setup(repo => repo.GetUserFavouriteClients(securityUserId)).ReturnsAsync(new List<FavouriteClient>());

            // Act
            var result = await _service.GetUserFavouriteClients(securityUserId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserFavouriteClients_ReturnsMappedList_WhenEntityListIsNotEmpty()
        {
            // Arrange
            string securityUserId = "testUserId";
            var entityList = new List<FavouriteClient> { new FavouriteClient() };
            var mappedList = new List<FavouriteClientModel> { new FavouriteClientModel() };

            _repositoryMock.Setup(repo => repo.GetUserFavouriteClients(securityUserId)).ReturnsAsync(entityList);
            _mapperMock.Setup(mapper => mapper.Map<List<FavouriteClientModel>>(entityList)).Returns(mappedList);

            // Act
            var result = await _service.GetUserFavouriteClients(securityUserId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(mappedList, result);
        }
        [Fact]
        public async Task GetUserFavouriteClientById_ReturnsNull_WhenEntityIsNull()
        {
            // Arrange
            string securityUserId = "testUserId";
            Guid favoriteClientId = Guid.NewGuid();
            _repositoryMock.Setup(repo => repo.GetUserFavouriteClientById(securityUserId, favoriteClientId)).ReturnsAsync((FavouriteClient)null);

            // Act
            var result = await _service.GetUserFavouriteClientById(securityUserId, favoriteClientId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserFavouriteClientById_ReturnsMappedModel_WhenEntityIsNotNull()
        {
            // Arrange
            string securityUserId = "testUserId";
            Guid favoriteClientId = Guid.NewGuid();
            var entity = new FavouriteClient();
            var mappedModel = new FavouriteClientModel();

            _repositoryMock.Setup(repo => repo.GetUserFavouriteClientById(securityUserId, favoriteClientId)).ReturnsAsync(entity);
            _mapperMock.Setup(mapper => mapper.Map<FavouriteClientModel>(entity)).Returns(mappedModel);

            // Act
            var result = await _service.GetUserFavouriteClientById(securityUserId, favoriteClientId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(mappedModel, result);
        }

        [Fact]
        public async Task SaveUserFavouriteClient_WhenClientExists_SavesFavouriteOnly()
        {
            // Arrange
            var userId = "balabharathi.s@mcgriff.com";
            var request = new FavouriteClientRequest
            {
                SagittaClientId = "1001",
                ClientName = "Test Client",
                ClientCode = "TC001"
            };

            var expectedModel = new FavouriteClientModel();

            _repositoryMock.Setup(r => r.IsClientIdExists(1001)).Returns(true);
            _repositoryMock.Setup(r => r.SaveUserFavouriteClient(It.IsAny<FavouriteClient>()))
            .ReturnsAsync(new FavouriteClient());
            _mapperMock.Setup(m => m.Map<FavouriteClientModel>(It.IsAny<FavouriteClient>()))
            .Returns(expectedModel);

            // Act
            var result = await _service.SaveUserFavouriteClient(userId, request);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedModel, result);
            _repositoryMock.Verify(r => r.IsClientIdExists(1001), Times.Once);
            _repositoryMock.Verify(r => r.SaveUserFavouriteClient(It.IsAny<FavouriteClient>()), Times.Once);
            _repositoryMock.Verify(r => r.AddSagittaClient(It.IsAny<SagittaClient>()), Times.Never);
        }
        [Fact]
        public async Task SaveUserFavouriteClient_CLIENTID_WhenClientExists_SavesFavouriteOnly()
        {
            // Arrange
            var userId = "balabharathi.s@mcgriff.com";
            var request = new FavouriteClientRequest
            {
                SagittaClientId = "1001",
                ClientName = "Test Client",
                ClientCode = "TC001"
            };

            var expectedModel = new FavouriteClientModel();

            _repositoryMock.Setup(r => r.IsClientIdExists(1001)).Returns(false);
            _repositoryMock.Setup(r => r.SaveUserFavouriteClient(It.IsAny<FavouriteClient>()))
            .ReturnsAsync(new FavouriteClient());
            _mapperMock.Setup(m => m.Map<FavouriteClientModel>(It.IsAny<FavouriteClient>()))
            .Returns(expectedModel);

            // Act
            var result = await _service.SaveUserFavouriteClient(userId, request);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedModel, result);
            _repositoryMock.Verify(r => r.IsClientIdExists(1001), Times.Once);
            _repositoryMock.Verify(r => r.SaveUserFavouriteClient(It.IsAny<FavouriteClient>()), Times.Once);
        }


        [Fact]
        public async Task UpdateUserFavouriteClient_ValidInput_UpdatesAndReturnsMappedModel()
        {
            // Arrange
            var userId = "balabharathi.s@mcgriff.com";
            var favoriteClientId = Guid.NewGuid();
            var request = new FavouriteClientRequest
            {
                SagittaClientId = "1001",
                ClientName = "Updated Client",
                ClientCode = "UC001"
            };

            var expectedModel = new FavouriteClientModel();

            _repositoryMock.Setup(r => r.UpdateUserFavouriteClient(It.IsAny<FavouriteClient>()))
                           .ReturnsAsync(new FavouriteClient());

            _mapperMock.Setup(m => m.Map<FavouriteClientModel>(It.IsAny<FavouriteClient>()))
                       .Returns(expectedModel);

            // Act
            var result = await _service.UpdateUserFavouriteClient(userId, favoriteClientId, request);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedModel, result);
            _repositoryMock.Verify(r => r.UpdateUserFavouriteClient(It.Is<FavouriteClient>(
                e => e.FavouriteClientId == favoriteClientId &&
                     e.UpdatedBy == userId &&
                     e.IsDeleted == true
            )), Times.Once);
        }

    }
}
