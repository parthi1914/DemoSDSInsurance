﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Repositories;

namespace BrokerPortal.API.UnitTest.Services
{
    public class TaskStackServiceTests
    {
        private readonly Mock<ITaskStackRepository> _mockTaskStackRepository;
        private readonly Mock<IStrategyRepository> _mockStrategyRepository;
        private readonly Mock<ISagittaClientService> _mockSagittaClientService;
        private readonly Mock<ISagittaStaffService> _mockSagittaStaffService;
        private readonly Mock<ISagittaStaffRepository> _mockSagittaStaffRepository;
        private readonly Mock<ILookupDataRepository> _mockLookupDataRepository;
        private readonly Mock<ISecurityUserService> _mockSecurityUserRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly TaskStackService _taskStackService;

        public TaskStackServiceTests()
        {
            _mockTaskStackRepository = new Mock<ITaskStackRepository>();
            _mockStrategyRepository = new Mock<IStrategyRepository>();
            _mockSagittaStaffRepository = new Mock<ISagittaStaffRepository>();
            _mockLookupDataRepository = new Mock<ILookupDataRepository>();
            _mockSagittaClientService = new Mock<ISagittaClientService>();
            _mockSagittaStaffService = new Mock<ISagittaStaffService>();
            _mockSecurityUserRepository = new Mock<ISecurityUserService>();
            _mockMapper = new Mock<IMapper>();
            _taskStackService = new TaskStackService(
                _mockTaskStackRepository.Object,
                _mockStrategyRepository.Object,
                _mockSagittaClientService.Object,
                _mockSagittaStaffService.Object,
                 _mockLookupDataRepository.Object,
                _mockSagittaStaffRepository.Object,
                _mockSecurityUserRepository.Object,
                _mockMapper.Object
            );
        }

        [Fact]
        public async Task GetAllTaskStacks_ShouldReturnMappedTaskStackModels_WhenTaskStacksExist()
        {
            // Arrange
            var taskStacks = new List<TaskStack>
        {
            new TaskStack {TaskSteps=new List<TaskStep>{ new TaskStep {TaskStepId=Guid.NewGuid() } } }
        };
            var taskStackModels = new List<TaskStackModel>
        {
            new TaskStackModel{TaskSteps=new List<TaskStepModel>{ new TaskStepModel { TaskStepId=Guid.NewGuid() } } }
        };
            var expectedStaffs = new List<SagittaStaff>
        {
            new SagittaStaff { SagittaStaffId = "id1", StaffName = "John" },
            new SagittaStaff { SagittaStaffId = "id2", StaffName = "Jane" }
        };

            _mockTaskStackRepository.Setup(repo => repo.GetAllTaskStacks()).ReturnsAsync(taskStacks);
          //  _mockSagittaStaffRepository.Setup(repo => repo.GetSagittaStaffsByAssignedStepIds(It.IsAny<List<Guid>>())).Returns(expectedStaffs);
            _mockMapper.Setup(mapper => mapper.Map<List<TaskStackModel>>(It.IsAny<List<TaskStack>>())).Returns(taskStackModels);

            // Act
            var result = await _taskStackService.GetAllTaskStacks();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(taskStackModels.Count, result.Count);
        }

        [Fact]
        public async Task GetAllTaskStacks_ShouldReturnNull_WhenNoTaskStacksExist()
        {
            // Arrange
            _mockTaskStackRepository.Setup(repo => repo.GetAllTaskStacks()).ReturnsAsync(new List<TaskStack>());

            // Act
            var result = await _taskStackService.GetAllTaskStacks();

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetTaskStackById_ShouldReturnNull_WhenTaskStackDoesNotExist()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            _mockTaskStackRepository.Setup(repo => repo.GetTaskStackById(taskStackId)).ReturnsAsync((TaskStack)null);

            // Act
            var result = await _taskStackService.GetTaskStackById(taskStackId);

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task GetTaskStackById_WithValidId_ReturnsMappedModel()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var taskStackEntity = new TaskStack();
            var taskStackModel = new TaskStackModel();

            _mockTaskStackRepository
                .Setup(repo => repo.GetTaskStackById(taskStackId))
                .ReturnsAsync(taskStackEntity);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(taskStackModel);

            // Act
            var result = await _taskStackService.GetTaskStackById(taskStackId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(taskStackModel, result);
        }
        [Fact]
        public async Task GetTaskStackById_WithMapped_ReturnsMappedModel()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var Id = new List<Guid> { Guid.NewGuid() };
            
            var taskStackEntity = new TaskStack();
            var taskStackModel = new TaskStackModel { TaskSteps=new List<TaskStepModel> { new TaskStepModel { TaskStepId=Guid.NewGuid()} } };
            var expectedStaffs = new List<SagittaStaff>
        {
            new SagittaStaff { SagittaStaffId = "id1", StaffName = "John" },
            new SagittaStaff { SagittaStaffId = "id2", StaffName = "Jane" }
        };
            _mockTaskStackRepository
                .Setup(repo => repo.GetTaskStackById(taskStackId))
                .ReturnsAsync(taskStackEntity);
            _mockSagittaStaffRepository
               .Setup(repo => repo.GetSagittaStaffsByAssignedStepIds(Id))
               .Returns(expectedStaffs);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(taskStackModel);

            // Act
            var result = await _taskStackService.GetTaskStackById(taskStackId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(taskStackModel, result);
        }
        [Fact]
        public async Task SaveTaskStack_WithGenericTaskType_SavesGenericTaskAndReturnsModel()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var taskStackId = Guid.NewGuid();
            var taskRequest = new TaskStackRequestInfo
            {
                TaskType = nameof(TaskRefType.GENERIC),
                TaskAssignTo = new List<string> { "PLCC"}
            };

            var genericTask = new GenericTask { TaskStackId = taskStackId };
            var expectedModel = new TaskStackModel();
            var taskStackEntity = new TaskStack();
            var taskStackModel = new TaskStackModel();

            _mockTaskStackRepository
                .Setup(repo => repo.GetTaskStackById(taskStackId))
                .ReturnsAsync(taskStackEntity);
            _mockTaskStackRepository
                .Setup(r => r.SaveGenericTask(It.IsAny<GenericTask>()))
                .ReturnsAsync(genericTask);
            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(taskStackModel);
            // Act
            var result = await _taskStackService.SaveTaskStack(securityUserId, taskRequest);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task UpdateTaskStack_WithGenericTaskType_UpdatesAndReturnsMappedModel()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var taskStackId = Guid.NewGuid();

            var taskAssignments = new List<TaskAssignment>
        {
            new TaskAssignment { IsDeleted = true,TaskAssignTo="PLCC" }
        };

            var taskSteps = new List<TaskStep>
        {
            new TaskStep { TaskAssignments = taskAssignments }
        };
            var taskStackEntity = new TaskStack
            {
                TaskStackId = taskStackId,
                TaskSteps = taskSteps,
                
            };
            var taskUpdateRequest = new TaskStackRequestInfo
            {
                TaskType = nameof(TaskRefType.GENERIC),
                TaskAssignTo = new List<string> { "PLCC" }
            };

            var existingGenericTask = new GenericTask { TaskStackId = taskStackId ,TaskStack=taskStackEntity,};
            var updatedGenericTask = new GenericTask { TaskStackId = taskStackId };



            var expectedModel = new TaskStackModel();

            _mockTaskStackRepository.Setup(r => r.GetGenericTaskForUpdateByTaskStackId(taskStackId))
                           .ReturnsAsync(existingGenericTask);

            _mockTaskStackRepository.Setup(r => r.UpdateGenericTask(It.IsAny<GenericTask>()))
                           .Returns(Task.FromResult(updatedGenericTask) );

            _mockTaskStackRepository.Setup(r => r.GetTaskStackById(taskStackId))
                           .ReturnsAsync(taskStackEntity);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(expectedModel);

            // Act
            var result = await _taskStackService.UpdateTaskStack(securityUserId, taskStackId, taskUpdateRequest);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task UpdateTaskStack_WithTaskMeta_UpdatesAndReturnsMappedModel()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var taskStackId = Guid.NewGuid();

            var taskAssignments = new List<TaskAssignment>
        {
            new TaskAssignment { IsDeleted = true,TaskAssignTo="PLCC" }
        };

            var taskSteps = new List<TaskStep>
        {
            new TaskStep { TaskAssignments = taskAssignments }
        };
            var taskStackEntity = new TaskStack
            {
                TaskStackId = taskStackId,
                TaskSteps = taskSteps,
                TaskMeta = new List<TaskMeta> { new TaskMeta { TaskMetaId = Guid.NewGuid(), MarketId = null } }

            };
            var taskUpdateRequest = new TaskStackRequestInfo
            {
                TaskType = nameof(TaskRefType.GENERIC),
                TaskAssignTo = new List<string> { "PLCC" }
            };

            var existingGenericTask = new GenericTask { TaskStackId = taskStackId, TaskStack = taskStackEntity,
               
            };
            var updatedGenericTask = new GenericTask { TaskStackId = taskStackId };



            var expectedModel = new TaskStackModel();

            _mockTaskStackRepository.Setup(r => r.GetGenericTaskForUpdateByTaskStackId(taskStackId))
                           .ReturnsAsync(existingGenericTask);

            _mockTaskStackRepository.Setup(r => r.UpdateGenericTask(It.IsAny<GenericTask>()))
                           .Returns(Task.FromResult(updatedGenericTask));

            _mockTaskStackRepository.Setup(r => r.GetTaskStackById(taskStackId))
                           .ReturnsAsync(taskStackEntity);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(expectedModel);

            // Act
            var result = await _taskStackService.UpdateTaskStack(securityUserId, taskStackId, taskUpdateRequest);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task UpdateTaskStack_WithTaskAssignment_UpdatesAndReturnsMappedModel()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var taskStackId = Guid.NewGuid();

           

            var taskSteps = new List<TaskStep>
        {
            new TaskStep { TaskAssignments = null }
        };
            var taskStackEntity = new TaskStack
            {
                TaskStackId = taskStackId,
                TaskSteps = taskSteps,
                TaskMeta = new List<TaskMeta> { new TaskMeta { TaskMetaId = Guid.NewGuid(), MarketId = null } }

            };
            var taskUpdateRequest = new TaskStackRequestInfo
            {
                TaskType = nameof(TaskRefType.GENERIC),
                TaskAssignTo = new List<string> { "PLCC" }
            };

            var existingGenericTask = new GenericTask
            {
                TaskStackId = taskStackId,
                TaskStack = taskStackEntity,

            };
            var updatedGenericTask = new GenericTask { TaskStackId = taskStackId };



            var expectedModel = new TaskStackModel();

            _mockTaskStackRepository.Setup(r => r.GetGenericTaskForUpdateByTaskStackId(taskStackId))
                           .ReturnsAsync(existingGenericTask);

            _mockTaskStackRepository.Setup(r => r.UpdateGenericTask(It.IsAny<GenericTask>()))
                           .Returns(Task.FromResult(updatedGenericTask));

            _mockTaskStackRepository.Setup(r => r.GetTaskStackById(taskStackId))
                           .ReturnsAsync(taskStackEntity);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(expectedModel);

            // Act
            var result = await _taskStackService.UpdateTaskStack(securityUserId, taskStackId, taskUpdateRequest);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task UpdateTaskStack_WithStaffs_UpdatesAndReturnsMappedModel()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var taskStackId = Guid.NewGuid();



            var taskSteps = new List<TaskStep>
        {
            new TaskStep { TaskAssignments = new List<TaskAssignment>
        {
            new TaskAssignment { IsDeleted = false,TaskAssignTo="PLCC" }
        } }
        };
            var taskStackEntity = new TaskStack
            {
                TaskStackId = taskStackId,
                TaskSteps = taskSteps,
                TaskMeta = new List<TaskMeta> { new TaskMeta { TaskMetaId = Guid.NewGuid(), MarketId = null } }

            };
            var taskUpdateRequest = new TaskStackRequestInfo
            {
                TaskType = nameof(TaskRefType.GENERIC),
                TaskAssignTo = new List<string> { "ABCD" }
            };

            var existingGenericTask = new GenericTask
            {
                TaskStackId = taskStackId,
                TaskStack = taskStackEntity,

            };
            var updatedGenericTask = new GenericTask { TaskStackId = taskStackId };



            var expectedModel = new TaskStackModel();

            _mockTaskStackRepository.Setup(r => r.GetGenericTaskForUpdateByTaskStackId(taskStackId))
                           .ReturnsAsync(existingGenericTask);

            _mockTaskStackRepository.Setup(r => r.UpdateGenericTask(It.IsAny<GenericTask>()))
                           .Returns(Task.FromResult(updatedGenericTask));

            _mockTaskStackRepository.Setup(r => r.GetTaskStackById(taskStackId))
                           .ReturnsAsync(taskStackEntity);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(expectedModel);

            // Act
            var result = await _taskStackService.UpdateTaskStack(securityUserId, taskStackId, taskUpdateRequest);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task UpdateTaskStack_GenericTask_UpdatesAndReturnsMappedModel()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var taskStackId = Guid.NewGuid();



            var taskSteps = new List<TaskStep>
        {
            new TaskStep { TaskAssignments = new List<TaskAssignment>
        {
            new TaskAssignment { IsDeleted = false,TaskAssignTo="PLCC" }
        } }
        };
            var taskStackEntity = new TaskStack
            {
                TaskStackId = taskStackId,
                TaskSteps = taskSteps,
                TaskMeta = new List<TaskMeta> { new TaskMeta { TaskMetaId = Guid.NewGuid(), MarketId = null } }

            };
            var taskUpdateRequest = new TaskStackRequestInfo
            {
                TaskType = nameof(TaskRefType.GENERIC),
                TaskAssignTo = new List<string> { "ABCD" }
            };

            var existingGenericTask = new GenericTask
            {
                TaskStackId = taskStackId,
                TaskStack = taskStackEntity,

            };
            var updatedGenericTask = new GenericTask { TaskStackId = taskStackId,GenericTaskMeta=new List<GenericTaskMeta> { new GenericTaskMeta { GenericTaskMetaId=Guid.NewGuid()} } };



            var expectedModel = new TaskStackModel();

            _mockTaskStackRepository.Setup(r => r.GetGenericTaskForUpdateByTaskStackId(taskStackId))
                           .ReturnsAsync(existingGenericTask);

            _mockTaskStackRepository.Setup(r => r.UpdateGenericTask(It.IsAny<GenericTask>()))
                           .Returns(Task.FromResult(updatedGenericTask));

            _mockTaskStackRepository.Setup(r => r.GetTaskStackById(taskStackId))
                           .ReturnsAsync(taskStackEntity);

            _mockMapper
                .Setup(mapper => mapper.Map<TaskStackModel>(It.IsAny<TaskStack>()))
                .Returns(expectedModel);

            // Act
            var result = await _taskStackService.UpdateTaskStack(securityUserId, taskStackId, taskUpdateRequest);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task DeleteTaskStack_ValidInput_ReturnsTrue()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            _mockTaskStackRepository
                .Setup(r => r.DeleteTaskStack(taskStackId, securityUserId))
                .ReturnsAsync(true);

            // Act
            var result = await _taskStackService.DeleteTaskStack(taskStackId, securityUserId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task DeleteTaskStack_InValidInput_ReturnsTrue()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            _mockTaskStackRepository
                .Setup(r => r.DeleteTaskStack(taskStackId, securityUserId))
                .ReturnsAsync(true);

            // Act
            var result = await _taskStackService.DeleteTaskStack(taskStackId, securityUserId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task RemoveTaskStack_ValidInput_ReturnsTrue()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            _mockTaskStackRepository
                .Setup(r => r.RemoveTaskStack(taskStackId, securityUserId))
                .ReturnsAsync(true);

            // Act
            var result = await _taskStackService.RemoveTaskStack(taskStackId, securityUserId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task BulkMergeStrategyStaffsToTasks_WithValidAssignments_UpdatesTasksAndCallsMerge()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var stepDefId = Guid.NewGuid();

            var request = new List<StrategyStepRequest>
        {
            new StrategyStepRequest
            {
                StepDefId = stepDefId.ToString(),
                AssignmentDueDate = DateTime.Today.AddDays(5),
                StrategyStaffAssignments = new List<StrategyStepStaffAssignmentRequest>
                {
                    new StrategyStepStaffAssignmentRequest { SagittaStaffId = "S001" }
                }
            }
        };

            var taskAssignments = new List<TaskAssignment>
        {
            new TaskAssignment
            {
                TaskAssignTo = "S002",
                TaskAssignmentType = nameof(TaskAssignmentType.SAGITTA_STAFF_ID),
                IsDeleted = false
            }
        };

            var taskSteps = new List<TaskStep>
        {
            new TaskStep
            {
                StepDefId = stepDefId.ToString(),
                TaskAssignments = taskAssignments
            }
        };

            var taskStacks = new List<TaskStack>
        {
            new TaskStack
            {
                TaskDueDate = null,
                TaskSteps = taskSteps,
                TaskMeta = new List<TaskMeta> { new TaskMeta { MarketId = null } }
            }
        };

            _mockTaskStackRepository
                .Setup(r => r.GetAllTasksByStrategyInclMarkets(strategyId))
                .ReturnsAsync(taskStacks);

            _mockTaskStackRepository
                .Setup(r => r.BulkMergeTaskStacks(It.IsAny<List<TaskStack>>()))
                .Returns(Task.FromResult(new List<TaskStack>()));

            // Act
           await _taskStackService.BulkMergeStrategyStaffsToTasks(strategyId, securityUserId, request);

            // Assert
            Assert.True(taskStacks[0].TaskDueDate.HasValue);
        }
        [Fact]
        public async Task DeleteTaskAssignmentByStrategyStaff_WithValidAssignments_UpdatesAndReturnsTrue()
        {
            // Arrange
            var strategyStaffId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            var assignments = new List<TaskAssignment>
        {
            new TaskAssignment { IsDeleted = false },
            new TaskAssignment { IsDeleted = false }
        };

            _mockTaskStackRepository
                .Setup(r => r.GetTaskAssignmentByStrategyStaffId(strategyStaffId))
                .ReturnsAsync(assignments);

            _mockTaskStackRepository
                .Setup(r => r.UpdateRangeTaskAssignments(It.IsAny<List<TaskAssignment>>()))
                .Returns(Task.FromResult(new List<TaskAssignment>()));

            // Act
            var result = await _taskStackService.DeleteTaskAssignmentByStrategyStaff(securityUserId, strategyStaffId);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task SearchTaskStacks_ShouldReturnMappedTaskStackModels_WhenValidInputProvided()
        {
            // Arrange
 
            var baseFilterType = SearchBaseFilterType.ALL;
            var searchType = TaskSearchType.MYASSIGNMENT;
            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = ["OPEN"]
            };
            var securityUserId = "balabharathi.s@mcgriff.com";
            var sagittaClientId = 12345L;
            var strategyId = Guid.NewGuid();

            var userSagittaStaffIds = new List<string> { "staff1" };
            var taskEntities = new List<TaskStack> { new TaskStack { /* properties */ } };
            var mappedModels = new List<TaskStackModel> { new TaskStackModel { TaskSteps=new List<TaskStepModel>
                {
                    new TaskStepModel
                    {
                        TaskStepId=Guid.NewGuid(),
                        StepDefId="MS-SUBM",
                        IsDeleted = false,
                        TaskAssignments = new List<TaskAssignmentModel>
                        {
                            new TaskAssignmentModel { TaskAssignTo="PLCC", IsDeleted = false }
                        }
                    }
            } } };

            _mockSagittaStaffService
                .Setup(s => s.GetSagittaStaffIdsBySecurityUserId(securityUserId))
                .ReturnsAsync(userSagittaStaffIds);
            _mockTaskStackRepository
               .Setup(r => r.GetAllTaskStatusCodesIdsByGroupCode("OPEN"))
               .Returns(["OPEN"]);
            _mockTaskStackRepository
                .Setup(r => r.SearchTaskStacks(
                    baseFilterType, searchType, It.IsAny<TaskSearchCriterias>(),
                    securityUserId, userSagittaStaffIds.ToArray(), null, null,
                    sagittaClientId, strategyId))
                .ReturnsAsync(taskEntities);

            _mockMapper
                .Setup(m => m.Map<List<TaskStackModel>>(taskEntities))
                .Returns(mappedModels);

            // Act
            var result = await _taskStackService.SearchTaskStacks(
                baseFilterType, searchType, searchCriterias,
                securityUserId, sagittaClientId, strategyId);

            // Assert
            Assert.NotNull(result);
        }

    }
}
