﻿using Xunit;
using Moq;
using System;
using System.Collections.Generic;
using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.Services;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
namespace BrokerPortal.API.UnitTest.Services
{
    public class MarketServiceTests
    {
        private readonly Mock<IMarketRepository> _mockMarketRepo;
        private readonly Mock<ITaskStackRepository> _mockTaskStackRepo;
        private readonly Mock<IMarketTaskRepository> _mockMarketTaskRepo;
        private readonly Mock<IStrategyRepository> _mockStrategyRepo;
        private readonly Mock<IStrategyTaskRepository> _mockStrategyTaskRepo;
        private readonly Mock<ILookupDataRepository> _mockLookupDataRepo;
        private readonly Mock<ISagittaStaffRepository> _mockSagittaStaffRepo;
        private readonly Mock<IMapper> _mockMapper;
        private readonly MarketService _service;

        public MarketServiceTests()
        {
            _mockMarketRepo = new Mock<IMarketRepository>();
            _mockTaskStackRepo = new Mock<ITaskStackRepository>();
            _mockMarketTaskRepo = new Mock<IMarketTaskRepository>();
            _mockStrategyRepo = new Mock<IStrategyRepository>();
            _mockStrategyTaskRepo = new Mock<IStrategyTaskRepository>();
            _mockLookupDataRepo = new Mock<ILookupDataRepository>();
            _mockSagittaStaffRepo = new Mock<ISagittaStaffRepository>();
            _mockMapper = new Mock<IMapper>();

            _service = new MarketService(
                _mockMarketRepo.Object,
                _mockMapper.Object,
                _mockTaskStackRepo.Object,
                _mockMarketTaskRepo.Object,
                _mockStrategyRepo.Object,
                _mockStrategyTaskRepo.Object,
                _mockLookupDataRepo.Object,
                _mockSagittaStaffRepo.Object
            );
        }


       

        [Fact]
        public async Task MergeMarket_WithNewMarket_SavesMarket()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var newMarketId = Guid.NewGuid();
            var securityUserId = "user-002";

            var marketRequest = new MarketRequest
            {
                MarketId = newMarketId,
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,
                SubStepDefId = "101",
                MarketTimelines = new List<MarketTimelineRequest>
        {
            new MarketTimelineRequest
            {
                MarketTimelineId = Guid.NewGuid(),
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
            }
        }
            };

            var strategy = new Strategy
            {
                StrategyId = strategyId,
                StrategyTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline
            {
                StrategyTimelineId = Guid.NewGuid(),
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
            }
        }
            };

            var newMarketEntity = new Market
            {
                MarketId = newMarketId,
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimeline>
        {
            new MarketTimeline
            {
                MarketTimelineId = Guid.NewGuid(),
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
            }
        },
                StatusCode = new BpstatusCode
                {
                    StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE,
                    StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE,
                    StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE
                }
            };

            var expectedModel = new MarketModel
            {
                MarketId = newMarketId,
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimelineModel>
        {
            new MarketTimelineModel
            {
                MarketTimelineId = Guid.NewGuid()
            }
        }
            };

            // Mock setup
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketsForUpdateByStrategy(strategyId)).ReturnsAsync(new List<Market>()); // No match

            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY))
                .Returns(new List<StepDef> { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } });

            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs())
                .Returns(new List<SubStepDef> { new SubStepDef { SubStepDefId = "101" } });

            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes())
                .Returns(new List<BpstatusCode> { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });

            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes())
                .Returns(new List<TaskStatusCode> { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.SaveMarket(It.IsAny<Market>())).ReturnsAsync(newMarketEntity);
            _mockMarketRepo.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(new List<Market> { newMarketEntity });
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.MergeMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(newMarketId, result.MarketId);
            Assert.Equal(strategyId, result.StrategyId);

            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Once);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Never);
            _mockMarketRepo.Verify(r => r.TrackMarketChanges(It.IsAny<Market>()), Times.Never);
        }




        [Fact]
        public void GetAllMarketByStrategy_ReturnsMappedMarkets()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketEntities = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } },
            new Market { MarketId = Guid.NewGuid(), StrategyId =  strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } }
        };

            var marketModels = new List<MarketModel>
        {
            new MarketModel {MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimelineModel> { new MarketTimelineModel{MarketTimelineId=Guid.NewGuid()} }  },
            new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimelineModel> { new MarketTimelineModel{MarketTimelineId=Guid.NewGuid()} }  }
        };

            _mockMarketRepo.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(marketEntities);
            _mockMapper.Setup(m => m.Map<List<MarketModel>>(marketEntities)).Returns(marketModels);

            // Act
            var result = _service.GetAllMarketByStrategy(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
        }

        [Fact]
        public async Task GetMarketById_ReturnsMappedMarketModel_WhenValidId()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketId = Guid.NewGuid();
            var marketEntity = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(marketEntity);
            _mockMapper.Setup(m => m.Map<MarketModel>(marketEntity)).Returns(expectedModel);

            // Act
            var result = await _service.GetMarketById(marketId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
        }
        [Fact]
        public async Task GetMarketById_ReturnsMarketModel_WhenValidId()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketId = Guid.NewGuid();
            var marketEntity = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(marketEntity);
            _mockMapper.Setup(m => m.Map<MarketModel>(marketEntity)).Returns(expectedModel);

            // Act
            var result = await _service.GetMarketById(marketId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
        }
        [Fact]
        public async Task GetMarketById_ReturnsException_WhenInValidId()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketId = Guid.NewGuid();
            var marketEntity = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(marketEntity);
            _mockMapper.Setup(m => m.Map<MarketModel>(marketEntity)).Returns(expectedModel);

            // Act
            var result = await _service.GetMarketById(marketId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
        }
        [Fact]
        public async Task SaveMarket_SavesNewMarketAndReturns()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest { MarketId = marketId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var newMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            // Simulate building and saving the market
            _mockMarketRepo.Setup(r => r.SaveMarket(It.IsAny<Market>())).Returns(Task.FromResult(newMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(newMarket.MarketId)).ReturnsAsync(newMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.SaveMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Once);
        }
        [Fact]
        public async Task SaveMarket_StepAssignment_SavesNewMarketAndReturns()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var strategyStaffId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest { MarketId = marketId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,StepAssignments= new List<StrategyStaffAssignmentRequest> { new StrategyStaffAssignmentRequest { StrategyStaffId = strategyStaffId, SagittaStaffId = "PLCC" } } } } };

            var strategy = new Strategy { StrategyId = strategyId,StrategyStaffs=new List<StrategyStaff> { new StrategyStaff { StrategyStaffId = strategyStaffId, SagittaStaffId = "PLCC" } }, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var newMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            // Simulate building and saving the market
            _mockMarketRepo.Setup(r => r.SaveMarket(It.IsAny<Market>())).Returns(Task.FromResult(newMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(newMarket.MarketId)).ReturnsAsync(newMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.SaveMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Once);
        }
        [Fact]
        public async Task SaveMarket_CoveragesValues_SavesNewMarketAndReturnsModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyStaffId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var marketRequest = new MarketRequest
            {
                MarketId = marketId,
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,
                SubStepDefId = "101",
                MarketAddlCoverages = new List<MarketAddlCovRequest>
{
    new MarketAddlCovRequest
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 1,
        CovId = 101,
        CovCode = "COV101",
        CovDesc = "Coverage A",
        IsDeleted = false
    },
    new MarketAddlCovRequest
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 2,
        CovId = 102,
        CovCode = "COV102",
        CovDesc = "Coverage B",
        IsDeleted = true
    }
},
                MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(),
                    StepAssignments= new List<StrategyStaffAssignmentRequest>
{
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "SAG10001",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = false
    },
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "PLCC",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = true
    }
},
                    StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }
            };

            var strategy = new Strategy
            {
                StrategyId = strategyId,
                StrategyStaffs = new List<StrategyStaff> { new StrategyStaff { StrategyStaffId = strategyStaffId } },
                StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }
            };
            var newMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            // Simulate building and saving the market
            _mockMarketRepo.Setup(r => r.SaveMarket(It.IsAny<Market>())).Returns(Task.FromResult(newMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(newMarket.MarketId)).ReturnsAsync(newMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.SaveMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Once);
        }
        [Fact]
        public async Task SaveMarket_SavesNewMarketAndReturnsModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest {MarketId= marketId,StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,SubStepDefId="101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(),StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };

            var strategy = new Strategy { StrategyId = strategyId,StrategyTimelines=new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(),StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var newMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef {StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,IsValidForTaskAutoClose=false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId="101",IsValidForTaskAutoClose=false} });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId=AppConstants.STEP_STATUSCODE_ACTIVE} });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId=AppConstants.TASK_STATUS_CODE_OPEN} });

            // Simulate building and saving the market
            _mockMarketRepo.Setup(r => r.SaveMarket(It.IsAny<Market>())).Returns(Task.FromResult(newMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(newMarket.MarketId)).ReturnsAsync(newMarket);
            _mockMapper.Setup(m => m.Map<MarketModel> (It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.SaveMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Once);
        }
        [Fact]
        public async Task SaveMarket_Coverages_SavesNewMarketAndReturnsModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyStaffId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var marketRequest = new MarketRequest { MarketId = marketId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101",
                MarketAddlCoverages= new List<MarketAddlCovRequest>
{
    new MarketAddlCovRequest
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 1,
        CovId = 101,
        CovCode = "COV101",
        CovDesc = "Coverage A",
        IsDeleted = false
    },
    new MarketAddlCovRequest
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 2,
        CovId = 102,
        CovCode = "COV102",
        CovDesc = "Coverage B",
        IsDeleted = true
    }
},
                MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(),
                    StepAssignments= new List<StrategyStaffAssignmentRequest>
{
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "SAG10001",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = false
    },
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "PLCC",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = true
    }
},
                    StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };

            var strategy = new Strategy { StrategyId = strategyId,
                StrategyStaffs = new List<StrategyStaff> { new StrategyStaff {StrategyStaffId=strategyStaffId } },
                StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var newMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            // Simulate building and saving the market
            _mockMarketRepo.Setup(r => r.SaveMarket(It.IsAny<Market>())).Returns(Task.FromResult(newMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(newMarket.MarketId)).ReturnsAsync(newMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.SaveMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Once);
        }
        [Fact]
        public async Task UpdateMarket_UpdatesReturnsMarketModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var marketCovId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest
            {
                MarketId = marketId,
                MarketAddlCoverages = new List<MarketAddlCovRequest>
{
    new MarketAddlCovRequest
    {
        MarketAddlCovId = marketCovId,
        Version = 1,
        CovId = 101,
        CovCode = "COV101",
        CovDesc = "Coverage A",
        IsDeleted = false
    },
    new MarketAddlCovRequest
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 2,
        CovId = 102,
        CovCode = "COV102",
        CovDesc = "Coverage B",
        IsDeleted = true
    }
},
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,
                SubStepDefId = "101",
                MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }
            };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var existingMarket = new Market
            {
                MarketId = Guid.NewGuid(),
                MarketAddlCovs = new List<MarketAddlCov>
{
    new MarketAddlCov
    {
        MarketAddlCovId = marketCovId,
        Version = 1,
        CovId = 101,
        CovCode = "COV101",
        CovDesc = "Coverage A",
        IsDeleted = false
    },
    new MarketAddlCov
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 2,
        CovId = 102,
        CovCode = "COV102",
        CovDesc = "Coverage B",
        IsDeleted = true
    } }
,
                StatusCode = new BpstatusCode { StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE },
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }
            };
            var updatedMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketForUpdateById(marketId)).ReturnsAsync(existingMarket);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).Returns(Task.FromResult(updatedMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(updatedMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.UpdateMarket(marketId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
        }

        [Fact]
        public async Task UpdateMarket_Task_UpdateReturnsMarketModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest { MarketId = marketId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var existingMarket = new Market { MarketId = Guid.NewGuid(), StatusCode = new BpstatusCode { StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE }, StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var updatedMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketForUpdateById(marketId)).ReturnsAsync(existingMarket);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).Returns(Task.FromResult(updatedMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(updatedMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.UpdateMarket(marketId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
        }

        [Fact]
        public async Task UpdateMarket_TaskMeta_UpdatesReturnsMarketModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest
            {
                MarketId = marketId,
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,
                SubStepDefId = "101",
                MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,StepAssignments= new List<StrategyStaffAssignmentRequest>
{
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "SAG10001",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = false
    },
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "PLCC",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = true
    }
}, } }
            };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var existingMarket = new Market
            {
                MarketId = marketId,

                MarketTaskMeta = new List<MarketTaskMeta>{ new MarketTaskMeta
                {
                    MarketTaskId = Guid.NewGuid(),
                    MarketId = marketId,
                    TaskStack= new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack",TaskSteps= new List<TaskStep>
                {
                    new TaskStep
                    {
                        TaskStepId=Guid.NewGuid(),
                        StepDefId="MS-SUBM",
                        IsDeleted = false,
                        TaskAssignments = new List<TaskAssignment>
                        {
                            new TaskAssignment { TaskAssignTo="PLCC", IsDeleted = false }
                        }
                    }
                } },
                    TaskStackId = Guid.NewGuid(),
                    IsDeleted = false,
                } },

                StatusCode = new BpstatusCode { StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE },
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }
            };
            var updatedMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketForUpdateById(marketId)).ReturnsAsync(existingMarket);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).Returns(Task.FromResult(updatedMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(updatedMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.UpdateMarket(marketId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
        }

        [Fact]
        public async Task UpdateMarket_UpdatesAndReturnsMarketModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var marketCovId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest { MarketId = marketId,
                MarketAddlCoverages = new List<MarketAddlCovRequest>
{
    new MarketAddlCovRequest
    {
        MarketAddlCovId = marketCovId,
        Version = 1,
        CovId = 101,
        CovCode = "COV101",
        CovDesc = "Coverage A",
        IsDeleted = false
    },
    new MarketAddlCovRequest
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 2,
        CovId = 102,
        CovCode = "COV102",
        CovDesc = "Coverage B",
        IsDeleted = true
    }
},
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var existingMarket = new Market { MarketId = Guid.NewGuid(),
                MarketAddlCovs = new List<MarketAddlCov>
{
    new MarketAddlCov
    {
        MarketAddlCovId = marketCovId,
        Version = 1,
        CovId = 101,
        CovCode = "COV101",
        CovDesc = "Coverage A",
        IsDeleted = false
    },
    new MarketAddlCov
    {
        MarketAddlCovId = Guid.NewGuid(),
        Version = 2,
        CovId = 102,
        CovCode = "COV102",
        CovDesc = "Coverage B",
        IsDeleted = true
    } }
, StatusCode=new BpstatusCode {StatusCode= AppConstants.STEP_STATUSCODE_ACTIVE,StatusCodeId= AppConstants.STEP_STATUSCODE_ACTIVE,StatusGroupCode=AppConstants.STEP_STATUSCODE_ACTIVE }  , StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var updatedMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketForUpdateById(marketId)).ReturnsAsync(existingMarket);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).Returns(Task.FromResult(updatedMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(updatedMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.UpdateMarket(marketId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
        }

        [Fact]
        public async Task UpdateMarket_Task_UpdatesAndReturnsMarketModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest { MarketId = marketId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var existingMarket = new Market { MarketId = Guid.NewGuid(), StatusCode = new BpstatusCode { StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE }, StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var updatedMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketForUpdateById(marketId)).ReturnsAsync(existingMarket);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).Returns(Task.FromResult(updatedMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(updatedMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.UpdateMarket(marketId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
        }

        [Fact]
        public async Task UpdateMarket_TaskMeta_UpdatesAndReturnsMarketModel()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "user123";
            var marketRequest = new MarketRequest { MarketId = marketId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, SubStepDefId = "101", MarketTimelines = new List<MarketTimelineRequest> { new MarketTimelineRequest { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,StepAssignments= new List<StrategyStaffAssignmentRequest>
{
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "SAG10001",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = false
    },
    new StrategyStaffAssignmentRequest
    {
        StrategyStaffId = Guid.NewGuid(),
        SagittaStaffId = "PLCC",
        StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION ,
        IsDeleted = true
    }
}, } } };

            var strategy = new Strategy { StrategyId = strategyId, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var existingMarket = new Market { MarketId = marketId,
                
                MarketTaskMeta = new List<MarketTaskMeta>{ new MarketTaskMeta
                {
                    MarketTaskId = Guid.NewGuid(),
                    MarketId = marketId,
                    TaskStack= new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack",TaskSteps= new List<TaskStep>
                {
                    new TaskStep
                    {
                        TaskStepId=Guid.NewGuid(),
                        StepDefId="MS-SUBM",
                        IsDeleted = false,
                        TaskAssignments = new List<TaskAssignment>
                        {
                            new TaskAssignment { TaskAssignTo="PLCC", IsDeleted = false }
                        }
                    }
                } },
                    TaskStackId = Guid.NewGuid(),
                    IsDeleted = false,
                } },

                StatusCode = new BpstatusCode { StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE }, StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var updatedMarket = new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } } };
            var expectedModel = new MarketModel { MarketId = Guid.NewGuid(), StrategyId = strategyId, MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } } };

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketForUpdateById(marketId)).ReturnsAsync(existingMarket);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).Returns(Task.FromResult(updatedMarket));
            _mockMarketRepo.Setup(r => r.GetMarketById(marketId)).ReturnsAsync(updatedMarket);
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.UpdateMarket(marketId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
        }

        [Fact]
        public async Task MergeMarket_WithExisting_Market_UpdatesMarket()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketId = Guid.NewGuid();
            var securityUserId = "user-001";

            var marketRequest = new MarketRequest
            {
                MarketId = marketId,
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,
                SubStepDefId = "101",
                MarketTimelines = new List<MarketTimelineRequest>
        {
            new MarketTimelineRequest
            {
                MarketTimelineId = Guid.NewGuid(),
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
            }
        }
            };

            var strategy = new Strategy
            {
                StrategyId = strategyId,
                StrategyTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline
            {
                StrategyTimelineId = Guid.NewGuid(),
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
            }
        }
            };

            var existingMarket = new Market
            {
                MarketId = marketId,
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimeline>
        {
            new MarketTimeline
            {
                MarketTimelineId = Guid.NewGuid(),
                StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
            }
        },
                StatusCode = new BpstatusCode
                {
                    StatusCode = AppConstants.STEP_STATUSCODE_ACTIVE,
                    StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE,
                    StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE
                }
            };

            var expectedModel = new MarketModel
            {
                MarketId = marketId,
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimelineModel>
        {
            new MarketTimelineModel
            {
                MarketTimelineId = Guid.NewGuid()
            }
        }
            };

            // Mock setup
            _mockStrategyRepo.Setup(r => r.GetStrategyForMarketChanges(strategyId)).ReturnsAsync(strategy);
            _mockMarketRepo.Setup(r => r.GetMarketsForUpdateByStrategy(strategyId)).ReturnsAsync(new List<Market> { existingMarket });

            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(AppConstants.FLOWDEF_STRATEGY))
                .Returns(new List<StepDef> { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } });

            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs())
                .Returns(new List<SubStepDef> { new SubStepDef { SubStepDefId = "101" } });

            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes())
                .Returns(new List<BpstatusCode> { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });

            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes())
                .Returns(new List<TaskStatusCode> { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockMarketRepo.Setup(r => r.TrackMarketChanges(It.IsAny<Market>())).Returns(Task.CompletedTask);
            _mockMarketRepo.Setup(r => r.UpdateMarket(It.IsAny<Market>())).ReturnsAsync(existingMarket);
            _mockMarketRepo.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(new List<Market> { existingMarket });
            _mockMapper.Setup(m => m.Map<MarketModel>(It.IsAny<Market>())).Returns(expectedModel);

            // Act
            var result = await _service.MergeMarket(strategyId, securityUserId, marketRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(marketId, result.MarketId);
            Assert.Equal(strategyId, result.StrategyId);

            _mockMarketRepo.Verify(r => r.TrackMarketChanges(It.IsAny<Market>()), Times.Once);
            _mockMarketRepo.Verify(r => r.UpdateMarket(It.IsAny<Market>()), Times.Once);
            _mockMarketRepo.Verify(r => r.SaveMarket(It.IsAny<Market>()), Times.Never);
        }


        [Fact]
        public async Task RemoveMarket_WithValidStrategyId_CallsRemoveMarketAndReturnsTrue()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var userId = "user123";

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });
            _mockMarketRepo.Setup(r => r.RemoveMarket(marketId, userId)).Returns(Task.FromResult(true));

            // Act
            var result = await _service.RemoveMarket(marketId, userId);

            // Assert
            Assert.True(result);
            _mockMarketRepo.Verify(r => r.RemoveMarket(marketId, userId), Times.Once);
        }

        [Fact]
        public async Task ArchiveMarket_WithValidStrategyId_CallsArchiveMarketAndReturnsTrue()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            _mockMarketRepo.Setup(r => r.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            // Act
            var result = await _service.ArchiveMarket(marketId, securityUserId);

            // Assert
            Assert.True(result);
            _mockMarketRepo.Verify(r => r.ArchiveMarket(marketId, securityUserId), Times.Once);
        }


        [Fact]
        public async Task GetStrategyIdByMarketId_ReturnsExpectedGuid()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var expectedStrategyId = Guid.NewGuid();

            _mockMarketRepo
            .Setup(r => r.GetStrategyIdByMarketId(marketId))
            .ReturnsAsync(expectedStrategyId);

            // Act
            var result = await _service.GetStrategyIdByMarketId(marketId);

            // Assert
            Assert.Equal(expectedStrategyId, result);
            _mockMarketRepo.Verify(r => r.GetStrategyIdByMarketId(marketId), Times.Once);
        }



    }
}