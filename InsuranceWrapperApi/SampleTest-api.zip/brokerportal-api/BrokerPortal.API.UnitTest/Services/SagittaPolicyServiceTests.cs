﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokerPortal.API.UnitTest.Services
{
    public class SagittaPolicyServiceTests
    {
        private readonly Mock<ISagittaPolicyRepository> _mockRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly SagittaPolicyService _service;
        public SagittaPolicyServiceTests()
        {
            _mockRepository = new Mock<ISagittaPolicyRepository>();
            _mockMapper = new Mock<IMapper>();
            _service = new SagittaPolicyService(_mockRepository.Object, _mockMapper.Object);
        }

        [Fact]
        public async Task MergeSagittaPolicy_ValidRequest_CallsRepositoryMethods()
        {
            // Arrange
            var securityUserId = "user123";
            var sagittaPolicyRequest = new SagittaPolicyModelRequest
            {
                SagittaPolicyId = 1,
                SagittaClientId = 2001,
                PolicyNumber = "POL123456",
                PolicyDescription = "General Liability Policy",
                PolicyEffDate = new DateTime(2025, 1, 1),
                PolicyExpDate = new DateTime(2026, 1, 1),
                PolicyType = "GL",
                NewRenew = "New",
                CovId = 3001,
                CovCode = "GL01",
                InsurorId = 4001,
                InsurorCode = "INS001",
                PayeeId = "PAY001",
                PayeeCode = "PC001",
                PayeeName = "ABC Insurance",
                Prod1Code = "P1",
                Prod2Code = "P2",
                Prod3Code = "P3",
                Prod1Name = "Product One",
                Prod2Name = "Product Two",
                Prod3Name = "Product Three",
                Serv1Code = "S1",
                Serv2Code = "S2",
                Serv3Code = "S3",
                Serv1Name = "Service One",
                Serv2Name = "Service Two",
                Serv3Name = "Service Three",
                PremiumAmt = 1500.00m,
                CommissionAmt = 150.00m,
                MarketingRepId = "MR001",
                MarketingRepCode = "MRC001",
                MarketingRepName = "John Doe",
                AccountExecId = "AE001",
                AccountExecCode = "AEC001",
                AccountExecName = "Jane Smith",
                IsActive = true,
                IsSagSync = false

            };

            var existingPolicy = new SagittaPolicy
            {
                SagittaPolicyId = 101,
                // Add other mock fields here
            };

            _mockRepository
                .Setup(r => r.GetSagittaPoliciesRepository(101))
                .ReturnsAsync(existingPolicy);

            _mockRepository
                .Setup(r => r.BulkMerge(It.IsAny<List<SagittaPolicy>>()))
                .Verifiable();

            // Act
            await _service.MergeSagittaPolicy(securityUserId, sagittaPolicyRequest);

            // Assert
            Assert.Equal(true, true);
        }


        [Fact]
        public void GetSagittaPoliciesByStrategyId_ReturnsMappedList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var policies = new List<SagittaPolicy> { new SagittaPolicy() };
            var mappedPolicies = new List<SagittaPolicyModel> { new SagittaPolicyModel() };

            _mockRepository.Setup(r => r.GetSagittaPoliciesByStrategyId(strategyId)).Returns(policies);
            _mockMapper.Setup(m => m.Map<List<SagittaPolicyModel>>(policies)).Returns(mappedPolicies);

            // Act
            var result = _service.GetSagittaPoliciesByStrategyId(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }
        [Fact]
        public void BulkMergeSagittaPolicies_WithValidRequests_ReturnsMappedList()
        {
            // Arrange
            var requests = new List<SagittaPolicyModelRequest>
                {
                    new SagittaPolicyModelRequest
                    {
                        SagittaPolicyId = 1,
                        SagittaClientId = 2001,
                        PolicyNumber = "POL123456",
                        PolicyDescription = "General Liability Policy",
                        PolicyEffDate = new DateTime(2025, 1, 1),
                        PolicyExpDate = new DateTime(2026, 1, 1),
                        PolicyType = "GL",
                        NewRenew = "New",
                        CovId = 3001,
                        CovCode = "GL01",
                        InsurorId = 4001,
                        InsurorCode = "INS001",
                        PayeeId = "PAY001",
                        PayeeCode = "PC001",
                        PayeeName = "ABC Insurance",
                        Prod1Code = "P1",
                        Prod2Code = "P2",
                        Prod3Code = "P3",
                        Prod1Name = "Product One",
                        Prod2Name = "Product Two",
                        Prod3Name = "Product Three",
                        Serv1Code = "S1",
                        Serv2Code = "S2",
                        Serv3Code = "S3",
                        Serv1Name = "Service One",
                        Serv2Name = "Service Two",
                        Serv3Name = "Service Three",
                        PremiumAmt = 1500.00m,
                        CommissionAmt = 150.00m,
                        MarketingRepId = "MR001",
                        MarketingRepCode = "MRC001",
                        MarketingRepName = "John Doe",
                        AccountExecId = "AE001",
                        AccountExecCode = "AEC001",
                        AccountExecName = "Jane Smith",
                        IsActive = true,
                        IsSagSync = false
                    }
                };


            var existingEntities = new List<SagittaPolicy> { new SagittaPolicy { SagittaPolicyId = 1 } };
            var mergedEntities = new List<SagittaPolicy> { new SagittaPolicy { SagittaPolicyId = 1 } };
            var mappedModels = new List<SagittaPolicyModel> { new SagittaPolicyModel() };

            _mockRepository.Setup(r => r.GetSagittaPoliciesByIds(It.IsAny<long?[]>()))
                           .Returns(existingEntities);
            _mockRepository.Setup(r => r.BulkMerge(It.IsAny<List<SagittaPolicy>>()));
            _mockMapper.Setup(m => m.Map<List<SagittaPolicyModel>>(It.IsAny<List<SagittaPolicy>>()))
                       .Returns(mappedModels);

            // Act
            var result = _service.BulkMergeSagittaPolicies("user123", requests);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }
        [Fact]
        public async Task SaveSagittaPolicy_WithNewPolicy_ReturnsMappedModel()
        {
            // Arrange
            var request = 
                    new SagittaPolicyModelRequest
                    {
                        SagittaPolicyId = 1001,
                        SagittaClientId = 2001,
                        PolicyNumber = "POL123456",
                        PolicyDescription = "General Liability Policy",
                        PolicyEffDate = new DateTime(2025, 1, 1),
                        PolicyExpDate = new DateTime(2026, 1, 1),
                        PolicyType = "GL",
                        NewRenew = "New",
                        CovId = 3001,
                        CovCode = "GL01",
                        InsurorId = 4001,
                        InsurorCode = "INS001",
                        PayeeId = "PAY001",
                        PayeeCode = "PC001",
                        PayeeName = "ABC Insurance",
                        Prod1Code = "P1",
                        Prod2Code = "P2",
                        Prod3Code = "P3",
                        Prod1Name = "Product One",
                        Prod2Name = "Product Two",
                        Prod3Name = "Product Three",
                        Serv1Code = "S1",
                        Serv2Code = "S2",
                        Serv3Code = "S3",
                        Serv1Name = "Service One",
                        Serv2Name = "Service Two",
                        Serv3Name = "Service Three",
                        PremiumAmt = 1500.00m,
                        CommissionAmt = 150.00m,
                        MarketingRepId = "MR001",
                        MarketingRepCode = "MRC001",
                        MarketingRepName = "John Doe",
                        AccountExecId = "AE001",
                        AccountExecCode = "AEC001",
                        AccountExecName = "Jane Smith",
                        IsActive = true,
                        IsSagSync = false
    
                };

            var entity = new SagittaPolicy { SagittaPolicyId = 1 };
            var mappedModel = new SagittaPolicyModel();

            _mockRepository.Setup(r => r.GetSagittaPoliciesRepository(1)).ReturnsAsync((SagittaPolicy)null);
            _mockRepository.Setup(r => r.SaveSagittaEntity(It.IsAny<SagittaPolicy>())).Returns(Task.FromResult( (SagittaPolicy)entity));
            _mockMapper.Setup(m => m.Map<SagittaPolicyModel>(It.IsAny<SagittaPolicy>())).Returns(mappedModel);

            // Act
            var result = await _service.SaveSagittaPolicy("user123", request);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task UpdateSagittaPolicy_WithExistingPolicy_ReturnsMappedModel()
        {
            // Arrange
            var request = new SagittaPolicyModelRequest
            {
                SagittaPolicyId = 1001,
                SagittaClientId = 2001,
                PolicyNumber = "POL-2025-001",
                PolicyDescription = "Commercial Auto Insurance",
                PolicyEffDate = new DateTime(2025, 1, 1),
                PolicyExpDate = new DateTime(2026, 1, 1),
                PolicyType = "Auto",
                NewRenew = "New",
                CovId = 3001,
                CovCode = "AUTO-COV",
                InsurorId = 4001,
                InsurorCode = "INS-001",
                PayeeId = "PAY-001",
                PayeeCode = "PC-001",
                PayeeName = "ABC Insurance Co.",
                Prod1Code = "P1",
                Prod2Code = "P2",
                Prod3Code = "P3",
                Prod1Name = "Auto Liability",
                Prod2Name = "Collision",
                Prod3Name = "Comprehensive",
                Serv1Code = "S1",
                Serv2Code = "S2",
                Serv3Code = "S3",
                Serv1Name = "Roadside Assistance",
                Serv2Name = "Rental Coverage",
                Serv3Name = "Glass Repair",
                PremiumAmt = 2500.00m,
                CommissionAmt = 250.00m,
                MarketingRepId = "MR-001",
                MarketingRepCode = "MRC-001",
                MarketingRepName = "John Doe",
                AccountExecId = "AE-001",
                AccountExecCode = "AEC-001",
                AccountExecName = "Jane Smith",
                IsActive = true,
                IsSagSync = false
            };

            var entity = new SagittaPolicy { SagittaPolicyId = 1 };
            var mappedModel = new SagittaPolicyModel();

            _mockRepository.Setup(r => r.GetSagittaPoliciesRepository(1)).ReturnsAsync(entity);
            _mockRepository.Setup(r => r.UpdateSagittaEntity(It.IsAny<SagittaPolicy>())).Returns(Task.FromResult((SagittaPolicy)entity));
            _mockMapper.Setup(m => m.Map<SagittaPolicyModel>(It.IsAny<SagittaPolicy>())).Returns(mappedModel);

            // Act
            var result = await _service.UpdateSagittaPolicy("user123", request);

            // Assert
            Assert.NotNull(result);
        }
    }


}

