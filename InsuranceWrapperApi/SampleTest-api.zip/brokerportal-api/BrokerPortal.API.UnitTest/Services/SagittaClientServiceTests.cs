﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Services;
using Moq;
using BrokerPortal.API.Utilities;
using Microsoft.Extensions.Configuration;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using Moq.Protected;
using System.Net;
using System.Net.Http.Json;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;

namespace BrokerPortal.API.UnitTest.Services
{
    public class SagittaClientServiceTests
    {
        private readonly RestServiceClient _mockRestServiceClient;
        private readonly SagittaClientService _sagittaClientService;
        private readonly Mock<ISagittaClientService> _mockSagittaClientService;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<ISagittaClientRepository> _mockSagittaClientRepository;
        private readonly Mock<IConfiguration> _mockConfig;
        public SagittaClientServiceTests()
        {
            var handlerMock = new Mock<HttpMessageHandler>();
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(req =>
                        req.Method == HttpMethod.Get &&
                        req.RequestUri.ToString() == "http://test/api/sagitta/repl/clients/123"),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = JsonContent.Create(new SagittaReplClientSearchResponse { ClientId="123"})
                });

            handlerMock
             .Protected()
             .Setup<Task<HttpResponseMessage>>(
             "SendAsync",
             ItExpr.Is<HttpRequestMessage>(req =>
             req.Method == HttpMethod.Post &&
             req.RequestUri.ToString() == "http://test/api/sagitta/repl/clients/search"),
             ItExpr.IsAny<CancellationToken>())
             .ReturnsAsync(new HttpResponseMessage
             {
                 StatusCode = HttpStatusCode.OK,
                 Content = JsonContent.Create(new List<SagittaReplClientSearchResponse>
             {
             new SagittaReplClientSearchResponse { ClientId = "123" },
             new SagittaReplClientSearchResponse { ClientId = "456" }
             })
             });

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test/")
            };
            _mockRestServiceClient = new RestServiceClient(httpClient);
            _mockSagittaClientRepository = new Mock<ISagittaClientRepository>();
            _mockSagittaClientService = new Mock<ISagittaClientService>();
            _mockConfig = new Mock<IConfiguration>();
            _mockMapper = new Mock<IMapper>();
            _sagittaClientService = new SagittaClientService(_mockConfig.Object, _mockMapper.Object, _mockRestServiceClient, _mockSagittaClientRepository.Object);

        }

        [Fact]
        public async Task GetSagittaClientByIdFromRepl_ReturnsMappedResponse()
        {
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");

            var replResponse = new SagittaReplClientSearchResponse();
            var mappedResponse = new SagittaClientResponse();

            _mockMapper
             .Setup(m => m.Map<SagittaClientResponse>(It.IsAny<SagittaReplClientSearchResponse>()))
             .Returns(mappedResponse);
            var result = await _sagittaClientService.GetSagittaClientByIdFromRepl("token", "123");

            Assert.Equal(mappedResponse, result);
        }
        [Fact]
        public async Task GetSagittaClient_ReturnsClient()
        {
            var clientId = "123";
            var expectedClient = new SagittaClient { SagittaClientId = 123 };

            _mockSagittaClientRepository.Setup(r => r.GetSagittaClient(clientId)).ReturnsAsync(expectedClient);

            var result = await _sagittaClientService.GetSagittaClient(clientId);

            Assert.Equal(expectedClient, result);
        }
        [Fact]
        public async Task IsSagittaClientExists_ReturnsTrue()
        {
            long clientId = 123;
            _mockSagittaClientRepository.Setup(r => r.IsSagittaClientExists(clientId)).ReturnsAsync(true);

            var result = await _sagittaClientService.IsSagittaClientExists(clientId);

            Assert.True(result);
        }
        [Fact]
        public async Task SaveSagittaClientFromReplIfNotExist_SavesAndReturnsMappedClient() 
        {
            var clientId = "123";
            var accessToken = "token";
            var userId = "user1";

            _mockSagittaClientRepository.Setup(r => r.GetSagittaClient(clientId)).ReturnsAsync((SagittaClient)null);

            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");
            var mappedResponse = new SagittaClientResponse();

            _mockMapper
             .Setup(m => m.Map<SagittaClientResponse>(It.IsAny<SagittaReplClientSearchResponse>()))
             .Returns(mappedResponse);

            var replResponse = new SagittaClientResponse();
            _mockSagittaClientService.Setup(s => s.GetSagittaClientByIdFromRepl(accessToken, clientId)).ReturnsAsync(replResponse);

            var newEntity = new SagittaClient();

            _mockSagittaClientRepository.Setup(r => r.AddSagittaClient(newEntity)).Returns(Task.FromResult(newEntity));

            var mappedModel = new SagittaClientModel();
            _mockMapper.Setup(m => m.Map<SagittaClientModel>(It.IsAny<SagittaClient>())).Returns(mappedModel);

            var result = await _sagittaClientService.SaveSagittaClientFromReplIfNotExist(userId, accessToken, clientId);

            Assert.Equal(mappedModel, result);
        }

        [Fact]
        public async Task UpdateSagittaClientFromRepl_UpdatesAndReturnsMappedClient()
        {
            var clientId = "123";
            var accessToken = "token";
            var userId = "user1";
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");
            var mappedResponse = new SagittaClientResponse();

            _mockMapper
             .Setup(m => m.Map<SagittaClientResponse>(It.IsAny<SagittaReplClientSearchResponse>()))
             .Returns(mappedResponse);

            var existingEntity = new SagittaClient { SagittaClientId = 123 };
            _mockSagittaClientRepository.Setup(r => r.GetSagittaClient(clientId)).ReturnsAsync(existingEntity);

            var replResponse = new SagittaClientResponse();
            _mockSagittaClientService.Setup(s => s.GetSagittaClientByIdFromRepl(accessToken, clientId)).ReturnsAsync(replResponse);

            var updatedEntity = new SagittaClient();
            _mockSagittaClientRepository.Setup(r => r.UpdateSagittaClient(updatedEntity)).Returns((Task.FromResult(updatedEntity)));

            var mappedModel = new SagittaClientModel();
            _mockMapper.Setup(m => m.Map<SagittaClientModel>(It.IsAny<SagittaClient>())).Returns(mappedModel);

            var result = await _sagittaClientService.UpdateSagittaClientFromRepl(userId, accessToken, clientId);

            Assert.Equal(mappedModel, result);
        }

        [Fact]
        public async Task SearchSagittaClientsFromRepl_ReturnsMappedClients()
        {
            // Arrange

            var accessToken = "test-token";
            var searchRequest = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                searchOption = "CONTAINS",
                searchCondition = "OR",
                SearchCriterias = new SearchClientCriterias
                {
                    clientStatusOption = "ACTIVE",
                    clientCode = "123",
                    clientName = "Acme Corp",
                    clientAssignedToStaffIds = new[] { "STF001", "STF002" }
                },
                SecurityUser = new SecurityUserModel
                {
                    SecurityUserId = "USR001",
                }
            };

            var sagittaReplRequest = new SagittaReplClientSearchRequest(); // Expected built request


            var mappedResponse = new List<SagittaClientResponse>
    {
        new SagittaClientResponse { SagittaClientId = "123" }
    };
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");

            _mockMapper
                .Setup(x => x.Map<List<SagittaClientResponse>>(It.IsAny<List<SagittaReplClientSearchResponse>>()))
                .Returns(mappedResponse);

            // Act
            var result = await _sagittaClientService.SearchSagittaClientsFromRepl(accessToken, searchRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal("123", result[0].SagittaClientId);
        }
        [Fact]
        public async Task SearchFavSagittaClientsFromRepl_ReturnsMappedResponse()
        {
            // Arrange
            var accessToken = "token123";
            var favClientList = new List<FavouriteClientModel>
        {
            new FavouriteClientModel { SagittaClientId = "C001" },
            new FavouriteClientModel { SagittaClientId = "C002" }
        };
            var searchRequest = new SagittaClientSearchRequest
            {
                searchType = "ALL",
                searchOption = "CONTAINS",
                searchCondition = "OR",
                SearchCriterias = new SearchClientCriterias
                {
                    clientStatusOption = "ACTIVE",
                    clientCode = "123",
                    clientName = "Acme Corp",
                    clientAssignedToStaffIds = new[] { "STF001", "STF002" }
                },
                SecurityUser = new SecurityUserModel
                {
                    SecurityUserId = "balabharathi.s@mcgriff.com",
                }
            };
            var replResponse = new List<SagittaReplClientSearchResponse>
        {
            new SagittaReplClientSearchResponse()
        };

            var expectedMappedResponse = new List<SagittaClientResponse>
        {
            new SagittaClientResponse()
        };

            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");
            _mockMapper
               .Setup(x => x.Map<List<SagittaClientResponse>>(It.IsAny<List<SagittaReplClientSearchResponse>>()))
               .Returns(expectedMappedResponse);

            // Act
            var result = await _sagittaClientService.SearchFavSagittaClientsFromRepl(accessToken, favClientList, searchRequest);

            // Assert
            Assert.Equal(expectedMappedResponse, result);
        }


    }

}
