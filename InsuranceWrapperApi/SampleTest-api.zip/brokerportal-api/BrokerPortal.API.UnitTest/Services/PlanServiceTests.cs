﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Plan;
using BrokerPortal.API.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.UnitTest.Services
{
    public class PlanServiceTests
    {
        private readonly Mock<IPlanRepository> _mockPlanRepository;
        private readonly Mock<IStrategyRepository> _mockStrategyRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly PlanService _planService;

        public PlanServiceTests()
        {
            _mockPlanRepository = new Mock<IPlanRepository>();
            _mockStrategyRepository = new Mock<IStrategyRepository>();
            _mockMapper = new Mock<IMapper>();
            _planService = new PlanService(_mockPlanRepository.Object, _mockStrategyRepository.Object, _mockMapper.Object);
        }
        [Fact]
        public async Task GetAllPlans_ReturnsMappedPlans()
        {
            // Arrange
            var plans = new List<Plan> { new Plan { PlanId = Guid.NewGuid(), PlanClients = new List<PlanClient> { new PlanClient { SagittaClient = new SagittaClient() } } } };
            var mappedPlans = new List<PlanResponse> { new PlanResponse { PlanId = plans[0].PlanId } };
            var mappedClient = new PlanClientDetailsResponse();

            _mockPlanRepository.Setup(r => r.GetAllPlans()).ReturnsAsync(plans);
            _mockMapper.Setup(m => m.Map<List<PlanResponse>>(plans)).Returns(mappedPlans);
            _mockMapper.Setup(m => m.Map<PlanClientDetailsResponse>(It.IsAny<SagittaClient>())).Returns(mappedClient);

            // Act
            var result = await _planService.GetAllPlans();

            // Assert
            Assert.Single(result);
            Assert.Equal(mappedClient, result[0].PlanClients);
        }
        [Fact]
        public async Task GetPlanById_ValidId_ReturnsMappedPlan()
        {
            var planId = Guid.NewGuid();
            var plan = new Plan
            {
                PlanId = planId,
                PlanClients = new List<PlanClient> { new PlanClient { PlanClientId = Guid.NewGuid(), SagittaClient = new SagittaClient() } }
            };
            var mappedPlan = new PlanResponse { PlanId = planId };
            var mappedClient = new PlanClientDetailsResponse();

            _mockPlanRepository.Setup(r => r.GetPlanById(planId)).ReturnsAsync(plan);
            _mockMapper.Setup(m => m.Map<PlanResponse>(plan)).Returns(mappedPlan);
            _mockMapper.Setup(m => m.Map<PlanClientDetailsResponse>(plan.PlanClients.SingleOrDefault().SagittaClient)).Returns(mappedClient);

            // Act
            var result = await _planService.GetPlanById(planId);

            // Assert
            Assert.Equal(planId, result.PlanId);
            Assert.Equal(mappedClient, result.PlanClients);
        }
        [Fact]
        public async Task SavePlan_ValidRequest_ReturnsSavedPlan()
        {
                var planRequest = new PlanRequest
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Sample Strategic Plan",
                PlanEffDate = DateTime.UtcNow.Date,
                PlanClients = new PlanClientDetailsRequest
                {
                    PlanClientId = Guid.NewGuid(),
                    ClientName = "Acme Corporation",
                    SagittaClientId=100067
                },
                PlanTimelines = new List<PlanTimelinesRequest>
    {
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow,
            StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION
        }
    },
                SecurityUsers = new SecurityUserModel
                {
                    SecurityUserId = "balabharathi.s@mcgriff.com",
                }
            };
            var newPlan = new Plan { PlanId = Guid.NewGuid(), PlanClients = new List<PlanClient> { new PlanClient { PlanClientId = Guid.NewGuid(), SagittaClient = new SagittaClient() } } };

            _mockPlanRepository.Setup(r => r.SavePlan(It.IsAny<Plan>())).ReturnsAsync(newPlan);
            _mockPlanRepository.Setup(r => r.GetPlanById(newPlan.PlanId)).ReturnsAsync(newPlan);
            _mockMapper.Setup(m => m.Map<PlanResponse>((It.IsAny<Plan>()))).Returns(new PlanResponse { PlanId = newPlan.PlanId,PlanClients=new PlanClientDetailsResponse() });
            _mockMapper.Setup(m => m.Map<PlanClientDetailsResponse>((It.IsAny<SagittaClient>()))).Returns( new PlanClientDetailsResponse(){PlanClientId=Guid.NewGuid() });
            // Act
            var result = await _planService.SavePlan(planRequest);

            // Assert
            Assert.Equal(newPlan.PlanId, result.PlanId);
        }
        [Fact]
        public async Task UpdatePlan_WithValidInput_UpdatesPlanAndReturnsResponse()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var planRequest = new PlanRequest
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Sample Strategic Plan",
                PlanEffDate = DateTime.UtcNow.Date,
                PlanClients = new PlanClientDetailsRequest
                {
                    PlanClientId = Guid.NewGuid(),
                    ClientName = "Acme Corporation",
                    SagittaClientId = 100067
                },
                PlanTimelines = new List<PlanTimelinesRequest>
    {
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow,
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_MARKET
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_PROPOSAL
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_BIND
        }
    },
                SecurityUsers = new SecurityUserModel
                {
                    SecurityUserId = "balabharathi.s@mcgriff.com",
                }
            };
            var existingPlan = new Plan
            {
                PlanId = planId,
                Strategies = new List<Strategy> { new Strategy() }
            };
            var updatedPlan = new Plan { PlanId = planId };
            var expectedResponse = new PlanResponse();

            _mockPlanRepository.Setup(r => r.FetchForUpdatePlanAndStrategiesByPlan(planId))
                           .ReturnsAsync(existingPlan);

            _mockPlanRepository.Setup(r => r.UpdatePlan(existingPlan))
                           .ReturnsAsync(updatedPlan);

            // Act
            var result = await _planService.UpdatePlan(planRequest, planId);

            // Assert
            Assert.Equal(expectedResponse.PlanId, result.PlanId);

        }
        [Fact]
        public async Task UpdatePlan_WithTimelines_UpdatesPlanAndReturnsResponse()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var planRequest = new PlanRequest
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Sample Strategic Plan",
                PlanEffDate = DateTime.UtcNow.Date,
                PlanClients = new PlanClientDetailsRequest
                {
                    PlanClientId = Guid.NewGuid(),
                    ClientName = "Acme Corporation",
                    SagittaClientId = 100067
                },
                PlanTimelines = new List<PlanTimelinesRequest>
    {
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow,
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_MARKET
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_PROPOSAL
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_BIND
        }
    },
                SecurityUsers = new SecurityUserModel
                {
                    SecurityUserId = "balabharathi.s@mcgriff.com",
                }
            };
            var existingPlan = new Plan
            {
                PlanId = planId,
                PlanClients = new List<PlanClient> { new PlanClient { PlanClientId = Guid.NewGuid() } },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } },
                Strategies = new List<Strategy> { new Strategy() }
            };
            var updatedPlan = new Plan { PlanId = planId };
            var expectedResponse = new PlanResponse();

            _mockPlanRepository.Setup(r => r.FetchForUpdatePlanAndStrategiesByPlan(planId))
                           .ReturnsAsync(existingPlan);

            _mockPlanRepository.Setup(r => r.UpdatePlan(existingPlan))
                           .ReturnsAsync(updatedPlan);

            // Act
            var result = await _planService.UpdatePlan(planRequest, planId);

            // Assert
            Assert.Equal(expectedResponse.PlanId, result.PlanId);

        }
        [Fact]
        public async Task UpdatePlan_StrategyTimelines_UpdatesPlanAndReturnsResponse()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var planRequest = new PlanRequest
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Sample Strategic Plan",
                PlanEffDate = DateTime.UtcNow.Date,
                PlanClients = new PlanClientDetailsRequest
                {
                    PlanClientId = Guid.NewGuid(),
                    ClientName = "Acme Corporation",
                    SagittaClientId = 100067
                },
                PlanTimelines = new List<PlanTimelinesRequest>
    {
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow,
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_MARKET
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_PROPOSAL
        },
        new PlanTimelinesRequest
        {
            PlanTimelineId = Guid.NewGuid(),
            DueDate = DateTime.UtcNow.AddMonths(6),
            StepDefId=AppConstants.PLAN_STEP_STEPDEFID_BIND
        }
    },
                SecurityUsers = new SecurityUserModel
                {
                    SecurityUserId = "balabharathi.s@mcgriff.com",
                }
            };
            var existingPlan = new Plan
            {
                PlanId = planId,
                PlanClients = new List<PlanClient> { new PlanClient { PlanClientId = Guid.NewGuid(),SagittaClientId=1007 } },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } },
                Strategies = new List<Strategy> { new Strategy { StrategyId=Guid.NewGuid(),
                   StrategyTimelines=new List<StrategyTimeline>{ new StrategyTimeline { StepDefId=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,StatusCodeId= AppConstants.STEP_STATUSCODE_ACTIVE } }, StrategyClients= new List<StrategyClient> { new StrategyClient { SagittaClientId=1007} } } }
            };
            var updatedPlan = new Plan { PlanId = planId };
            var expectedResponse = new PlanResponse();

            _mockPlanRepository.Setup(r => r.FetchForUpdatePlanAndStrategiesByPlan(planId))
                           .ReturnsAsync(existingPlan);

            _mockPlanRepository.Setup(r => r.UpdatePlan(existingPlan))
                           .ReturnsAsync(updatedPlan);

            // Act
            var result = await _planService.UpdatePlan(planRequest, planId);

            // Assert
            Assert.Equal(expectedResponse.PlanId, result.PlanId);

        }
        [Fact]
        public async Task RemovePlan_CallsRepositoriesAndReturnsTrue()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            _mockPlanRepository.Setup(r => r.RemovePlan(planId, securityUserId)).Returns(Task.FromResult(true));
            _mockStrategyRepository.Setup(s => s.RemoveStrategyByPlan(planId, securityUserId)).Returns(Task.FromResult(true));

            // Act
            var result = await _planService.RemovePlan(planId, securityUserId);

            // Assert
            Assert.True(result);
            _mockPlanRepository.Verify(r => r.RemovePlan(planId, securityUserId), Times.Once);
            _mockStrategyRepository.Verify(s => s.RemoveStrategyByPlan(planId, securityUserId), Times.Once);
        }
        [Fact]
        public async Task ArchivePlan_CallsRepositoriesAndReturnsTrue()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            _mockPlanRepository.Setup(r => r.ArchivePlan(planId, securityUserId)).Returns(Task.FromResult(true));
            _mockStrategyRepository.Setup(s => s.ArchiveStrategyByPlan(planId, securityUserId)).Returns(Task.FromResult(true));

            // Act
            var result = await _planService.ArchivePlan(planId, securityUserId);

            // Assert
            Assert.True(result);
            _mockPlanRepository.Verify(r => r.ArchivePlan(planId, securityUserId), Times.Once);
            _mockStrategyRepository.Verify(s => s.ArchiveStrategyByPlan(planId, securityUserId), Times.Once);
        }


    }
}
