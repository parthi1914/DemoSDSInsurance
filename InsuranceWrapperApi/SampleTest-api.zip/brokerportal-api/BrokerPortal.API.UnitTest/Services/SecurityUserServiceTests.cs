﻿using Xunit;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.Services;
using BrokerPortal.API.RepositoryContracts.Domain;
namespace BrokerPortal.API.UnitTest.Services
{
    public class SecurityUserServiceTests
    {
        private readonly Mock<IConfiguration> _mockConfig;
        private readonly Mock<ISecurityUserRepository> _mockRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly SecurityUserService _service;

        public SecurityUserServiceTests()
        {
            _mockConfig = new Mock<IConfiguration>();
            _mockRepository = new Mock<ISecurityUserRepository>();
            _mockMapper = new Mock<IMapper>();
            _service = new SecurityUserService(_mockConfig.Object, _mockRepository.Object, _mockMapper.Object);
        }

        [Fact]
        public async Task GetEmployeeIdBySecurityUserId_ReturnsEmployeeId()
        {
            // Arrange
            var securityUserId = "user123";
            var expectedEmployeeId = "emp456";
            _mockRepository.Setup(r => r.GetEmployeeIdBySecurityUserId(securityUserId))
                           .ReturnsAsync(expectedEmployeeId);

            // Act
            var result = await _service.GetEmployeeIdBySecurityUserId(securityUserId);

            // Assert
            Assert.Equal(expectedEmployeeId, result);
        }

        [Fact]
        public async Task GetExternalSystemIdsBySecurityUserId_ReturnsMappedIds()
        {
            // Arrange
            var securityUserId = "user123";
            var externalSystemId = "sys789";
            var mappings = new List<SecurityUserMapExternalSystem>
        {
            new SecurityUserMapExternalSystem { ExternalSystemUserId = "ext1" },
            new SecurityUserMapExternalSystem { ExternalSystemUserId = "ext2" }
        };

            _mockRepository.Setup(r => r.GetSecurityUserMapExternalSystemUserList(securityUserId, externalSystemId))
                           .ReturnsAsync(mappings);

            // Act
            var result = await _service.GetExternalSystemIdsBySecurityUserId(securityUserId, externalSystemId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Contains("ext1", result);
            Assert.Contains("ext2", result);
        }
        [Fact]
        public async Task GetSecurityUserIdsByExternalSystemUserIds_AddsNewMappings()
        {
            // Arrange
            var securityUserId = "user123";
            var externalSystemId = "sys789";
            var externalSystemUserIds = new List<string> { "ext1", "ext2" }.ToArray();
            var existingMappings = new List<SecurityUserMapExternalSystem>(); // No existing mappings

            _mockRepository.Setup(r => r.GetSecurityUserMapExternalSystemUserList(securityUserId, externalSystemId))
                           .ReturnsAsync(existingMappings);

            _mockRepository.Setup(r => r.BulkSaveSecurityUserMapExternalSystemUserList(It.IsAny<List<SecurityUserMapExternalSystem>>()))
                           .ReturnsAsync((List<SecurityUserMapExternalSystem> list) => list);

            // Act
            var result = await _service.GetSecurityUserIdsByExternalSystemUserIds(externalSystemId, externalSystemUserIds);

            // Assert
            Assert.Null(result);
          
        }

        [Fact]
        public async Task BulkMergeUserMapExternalSystem_AddsNewMappings()
        {
            // Arrange
            var securityUserId = "user123";
            var externalSystemId = "sys789";
            var externalSystemUserIds = new List<string> { "ext1", "ext2" };
            var existingMappings = new List<SecurityUserMapExternalSystem>(); // No existing mappings

            _mockRepository.Setup(r => r.GetSecurityUserMapExternalSystemUserList(securityUserId, externalSystemId))
                           .ReturnsAsync(existingMappings);

            _mockRepository.Setup(r => r.BulkSaveSecurityUserMapExternalSystemUserList(It.IsAny<List<SecurityUserMapExternalSystem>>()))
                           .ReturnsAsync((List<SecurityUserMapExternalSystem> list) => list);

            // Act
            var result = await _service.BulkMergeUserMapExternalSystem(securityUserId, externalSystemId, externalSystemUserIds);

            // Assert
            Assert.True(result);
            _mockRepository.Verify(r => r.BulkSaveSecurityUserMapExternalSystemUserList(It.IsAny<List<SecurityUserMapExternalSystem>>()), Times.Once);
        }
    }
}