﻿using Xunit;
using Moq;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Services;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.UnitTest.Services
{
    public class StrategyStaffServiceTests
    {
        private readonly Mock<IStrategyStaffRepository> _strategyRepoMock;
        private readonly Mock<ITaskStackRepository> _taskStackRepoMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly StrategyStaffService _service;

        public StrategyStaffServiceTests()
        {
            _strategyRepoMock = new Mock<IStrategyStaffRepository>();
            _taskStackRepoMock = new Mock<ITaskStackRepository>();
            _mapperMock = new Mock<IMapper>();
            _service = new StrategyStaffService(_strategyRepoMock.Object, _taskStackRepoMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetStrategyStaffs_WithValidStrategyId_ReturnsMappedList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var strategyStaffs = new List<StrategyStaff> { new StrategyStaff() };
            var mappedStaffs = new List<StrategyStaffModel> { new StrategyStaffModel() };
            var assignments = new List<StepTimelineStaffAssignment> { new StepTimelineStaffAssignment() };

            _strategyRepoMock.Setup(r => r.GetStrategyStaffs(strategyId)).Returns(strategyStaffs);
            _mapperMock.Setup(m => m.Map<List<StrategyStaffModel>>(strategyStaffs)).Returns(mappedStaffs);
            _taskStackRepoMock.Setup(r => r.GetStrategyStaffAssignmentsByStrategy(strategyId)).Returns(assignments);

            // Act
            var result = await _service.GetStrategyStaffs(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            _strategyRepoMock.Verify(r => r.GetStrategyStaffs(strategyId), Times.Once);
            _taskStackRepoMock.Verify(r => r.GetStrategyStaffAssignmentsByStrategy(strategyId), Times.Once);
        }
        [Fact]
        public async Task BulkMergeStrategyStaffs_WithValidInput_PerformsMergeAndReturnsMappedList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var userId = "balabharathi.s@mcgriff.com";
            var staffRequests = new List<StaffRequest> { new StaffRequest { StrategyStaffId=Guid.NewGuid(),SagittaStaffId="PLCC" } };
            var existingStaffs = new List<StrategyStaff> { new StrategyStaff() };
            var upsertList = new List<StrategyStaff> { new StrategyStaff { StrategyStaffId = Guid.NewGuid(), SagittaStaffId = "PLCC" } };
            var mappedList = new List<StrategyStaffModel> { new StrategyStaffModel { StrategyStaffId = Guid.NewGuid(), SagittaStaffId = "PLCC" } };

            _strategyRepoMock.Setup(r => r.GetStrategyStaffs(strategyId)).Returns(existingStaffs);
            _strategyRepoMock.Setup(r => r.BulkMergeWithSubEntities(upsertList)).Returns(Task.FromResult(upsertList));
            _mapperMock.Setup(m => m.Map<List<StrategyStaffModel>>(It.IsAny<List<StrategyStaff>>())).Returns(mappedList);

            // Act
            var result = await _service.BulkMergeStrategyStaffs(strategyId, userId, staffRequests);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            _strategyRepoMock.Verify(r => r.BulkMergeWithSubEntities(It.IsAny<List<StrategyStaff>>()), Times.Once);
        }

        [Fact]
        public async Task DeleteStrategyStaff_ValidInput_CallsRepositoryAndReturnsTrue()
        {
            // Arrange
            var userId = "user123";
            var staffId = Guid.NewGuid();

            _strategyRepoMock
            .Setup(r => r.DeleteStrategyStaff(userId, staffId))
            .Returns(Task.FromResult(true));

            // Act
            var result = await _service.DeleteStrategyStaff(userId, staffId);

            // Assert
            Assert.True(result);
            _strategyRepoMock.Verify(r => r.DeleteStrategyStaff(userId, staffId), Times.Once);
        }
        [Fact]
        public void BuildDefaultStrategyStaffsFromClient_WithValidClientData_ReturnsStaffList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var timelineList = new List<StrategyTimelineModel> { new StrategyTimelineModel { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }; 

            var securityUser = new SagittaStaffResponse
            {
                SagittaStaffId = "user123",
                isActive = true
            };

            var sagittaClient = new SagittaClientResponse
            {
                Producers = new List<SagittaStaffResponse>
            {
                new SagittaStaffResponse { SagittaStaffId = "prod1", isActive = true }
            },
                Servicers = new List<SagittaStaffResponse>
            {
                new SagittaStaffResponse { SagittaStaffId = "serv1", isActive = true, StaffIndex = 1 }
            },
                ServiceTeams = new List<SagittaStaffResponse>
            {
                new SagittaStaffResponse { SagittaStaffId = "team1", isActive = true, StaffServiceTeamTitle = "Marketing" }
            }
            };

            // Act
            var result = _service.BuildDefaultStrategyStaffsFromClient(strategyId, timelineList, securityUser, sagittaClient);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count > 0);
            Assert.All(result, staff => Assert.True(staff.IsAccessible));
        }


    }
}