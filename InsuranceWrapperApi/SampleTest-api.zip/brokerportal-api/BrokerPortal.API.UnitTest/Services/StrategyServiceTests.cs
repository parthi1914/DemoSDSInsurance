﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using BrokerPortal.API.RepositoryContracts.CustomDomain;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;

namespace BrokerPortal.API.UnitTest.Services
{
    public class StrategyServiceTests
    {

        private readonly Mock<IStrategyRepository> _mockStrategyRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<ITaskStackRepository> _mockTaskStackRepository;
        private readonly Mock<ILookupDataRepository> _mockLookupDataRepo;
        private readonly Mock<IMarketRepository> _mockMarketRepository;
        private readonly Mock<ISecurityUserRepository> _mockSecurityUserRepository;
        private readonly StrategyService _strategyService;
        private readonly Mock<IStrategyService> _mockStrategyService;

        public StrategyServiceTests()
        {
            _mockStrategyRepository = new Mock<IStrategyRepository>();
            _mockTaskStackRepository = new Mock<ITaskStackRepository>();
            _mockLookupDataRepo = new Mock<ILookupDataRepository>();
            _mockMarketRepository = new Mock<IMarketRepository>();
            _mockSecurityUserRepository = new Mock<ISecurityUserRepository>();
            _mockStrategyService = new Mock<IStrategyService>();

            _mockMapper = new Mock<IMapper>();
            _strategyService = new StrategyService(
                _mockStrategyRepository.Object,
                new Mock<ISagittaStaffRepository>().Object,
                _mockLookupDataRepo.Object, _mockTaskStackRepository.Object,
                _mockMarketRepository.Object, _mockSecurityUserRepository.Object,
                _mockMapper.Object
            );
        }

        [Fact]
        public async Task GetAllStrategies_ShouldReturnMappedStrategyResponses()
        {
            // Arrange
            var strategies = new List<Strategy>
        {
            new Strategy { StrategyClients = new List<StrategyClient> { new StrategyClient { SagittaClientId = 1000095 } } },
            new Strategy { StrategyClients = new List<StrategyClient> { new StrategyClient { SagittaClientId = 1000096 } } }
        };
            var strategyResponses = new List<StrategyModel>
        {
            new StrategyModel {  },
            new StrategyModel { }
        };

            _mockStrategyRepository.Setup(repo => repo.GetAllStrategies()).ReturnsAsync(strategies);
            _mockMapper.Setup(mapper => mapper.Map<List<StrategyModel>>(strategies)).Returns(strategyResponses);

            // Act
            var result = await _strategyService.GetAllStrategies();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyResponses.Count, result.Count);

        }

        [Fact]
        public async Task GetStrategyById_ShouldReturnEmptyStrategyResponse_WhenStrategyDoesNotExist()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(strategyId, true)).ReturnsAsync((Strategy)null);

            // Act
            var result = await _strategyService.GetStrategyById(strategyId, true);

            // Assert
            Assert.Null(result);

        }

        [Fact]
        public async Task GetStrategyById_ShouldReturnStrategyResponse_WhenStrategExist()
        {
            // Arrange
            var strategies = new Strategy
            {
                StrategyClients = new List<StrategyClient> { new StrategyClient { SagittaClientId = 1000095 } },

            };
            var strategyResponses = new StrategyModel();
            var strategyId = Guid.NewGuid();
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(strategyId, true)).ReturnsAsync(strategies);
            _mockMapper.Setup(mapper => mapper.Map<StrategyModel>(strategies)).Returns(strategyResponses);

            // Act
            var result = await _strategyService.GetStrategyById(strategyId, true);

            // Assert
            Assert.NotNull(result);

        }

        [Fact]
        public async Task GetStrategyByPlanId_ReturnsStrategyModel_WhenStrategyIdIsValid()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var expectedStrategy = new StrategyModel { StrategyId = strategyId };
            var strategies = new Strategy
            {
                StrategyClients = new List<StrategyClient> { new StrategyClient { SagittaClientId = 1000095 } },

            };
            var strategyResponse = new StrategyModel
            {
                StrategyId = strategyId,
                StrategyTimelines = new List<StrategyTimelineModel> { new StrategyTimelineModel { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } },
                Markets = new List<MarketModel>{ new MarketModel{   MarketId = Guid.NewGuid(),
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } }
            } }
            };
            var marketEntities = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } },
            new Market { MarketId = Guid.NewGuid(), StrategyId =  strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } }
        };

            _mockMarketRepository.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(marketEntities);
            _mockStrategyRepository.Setup(r => r.GetStrategyIdByPlanId(planId)).ReturnsAsync(strategyId);
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(strategyId, true)).ReturnsAsync(strategies);
            _mockStrategyService.Setup(s => s.GetStrategyById(strategyId, true)).ReturnsAsync(expectedStrategy);
            _mockMapper.Setup(mapper => mapper.Map<StrategyModel>(strategies)).Returns(strategyResponse);
            // Act
            var result = await _strategyService.GetStrategyByPlanId(planId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(strategyId, result.StrategyId);
        }

        [Fact]
        public async Task SaveStrategy_ShouldSaveAndReturnStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var strategyRequest = new StrategyRequest
            {
                SecurityUsers = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" }
            };

            var strategyEntity = new Strategy
            {
                StrategyId = strategyId
            };

            var expectedStrategyModel = new StrategyModel
            {
                StrategyId = strategyEntity.StrategyId
            };

            _mockStrategyRepository.Setup(r => r.SaveStrategy(strategyEntity))
                          .Returns(Task.FromResult(strategyEntity));
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(It.IsAny<Guid>(), true)).ReturnsAsync(strategyEntity);
            _mockMapper.Setup(mapper => mapper.Map<StrategyModel>(It.IsAny<Strategy>())).Returns(expectedStrategyModel);
            // Act
            var result = await _strategyService.SaveStrategy(strategyRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedStrategyModel, result);
        }
        [Fact]
        public async Task SaveStrategyWithTimelines_ShouldSaveAndReturnStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var strategyRequest = new StrategyRequest
            {
                PlanId = Guid.NewGuid(),
                SagittaClientId=123,
                SecurityUsers = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" },
                StrategyTimelines = new List<StrategyTimelinesRequest> { new StrategyTimelinesRequest { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }

            };

            var strategyEntity = new Strategy
            {
                StrategyId = strategyId
            };

            var expectedStrategyModel = new StrategyModel
            {
                StrategyId = strategyEntity.StrategyId
            };

            _mockStrategyRepository.Setup(r => r.SaveStrategy(strategyEntity))
                          .Returns(Task.FromResult(strategyEntity));
            _mockLookupDataRepo.Setup(r => r.GetAllStepDefsByFlowDef(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,StepName=AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } });
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(It.IsAny<Guid>(), true)).ReturnsAsync(strategyEntity);
            _mockMapper.Setup(mapper => mapper.Map<StrategyModel>(It.IsAny<Strategy>())).Returns(expectedStrategyModel);
            // Act
            var result = await _strategyService.SaveStrategy(strategyRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedStrategyModel, result);
        }
        [Fact]
        public async Task UpdateStrategy_ShouldUpdateAndReturnStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var strategyRequest = new StrategyRequest
            {
                SecurityUsers = new SecurityUserModel { SecurityUserId = securityUserId }
            };

            var existingStrategy = new Strategy
            {
                StrategyId = strategyId
            };

            var updatedStrategy = new Strategy
            {
                StrategyId = strategyId
            };

            var expectedStrategyModel = new StrategyModel
            {
                StrategyId = strategyId
            };
            var marketEntities = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } },
            new Market { MarketId = Guid.NewGuid(), StrategyId =  strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } }
        };
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdate(strategyId))
                          .ReturnsAsync(existingStrategy);

            _mockStrategyRepository.Setup(r => r.UpdateStrategy(updatedStrategy))
                          .Returns(Task.FromResult(strategyId));
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(It.IsAny<Guid>(), true)).ReturnsAsync(updatedStrategy);
            _mockMarketRepository.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(marketEntities);
            _mockMapper.Setup(mapper => mapper.Map<StrategyModel>(It.IsAny<Strategy>())).Returns(expectedStrategyModel);
            // Act
            var result = await _strategyService.UpdateStrategy(strategyId, strategyRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedStrategyModel.StrategyId, result.StrategyId);
        }
        [Fact]
        public async Task UpdateStrategyWithTimelines_ShouldUpdateAndReturnStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var strategyTimelineID = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var strategyRequest = new StrategyRequest
            {
                PlanId = Guid.NewGuid(),
                SagittaClientId = 123,
                SecurityUsers = new SecurityUserModel { SecurityUserId = securityUserId },
                StrategyTimelines = new List<StrategyTimelinesRequest> { new StrategyTimelinesRequest { StrategyTimelineId = strategyTimelineID, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } }
            };
            var plan = new Plan
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Test",
                StatusCodeId = "OPEN",
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST" }
                    }
                },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
            };
            var strategy = new Strategy
            {
                StrategyId = Guid.NewGuid(),
                IsDeleted = false,
                StrategyName = "test strategy",
                Plan = plan,
                StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient { IsDeleted = false, SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" } }
                },
                StrategyTimelines =  new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = strategyTimelineID, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } },
                StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff { IsDeleted = false, SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" } }
                },
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                UpdatedByNavigation = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" }
            };
            var existingStrategy =strategy;

            var updatedStrategy = new Strategy
            {
                StrategyId = strategyId
            };

            var expectedStrategyModel = new StrategyModel
            {
                StrategyId = strategyId
            };
            var marketEntities = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } },
            new Market { MarketId = Guid.NewGuid(), StrategyId =  strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } }
        };
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdate(strategyId))
                          .ReturnsAsync(existingStrategy);

            _mockStrategyRepository.Setup(r => r.UpdateStrategy(updatedStrategy))
                          .Returns(Task.FromResult(strategyId));
            _mockStrategyRepository.Setup(repo => repo.GetStrategyById(It.IsAny<Guid>(), true)).ReturnsAsync(updatedStrategy);
            _mockMarketRepository.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(marketEntities);
            _mockMapper.Setup(mapper => mapper.Map<StrategyModel>(It.IsAny<Strategy>())).Returns(expectedStrategyModel);
            // Act
            var result = await _strategyService.UpdateStrategy(strategyId, strategyRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedStrategyModel.StrategyId, result.StrategyId);
        }

        [Fact]
        public async Task UpdateStrategyTimelines_ShouldUpdateAndReturnMappedTimelines()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var currentDateTime = DateTime.Now;

            var strategyTimelineRequests = new List<StrategyTimelinesRequest>
        {
            new StrategyTimelinesRequest { /* populate with test data */ }
        };

            var existingTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline { /* populate with test data */ }
        };

            var updatedTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline { /* updated version */ }
        };

            var expectedTimelineModels = new List<StrategyTimelineModel>
        {
            new StrategyTimelineModel { /* mapped model */ }
        };

            var existingStrategy = new Strategy
            {
                StrategyId = strategyId,
                StrategyTimelines = existingTimelines
            };
            var marketEntities = new List<Market>
{
    new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } },
    new Market { MarketId = Guid.NewGuid(), StrategyId =  strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } }
};
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdate(strategyId))
                          .ReturnsAsync(existingStrategy);
            _mockMarketRepository.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(marketEntities);
            _mockStrategyRepository.Setup(r => r.UpdateStrategy(It.IsAny<Strategy>()))
                          .Returns(Task.FromResult(strategyId));

            _mockMapper.Setup(m => m.Map<List<StrategyTimelineModel>>(It.IsAny<List<StrategyTimeline>>()))
                      .Returns(expectedTimelineModels);
            // Act
            var result = await _strategyService.UpdateStrategyTimelines(strategyId, securityUserId, strategyTimelineRequests);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedTimelineModels.Count, result.Count);
        }

        [Fact]
        public async Task UpdateStrategyTimelinesWithAssignments_ShouldUpdateAndReturnMappedTimelines()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var strategyTimelineId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var currentDateTime = DateTime.Now;

            var strategyTimelineRequests = new List<StrategyTimelinesRequest>
        {
            new StrategyTimelinesRequest {StrategyId=strategyId ,StrategyTimelineId=strategyTimelineId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION}
        };

            var existingTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline { StrategyTimelineId = strategyTimelineId, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } 
        };

            var updatedTimelines = new List<StrategyTimeline>
        {
           new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } 
        };

            var expectedTimelineModels = new List<StrategyTimelineModel>
        {
           new StrategyTimelineModel { StrategyTimelineId = Guid.NewGuid(), StatusCodeId=AppConstants.STEP_STATUSCODE_ACTIVE, StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } 
        };

            var existingStrategy = new Strategy
            {
                StrategyId = strategyId,
                StrategyTimelines = existingTimelines,
                StrategyTaskMeta = new List<StrategyTaskMeta> { new StrategyTaskMeta
{
    StrategyTaskId = Guid.NewGuid(),
    StrategyId = Guid.NewGuid(),
    StrategyTimelineId = Guid.NewGuid(),
    TaskStackId = Guid.NewGuid(),
    CreatedBy = "creator_user",
    CreatedDate = DateTime.UtcNow.AddDays(-15),
    UpdatedBy = "updater_user",
    UpdatedDate = DateTime.UtcNow,
    IsDeleted = false,
    Strategy = new Strategy
    {
        StrategyId = Guid.NewGuid(),
        StrategyName = "Growth Strategy 2025"
    },
    StrategyTimeline = new StrategyTimeline
    {
        StrategyTimelineId = Guid.NewGuid(),

    },
    TaskStack = new TaskStack
    {
        TaskStackId = Guid.NewGuid(),


    }
}},
                MarketTimelines= new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid() } }
            };
            var marketEntities = new List<Market>
{
    new Market { MarketId = Guid.NewGuid(), StrategyId = strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } },
    new Market { MarketId = Guid.NewGuid(), StrategyId =  strategyId,MarketTimelines=new  List<MarketTimeline> { new MarketTimeline{MarketTimelineId=Guid.NewGuid()} } }
};
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdate(strategyId))
                          .ReturnsAsync(existingStrategy);
            _mockMarketRepository.Setup(r => r.GetAllMarketByStrategy(strategyId)).Returns(marketEntities);
            _mockStrategyRepository.Setup(r => r.UpdateStrategy(It.IsAny<Strategy>()))
                          .Returns(Task.FromResult(strategyId));

            _mockMapper.Setup(m => m.Map<List<StrategyTimelineModel>>(It.IsAny<List<StrategyTimeline>>()))
                      .Returns(expectedTimelineModels);
            // Act
            var result = await _strategyService.UpdateStrategyTimelines(strategyId, securityUserId, strategyTimelineRequests);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedTimelineModels.Count, result.Count);
        }

        [Fact]
        public async Task RemoveStrategy_ShouldCallRepositoryAndReturnResult()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var expectedResult = true;
            _mockStrategyRepository.Setup(r => r.RemoveStrategy(strategyId, securityUserId))
                          .ReturnsAsync(expectedResult);

            // Act
            var result = await _strategyService.RemoveStrategy(strategyId, securityUserId);

            // Assert
            Assert.Equal(expectedResult, result);
            _mockStrategyRepository.Verify(r => r.RemoveStrategy(strategyId, securityUserId), Times.Once);
        }
        [Fact]
        public async Task ArchiveStrategy_ShouldCallRepositoryAndReturnResult()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var expectedResult = true;
            _mockStrategyRepository.Setup(r => r.ArchiveStrategy(strategyId, securityUserId))
                          .ReturnsAsync(expectedResult);

            // Act
            var result = await _strategyService.ArchiveStrategy(strategyId, securityUserId);

            // Assert
            Assert.Equal(expectedResult, result);
            _mockStrategyRepository.Verify(r => r.ArchiveStrategy(strategyId, securityUserId), Times.Once);
        }
        [Fact]
        public async Task SyncStrategyForMarkets_ShouldSyncAndReturnTrue()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var strategyEntity = new Strategy { StrategyId = strategyId, StatusCode = new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE }, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var marketList = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(),StatusCode=new BpstatusCode {StatusCode= AppConstants.STEP_STATUSCODE_ACTIVE,StatusCodeId= AppConstants.STEP_STATUSCODE_ACTIVE,StatusGroupCode=AppConstants.STEP_STATUSCODE_ACTIVE }  , StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, StatusCodeId=AppConstants.STEP_STATUSCODE_ACTIVE, StatusCode= new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE } } } },

        };

            var stepDefs = new List<StepDef> { new StepDef() };
            var subStepDefs = new List<SubStepDef> { new SubStepDef() };
            var bpStatusCodes = new List<BpstatusCode> { new BpstatusCode() };
            var taskStatusCodes = new List<TaskStatusCode> { new TaskStatusCode() };
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdateToSyncMarketChanges(strategyId))
                          .ReturnsAsync(strategyEntity);

            _mockMarketRepository.Setup(m => m.GetMarketsForStrategySyncByStrategy(strategyId))
                          .ReturnsAsync(marketList);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockStrategyRepository.Setup(r => r.UpdateStrategy(strategyEntity))
                          .Returns(Task.FromResult(strategyId));

            // Act
            var result = await _strategyService.SyncStrategyForMarkets(strategyId, securityUserId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task SyncStrategyForMarkets_StepTimeline_ShouldSyncAndReturnTrue()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var strategyEntity = new Strategy { StrategyId = strategyId, StatusCode = new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_INITIALIZE }, StatusCodeId = AppConstants.STEP_STATUSCODE_INITIALIZE, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } } };
            var marketList = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(),StatusCodeId=AppConstants.STEP_STATUSCODE_INITIALIZE, StatusCode=new BpstatusCode {StatusCode= AppConstants.STEP_STATUSCODE_INITIALIZE,StatusCodeId= AppConstants.STEP_STATUSCODE_INITIALIZE,StatusGroupCode=AppConstants.STEP_STATUSCODE_INITIALIZE }  , StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, StatusCodeId=AppConstants.STEP_STATUSCODE_INITIALIZE, StatusCode= new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_INITIALIZE, StatusGroupCode = AppConstants.STEP_STATUSCODE_INITIALIZE } } } },

        };

            var stepDefs = new List<StepDef> { new StepDef() };
            var subStepDefs = new List<SubStepDef> { new SubStepDef() };
            var bpStatusCodes = new List<BpstatusCode> { new BpstatusCode() };
            var taskStatusCodes = new List<TaskStatusCode> { new TaskStatusCode() };
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdateToSyncMarketChanges(strategyId))
                          .ReturnsAsync(strategyEntity);

            _mockMarketRepository.Setup(m => m.GetMarketsForStrategySyncByStrategy(strategyId))
                          .ReturnsAsync(marketList);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_INITIALIZE, StatusGroupCode = AppConstants.STEP_STATUSCODE_INITIALIZE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockStrategyRepository.Setup(r => r.UpdateStrategy(strategyEntity))
                          .Returns(Task.FromResult(strategyId));

            // Act
            var result = await _strategyService.SyncStrategyForMarkets(strategyId, securityUserId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task SyncStrategyForMarkets_Updates_ShouldSyncAndReturnTrue()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            var strategyEntity = new Strategy { StrategyId = strategyId, StatusCode = new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE }, StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StrategyTimelines = new List<StrategyTimeline> { new StrategyTimeline { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION,StrategyTaskMeta=new List<StrategyTaskMeta> { new StrategyTaskMeta
{
    StrategyTaskId = Guid.NewGuid(),
    StrategyId = Guid.NewGuid(),
    StrategyTimelineId = Guid.NewGuid(),
    TaskStackId = Guid.NewGuid(),
    CreatedBy = "creator_user",
    CreatedDate = DateTime.UtcNow.AddDays(-15),
    UpdatedBy = "updater_user",
    UpdatedDate = DateTime.UtcNow,
    IsDeleted = false,
    Strategy = new Strategy
    {
        StrategyId = Guid.NewGuid(),
        StrategyName = "Growth Strategy 2025"
    },
    StrategyTimeline = new StrategyTimeline
    {
        StrategyTimelineId = Guid.NewGuid(),

    },
    TaskStack = new TaskStack
    {
        TaskStackId = Guid.NewGuid(),
        TaskMeta= new List<TaskMeta>{ new TaskMeta{TaskMetaId=Guid.NewGuid()} }


    },
}} } } };
            var marketList = new List<Market>
        {
            new Market { MarketId = Guid.NewGuid(),StatusCode=new BpstatusCode {StatusCode= AppConstants.STEP_STATUSCODE_ACTIVE,StatusCodeId= AppConstants.STEP_STATUSCODE_ACTIVE,StatusGroupCode=AppConstants.STEP_STATUSCODE_ACTIVE }  , StrategyId = strategyId, MarketTimelines = new List<MarketTimeline> { new MarketTimeline { MarketTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, StatusCodeId=AppConstants.STEP_STATUSCODE_ACTIVE, StatusCode= new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE } } } },

        };

            var stepDefs = new List<StepDef> { new StepDef() };
            var subStepDefs = new List<SubStepDef> { new SubStepDef() };
            var bpStatusCodes = new List<BpstatusCode> { new BpstatusCode() };
            var taskStatusCodes = new List<TaskStatusCode> { new TaskStatusCode() };
            _mockStrategyRepository.Setup(r => r.GetStrategyForUpdateToSyncMarketChanges(strategyId))
                          .ReturnsAsync(strategyEntity);

            _mockMarketRepository.Setup(m => m.GetMarketsForStrategySyncByStrategy(strategyId))
                          .ReturnsAsync(marketList);
            _mockLookupDataRepo.Setup(r => r.GetSortedStepsByStrategyFlow(It.IsAny<string>())).Returns(new List<StepDef>() { new StepDef { StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION, IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllSubStepDefs()).Returns(new List<SubStepDef>() { new SubStepDef { SubStepDefId = "101", IsValidForTaskAutoClose = false } });
            _mockLookupDataRepo.Setup(r => r.GetAllBPStatusCodes()).Returns(new List<BpstatusCode>() { new BpstatusCode { StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE, StatusGroupCode = AppConstants.STEP_STATUSCODE_ACTIVE } });
            _mockLookupDataRepo.Setup(r => r.GetAllTaskStatusCodes()).Returns(new List<TaskStatusCode>() { new TaskStatusCode { TaskStatusCodeId = AppConstants.TASK_STATUS_CODE_OPEN } });

            _mockStrategyRepository.Setup(r => r.UpdateStrategy(strategyEntity))
                          .Returns(Task.FromResult(strategyId));

            // Act
            var result = await _strategyService.SyncStrategyForMarkets(strategyId, securityUserId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task SearchStrategies_WithActiveStatus_ReturnsMappedStrategies()
        {
            // Arrange
            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { AppConstants.STEP_STATUSGROUPCODE_ACTIVE }
            };

            var expectedStatusCodes = new List<string> { "ACTI" };
            var strategyEntities = new List<Strategy>
        {
            new Strategy { StrategyId = Guid.NewGuid() }
        };

            var mappedModels = new List<StrategyModel>
        {
            new StrategyModel()
        };

            _mockLookupDataRepo
                .Setup(x => x.GetAllBPStatusCodesIdsByGroupCode(AppConstants.STEP_STATUSGROUPCODE_ACTIVE))
                .Returns(expectedStatusCodes);

            _mockStrategyRepository
                .Setup(x => x.SearchStrategies(It.IsAny<SearchBaseFilterType>(), It.IsAny<StrategySearchType>(), It.IsAny<StrategySearchCriterias>(), It.IsAny<string>(), It.IsAny<string[]>(), It.IsAny<string>()))
                .ReturnsAsync(strategyEntities);

            _mockMarketRepository
                .Setup(x => x.GetAllMarketByStrategies(It.IsAny<List<Guid>>()))
                .Returns(new List<Market>());

            _mockMapper
                .Setup(x => x.Map<List<StrategyModel>>(strategyEntities))
                .Returns(mappedModels);

            // Act
            var result = await _strategyService.SearchStrategies(
                SearchBaseFilterType.ALL,
                StrategySearchType.ALL,
                searchCriterias,
                "user123",
                "client456"
            );

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }

        [Fact]
        public async Task SearchStrategies_MapAssignment_WithActiveStatus_ReturnsMappedStrategies()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var timelineId = Guid.NewGuid();
            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { AppConstants.STEP_STATUSGROUPCODE_ACTIVE }
            };

            var expectedStatusCodes = new List<string> { "ACTI" };
            var staffTimelines = new List<StepTimelineStaffAssignment> { new StepTimelineStaffAssignment { StepTimelineId = timelineId } };
            var staffModels = new List<StepTimelineStaffAssignmentModel> { new StepTimelineStaffAssignmentModel { StepTimelineId = timelineId } };
            var strategyEntities = new List<Strategy>
        {
            new Strategy { StrategyId = strategyId }
        };

            var mappedModels = new List<StrategyModel>
        {
            new StrategyModel
            {
                StrategyId = strategyId,
                StrategyTimelines = new List<StrategyTimelineModel> { new StrategyTimelineModel { StrategyTimelineId = Guid.NewGuid(), StepDefId = AppConstants.STRATEGY_STEP_STEPDEFID_SUBMISSION } },
                Markets = new List<MarketModel>{ new MarketModel{   MarketId = Guid.NewGuid(),
                StrategyId = strategyId,
                MarketTimelines = new List<MarketTimelineModel> { new MarketTimelineModel { MarketTimelineId = Guid.NewGuid() } }
            } }
            }
        };

            _mockLookupDataRepo
                .Setup(x => x.GetAllBPStatusCodesIdsByGroupCode(AppConstants.STEP_STATUSGROUPCODE_ACTIVE))
                .Returns(expectedStatusCodes);

            _mockStrategyRepository
                .Setup(x => x.SearchStrategies(It.IsAny<SearchBaseFilterType>(), It.IsAny<StrategySearchType>(), It.IsAny<StrategySearchCriterias>(), It.IsAny<string>(), It.IsAny<string[]>(), It.IsAny<string>()))
                .ReturnsAsync(strategyEntities);

            _mockTaskStackRepository
                .Setup(x => x.GetStaffAssignedByStrategyAndMarketsTimelines(It.IsAny<List<Guid>>()))
                .Returns(staffTimelines);
            _mockMarketRepository
                .Setup(x => x.GetAllMarketByStrategies(It.IsAny<List<Guid>>()))
                .Returns(new List<Market>());

            _mockMapper
                .Setup(x => x.Map<List<StepTimelineStaffAssignmentModel>>(It.IsAny<List<StepTimelineStaffAssignment>>()))
                .Returns(staffModels);
            _mockMapper
                .Setup(x => x.Map<List<StrategyModel>>(strategyEntities))
                .Returns(mappedModels);

            // Act
            var result = await _strategyService.SearchStrategies(
                SearchBaseFilterType.ALL,
                StrategySearchType.ALL,
                searchCriterias,
                "user123",
                "client456"
            );

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }
        [Fact]
        public async Task GetStrategyClientId_ValidStrategyId_ReturnsClientId()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var expectedClientId = "Client123";

            _mockStrategyRepository
                .Setup(repo => repo.GetStrategyClientId(strategyId))
                .ReturnsAsync(expectedClientId);

            // Act
            var result = await _strategyService.GetStrategyClientId(strategyId);

            // Assert
            Assert.Equal(expectedClientId, result);
        }
        [Fact]
        public async Task GetStrategyTimelines_WithValidStrategyId_ReturnsMappedList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var entityList = new List<StrategyTimeline>
        {
            new StrategyTimeline()
        };
            var modelList = new List<StrategyTimelineModel>
        {
            new StrategyTimelineModel()
        };

            _mockStrategyRepository
                .Setup(repo => repo.GetStrategyTimelines(strategyId))
                .ReturnsAsync(entityList);

            _mockMapper
                .Setup(mapper => mapper.Map<List<StrategyTimelineModel>>(entityList))
                .Returns(modelList);

            // Act
            var result = await _strategyService.GetStrategyTimelines(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(modelList.Count, result.Count);
        }

    }
}
