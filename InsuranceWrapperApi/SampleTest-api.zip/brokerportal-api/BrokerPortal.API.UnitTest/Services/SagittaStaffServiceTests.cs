﻿using Xunit;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Services;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using Moq.Protected;
using System.Net.Http.Json;
using System.Net;
namespace BrokerPortal.API.UnitTest.Services
{
    public class SagittaStaffServiceTests
    {
        private readonly Mock<IConfiguration> _mockConfig = new();
        private readonly Mock<ISagittaStaffRepository> _mockRepository = new();
        private readonly Mock<ISecurityUserRepository> _mockSecurityUserRepo = new();
        private readonly Mock<IMapper> _mockMapper = new();
        private readonly RestServiceClient _mockRestService;
        private readonly SagittaStaffService _service;

        public SagittaStaffServiceTests()
        {
            var handlerMock = new Mock<HttpMessageHandler>();
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(req =>
                        (req.Method == HttpMethod.Get || req.Method == HttpMethod.Post) &&
                        req.RequestUri.ToString() == "http://test/api/sagitta/repl/staffs/GetStaffByIds"),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = JsonContent.Create(new List<SagittaReplStaffModel> {new SagittaReplStaffModel { StaffId = "id1" } })
                });
            handlerMock
               .Protected()
               .Setup<Task<HttpResponseMessage>>(
                   "SendAsync",
                   ItExpr.Is<HttpRequestMessage>(req =>
                       (req.Method == HttpMethod.Get || req.Method == HttpMethod.Post) &&
                       req.RequestUri.ToString() == "http://test/api/sagitta/repl/staffs/123"),
                   ItExpr.IsAny<CancellationToken>())
               .ReturnsAsync(new HttpResponseMessage
               {
                   StatusCode = HttpStatusCode.OK,
                   Content = JsonContent.Create(new SagittaReplStaffModel { StaffId = "123", } )
               });
            handlerMock
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.Is<HttpRequestMessage>(req =>
                    (req.Method == HttpMethod.Get || req.Method == HttpMethod.Post) &&
                    req.RequestUri.ToString() == "http://test/api/sagitta/repl/staffs/findmatches/employees/emp456"),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = JsonContent.Create(new List<SagittaReplStaffModel> { new SagittaReplStaffModel { StaffId = "id1" } })
            });

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test/")
            };
            _mockRestService = new RestServiceClient(httpClient);
            _service = new SagittaStaffService(_mockConfig.Object, _mockRepository.Object,
                _mockSecurityUserRepo.Object, _mockMapper.Object, _mockRestService);
        }
        
        [Fact]
        public async Task BulkSaveFromReplByIdsIfNotExists_ReturnsEmpty_WhenIdsAreNull()
        {
            var result = await _service.BulkSaveFromReplByIdsIfNotExists("user1", "token", null);
            Assert.Empty(result);
        }

        [Fact]
        public async Task BulkSaveFromReplByIdsIfNotExists_ReturnsExisting_WhenAllExist()
        {
            
            var ids = new List<string> { "id1" };
            var existing = new List<SagittaStaff> { new() { SagittaStaffId = "id1" } };

            _mockRepository.Setup(r => r.GetSagittaStaffsByIds(It.IsAny<string[]>()))
                .Returns(existing);
            _mockMapper.Setup(m => m.Map<List<SagittaStaffModel>>(It.IsAny<List<SagittaStaff>>()))
                .Returns(new List<SagittaStaffModel> { new() });

            var result = await _service.BulkSaveFromReplByIdsIfNotExists("user1", "token", ids);
            Assert.Single(result);
        }
        
        [Fact]
        public async Task BulkSaveFromReplByIdsIfNotExists_MergesNew_WhenSomeDoNotExist()
        {
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");
            var ids = new List<string> { "id1", "id2" };
            var existing = new List<SagittaStaff> { new() { SagittaStaffId = "id1" } };
            var replResponse = new List<SagittaStaffResponse> { new() };
            var newStaff = new List<SagittaStaff> { new() };

            _mockRepository.Setup(r => r.GetSagittaStaffsByIds(It.IsAny<string[]>()))
                .Returns(existing);
            _mockRepository.Setup(r => r.BulkMerge(It.IsAny<List<SagittaStaff>>()))
                .ReturnsAsync(newStaff);
            _mockMapper.Setup(m => m.Map<List<SagittaStaffModel>>(It.IsAny<List<SagittaStaff>>()))
                .Returns(new List<SagittaStaffModel> { new(), new() });
            _mockMapper.Setup(m => m.Map<List<SagittaStaffResponse>>(It.IsAny<List<SagittaReplStaffModel>>()))
              .Returns(new List<SagittaStaffResponse> { new(), new() });

            var result = await _service.BulkSaveFromReplByIdsIfNotExists("user1", "token", ids);
            Assert.Equal(2, result.Count);
        }
        [Fact]
        public async Task BulkMergeSagittaStaffs_ShouldMergeAndReturnMappedStaffs()
        {
            var securityUserId = "user123";
            var sagittaStaffRequests = new List<SagittaStaffRequest>
    {
        new SagittaStaffRequest
        {
            SagittaStaffId = "STF001",
            StaffCode = "SC001",
            StaffName = "John Doe",
            StaffTitle = "Manager",
            StaffEmail = "john@example.com",
            IsDatedOff = false,
            UserId = "USR001",
            StaffEmpCode = "EMP001",
            StaffNetworkId = "NET001",
            City = "Chennai",
            DatedOffDate = null
        }
    };

            var existingStaffs = new List<SagittaStaff>(); // Simulate no existing staff
            _mockRepository.Setup(r => r.GetSagittaStaffsByIds(It.IsAny<string[]>()))
                          .Returns(existingStaffs);

            _mockRepository.Setup(r => r.BulkMerge(It.IsAny<List<SagittaStaff>>()))
                          .Returns(Task.FromResult(new List<SagittaStaff>()));

            var mappedResult = new List<SagittaStaffModel>
    {
        new SagittaStaffModel { SagittaStaffId = "STF001", StaffName = "John Doe" }
    };

            _mockMapper.Setup(m => m.Map<List<SagittaStaffModel>>(It.IsAny<List<SagittaStaff>>()))
                      .Returns(mappedResult);

            // Act
            var result = await _service.BulkMergeSagittaStaffs(securityUserId, sagittaStaffRequests);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal("STF001", result[0].SagittaStaffId);
            Assert.Equal("John Doe", result[0].StaffName);
        }

        [Fact]
        public async Task BulkMergeSagittaStaffsFromReplResponse_ShouldMapAndCallBulkMerge()
        {
    

            var securityUserId = "user123";
            var replStaffModels = new List<SagittaReplStaffModel>
    {
        new SagittaReplStaffModel { StaffId = "STF001", StaffName = "John Doe" }
    };

            var mappedRequests = new List<SagittaStaffRequest>
    {
        new SagittaStaffRequest { SagittaStaffId = "STF001", StaffName = "John Doe" }
    };

            var expectedResponse = new List<SagittaStaffModel>
    {
        new SagittaStaffModel { SagittaStaffId = "STF001", StaffName = "John Doe" }
    };

            _mockMapper.Setup(m => m.Map<List<SagittaStaffRequest>>(It.IsAny<List<SagittaReplStaffModel>>()))
                      .Returns(mappedRequests);
            //_service.Setup(s => s.BulkMergeSagittaStaffs(securityUserId, mappedRequests))
            //           .ReturnsAsync(expectedResponse);

            // Act
            var result = await _service.BulkMergeSagittaStaffsFromReplResponse(securityUserId, replStaffModels);

            // Assert
            Assert.Null(result);
            //Assert.Single(result);
            //Assert.Equal("STF001", result[0].SagittaStaffId);
            //Assert.Equal("John Doe", result[0].StaffName);
        }
        [Fact]
        public async Task UpsertSagittaStaff_UpdatesExistingStaff_WhenChangesDetected()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var request = new SagittaStaffRequest { SagittaStaffId = "S001" };
            var existingEntity = new SagittaStaff { SagittaStaffId = "S001" };
            var updatedEntity = new SagittaStaff { SagittaStaffId = "S001", UpdatedBy = securityUserId };
            var expectedModel = new SagittaStaffModel();

            _mockRepository.Setup(r => r.GetSagittaStaffById("S001")).ReturnsAsync(existingEntity);
          //  _service.Setup(s => s.IsAnyChangeDetectedSagittaStaff(request, existingEntity)).Returns(true);
            _mockRepository.Setup(r => r.UpdateSagittaStaff(It.IsAny<SagittaStaff>())).ReturnsAsync(updatedEntity);
            _mockMapper.Setup(m => m.Map<SagittaStaffModel>(It.IsAny<SagittaStaff>())).Returns(expectedModel);

            // Act
            var result = await _service.UpsertSagittaStaff(securityUserId, request);

            // Assert
            Assert.Equal(expectedModel, result);
        }
        [Fact]
        public async Task UpsertSagittaStaff_InsertsNewStaff_WhenNotExists()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var request = new SagittaStaffRequest
            {
                SagittaStaffId = "S002",
                StaffCode = "SC001",
                StaffName = "John Doe"
            };
            var newEntity = new SagittaStaff { SagittaStaffId = "S002" };
            var expectedModel = new SagittaStaffModel();

            _mockRepository.Setup(r => r.GetSagittaStaffById("S002")).ReturnsAsync((SagittaStaff)null);
            _mockRepository.Setup(r => r.SaveSagittaStaff(It.IsAny<SagittaStaff>())).ReturnsAsync(newEntity);
            _mockMapper.Setup(m => m.Map<SagittaStaffModel>(It.IsAny<SagittaStaff>())).Returns(expectedModel);

            // Act
            var result = await _service.UpsertSagittaStaff(securityUserId, request);

            // Assert
            Assert.Equal(expectedModel, result);
        }
        [Fact]
        public async Task GetSagittaStaffIdsBySecurityUserId_ReturnsList_WhenSecurityUserIdIsValid()
        {
            // Arrange
            var userId = "balabharathi.s@mcgriff.com";
            var expectedList = new List<string> { "ID1", "ID2" };

            _mockSecurityUserRepo
                .Setup(r => r.GetSecurityUserMapExternalSystemUserIds(userId, AppConstants.EXTERNAL_SYS_SAGITTA))
                .ReturnsAsync(expectedList);

            // Act
            var result = await _service.GetSagittaStaffIdsBySecurityUserId(userId);

            // Assert
            Assert.Equal(expectedList, result);
            _mockSecurityUserRepo.Verify(r => r.GetSecurityUserMapExternalSystemUserIds(userId, AppConstants.EXTERNAL_SYS_SAGITTA), Times.Once);
        }

        [Fact]
        public async Task GetSagittaStaffFromRepl_ReturnsMappedResponse_WhenValidResponse()
        {
            // Arrange
            var accessToken = "token";
            var staffId = "123";
            var replModel = new SagittaReplStaffModel { StaffId = "123" };
            var expectedResponse = new SagittaStaffResponse();
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");

            _mockMapper
                .Setup(m => m.Map<SagittaStaffResponse>(It.IsAny<SagittaReplStaffModel>()))
                .Returns(expectedResponse);

            // Act
            var result = await _service.GetSagittaStaffFromRepl(accessToken, staffId);

            // Assert
            Assert.Equal(expectedResponse, result);
        }
        [Fact]
        public async Task GetSagittaStaffByIdsFromRepl_ReturnsMappedList_WhenValidInput()
        {
            // Arrange
            var accessToken = "token";
            var staffIds = new[] { "id1", "id2" };
            var expectedResponse = new List<SagittaStaffResponse>
        {
            new SagittaStaffResponse(),
            new SagittaStaffResponse()
        };
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");
            _mockMapper
                .Setup(m => m.Map<List<SagittaStaffResponse>>(It.IsAny<List<SagittaReplStaffModel>>()))
                .Returns(expectedResponse);

            // Act
            var result = await _service.GetSagittaStaffByIdsFromRepl(accessToken, staffIds);

            // Assert
            Assert.Equal(expectedResponse, result);
        }


        [Fact]
        public void GetSagittaStaffsByIds_ReturnsExpectedList()
        {
            // Arrange
            var staffIds = new[] { "id1", "id2" };
            var expectedStaffs = new List<SagittaStaff>
        {
            new SagittaStaff { SagittaStaffId = "id1", StaffName = "John" },
            new SagittaStaff { SagittaStaffId = "id2", StaffName = "Jane" }
        };

            _mockRepository
                .Setup(r => r.GetSagittaStaffsByIds(staffIds))
                .Returns(expectedStaffs);

            // Act
            var result = _service.GetSagittaStaffsByIds(staffIds);

            // Assert
            Assert.Equal(expectedStaffs, result);
            _mockRepository.Verify(r => r.GetSagittaStaffsByIds(staffIds), Times.Once);
        }
        [Fact]
        public async Task GetMappedSagittaStaffsFromReplBySecurityUserEmployeeId_ReturnsList_WhenInputsAreValid()
        {
            // Arrange
            var accessToken = "token";
            var securityUserId = "balabharathi.s@mcgriff.com";
            var employeeId = "emp456";
            
            var expectedList = new List<SagittaReplStaffModel>
        {
            new SagittaReplStaffModel { StaffId = "id1" }
        };
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfig.Setup(c => c.GetSection("SagittaURL")).Returns(mockSection.Object);
            mockSection.Setup(s => s.Value).Returns("http://test/");

            // Act
            var result = await _service.GetMappedSagittaStaffsFromReplBySecurityUserEmployeeId(accessToken, securityUserId, employeeId);

            // Assert
            Assert.Equal(expectedList?.SingleOrDefault()?.StaffId, result?.SingleOrDefault()?.StaffId);
        }


    }
}
