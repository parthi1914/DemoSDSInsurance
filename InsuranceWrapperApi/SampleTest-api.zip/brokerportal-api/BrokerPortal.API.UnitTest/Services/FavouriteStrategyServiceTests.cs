﻿using AutoMapper;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.Repositories.DBContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using BrokerPortal.API.RepositoryContracts.Views;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.UnitTest.Services
{
    public class FavouriteStrategyServiceTests
    {
        private readonly Mock<IFavouriteStrategyRepository> _mockRepository;
        private readonly Mock<ISagittaStaffRepository> _mockSagittaStaffRepository;
        private readonly Mock<ISecurityUserRepository> _mockSecurityUserRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly FavouriteStrategyService _service;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public FavouriteStrategyServiceTests()
        {
            _mockRepository = new Mock<IFavouriteStrategyRepository>();
            _mockSagittaStaffRepository = new Mock<ISagittaStaffRepository>();
            _mockMapper = new Mock<IMapper>();
            _mockSecurityUserRepository = new Mock<ISecurityUserRepository>();
            _service = new FavouriteStrategyService(_mockRepository.Object, _mockSagittaStaffRepository.Object,_mockSecurityUserRepository.Object, _mockMapper.Object);
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
       .UseInMemoryDatabase(databaseName: "TestDatabase")
        .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
        .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
        }

        [Fact]
        public async Task GetAllFavouriteStrategies_ReturnsMappedFavouriteStrategyModels_WhenEntitiesExist()
        {
            // Arrange
            var entityList = new List<FavouriteStrategy>
        {
            new FavouriteStrategy (),
            new FavouriteStrategy ()
        };
            var modelList = new List<FavouriteStrategyModel>
        {
            new FavouriteStrategyModel (),
            new FavouriteStrategyModel ()
        };

            _mockRepository.Setup(repo => repo.GetAllFavouriteStrategies()).ReturnsAsync(entityList);
            _mockMapper.Setup(mapper => mapper.Map<List<FavouriteStrategyModel>>(entityList)).Returns(modelList);

            // Act
            var result = await _service.GetAllFavouriteStrategies();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(modelList.Count, result.Count);
            _mockRepository.Verify(repo => repo.GetAllFavouriteStrategies(), Times.Once);
            _mockMapper.Verify(mapper => mapper.Map<List<FavouriteStrategyModel>>(entityList), Times.Once);
        }

        [Fact]
        public async Task GetFavouriteStrategyById_ReturnsMappedFavouriteStrategyModel_WhenEntityExists()
        {
            // Arrange
            var favoriteStrategyId = Guid.NewGuid();
            var entity = new FavouriteStrategy();
            var model = new FavouriteStrategyModel();

            _mockRepository.Setup(repo => repo.GetFavouriteStrategyById(favoriteStrategyId)).ReturnsAsync(entity);
            _mockMapper.Setup(mapper => mapper.Map<FavouriteStrategyModel>(entity)).Returns(model);

            // Act
            var result = await _service.GetFavouriteStrategyById(favoriteStrategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(model, result);
            _mockRepository.Verify(repo => repo.GetFavouriteStrategyById(favoriteStrategyId), Times.Once);
            _mockMapper.Verify(mapper => mapper.Map<FavouriteStrategyModel>(entity), Times.Once);
        }
        [Fact]
        public async Task GetFavouriteStrategyById_WithStrategy_WhenEntityExists()
        {
            // Arrange
            var favoriteStrategyId = Guid.NewGuid();
            var entity = new FavouriteStrategy { Strategy = new Strategy { StrategyId=Guid.NewGuid(),Plan=new Plan { PlanName = "TEST", PlanClients = new List<PlanClient> { new PlanClient { PlanClientId = Guid.NewGuid(),SagittaClient=new SagittaClient { SagittaClientId=1007,ClientName="Test",ClientCode="1007"} } } } } };
            var model = new FavouriteStrategyModel();

            _mockRepository.Setup(repo => repo.GetFavouriteStrategyById(favoriteStrategyId)).ReturnsAsync(entity);
            _mockMapper.Setup(mapper => mapper.Map<FavouriteStrategyModel>(entity)).Returns(model);

            // Act
            var result = await _service.GetFavouriteStrategyById(favoriteStrategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(model, result);
            _mockRepository.Verify(repo => repo.GetFavouriteStrategyById(favoriteStrategyId), Times.Once);
            _mockMapper.Verify(mapper => mapper.Map<FavouriteStrategyModel>(entity), Times.Once);
        }

        [Fact]
        public async Task GetFavouriteStrategyById_ReturnsEmptyModel_WhenEntityDoesNotExist()
        {
            // Arrange
            var favoriteStrategyId = Guid.NewGuid();
            _mockRepository.Setup(repo => repo.GetFavouriteStrategyById(favoriteStrategyId)).ReturnsAsync((FavouriteStrategy)null);

            // Act
            var result = await _service.GetFavouriteStrategyById(favoriteStrategyId);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<FavouriteStrategyModel>(result);
            _mockRepository.Verify(repo => repo.GetFavouriteStrategyById(favoriteStrategyId), Times.Once);
            _mockMapper.Verify(mapper => mapper.Map<FavouriteStrategyModel>(It.IsAny<FavouriteStrategy>()), Times.Never);
        }


        [Fact]
        public async Task SaveFavouriteStrategy_ReturnsNull_WhenEntityIsNotSaved()
        {
            // Arrange
            var securityUserId = "test-user-id";
            var favouriteStrategyRequest = new FavouriteStrategyRequest
            {
                StrategyId = Guid.NewGuid()
            };
            _mockRepository.Setup(repo => repo.SaveFavouriteStrategy(It.IsAny<FavouriteStrategy>())).ReturnsAsync((FavouriteStrategy)null);

            // Act
            var result = await _service.SaveFavouriteStrategy(securityUserId, favouriteStrategyRequest);

            // Assert
            Assert.Null(result);


        }
        [Fact]
        public async Task UpdateFavouriteStrategy_ValidInput_UpdatesAndMapsModel()
        {
            // Arrange
            var userId = "balabharathi.s@mcgriff.com";
            var strategyId = Guid.NewGuid();
            var request = new FavouriteStrategyRequest();
            var entity = new FavouriteStrategy
            {
                FavouriteStrategyId = strategyId,
                UpdatedBy = userId,
                UpdatedDate = DateTime.Now,
                IsDeleted = true
            };

            var expectedModel = new FavouriteStrategyModel();

            _mockRepository.Setup(r => r.UpdateFavouriteStrategy(It.IsAny<FavouriteStrategy>()))
                           .ReturnsAsync(entity);

            _mockMapper.Setup(m => m.Map<FavouriteStrategyModel>(It.IsAny<FavouriteStrategy>()))
                       .Returns(expectedModel);

            // Act
            var result = await _service.UpdateFavouriteStrategy(userId, strategyId, request);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedModel, result);
            _mockRepository.Verify(r => r.UpdateFavouriteStrategy(It.Is<FavouriteStrategy>(
                e => e.FavouriteStrategyId == strategyId &&
                     e.UpdatedBy == userId &&
                     e.IsDeleted == true
            )), Times.Once);
            _mockMapper.Verify(m => m.Map<FavouriteStrategyModel>(It.IsAny<FavouriteStrategy>()), Times.Once);
        }
        [Fact]
        public async Task GetFavouriteStrategiesByUser_WithMappedIds_ReturnsMappedList()
        {
            // Arrange
            var userId = "balabharathi.s@mcgriff.com";
            var sagittaIds = new List<string> { "SAG001", "SAG002" };
            var entityList = new List<FavouriteStrategyView> { new FavouriteStrategyView() };
            var expectedModels = new List<FavouriteStrategyModel> { new FavouriteStrategyModel() };

            _mockSecurityUserRepository.Setup(r => r.GetSecurityUserMapExternalSystemUserIds(userId, AppConstants.EXTERNAL_SYS_SAGITTA))
                                 .ReturnsAsync(sagittaIds);

            _mockRepository.Setup(r => r.GetFavouriteStrategiesByUser(userId, sagittaIds.ToArray()))
                           .ReturnsAsync(entityList);

            _mockMapper.Setup(m => m.Map<List<FavouriteStrategyModel>>(entityList))
                       .Returns(expectedModels);

            // Act
            var result = await _service.GetFavouriteStrategiesByUser(userId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            _mockSecurityUserRepository.Verify(r => r.GetSecurityUserMapExternalSystemUserIds(userId, AppConstants.EXTERNAL_SYS_SAGITTA), Times.Once);
            _mockRepository.Verify(r => r.GetFavouriteStrategiesByUser(userId, sagittaIds.ToArray()), Times.Once);
            _mockMapper.Verify(m => m.Map<List<FavouriteStrategyModel>>(entityList), Times.Once);
        }

    }
}
