﻿using Xunit;
using Moq;
using AutoMapper;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.Services;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;

namespace BrokerPortal.API.UnitTest.Services
{
    public class SagittaPayeeServiceTests
    {
        private readonly Mock<ISagittaPayeeRepository> _mockRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly SagittaPayeeService _service;

        public SagittaPayeeServiceTests()
        {
            _mockRepository = new Mock<ISagittaPayeeRepository>();
            _mockMapper = new Mock<IMapper>();
            _service = new SagittaPayeeService(_mockRepository.Object, _mockMapper.Object);
        }

        [Fact]
        public void MergeSagittaPayee_ValidRequest_CallsBulkMergeWithUpsertedEntity()
        {
            // Arrange
            var securityUserId = "user-123";
            var sagittaPayeeRequest = new SagittaPayeeRequest
            {
                SagittaPayeeId = "SP001",
                PayeeCode = "PC001",
                PayeeName = "Test Payee",
                IsDatedOff = false
            };

            var existingEntity = new SagittaPayee
            {
                SagittaPayeeId = "SP001",
                PayeeName = "Old Name"
            };

            // Simulate no match found in DB
            _mockRepository.Setup(r => r.GetSagittaPayeeById("SP001"))
                .Returns(existingEntity);

            // Act
            _service.MergeSagittaPayee(securityUserId, sagittaPayeeRequest);

            // Assert
            Assert.Equal(true, true);
        }

        [Fact]
        public void MergeSagittaPayee_NullRequest_DoesNothing()
        {
            // Act
            _service.MergeSagittaPayee("user-123", null);

            // Assert
            _mockRepository.Verify(r => r.GetSagittaPayeeById(It.IsAny<string>()), Times.Never);
            _mockRepository.Verify(r => r.BulkMerge(It.IsAny<List<SagittaPayee>>()), Times.Never);
        }

        [Fact]
        public void BulkMergeSagittaPayees_WithExistingPayees_ReturnsMappedModels()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var requestList = new List<SagittaPayeeRequest>
        {
            new SagittaPayeeRequest { SagittaPayeeId = "P1" }
        };

            var existingEntities = new List<SagittaPayee>
        {
            new SagittaPayee { SagittaPayeeId = "P1" }
        };

            _mockRepository.Setup(r => r.GetSagittaPayeesByIds(It.IsAny<string[]>()))
                           .Returns(existingEntities);

            _mockRepository.Setup(r => r.BulkMerge(It.IsAny<List<SagittaPayee>>()));

            _mockMapper.Setup(m => m.Map<List<SagittaPayeeModel>>(It.IsAny<List<SagittaPayee>>()))
                       .Returns(new List<SagittaPayeeModel> { new SagittaPayeeModel() });

            // Act
            var result = _service.BulkMergeSagittaPayees(securityUserId, requestList);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }

        [Fact]
        public void BulkMergeSagittaPayees_WithNoExistingPayees_ReturnsMappedModels()
        {
            // Arrange
            var requestList = new List<SagittaPayeeRequest>
        {
            new SagittaPayeeRequest { SagittaPayeeId = "P2" }
        };

            _mockRepository.Setup(r => r.GetSagittaPayeesByIds(It.IsAny<string[]>()))
                           .Returns(new List<SagittaPayee>());

            _mockRepository.Setup(r => r.BulkMerge(It.IsAny<List<SagittaPayee>>()));

            _mockMapper.Setup(m => m.Map<List<SagittaPayeeModel>>(It.IsAny<List<SagittaPayee>>()))
                       .Returns(new List<SagittaPayeeModel> { new SagittaPayeeModel() });

            // Act
            var result = _service.BulkMergeSagittaPayees("balabharathi.s@mcgriff.com", requestList);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
        }

        [Fact]
        public void BulkMergeSagittaPayees_WithNullRequestList_ReturnsEmptyList()
        {
            // Act
            var result = _service.BulkMergeSagittaPayees("balabharathi.s@mcgriff.com", null);

            // Assert
            Assert.Null(result);   
        }

        [Fact]
        public void BulkMergeSagittaPayees_WithEmptyRequestList_ReturnsEmptyList()
        {
            // Act
            var result = _service.BulkMergeSagittaPayees("balabharathi.s@mcgriff.com", new List<SagittaPayeeRequest>());

            // Assert
            Assert.Null(result);
        }
    }
}