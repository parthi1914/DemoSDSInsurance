﻿using BrokerPortal.API.Controllers;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Text.Json.Serialization;
using Xunit;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace BrokerPortal.API.UnitTest
{
    public class StrategiesControllerTest
    {
        private readonly Mock<IStrategyService> _mockService;
        private readonly Mock<ILogger<StrategiesController>> _mockLogger;
        private readonly StrategiesController _controller;
        public StrategiesControllerTest()
        {
            _mockService = new Mock<IStrategyService>();
            _mockLogger = new Mock<ILogger<StrategiesController>>();
            _controller = new StrategiesController(_mockService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task GetAllStrategies_ReturnsOk_WithStrategies()
        {
            //ARRANGE
            var strategyList = LoadStrategyModelList();

            _mockService.Setup(s => s.GetAllStrategies()).Returns(strategyList);

            //ACT
            var result = await _controller.GetAllStrategies();

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<StrategyModel>>(okResult.Value);
            Assert.Single(returnValue);

        }

        [Fact]
        public async Task GetAllStrategies_ReturnsOk_EmptyStrategies()
        {
            //ARRANGE
            var strategyList = new List<StrategyModel>();
            _mockService.Setup(s => s.GetAllStrategies()).ReturnsAsync(strategyList);

            //ACT
            var result = await _controller.GetAllStrategies();

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<StrategyModel>>(okResult.Value);
            Assert.Empty(returnValue);

        }

        [Fact]
        public async Task GetStrategyById_ReturnsOk_WhenFound()
        {
            //ARRANGE
            var strategyId = Guid.NewGuid();

            var strategy = LoadStrategyModel();
            Guid strategyIdReq = strategy.Result.StrategyId;
            _mockService.Setup(s => s.GetStrategyById(strategyId,true)).Returns(strategy);

            //ACT
            var result = await _controller.GetStrategyById(strategyId);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<StrategyModel>(okResult.Value);
            Assert.Equal(strategyIdReq, returnValue.StrategyId);

        }


        [Fact]
        public async Task GetStrategyById_ReturnsEmpty_WhenNotFound()
        {
            //ARRANGE
            var strategyId = Guid.NewGuid();

            _mockService.Setup(s => s.GetStrategyById(strategyId,true)).ReturnsAsync((StrategyModel)null);

            //ACT
            var result = await _controller.GetStrategyById(strategyId);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);

        }


        [Fact]
        public async Task GetStrategyById_ThrowsBadRequestException_WhenStrategyIdIsEmpty()
        {
            // Arrange
            var strategyId = Guid.Empty;

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetStrategyById(strategyId));
        }

        [Fact]
        public async Task SaveStrategy_ReturnsOk_WhenValid()
        {
            //ARRANGE
            var strategyRequest =await LoadStrategyRequest();
            var strategyResponse = LoadStrategyModel();
            _mockService.Setup(s => s.SaveStrategy(It.IsAny<StrategyRequest>())).Returns((strategyResponse));

            //ACT
            var result = await _controller.SaveStrategy(strategyRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.True(okResult is not null);
          
        }

        [Fact]
        public async Task SaveStrategy_ThrowsBadRequestException_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("StrategyId", "StrategyName");
            var strategyRequest = new StrategyRequest { StrategyId = Guid.Empty };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveStrategy(strategyRequest));
        }

        [Fact]
        public async Task SaveStrategy_ReturnsBadRequest_WhenServiceThrowsException()
        {
            // Arrange
            var strategyRequest = new StrategyRequest {PlanId=Guid.NewGuid(), StrategyId = Guid.NewGuid(), StrategyName = "Test Strategy" };
            _mockService.Setup(s => s.SaveStrategy(strategyRequest)).ThrowsAsync(new BadRequestException("Service error"));

            // Act
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveStrategy(strategyRequest));
            
        }


        [Fact]
        public async Task SaveStrategy_ReturnsBadRequest_WhenInValid()
        {
            _controller.ModelState.AddModelError("Error", "Invalid Request");
            var strategyRequest = await LoadStrategyRequest();

            //ASSERT
            await Assert.ThrowsAsync<BadRequestException>(() =>
               _controller.SaveStrategy(strategyRequest));

        }
        [Fact]
        public async Task ArchiveStrategy_ValidRequest_ReturnsOk()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "balabharathi.s@mcgriff.com" };
            var mockService = new Mock<IStrategyService>();
            var mockLogger = new Mock<ILogger<StrategiesController>>();

            mockService.Setup(s => s.ArchiveStrategy(strategyId, securityUser.SecurityUserId)).ReturnsAsync(true);

            // Act
            var result = await _controller.ArchiveStrategy(strategyId, securityUser);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task ArchiveStrategy_EmptySecurityUserId_ThrowsBadRequest()
        {

            await Assert.ThrowsAsync<BadRequestException>(() =>
                _controller.ArchiveStrategy(Guid.NewGuid(), new SecurityUserModel { SecurityUserId = "" }));
        }



        [Fact]
        public async Task UpdateStrategy_ReturnsOk_WhenValid()
        {
            //ARRANGE
            var strategyRequest = await LoadStrategyRequest();
            var strategyResponse = LoadStrategyModel();
            _mockService.Setup(s => s.UpdateStrategy(It.IsAny<Guid>(), It.IsAny<StrategyRequest>())).Returns((strategyResponse));

            //ACT
            var result = await _controller.UpdateStrategy(strategyRequest,strategyResponse.Result.StrategyId);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.True(okResult is not null);
        }

        [Fact]
        public async Task UpdateStrategy_ThrowsBadRequestException_WhenInvalidModelState()
        {
            // Arrange
            _controller.ModelState.AddModelError("StrategyId", "StrategyName");
            var strategyId = Guid.NewGuid();
            var strategyRequest = new StrategyRequest { StrategyId=strategyId };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateStrategy(strategyRequest, strategyId));
        }

        public async Task UpdateStrategy_ThrowsBadRequestException_WhenEmptyStrategyId()
        {
            // Arrange
            var strategyId = Guid.Empty;
            var strategyRequest = new StrategyRequest { StrategyId=strategyId };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateStrategy(strategyRequest, strategyId));
        }


        [Fact]
        public async Task UpdateStrategy_ReturnsBadRequest_WhenInValid()
        {

        }

        [Fact]
        public async Task DeleteStrategy_ReturnsOk_WhenValid()
        {
            //ARRANGE
            var strategyID = Guid.NewGuid();
            var user = new SecurityUserModel() { SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com"};
            _mockService.Setup(s => s.RemoveStrategy(strategyID,user.SecurityUserId)).ReturnsAsync(true);

            //ACT
            var result = await _controller.RemoveStrategy(strategyID, user);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.True((bool)okResult.Value);
        }

        [Fact]
        public async Task SearchStrategies_ValidRequest_ReturnResults()
        {
            var SearchRequest = new StrategySearchRequest { SearchType = "ALL" };
            SearchRequest.SearchCriterias = new StrategySearchCriterias();
            //SearchRequest.SearchCriterias.stepStatusCodes = ["MS_SUBM"];
            //SearchRequest.SearchCriterias.stepStatusCodes = ["Acti"];
            SearchRequest.SecurityUser = new SecurityUserModel();
            SearchRequest.SecurityUser.SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com";
            //var strategySearchType= new StrategySearchCriterias {stepDefCodes=["MS_SUBM"] };
            var searchResults = new List<StrategyModel> { new StrategyModel { StrategyName = "Test1" } };
            string securityUserId = "parthiban.kaliaperumal@tihinsurance.com";
            _mockService.Setup(s => s.SearchStrategies(It.IsAny<SearchBaseFilterType>(), It.IsAny<StrategySearchType>(), It.IsAny<StrategySearchCriterias>(), securityUserId, It.IsAny<string>())).ReturnsAsync(new List<StrategyModel>() );

            //ACT
            var result = await _controller.SearchStrtaegies(SearchRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200,okResult.StatusCode);
        }


        [Fact]
        public async Task SearchUserStrategies_ValidRequest_ReturnResults()
        {
            var SearchRequest = new StrategySearchRequest { SearchType = "ALL" };
            SearchRequest.SearchCriterias = new StrategySearchCriterias();
            //SearchRequest.SearchCriterias.stepStatusCodes = ["MS_SUBM"];
            //SearchRequest.SearchCriterias.stepStatusCodes = ["Acti"];
            SearchRequest.SecurityUser = new SecurityUserModel();
            SearchRequest.SecurityUser.SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com";
            //var strategySearchType = new StrategySearchCriterias { stepDefCodes = ["MS_SUBM"] };
            var searchResults = new List<StrategyModel> { new StrategyModel { StrategyName = "Test1" } };
            string securityUserId = "parthiban.kaliaperumal@tihinsurance.com";
            _mockService.Setup(s => s.SearchStrategies(It.IsAny<SearchBaseFilterType>(), It.IsAny<StrategySearchType>(), It.IsAny<StrategySearchCriterias>(), securityUserId, It.IsAny<string>())).ReturnsAsync(new List<StrategyModel>());

            //ACT
            var result = await _controller.SearchUserStrategies("parthiban.kaliaperumal@tihinsurance.com", SearchRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }


        [Fact]
        public async Task SearchStrategiesByClient_ValidRequest_ReturnResults()
        {
            var SearchRequest = new StrategySearchRequest { SearchType = "ALL" };
            SearchRequest.SearchCriterias = new StrategySearchCriterias();
            //SearchRequest.SearchCriterias.stepStatusCodes = ["MS_SUBM"];
            //SearchRequest.SearchCriterias.stepStatusCodes = ["Acti"];
            SearchRequest.SecurityUser = new SecurityUserModel();
            SearchRequest.SecurityUser.SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com";
            //var strategySearchType = new StrategySearchCriterias { stepDefCodes = ["MS_SUBM"] };
            var searchResults = new List<StrategyModel> { new StrategyModel { StrategyName = "Test1" } };
            string securityUserId = "parthiban.kaliaperumal@tihinsurance.com";
            _mockService.Setup(s => s.SearchStrategies(It.IsAny<SearchBaseFilterType>(), It.IsAny<StrategySearchType>(), It.IsAny<StrategySearchCriterias>(), securityUserId, It.IsAny<string>())).ReturnsAsync(new List<StrategyModel>());

            //ACT
            var result = await _controller.SearchStrtaegiesByClient("1001", SearchRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }



        private Task<StrategyRequest> LoadStrategyRequest()
        {
            StrategyRequest strategyRequest = new StrategyRequest();
            strategyRequest.StrategyId = null;
            strategyRequest.StrategyName = "Test Strategy One";
            strategyRequest.SecurityUsers.SecurityUserEmail = "parthiban.kaliaperumal@tihinsurance.com";
            strategyRequest.PlanId = Guid.NewGuid();
            strategyRequest.StrategyEffDate = DateTime.Now;
            strategyRequest.SagittaClientId = 101;

            StrategyTimelinesRequest strategyTimelinesRequest = new StrategyTimelinesRequest();
            strategyTimelinesRequest.StepDefId = "MS_SUBM";
            strategyTimelinesRequest.AssignmentDueDate = DateTime.Now;
            strategyTimelinesRequest.DueDate = DateTime.Now;

            strategyRequest.StrategyTimelines.Add(strategyTimelinesRequest);
            return Task.FromResult(strategyRequest);

        }


        private  Task<List<StrategyModel>> LoadStrategyModelList()
        {
            List<StrategyModel> strategyResponses = new List<StrategyModel>();
            StrategyModel strategyResponse   = new StrategyModel();
            strategyResponse.StrategyId = Guid.NewGuid();
            strategyResponse.StrategyName = "Test Strategy One";
            strategyResponse.PlanId = Guid.NewGuid();
            strategyResponse.StrategyEffDate =DateTime.Now ;
            strategyResponse.SagittaClientId = 1001;
            strategyResponse.StrategyStatusCode = "ACTI";
            strategyResponse.CreatedDate = DateTime.Now;
            strategyResponse.CreatedBy = "parthiban.kaliaperumal@tihinsurance.com";

            StrategyTimelineModel strategyTimelineModel = new StrategyTimelineModel();
            strategyTimelineModel.StrategyTimelineId = Guid.NewGuid();
            strategyTimelineModel.StrategyId = strategyResponse.StrategyId;
            strategyTimelineModel.StepDefId = "MS-SUBM";
            strategyTimelineModel.AssignmentDueDate = DateTime.Now;
            strategyTimelineModel.DueDate = DateTime.Now;
            strategyTimelineModel.StatusCodeId = "INIT  ";
            strategyTimelineModel.CreatedDate = DateTime.Now;
            strategyTimelineModel.CreatedBy = "parthiban.kaliaperumal@tihinsurance.com";

            strategyResponse.StrategyTimelines.Add(strategyTimelineModel);
            strategyResponses.Add(strategyResponse);
            return Task.FromResult(strategyResponses);

        }

        private Task<StrategyModel> LoadStrategyModel()
        {
            List<StrategyModel> strategyResponses = new List<StrategyModel>();
            StrategyModel strategyResponse = new StrategyModel();
            strategyResponse.StrategyId = Guid.NewGuid();
            strategyResponse.StrategyName = "Test Strategy One";
            strategyResponse.PlanId = Guid.NewGuid();
            strategyResponse.StrategyEffDate = DateTime.Now;
            strategyResponse.SagittaClientId = 1001;
            strategyResponse.StrategyStatusCode = "ACTI";
            strategyResponse.CreatedDate = DateTime.Now;
            strategyResponse.CreatedBy = "parthiban.kaliaperumal@tihinsurance.com";

            StrategyTimelineModel strategyTimelineModel = new StrategyTimelineModel();
            strategyTimelineModel.StrategyTimelineId = Guid.NewGuid();
            strategyTimelineModel.StrategyId = strategyResponse.StrategyId;
            strategyTimelineModel.StepDefId = "MS-SUBM";
            strategyTimelineModel.AssignmentDueDate = DateTime.Now;
            strategyTimelineModel.DueDate = DateTime.Now;
            strategyTimelineModel.StatusCodeId = "INIT  ";
            strategyTimelineModel.CreatedDate = DateTime.Now;
            strategyTimelineModel.CreatedBy = "parthiban.kaliaperumal@tihinsurance.com";

            strategyResponse.StrategyTimelines.Add(strategyTimelineModel);
          
            return Task.FromResult(strategyResponse);

        }
    }
}
