using BrokerPortal.API.Controllers;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Plan;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;

namespace BrokerPortal.API.UnitTest
{
    public class PlanControllerTests
    {

        private readonly Mock<ILogger<PlansController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<IPlanService> _mockPService;
        private readonly Mock<IStrategyService> _mockSService;
        private readonly PlansController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public PlanControllerTests()
        {
            _mockLogger = new Mock<ILogger<PlansController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
            _mockPService = new Mock<IPlanService>();
            _mockSService = new Mock<IStrategyService>();
            _controller = new PlansController(_mockPService.Object, _mockLogger.Object, _context, _mockSService.Object);

        }

        [Fact]
        public async Task Get_ReturnsOkResult_WithListOfPlans()
        {
            // Arrange
            var planList = new List<PlanResponse> { new PlanResponse { PlanId = Guid.NewGuid(), PlanName = "TestName", PlanCreatedDate = DateTime.Now, PlanCreatedBy = "system@system.com", PlanUpdatedBy = "system@system.com" },
            new PlanResponse { PlanId = Guid.NewGuid(), PlanName = "TestName1", PlanCreatedDate = DateTime.Now, PlanCreatedBy = "system@system.com", PlanUpdatedBy = "system@system.com" }};
            _mockPService.Setup(service => service.GetAllPlans()).ReturnsAsync(planList);

            // Act
            var result = await _controller.Get();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<PlanResponse>>(okResult.Value);
            Assert.Equal(planList.Count, returnValue.Count);
        }

        [Fact]
        public async Task Get_ReturnsOkResult_WithEmptyList()
        {
            // Arrange
            var planList = new List<PlanResponse>();
            _mockPService.Setup(service => service.GetAllPlans()).ReturnsAsync(planList);

            // Act
            var result = await _controller.Get();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<PlanResponse>>(okResult.Value);
            Assert.Empty(returnValue);
        }


        [Fact]
        public async Task GetById_ReturnsOkResult_WithPlan()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var plan = new PlanResponse { PlanId = planId, PlanName = "TestName", PlanCreatedDate = DateTime.Now, PlanCreatedBy = "system@system.com", PlanUpdatedBy = "system@system.com" };
            _mockPService.Setup(service => service.GetPlanById(planId)).ReturnsAsync(plan);

            // Act
            var result = await _controller.Get(planId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<PlanResponse>(okResult.Value);
            Assert.Equal(planId, returnValue.PlanId);
        }

        [Fact]
        public async Task GetById_ReturnsNotFoundResult_WhenPlanNotFound()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var plan = new PlanResponse();
            _mockPService.Setup(service => service.GetPlanById(planId)).ReturnsAsync(plan);
            // Act
            var result = await _controller.Get(planId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<PlanResponse>(okResult.Value);
            Assert.Equal(Guid.Empty, returnValue.PlanId);
        }

        [Fact]
        public async Task GetById_ReturnsBadRequest_WhenPlanIdIsEmpty()
        {
            // Arrange
            var emptyGuid = Guid.Empty;

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.Get(emptyGuid));
        }

        [Fact]
        public async Task Post_ValidInput_ReturnsOk()
        {
            // Arrange
            PlanRequest planRequest = new PlanRequest();
            planRequest = loadPlanRequest();
            Guid stratplanId = planRequest.PlanId.Value;
            Guid planClientid = planRequest.PlanClients.PlanClientId ?? default;

            var planResponse = new PlanResponse
            {
                PlanId = planRequest.PlanId ?? default,
                PlanName = planRequest.PlanName,
                PlanEffDate = planRequest.PlanEffDate,
                PlanCreatedBy = "test@test.com",
                PlanCreatedDate = DateTime.Now,
                PlanStatus = "STA",
                PlanClients = new PlanClientDetailsResponse
                {
                    PlanClientId = planClientid,
                    SagittaClientId = 1212232,
                    ClientCode = "TES",
                    ClientName = "sample client",
                    ClientContPersId = 12,
                    ClientContPersCode = "testprescode",
                    ClientContPersName = "testname",
                    ClientContPersEmail = "test@test.com",
                    ClientContPersPhone1 = "1234567890",
                    ClientCity = "testcity",
                    ClientState = "teststate",
                    IsDatedOff = false,
                    DatedOffDate = DateTime.Now
                },


            };
            var strategyResponse = new StrategyModel();

            _mockPService.Setup(s => s.SavePlan(It.IsAny<PlanRequest>())).ReturnsAsync(planResponse);
            _mockSService.Setup(s => s.SaveStrategy(It.IsAny<StrategyRequest>())).ReturnsAsync(strategyResponse);

            // Act
            var result = await _controller.Post(planRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(planResponse, okResult.Value);
        }

        [Fact]
        public async Task Post_InvalidModel_ThrowsBadRequestException()
        {
            // Arrange
            _controller.ModelState.AddModelError("Error", "Invalid model");

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.Post(new PlanRequest()));
        }

        [Fact]
        public async Task Post_ExceptionThrown_RollsBackTransaction()
        {
            // Arrange
            PlanRequest planRequest = new PlanRequest();
            planRequest = loadPlanRequest();
            _mockPService.Setup(s => s.SavePlan(It.IsAny<PlanRequest>())).ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _controller.Post(planRequest));

        }
        [Fact]
        public async Task Post_SaveStrategyThrowsException_TransactionRollback()
        {
            // Arrange
            var planRequest = new PlanRequest();
            var planResponse = new PlanResponse();
            _mockPService.Setup(s => s.SavePlan(It.IsAny<PlanRequest>())).ReturnsAsync(planResponse);
            _mockSService.Setup(s => s.SaveStrategy(It.IsAny<StrategyRequest>())).ThrowsAsync(new Exception("SaveStrategy Error"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.Post(planRequest));
            Assert.Contains("Plan Save Error", exception.Message);

        }
        [Fact]
        public async Task Post_ValidPlanRequestWithStrategy_ReturnsOk()
        {
            // Arrange
            PlanRequest planRequest = new PlanRequest();
            planRequest = loadPlanRequest();
            Guid stratplanId = planRequest.PlanId.Value;
            Guid planClientid = planRequest.PlanClients.PlanClientId ?? default;

            var planResponse = new PlanResponse
            {
                PlanId = planRequest.PlanId ?? default,
                PlanName = planRequest.PlanName,
                PlanEffDate = planRequest.PlanEffDate,
                PlanCreatedBy = "test@test.com",
                PlanCreatedDate = DateTime.Now,
                PlanStatus = "STA",
                PlanClients = new PlanClientDetailsResponse
                {
                    PlanClientId = planClientid,
                    SagittaClientId = 1212232,
                    ClientCode = "TES",
                    ClientName = "sample client",
                    ClientContPersId = 12,
                    ClientContPersCode = "testprescode",
                    ClientContPersName = "testname",
                    ClientContPersEmail = "test@test.com",
                    ClientContPersPhone1 = "1234567890",
                    ClientCity = "testcity",
                    ClientState = "teststate",
                    IsDatedOff = false,
                    DatedOffDate = DateTime.Now
                },


            };
            var strategyResponse = new StrategyResponse();

            _mockPService.Setup(s => s.SavePlan(It.IsAny<PlanRequest>())).ReturnsAsync(planResponse);
            //_mockSService.Setup(s => s.SaveStrategy(It.IsAny<StrategyRequest>())).ReturnsAsync(strategyResponse);

            // Act
            var result = await _controller.Post(planRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
            Assert.Equal(planResponse, okResult.Value);
            //Assert.Equal(strategyResponse, planResponse.Strategy);
        }


        //[Fact]
        //public async Task Put_ValidModel_ReturnsOkResult()
        //{
        //    // Arrange
        //    PlanRequest planRequest = new PlanRequest();
        //    planRequest = loadPlanRequest();
        //    Guid stratplanId = planRequest.PlanId.Value;
        //    Guid planClientid = planRequest.PlanClients.PlanClientId ?? default;
        //    var planResponse = new PlanResponse
        //    {
        //        PlanId = planRequest.PlanId ?? default,
        //        PlanName = planRequest.PlanName,
        //        PlanEffDate = planRequest.PlanEffDate,
        //        PlanCreatedBy = "test@test.com",
        //        PlanCreatedDate = DateTime.Now,
        //        PlanStatus = "STA",
        //        PlanClients = new PlanClientDetailsResponse
        //        {
        //            PlanClientId = planClientid,
        //            SagittaClientId = 1212232,
        //            ClientCode = "TES",
        //            ClientName = "sample client",
        //            ClientContPersId = 12,
        //            ClientContPersCode = "testprescode",
        //            ClientContPersName = "testname",
        //            ClientContPersEmail = "test@test.com",
        //            ClientContPersPhone1 = "1234567890",
        //            ClientCity = "testcity",
        //            ClientState = "teststate",
        //            IsDatedOff = false,
        //            DatedOffDate = DateTime.Now
        //        },
        //    };
        //    var strategyResponse = new StrategyResponse {
        //        StrategyId = Guid.NewGuid(),
        //        SagittaClientId = planResponse.PlanClients.SagittaClientId,
        //        StrategyName="test strategy",
        //        PlanId= planResponse.PlanId,
        //    };


        //    _mockPService.Setup(s => s.UpdatePlan(It.IsAny<PlanRequest>(), It.IsAny<Guid>())).ReturnsAsync(planResponse);
        //    _mockSService.Setup(s => s.GetStrategyByPlanId(It.IsAny<Guid>())).ReturnsAsync(strategyResponse);
        //    _mockSService.Setup(s => s.UpdateStrategy(It.IsAny<Guid>(), It.IsAny<StrategyRequest>())).ReturnsAsync(strategyResponse);

        //    // Act
        //    var result = await _controller.Put(planRequest, planResponse.PlanId);

        //    // Assert
        //    var okResult = Assert.IsType<OkObjectResult>(result);
        //    var returnValue = Assert.IsType<PlanResponse>(okResult.Value);
        //    Assert.Equal(planResponse.PlanId, returnValue.PlanId);
        //    Assert.Equal(strategyResponse, returnValue.Strategy);
        //}

        [Fact]
        public async Task Put_ValidPlanRequestAndPlanId_ReturnsOk()
        {
            // Arrange
            PlanRequest planRequest = new PlanRequest();
            planRequest = loadPlanRequest();
            var planId = Guid.NewGuid();
            Guid stratplanId = planRequest.PlanId.Value;
            Guid planClientid = planRequest.PlanClients.PlanClientId ?? default;
            var planResponse = new PlanResponse
            {
                PlanId = planRequest.PlanId ?? default,
                PlanName = planRequest.PlanName,
                PlanEffDate = planRequest.PlanEffDate,
                PlanCreatedBy = "test@test.com",
                PlanCreatedDate = DateTime.Now,
                PlanStatus = "STA",
                PlanClients = new PlanClientDetailsResponse
                {
                    PlanClientId = planClientid,
                    SagittaClientId = 1212232,
                    ClientCode = "TES",
                    ClientName = "sample client",
                    ClientContPersId = 12,
                    ClientContPersCode = "testprescode",
                    ClientContPersName = "testname",
                    ClientContPersEmail = "test@test.com",
                    ClientContPersPhone1 = "1234567890",
                    ClientCity = "testcity",
                    ClientState = "teststate",
                    IsDatedOff = false,
                    DatedOffDate = DateTime.Now
                },


            };
            _mockPService.Setup(s => s.UpdatePlan(It.IsAny<PlanRequest>(), It.IsAny<Guid>())).ReturnsAsync(planResponse);

            // Act
            var result = await _controller.Put(planRequest, planId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
            Assert.Equal(planResponse, okResult.Value);
        }

        [Fact]
        public async Task Put_InvalidModel_ThrowsBadRequestException()
        {
            // Arrange
            _controller.ModelState.AddModelError("Error", "Invalid model");

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.Put(new PlanRequest(), Guid.NewGuid()));
        }


        [Fact]
        public async Task Put_EmptyPlanId_ThrowsBadRequestException()
        {
            // Arrange
            PlanRequest planRequest = new PlanRequest();
            planRequest = loadPlanRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.Put(planRequest, Guid.Empty));
        }

        [Fact]
        public async Task Put_ExceptionThrown_RollsBackTransaction()
        {
            // Arrange
            PlanRequest planRequest = new PlanRequest();
            planRequest = loadPlanRequest();
            var planId = Guid.NewGuid();
            _mockPService.Setup(s => s.UpdatePlan(It.IsAny<PlanRequest>(), It.IsAny<Guid>())).ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _controller.Put(planRequest, planId));
            //_contextMock.Verify(c => c.Database.BeginTransaction().Rollback(), Times.Once);
        }


        [Fact]
        public async Task DeletePlan_ValidModel_ReturnsOkResult()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "test@test.com" };

            _mockPService.Setup(s => s.RemovePlan(It.IsAny<Guid>(), It.IsAny<string>())).ReturnsAsync(true);

            // Act
            var result = await _controller.RemovePlan(planId, securityUser);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.True((bool)okResult.Value);
        }

        [Fact]
        public async Task DeletePlan_InvalidModel_ThrowsBadRequestException()
        {
            // Arrange
            _controller.ModelState.AddModelError("Error", "Invalid model");

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemovePlan(Guid.NewGuid(), new SecurityUserModel { SecurityUserId = "user123" }));
        }

        [Fact]
        public async Task DeletePlan_EmptyPlanId_ThrowsBadRequestException()
        {
            // Arrange
            var securityUser = new SecurityUserModel { SecurityUserId = "test@test.com" };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemovePlan(Guid.Empty, securityUser));
        }

        [Fact]
        public async Task DeletePlan_EmptySecurityUserId_ThrowsBadRequestException()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "" };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemovePlan(planId, securityUser));
        }

        [Fact]
        public async Task DeletePlan_ExceptionThrown_RollsBackTransaction()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "test@test.com" };
            _mockPService.Setup(s => s.RemovePlan(It.IsAny<Guid>(), It.IsAny<string>())).ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _controller.RemovePlan(planId, securityUser));
            //_contextMock.Verify(c => c.Database.BeginTransaction().Rollback(), Times.Once);
        }

        [Fact]
        public async Task ArchivePlan_ValidRequest_ReturnsOk()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "testUser@test.com" };
            _mockPService.Setup(s => s.ArchivePlan(planId, securityUser.SecurityUserId)).ReturnsAsync(true);


            // Act
            var result = await _controller.ArchivePlan(planId, securityUser);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.True((bool)okResult.Value);
        }

        [Fact]
        public async Task ArchivePlan_InvalidModel_ReturnsBadRequest()
        {
            // Arrange
            var planId = Guid.Empty;
            var securityUser = new SecurityUserModel { SecurityUserId = "" };
            _controller.ModelState.AddModelError("error", "some error");

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.ArchivePlan(planId, securityUser));
        }

        [Fact]
        public async Task ArchivePlan_ExceptionThrown_Transaction()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "testuser@test.com" };


            _mockPService.Setup(s => s.ArchivePlan(planId, securityUser.SecurityUserId)).ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _controller.ArchivePlan(planId, securityUser));

        }

        [Fact]
        public async Task GetPlanStrategies_ValidRequest_ReturnsOk()
        {
            // Arrange
            var planId = Guid.NewGuid();
            StrategyModel strategyResponse = new StrategyModel
            {
                StrategyId = Guid.NewGuid(),
                SagittaClientId = 1232333,
                StrategyName = "test strategy",
                PlanId = planId
            };

            _mockSService.Setup(s => s.GetStrategyByPlanId(planId)).ReturnsAsync(strategyResponse);

            // Act
            var result = await _controller.GetPlanStrategies(planId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(strategyResponse, okResult.Value);
        }

        [Fact]
        public async Task GetPlanStrategies_InvalidPlanId_ReturnsBadRequest()
        {
            // Arrange
            var planId = Guid.Empty;

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetPlanStrategies(planId));
        }



        private PlanRequest loadPlanRequest()
        {
            var prodRequest = new PlanRequest
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Sample Product",
                PlanEffDate = DateTime.Now,
                PlanClients = new PlanClientDetailsRequest
                {
                    PlanClientId = Guid.NewGuid(),
                    SagittaClientId = 1212232,
                    ClientCode = "TES",
                    ClientName = "sample client",
                    ClientContPersId = 12,
                    ClientContPersCode = "testprescode",
                    ClientContPersName = "testname",
                    ClientContPersEmail = "test@test.com",
                    ClientContPersPhone1 = "1234567890",
                    ClientCity = "testcity",
                    ClientState = "teststate",
                    IsDatedOff = false,
                    DatedOffDate = DateTime.Now
                },
                PlanTimelines = new List<PlanTimelinesRequest>
            {
                new PlanTimelinesRequest
                {
                    PlanTimelineId = Guid.NewGuid(),
                    StepDefId = "MP-PROP",
                    DueDate = DateTime.Parse("07/01/2025")//DateTime.ParseExact("7/1/2025", "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture)
                },
                 new PlanTimelinesRequest
                {
                    PlanTimelineId = Guid.NewGuid(),
                    StepDefId = "MP-MARK",
                    DueDate = DateTime.Parse("04/02/2025")//DateTime.ParseExact("4/2/2025", "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture)
                },
                   new PlanTimelinesRequest
                {
                    PlanTimelineId = Guid.NewGuid(),
                    StepDefId = "MP-BIND",
                    DueDate = DateTime.Parse("07/26/2025")//  DateTime.ParseExact("7/26/2025", "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture)
                },
                     new PlanTimelinesRequest
                {
                    PlanTimelineId = Guid.NewGuid(),
                    StepDefId = "MS-SUBM",
                    DueDate = DateTime.Parse("07/31/2025")//DateTime.ParseExact("7/31/2025", "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture)
                }
            },
                SecurityUsers = new SecurityUserModel
                {
                    SecurityUserId = "venkatesan@tihinsurance.com",
                    SecurityUserEmail = "SampleUser"
                }
            };
            return prodRequest;
        }
    }
}