﻿using Xunit;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.RepositoryContracts.Domain;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class SagittaPolicyRepositoryTests
    {
        private BrokerPortalApiDBContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            var context = new BrokerPortalApiDBContext(options);

            context.SagittaPolicies.AddRange(
                new SagittaPolicy { SagittaPolicyId = 1, SagittaClient = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" } }
            );

            context.Markets.AddRange(
                 new Market
                 {
                     MarketId = Guid.Parse("11111111-1111-1111-1111-111111111111"),
                     StrategyId = Guid.Parse("11111111-1111-1111-1111-111111111111"),
                     IsDeleted = false,
                     GrpNumber = 1,
                     IsSagPol=true,
                     SagittaPolicyId=1,
                     StepDef = new StepDef
                     {
                         StepDefId = "MS-SUBM",
                         StepDefCode = "MS-SUBM",
                         FlowDefId = "MS",
                         StepName = "MS-SUBM",
                         StepNameDisplay = "MS-SUBM",
                         IsDeleted = false,
                         StepOrder = 2

                     },
                     MarketAddlCovs = new List<MarketAddlCov> { new MarketAddlCov { IsDeleted = false } },
                     MarketTimelines = new List<MarketTimeline> { new MarketTimeline { IsDeleted = false, StepDefId = "MS-SUBM", StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" } } },
                     MarketTaskMeta = new List<MarketTaskMeta>
            {
                new MarketTaskMeta
                {
                    IsDeleted = false,
                    TaskStack = new TaskStack
                    {
                        TaskMeta = new List<TaskMeta>{ new TaskMeta() },
                        TaskSteps = new List<TaskStep>
                        {
                            new TaskStep
                            {
                                IsDeleted = false,
                                TaskAssignments = new List<TaskAssignment>
                                {
                                    new TaskAssignment { IsDeleted = false }
                                }
                            }
                        }
                    }
                }
                    }
                 }
            );

            context.SaveChanges();
            return context;
        }

        [Fact]
        public async Task GetSagittaPoliciesRepository_ReturnsCorrectPolicy()
        {
            var context = GetInMemoryDbContext();
            var repo = new SagittaPolicyRepository(context);

            var result = await repo.GetSagittaPoliciesRepository(1);

            Assert.NotNull(result);
            Assert.Equal(1, result.SagittaPolicyId);
        }

        [Fact]
        public void GetSagittaPoliciesByIds_ReturnsMatchingPolicies()
        {
            var context = GetInMemoryDbContext();
            var repo = new SagittaPolicyRepository(context);

            var result = repo.GetSagittaPoliciesByIds(new long?[] { 1 });

            Assert.Equal(1, result.Count);
        }

        [Fact]
        public void GetSagittaPoliciesByStrategyId_ReturnsPoliciesForStrategy()
        {
            var context = GetInMemoryDbContext();
            var repo = new SagittaPolicyRepository(context);

            var result = repo.GetSagittaPoliciesByStrategyId(Guid.Parse("11111111-1111-1111-1111-111111111111"));

            Assert.Single(result);
            Assert.Equal(1, result[0].SagittaPolicyId);
        }

        [Fact]
        public void GetSagittaPoliciesByStrategyId_ReturnsNullIfNoMatch()
        {
            var context = GetInMemoryDbContext();
            var repo = new SagittaPolicyRepository(context);

            var result = repo.GetSagittaPoliciesByStrategyId(Guid.NewGuid());

            Assert.Null(result);
        }

        [Fact]
        public void BulkMerge_CallsBulkMergeAndReturnsList()
        {
            var context = GetInMemoryDbContext();
            var policies = new List<SagittaPolicy>
        {
            new SagittaPolicy { SagittaPolicyId = 3,SagittaClient= new SagittaClient { SagittaClientId = 100095, ClientCode = "100095", ClientName = "TEST 3" }}
        };

            var repo = new SagittaPolicyRepository(context);

            var result = repo.BulkMerge(policies);

            Assert.Equal(policies, result);
        }

        [Fact]
        public async Task SaveSagittaEntity_AddsAndReturnsEntity()
        {
            var context = GetInMemoryDbContext();
            var repo = new SagittaPolicyRepository(context);

            var newPolicy = new SagittaPolicy { SagittaPolicyId = 10, SagittaClient = new SagittaClient { SagittaClientId = 100099, ClientCode = "100099", ClientName = "TEST1" } };
            var result = await repo.SaveSagittaEntity(newPolicy);

            Assert.Equal(10, result.SagittaPolicyId);
        }
        [Fact]
        public async Task UpdateSagittaEntity_UpdatesAndReturnsEntity()
        {
            var context = GetInMemoryDbContext();
            var repo = new SagittaPolicyRepository(context);

            var existing = context.SagittaPolicies.First();
            existing.PolicyNumber = "Updated Name";

            var result = await repo.UpdateSagittaEntity(existing);

            Assert.Equal("Updated Name", result.PolicyNumber);
        }

    }
}