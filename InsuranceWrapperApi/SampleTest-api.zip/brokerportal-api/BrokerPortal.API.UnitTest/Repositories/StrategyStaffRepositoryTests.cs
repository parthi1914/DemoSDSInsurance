﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.Services;
using Moq;
using Microsoft.Data.Sqlite;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class StrategyStaffRepositoryTests
    {
        private readonly BrokerPortalApiDBContext context;
        private readonly Guid _strategyStaffId = Guid.NewGuid();
        private readonly StrategyStaffRepository repository;
        public StrategyStaffRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

                        context = new BrokerPortalApiDBContext(options);
                        context.StrategyStaffs.AddRange(new StrategyStaff
                        {
                            StrategyStaffId = _strategyStaffId,
                            IsDeleted = false,
                            SagittaStaff = new SagittaStaff { SagittaStaffId = "NEMO", StaffName = "John Doe" }
                        }
           );


            repository = new StrategyStaffRepository(context);
        }
        [Fact]
        public void GetStrategyStaffs_ReturnsExpectedResults()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: "TestDB")
                .Options;

            var strategyId = Guid.NewGuid();

            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.StrategyStaffs.AddRange(
                    new StrategyStaff
                    {
                        StrategyStaffId = Guid.NewGuid(),
                        StrategyId = strategyId,
                        IsDeleted = false,
                        SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" }
                    }
                );
                context.SaveChanges();
            }

            using (var context = new BrokerPortalApiDBContext(options))
            {
                var repository = new StrategyStaffRepository(context);

                // Act
                var result = repository.GetStrategyStaffs(strategyId);

                // Assert
                Assert.Single(result);
                Assert.Equal("John Doe", result[0].SagittaStaff.StaffName);
            }
        }
        [Fact]
        public void GetStrategyStaffsWithNull_ReturnsNull()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: "TestDB")
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                var repository = new StrategyStaffRepository(context);

                // Act
                var result = repository.GetStrategyStaffs(Guid.Empty);

                // Assert
                Assert.Empty(result);
            }
        }
        [Fact]
        public async Task GetStrategyStaffById_ReturnsCorrectStaff()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: "TestDB_GetStrategyStaffById")
                .Options;

            var strategyStaffId = Guid.NewGuid();

            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.StrategyStaffs.Add(new StrategyStaff
                {
                    StrategyStaffId = strategyStaffId,
                    IsDeleted = false,
                    SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" }
                });


                context.SaveChanges();
            }

            using (var context = new BrokerPortalApiDBContext(options))
            {
                var repository = new StrategyStaffRepository(context);

                // Act
                var result = await repository.GetStrategyStaffById(strategyStaffId);

                // Assert
                Assert.NotNull(result);
                Assert.Equal("John Doe", result.SagittaStaff.StaffName);
            }
        }
        [Fact]
        public async Task GetStrategyStaffByIdWithNull_ReturnsNull()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: "TestDB_GetStrategyStaffById")
                .Options;

            using (var context = new BrokerPortalApiDBContext(options))
            {
                var repository = new StrategyStaffRepository(context);

                // Act
                var result = await repository.GetStrategyStaffById(Guid.Empty);

                // Assert
                Assert.Null(result);
            }
        }
        [Fact]
        public async Task BulkMergeWithSubEntities_ReturnsCorrectStaff()
        {
            // Arrange
            

                var list = context.StrategyStaffs.ToList();

                // Act
                var result = await repository.BulkMergeWithSubEntities(list);

                // Assert
                Assert.NotNull(result);
            
        }
        [Fact]
        public async Task DeleteStrategyStaff_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId = Guid.NewGuid(),
                        IsDeleted = false,
                        SagittaClientId = sagittaClient1.SagittaClientId
                    }
                },
                    PlanTimelines = new List<PlanTimeline>
                {
                    new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
                }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient
                    {
                        IsDeleted = false,
                        SagittaClientId = sagittaClient2.SagittaClientId
                    }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline
                    {
                        IsDeleted = false,
                        StatusCodeId = statusCode2.StatusCodeId,
                        StepDefId = stepDef.StepDefId
                    }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff
                    {
                        IsDeleted = false,
                        SagittaStaffId = sagittaStaff.SagittaStaffId
                    }
                }
                };

                context.Strategies.Add(strategy);
                context.StrategyStaffs.AddRange(new StrategyStaff
                {
                    StrategyStaffId = _strategyStaffId,
                    IsDeleted = false,
                    SagittaStaff = new SagittaStaff { SagittaStaffId = "NEMO", StaffName = "John Doe" }
                });

               await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new StrategyStaffRepository(context);

                // Act
                var result = await service.DeleteStrategyStaff(securityUserId, _strategyStaffId);

                // Assert
                Assert.True(result);

            }
        }

        [Fact]
        public async Task TrackStaffsChanges_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies

                context.StrategyStaffs.AddRange(new StrategyStaff
                {
                    StrategyStaffId = _strategyStaffId,
                    IsDeleted = false,
                    SagittaStaff = new SagittaStaff { SagittaStaffId = "NEMO", StaffName = "John Doe" }
                });

                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new StrategyStaffRepository(context);
                var list = new List<StrategyStaff>();
                list.Add(new StrategyStaff
                {
                    StrategyStaffId = _strategyStaffId,
                    IsDeleted = false,
                    SagittaStaff = new SagittaStaff { SagittaStaffId = "NEMO", StaffName = "John Doe" }
                });
                // Act
                await service.TrackStaffsChanges(list);

                // Assert
                Assert.True(true);

            }
        }



    }
}
