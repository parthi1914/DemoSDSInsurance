﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.Utilities;
using Microsoft.Data.Sqlite;



namespace BrokerPortal.API.UnitTest.Repositories
{
    public class TaskStackRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly TaskStackRepository _repository;
        private readonly Guid _taskStackId = Guid.NewGuid();
        private const string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=MarketTestDb20;Trusted_Connection=True;MultipleActiveResultSets=true";
        public TaskStackRepositoryTests()
        {

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.TaskStacks.AddRange(
  new List<TaskStack>
        {
            new TaskStack
            {
                TaskStackId=_taskStackId,
                TaskStatusCodeId="OPEN",
                IsDeleted = false,
                IsSysGen = false,
                TaskRefType="GENERIC",
                TaskSenderNavigation = new SecurityUser{SecurityUserId="balabharathi.s@mcgriff.com",UserEmail="balabharathi.s@mcgriff.com"},
                CreatedByNavigation = new SecurityUser{SecurityUserId="balabharathi.s@mcgriff.com",UserEmail="balabharathi.s@mcgriff.com"},
                UpdatedByNavigation = new SecurityUser{SecurityUserId="balabharathi.s@mcgriff.com",UserEmail="balabharathi.s@mcgriff.com"},
                TaskSteps = new List<TaskStep>
                {
                    new TaskStep
                    {
                        IsDeleted = false,
                        TaskAssignments = new List<TaskAssignment>
                        {
                            new TaskAssignment { TaskAssignTo="PLCC", IsDeleted = false }
                        }
                    }
                },
                TaskMeta = new List<TaskMeta>
                {
                    new TaskMeta
                    {
                        IsDeleted = false,
                        Strategy = new Strategy{StrategyName="Test",StatusCodeId="OPEN"},
                        SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" },
                        GenericTask = new GenericTask
                        {
                            GenericTaskMeta = new List<GenericTaskMeta>{ new GenericTaskMeta() }
                        }
                    }
                },
                GenericTasks=new List<GenericTask>{new GenericTask
            {
                GenericTaskId = Guid.NewGuid(),
                TaskStackId = _taskStackId,
                IsDeleted = false,

            }},
            }
  }
             );
            _context.TaskStatusCodes.AddRange(
new List<TaskStatusCode>
{ new TaskStatusCode{TaskStatusCodeId="OPEN",TaskStatusCode1="OPEN",TaskStatusName="OPEN",TaskStatusGroupCode="OPEN"}});

            _context.SaveChanges();
            _repository = new TaskStackRepository(_context);

        }
        [Fact]
        public async Task GetAllTaskStacks_ReturnsFilteredTaskStacks()
        {

            // Act
            var result = await _repository.GetAllTaskStacks();

            // Assert
            Assert.Single(result);
            Assert.False(result[0].IsDeleted);
            Assert.False(result[0].IsSysGen);
        }
        [Fact]
        public async Task GetTaskStackById_ReturnsFilteredTaskStacks()
        {

            // Act
            var result = await _repository.GetTaskStackById(_taskStackId);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsDeleted);
            Assert.False(result.IsSysGen);
        }
        [Fact]
        public async Task GetTaskStacksByIds_ReturnsFilteredTaskStacks()
        {
            //Arrange
            var taskIds = new List<Guid> { _taskStackId };
            // Act
            var result = await _repository.GetTaskStackById(_taskStackId);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsDeleted);
            Assert.False(result.IsSysGen);
        }
        [Fact]
        public async Task SaveTaskStack_AddsTaskStackAndSavesChanges()
        {
            // Arrange
            var mockSet = new Mock<DbSet<TaskStack>>();
            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(m => m.TaskStacks).Returns(mockSet.Object);
            mockContext.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var repository = new TaskStackRepository(mockContext.Object);
            var taskStack = new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack" };

            // Act
            var result = await repository.SaveTaskStack(taskStack);

            // Assert
            mockSet.Verify(m => m.Add(It.Is<TaskStack>(t => t == taskStack)), Times.Once);
            mockContext.Verify(m => m.SaveChangesAsync(default), Times.Once);
            Assert.Equal(taskStack, result);
        }
        [Fact]
        public void UpdateGenericTask_UpdatesEntityAndSavesChanges()
        {
            // Arrange
            var mockSet = new Mock<DbSet<GenericTask>>();
            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(m => m.GenericTasks).Returns(mockSet.Object);
            mockContext.Setup(m => m.SaveChanges()).Returns(1);

            var repository = new TaskStackRepository(mockContext.Object);
            var genericTask = new GenericTask { GenericTaskId = Guid.NewGuid() };

            // Act
            var result = repository.UpdateGenericTask(genericTask);

            // Assert
            mockSet.Verify(m => m.Update(It.Is<GenericTask>(g => g == genericTask)), Times.Once);
            mockContext.Verify(m => m.SaveChanges(), Times.Once);
            Assert.NotNull( result);
        }
        [Fact]
        public async Task UpdateTaskStack_UpdatesEntityAndSavesChanges()
        {
            // Arrange
            var mockSet = new Mock<DbSet<TaskStack>>();
            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(m => m.TaskStacks).Returns(mockSet.Object);
            mockContext.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var repository = new TaskStackRepository(mockContext.Object);
            var taskStack = new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Updated TaskStack" };

            // Act
            var result = await repository.UpdateTaskStack(taskStack);

            // Assert
            mockSet.Verify(m => m.Update(It.Is<TaskStack>(t => t == taskStack)), Times.Once);
            mockContext.Verify(m => m.SaveChangesAsync(default), Times.Once);
            Assert.Equal(taskStack, result);
        }
        [Fact]
        public async Task SaveGenericTask_AddsEntityAndSavesChanges()
        {
            // Arrange
            var mockSet = new Mock<DbSet<GenericTask>>();
            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(m => m.GenericTasks).Returns(mockSet.Object);
            mockContext.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var repository = new TaskStackRepository(mockContext.Object);
            var genericTask = new GenericTask { GenericTaskId = Guid.NewGuid()};

            // Act
            var result = await repository.SaveGenericTask(genericTask);

            // Assert
            mockSet.Verify(m => m.Add(It.Is<GenericTask>(g => g == genericTask)), Times.Once);
            mockContext.Verify(m => m.SaveChangesAsync(default), Times.Once);
            Assert.Equal(genericTask, result);
        }
        [Fact]
        public async Task GetGenericTaskForUpdateByTaskStackId_ReturnsExpectedGenericTask()
        {
            // Act
                var result = await _repository.GetGenericTaskForUpdateByTaskStackId(_taskStackId);

                // Assert
                Assert.NotNull(result);
                Assert.Equal(_taskStackId, result.TaskStackId);
                Assert.NotNull(result.GenericTaskMeta);
                Assert.NotNull(result.TaskStack);
                Assert.Single(result.TaskStack.TaskSteps);
                Assert.Single(result.TaskStack.TaskSteps.First().TaskAssignments);
            
        }
        [Fact]
        public async Task GetGenericTaskForUpdateByTaskStackIdWithNull_ReturnsExpectedGenericTask()
        {
            // Act
            var result = await _repository.GetGenericTaskForUpdateByTaskStackId(Guid.Empty);

            // Assert
            Assert.Null(result);

        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange
      

            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.ALL)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_MatchIds_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange
            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.ALL)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_MYASSIGNMENT__CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.MYASSIGNMENT)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_MYREQUEST__CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.MYREQUEST)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_SYSTEM__CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.ALL)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_SYSTEM_MYASSIGNMENT___CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.MYASSIGNMENT)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_SYSTEM_MYREQUEST___CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.MYREQUEST)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_ALL_SYSTEM__CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "ALL",
                TaskAssignType = nameof(TaskAssignTypeSearchCriteria.ALL)
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task SearchTaskStacks_WithAllFilterType_MYREQUEST_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = "MYREQUEST"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.ALL,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithUSER_SPECIFICFilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = "ALL"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.USER_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithUSER_SPECIFICFilterType_MYASSIGNMENT_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "MYASSIGNMENT",
                TaskAssignType = "ALL"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.USER_SPECIFIC,
                TaskSearchType.MYASSIGNMENT,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
       
        [Fact]
        public async Task SearchTaskStacks_WithUSER_SPECIFICFilterType_GENERIC_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = "ALL"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.USER_SPECIFIC,
                TaskSearchType.MYASSIGNMENT,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithUSER_SPECIFICFilterType_SYSYEM_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = "ALL"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.USER_SPECIFIC,
                TaskSearchType.MYASSIGNMENT,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithUSER_SPECIFIC_SYSTEM_FilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = "ALL"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.USER_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_WithUSER_SPECIFIC_ALL_FilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "ALL",
                TaskAssignType = "ALL"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.USER_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchTaskStacks_CLIENT_SPECIFICFilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "ALL",
                TaskAssignType = "MYASSIGNMENT"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_CLIENT_SPECIFICFilterType_GENERIC_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = "MYASSIGNMENT"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_CLIENT_SPECIFICFilterType_SYSTEM_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = "MYASSIGNMENT"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_STRATEGY_SPECIFICFilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange

            var strategy = Guid.NewGuid();
            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "SYSTEM",
                TaskAssignType = "MYREQUEST"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.STRATEGY_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null,null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_STRATEGY_SPECIFICF_GENERIC_ilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange

            var strategy = Guid.NewGuid();
            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "GENERIC",
                TaskAssignType = "MYREQUEST"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.STRATEGY_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchTaskStacks_STRATEGY_SPECIFICF_ALL_ilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange

            var strategy = Guid.NewGuid();
            var searchCriterias = new TaskSearchCriterias
            {
                TaskStatusCodes = new[] { "OPEN" },
                TaskCategory = "ALL",
                TaskAssignType = "MYREQUEST"
            };
            // Act
            var result = await _repository.SearchTaskStacks(
                SearchBaseFilterType.STRATEGY_SPECIFIC,
                TaskSearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null,
                null, null, null
            );

            // Assert
            Assert.Null(result);
        }
      
        [Fact]
        public void GetAllTaskStatusCodesIds_ReturnsAllIds()
        {
            // Act
            var result = _repository.GetAllTaskStatusCodesIds();

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public void GetAllTaskStatusCodesIdsByGroupCode_ReturnsAllIds()
        {
            // Act
            var result = _repository.GetAllTaskStatusCodesIdsByGroupCode("OPEN");

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public async Task DeleteTaskStack_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
        {
            new PlanClient
            {
                PlanClientId = Guid.NewGuid(),
                IsDeleted = false,
                SagittaClientId = sagittaClient1.SagittaClientId
            }
        },
                    PlanTimelines = new List<PlanTimeline>
        {
            new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
        }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
        {
            new StrategyClient
            {
                IsDeleted = false,
                SagittaClientId = sagittaClient2.SagittaClientId
            }
        },
                    StrategyTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline
            {
                IsDeleted = false,
                StatusCodeId = statusCode2.StatusCodeId,
                StepDefId = stepDef.StepDefId
            }
        },
                    StrategyStaffs = new List<StrategyStaff>
        {
            new StrategyStaff
            {
                IsDeleted = false,
                SagittaStaffId = sagittaStaff.SagittaStaffId
            }
        }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new TaskStackRepository(context);

                // Act
                var result = await service.DeleteTaskStack(strategyId, securityUserId);

                // Assert
                Assert.True(result);

            }
        }
        [Fact]
        public async Task RemoveTaskStack_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
        {
            new PlanClient
            {
                PlanClientId = Guid.NewGuid(),
                IsDeleted = false,
                SagittaClientId = sagittaClient1.SagittaClientId
            }
        },
                    PlanTimelines = new List<PlanTimeline>
        {
            new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
        }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
        {
            new StrategyClient
            {
                IsDeleted = false,
                SagittaClientId = sagittaClient2.SagittaClientId
            }
        },
                    StrategyTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline
            {
                IsDeleted = false,
                StatusCodeId = statusCode2.StatusCodeId,
                StepDefId = stepDef.StepDefId
            }
        },
                    StrategyStaffs = new List<StrategyStaff>
        {
            new StrategyStaff
            {
                IsDeleted = false,
                SagittaStaffId = sagittaStaff.SagittaStaffId
            }
        }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new TaskStackRepository(context);

                // Act
                var result = await service.RemoveTaskStack(strategyId, securityUserId);

                // Assert
                Assert.True(result);

            }
        }
        [Fact]
        public async Task UpdateRangeTaskStacks_UpdatesEntitiesCorrectly()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
       .Options;
           
            var context = new BrokerPortalApiDBContext(options);

            var repository = new TaskStackRepository(context);
            
            context.TaskStacks.AddRange(new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack" });
            await context.SaveChangesAsync();
            var timelinesToUpdate = context.TaskStacks.ToList();
            // Act
            var result = await repository.UpdateRangeTaskStacks(timelinesToUpdate);

            // Assert
            Assert.NotNull(result);

        }

        [Fact]
        public async Task UpdateRangeTaskAssignments_UpdatesEntitiesCorrectly()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
       .Options;

            var context = new BrokerPortalApiDBContext(options);

            var repository = new TaskStackRepository(context);

            context.TaskAssignments.AddRange(new TaskAssignment { TaskAssignmentId = Guid.NewGuid()});
            await context.SaveChangesAsync();
            var timelinesToUpdate = context.TaskAssignments.ToList();
            // Act
            var result = await repository.UpdateRangeTaskAssignments(timelinesToUpdate);

            // Assert
            Assert.NotNull(result);

        }

        [Fact]
        public async Task TrackTasksChanges_UpdatesEntitiesCorrectly()
        {
            // Arrange

            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new TaskStackRepository(context);
                context.TaskStacks.AddRange(new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack" });
                await context.SaveChangesAsync();
                var timelinesToUpdate = context.TaskStacks.ToList();
                // Act
                await service.TrackTasksChanges(timelinesToUpdate);

                // Assert
                Assert.True(true);

            }

        }
        [Fact]
        public async Task TrackTasksChanges_Child_UpdatesEntitiesCorrectly()
        {
            // Arrange

            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new TaskStackRepository(context);
                context.TaskStacks.AddRange(new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack" });
                await context.SaveChangesAsync();
                var timelinesToUpdate = context.TaskStacks.ToList();
                timelinesToUpdate[0].TaskStatusReason = "Changed";
                // Act
                 await service.TrackTasksChanges(timelinesToUpdate);

                // Assert
                    Assert.True(true);

            }

        }
        [Fact]
        public async Task BulkMergeTaskAssignments_UpdatesEntitiesCorrectly()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
       .Options;

            var context = new BrokerPortalApiDBContext(options);

            var repository = new TaskStackRepository(context);

            context.TaskAssignments.AddRange(new TaskAssignment { TaskAssignmentId = Guid.NewGuid() });
            await context.SaveChangesAsync();
            var timelinesToUpdate = context.TaskAssignments.ToList();
            // Act
            var result = await repository.BulkMergeTaskAssignments(timelinesToUpdate);

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task BulkMergeTaskStacks_UpdatesMatchingTaskSteps()
        {// Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");

            var repository = new TaskStackRepository(context);

            // Act
            
            var task = new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack" };
            var result = await repository.BulkMergeTaskStacks(new List<TaskStack> { task });

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetAllTasksByStrategyInclMarkets_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
            var service = new TaskStackRepository(context);
                // Act
                var result = await service.GetAllTasksByStrategyInclMarkets(Guid.NewGuid());

                // Assert
                Assert.Null(result);
            
        }
        [Fact]
        public async Task FindUserTeamByFilters_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
            var service = new TaskStackRepository(context);
            // Act
            var userStaffIds = new[] { "staff1", "staff2" };
            var expectedStaffIds = new[] { "staff3", "staff4" };
            string[] staffs = ["PLCC"];
            var result =  service.FindUserTeamByFilters(SearchBaseFilterType.ALL,staffs,123,Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task FindUserTeamByFilters_CLIENT_SPECIFIC_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
            var service = new TaskStackRepository(context);
            // Act
            var userStaffIds = new[] { "staff1", "staff2" };
            var expectedStaffIds = new[] { "staff3", "staff4" };
            string[] staffs = ["PLCC"];
            var result = service.FindUserTeamByFilters(SearchBaseFilterType.CLIENT_SPECIFIC, staffs, 123, Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task FindUserTeamByFilters_STRATEGY_SPECIFIC_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
            var service = new TaskStackRepository(context);
            // Act
            var userStaffIds = new[] { "staff1", "staff2" };
            var expectedStaffIds = new[] { "staff3", "staff4" };
            string[] staffs = ["PLCC"];
            var result = service.FindUserTeamByFilters(SearchBaseFilterType.STRATEGY_SPECIFIC, staffs, 123, Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task FindUserTeamByFilters_USER_SPECIFIC_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
            var service = new TaskStackRepository(context);
            // Act
            var userStaffIds = new[] { "staff1", "staff2" };
            var expectedStaffIds = new[] { "staff3", "staff4" };
            string[] staffs = ["PLCC"];
            var result = service.FindUserTeamByFilters(SearchBaseFilterType.USER_SPECIFIC, staffs, 123, Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetTaskAssignmentByStrategyStaffId_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");
            var service = new TaskStackRepository(context);
            // Act
            var userStaffIds = new[] { "staff1", "staff2" };
            var expectedStaffIds = new[] { "staff3", "staff4" };
            string[] staffs = ["PLCC"];
            var result = service.GetTaskAssignmentByStrategyStaffId( Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetStaffAssignedByStrategyTimelines_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            var service = new TaskStackRepository(context);
            // Act

            var result = service.GetStaffAssignedByStrategyTimelines( new List<Guid> { Guid.NewGuid() });

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetStaffAssignedByMarketsTimelines_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            var service = new TaskStackRepository(context);
            // Act

            var result = service.GetStaffAssignedByMarketsTimelines(new List<Guid> { Guid.NewGuid() });

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetStrategyStaffAssignmentsByStrategy_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            var service = new TaskStackRepository(context);
            // Act

            var result = service.GetStrategyStaffAssignmentsByStrategy(Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetStaffAssignedByStrategyAndMarketsTimelines_ReturnsExpectedTasks()
        {

            // Arrange
            using var context = CreateContext();
            var service = new TaskStackRepository(context);
            // Act

            var result = service.GetStaffAssignedByStrategyAndMarketsTimelines(new List<Guid> { Guid.NewGuid() });

            // Assert
            Assert.NotNull(result);

        }

        private BrokerPortalApiDBContext CreateContext()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlServer(ConnectionString)
                .Options;

            var context = new BrokerPortalApiDBContext(options);
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            return context;
        }


    }
}
