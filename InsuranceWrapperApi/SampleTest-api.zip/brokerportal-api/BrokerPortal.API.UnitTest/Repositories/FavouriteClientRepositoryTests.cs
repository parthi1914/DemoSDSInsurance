﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class FavouriteClientRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly FavouriteClientRepository _repository;
        private static readonly Guid favClientId = Guid.NewGuid();

        public FavouriteClientRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.FavouriteClients.AddRange(
                new FavouriteClient
                {
                    FavouriteClientId = favClientId,
                    IsDeleted = false,
                    SecurityUserId = "balabharathi.s@mcgriff.com",
                    SagittaClient = new SagittaClient { SagittaClientId = 101,ClientName="Test 1",ClientCode="Sally"}
                },
                new FavouriteClient
                {
                    FavouriteClientId = Guid.NewGuid(),
                    IsDeleted = false,
                    SecurityUserId = "test@mcgriff.com",
                    SagittaClient = new SagittaClient { SagittaClientId = 102, ClientName = "Test 2", ClientCode = "Sally 2" }
                }
            );

            _context.SaveChanges();
            _repository = new FavouriteClientRepository(_context);
        }

        [Fact]
        public async Task GetAllFavouriteClients_ReturnsOnlyNonDeletedClients()
        {
            // Act
            var result = await _repository.GetAllFavouriteClients();

            // Assert
            Assert.Equal(2, result.Count);
        }
        [Fact]
        public async Task GetUserFavouriteClients_ReturnsOnlyNonDeletedClientsForUser()
        {
            // Act
            var result = await _repository.GetUserFavouriteClients("balabharathi.s@mcgriff.com");

            // Assert
            Assert.Single(result);
            Assert.All(result, client => Assert.Equal("balabharathi.s@mcgriff.com", client.SecurityUserId));
        }
        [Fact]
        public async Task GetUserFavouriteClientById_ReturnsCorrectClient()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";

            // Act
            var result = await _repository.GetUserFavouriteClientById(securityUserId, favClientId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(favClientId, result.FavouriteClientId);
        }
        [Fact]
        public async Task SaveUserFavouriteClient_AddsClientSuccessfully()
        {
            // Arrange
            var newClient = new FavouriteClient
            {
                FavouriteClientId = Guid.NewGuid(),
                IsDeleted = false,
                SecurityUserId = "newuser@mcgriff.com",
                SagittaClient = new SagittaClient
                {
                    SagittaClientId = 301,
                    ClientName = "New Client",
                    ClientCode = "NC001"
                }
            };

            // Act
            var result = await _repository.SaveUserFavouriteClient(newClient);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("newuser@mcgriff.com", result.SecurityUserId);
            Assert.Contains(_context.FavouriteClients, fc => fc.FavouriteClientId == newClient.FavouriteClientId);
        }
        [Fact]
        public async Task UpdateUserFavouriteClient_UpdatesClientSuccessfully()
        {
            // Arrange
            var existingClient = _context.FavouriteClients.First();
            var updatedClient = new FavouriteClient
            {
                FavouriteClientId = existingClient.FavouriteClientId,
                SecurityUserId = "updateduser@mcgriff.com"
            };

            var repository = new FavouriteClientRepository(_context);

            // Act
            var result = await repository.UpdateUserFavouriteClient(updatedClient);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(updatedClient.FavouriteClientId, result.FavouriteClientId);
            Assert.Equal("updateduser@mcgriff.com", result.UpdatedBy);
            Assert.True(result.IsDeleted);
            Assert.True(result.UpdatedDate <= DateTime.Now && result.UpdatedDate > DateTime.Now.AddMinutes(-1));
        }
        [Fact]
        public void IsClientIdExists_ReturnsFalse_WhenClientDoesNotExist()
        {
            // Act
            var exists = _repository.IsClientIdExists(99999L);

            // Assert
            Assert.False(exists);
        }

        [Fact]
        public async Task AddSagittaClient_AddsClientSuccessfully()
        {
            // Arrange
            var client = new SagittaClient
            {
                SagittaClientId = 54321L,
                ClientCode = "C002",
                ClientName = "New Client"
            };

            // Act
            var result = await _repository.AddSagittaClient(client);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("C002", result.ClientCode);
        }
        [Fact]
        public async Task GetUserFavouriteClientByClientId_ValidInput_ReturnsFavouriteClient()
        {
            // Arrange
            var securityUserId = "balabharathi.s@mcgriff.com";
            var clientId = 101;

            // Act
            var result = await _repository.GetUserFavouriteClientByClientId(securityUserId, clientId);

            // Assert
            Assert.NotNull(result);
        }



    }
}
