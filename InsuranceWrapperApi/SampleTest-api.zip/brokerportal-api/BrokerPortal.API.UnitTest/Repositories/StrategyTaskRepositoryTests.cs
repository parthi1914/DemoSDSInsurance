﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using Moq;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class StrategyTaskRepositoryTests
    {
        private List<StrategyTaskMeta> GetFakeStrategyTasks()
        {
            return new List<StrategyTaskMeta>
        {
            new StrategyTaskMeta { StrategyId = Guid.Parse("11111111-1111-1111-1111-111111111111"), StrategyTimelineId = Guid.Parse("aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),Strategy=new Strategy
                {
                    StrategyId = Guid.Parse("11111111-1111-1111-1111-111111111111"),
                    IsDeleted = false,
                    StrategyName="test strategy",
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient { IsDeleted = false, SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" } }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline { IsDeleted = false, StatusCode =  new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" }, StepDef =new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode= "MS-SUBM",
                    FlowDefId="MS",
                    StepName= "MS-SUBM",
                    StepNameDisplay= "MS-SUBM",
                  IsDeleted =false

                } }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff { IsDeleted = false, SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" } }
                },
                    StatusCode =  new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                    UpdatedByNavigation = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" }
                },
                TaskStack= new TaskStack { TaskStackId = Guid.NewGuid(), TaskName = "Test TaskStack" }
            }
          
        };
        }

        private BrokerPortalApiDBContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            var context = new BrokerPortalApiDBContext(options);
            context.StrategyTaskMeta.AddRange(GetFakeStrategyTasks());
            context.SaveChanges();

            return context;
        }

        [Fact]
        public async Task GetStrategyTaskByStrategyId_ReturnsCorrectTasks()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new StrategyTaskRepository(context);
            var strategyId = Guid.Parse("11111111-1111-1111-1111-111111111111");

            // Act
            var result = await repository.GetStrategyTaskByStrategyId(strategyId);

            // Assert
            Assert.Single(result);
            Assert.Equal(strategyId, result.First().StrategyId);
        }
        [Fact]
        public async Task GetStrategyTaskByStrategyId_WhenExceptionThrown_ReturnsNullOrEmptyList()
        {
            // Arrange
            var mockContext = new Mock<BrokerPortalApiDBContext>();

            var repository = new StrategyTaskRepository(mockContext.Object);

            // Act
            var result = await repository.GetStrategyTaskByStrategyId(Guid.NewGuid());

            // Assert
            Assert.Null(result); 
        }
        [Fact]
        public async Task GetStrategyTimelineByTimelineId_WhenExceptionThrown_ReturnsNullOrEmptyList()
        {
            // Arrange
            var mockContext = new Mock<BrokerPortalApiDBContext>();

            var repository = new StrategyTaskRepository(mockContext.Object);

            // Act
            var result = await repository.GetStrategyTimelineByTimelineId(Guid.NewGuid());

            // Assert
            Assert.Null(result);
        }



        [Fact]
        public async Task GetStrategyTimelineByTimelineId_ReturnsCorrectTask()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var repository = new StrategyTaskRepository(context);
            var timelineId = Guid.Parse("aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaaa");

            // Act
            var result = await repository.GetStrategyTimelineByTimelineId(timelineId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(timelineId, result.StrategyTimelineId);
        }
    }
}