﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.Utilities;
using Moq;

namespace BrokerPortal.API.UnitTest.Repositories
{
   public class FavouriteStrategyRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly FavouriteStrategyRepository _repository;

        public FavouriteStrategyRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new BrokerPortalApiDBContext(options);
            _context.Database.EnsureCreated();

            _repository = new FavouriteStrategyRepository(_context);
        }

        [Fact]
        public async Task GetAllFavouriteStrategies_ReturnsOnlyNotDeleted()
        {
            // Arrange
            _context.FavouriteStrategies.AddRange(
                new FavouriteStrategy { FavouriteStrategyId = Guid.NewGuid(), IsDeleted = false, SecurityUserId = "balabharathi.s@mcgriff.com" },
                new FavouriteStrategy { FavouriteStrategyId = Guid.NewGuid(), IsDeleted = true, SecurityUserId = "balabharathi.s@mcgriff.com" }
            );
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetAllFavouriteStrategies();

            // Assert
            Assert.Single(result);
            Assert.Equal("balabharathi.s@mcgriff.com", result[0].SecurityUserId);
        }

        [Fact]
        public async Task GetFavouriteStrategyById_ReturnsCorrectStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            _context.FavouriteStrategies.Add(new FavouriteStrategy
            {
                FavouriteStrategyId = strategyId,
                SecurityUserId = "balabharathi.s@mcgriff.com",
                IsDeleted = false
            });
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetFavouriteStrategyById(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("balabharathi.s@mcgriff.com", result.SecurityUserId);
        }
        [Fact]
        public async Task SaveFavouriteStrategy_AddsNewStrategy()
        {
            // Arrange
            var strategy = new FavouriteStrategy
            {
                FavouriteStrategyId = Guid.NewGuid(),
                SecurityUserId = "user1",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Act
            var result = await _repository.SaveFavouriteStrategy(strategy);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("user1", result.SecurityUserId);
            Assert.Single(_context.FavouriteStrategies);
        }

        [Fact]
        public async Task UpdateFavouriteStrategy_UpdatesExistingStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var original = new FavouriteStrategy
            {
                FavouriteStrategyId = strategyId,
                SecurityUserId = "user1",
                IsDeleted = false
            };
            _context.FavouriteStrategies.Add(original);
            await _context.SaveChangesAsync();

            var updated = new FavouriteStrategy
            {
                FavouriteStrategyId = strategyId,
                SecurityUserId = "user2"
            };

            // Act
            var result = await _repository.UpdateFavouriteStrategy(updated);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("user2", result.UpdatedBy);
            Assert.True(result.IsDeleted.Value);
        }

        [Fact]
        public async Task GetFavouriteStrategiesByUser_ReturnsCorrectResults()
        {
            // Arrange
            var userId = "user1";
            var sagittaStaffId = "staff123";

            var plan = new Plan { PlanId = Guid.NewGuid(), PlanName = "Plan A",StatusCodeId=AppConstants.STEP_STATUSCODE_ACTIVE };
            var client = new SagittaClient { SagittaClientId = 100097, ClientCode = "C001", ClientName = "Client A" };
            var strategy = new Strategy
            {
                StrategyId = Guid.NewGuid(),
                PlanId = plan.PlanId,
                StrategyName = "Strategy A",
                CreatedBy = userId,
                IsDeleted = false,
                StatusCodeId = AppConstants.STEP_STATUSCODE_ACTIVE
            };
            var strategyClient = new StrategyClient
            {
                StratgeyClientId = Guid.NewGuid(),
                StrategyId = strategy.StrategyId,
                SagittaClientId = client.SagittaClientId
            };
            var strategyStaff = new StrategyStaff
            {
                StrategyStaffId = Guid.NewGuid(),
                StrategyId = strategy.StrategyId,
                SagittaStaffId = sagittaStaffId,
                IsDeleted = false
            };
            var favStrategy = new FavouriteStrategy
            {
                FavouriteStrategyId = Guid.NewGuid(),
                StrategyId = strategy.StrategyId,
                SecurityUserId = userId,
                IsDeleted = false
            };

            _context.Plans.Add(plan);
            _context.SagittaClients.Add(client);
            _context.Strategies.Add(strategy);
            _context.StrategyClients.Add(strategyClient);
            _context.StrategyStaffs.Add(strategyStaff);
            _context.FavouriteStrategies.Add(favStrategy);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetFavouriteStrategiesByUser(userId, new[] { sagittaStaffId });

            // Assert
            Assert.Single(result);
            Assert.Equal("Strategy A", result[0].StrategyName);
            Assert.Equal("Plan A", result[0].PlanName);
        }

        [Fact]
        public async Task GetFavouriteStrategyByStrategyId_ValidInput_ReturnsFavouriteStrategy()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";

            // Act
            var result = await _repository.GetFavouriteStrategyByStrategyId(strategyId, securityUserId);

            // Assert
            Assert.Null(result);
        }



        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }
    }
}
