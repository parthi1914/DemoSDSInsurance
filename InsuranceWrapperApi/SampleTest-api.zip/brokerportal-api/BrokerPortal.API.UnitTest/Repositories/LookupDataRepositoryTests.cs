﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class LookupDataRepositoryTests
    {

        private readonly BrokerPortalApiDBContext _context;
        private readonly LookupDataRepository _repository;

        public LookupDataRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.StepDefs.AddRange(
                new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode= "MS-SUBM",
                    FlowDefId="MS",
                    StepName= "MS-SUBM",
                    StepNameDisplay= "MS-SUBM",
                  IsDeleted =false
                    
                }
                
            );

            _context.SaveChanges();
            _repository = new LookupDataRepository(_context);
        }
        [Fact]
        public void GetAllStepDefs_ReturnsOnlyNonDeletedSteps()
        {
            // Act
            var result = _repository.GetAllStepDefs();

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public void GetAllSubStepDefs_ReturnsOnlyNonDeletedSubSteps()
        {
            // Arrange
            var data = new List<SubStepDef>
        {
            new SubStepDef { SubStepDefId = "1", IsDeleted = false },
            new SubStepDef { SubStepDefId = "2", IsDeleted = true },
            new SubStepDef { SubStepDefId = "3", IsDeleted = false }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<SubStepDef>>();
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(c => c.SubStepDefs).Returns(mockSet.Object);

            var repository = new LookupDataRepository(mockContext.Object);

            // Act
            var result = repository.GetAllSubStepDefs();

            // Assert
            Assert.Equal(2, result.Count);
            Assert.All(result, x => Assert.False(x.IsDeleted));
        }
        [Fact]
        public void GetAllSubStepDefsByStepDefId_ReturnsFilteredSubSteps()
        {
            // Arrange
            var stepDefId = "step-123";
            var data = new List<SubStepDef>
        {
            new SubStepDef { SubStepDefId = "1", StepDefId = "step-123", IsDeleted = false },
            new SubStepDef { SubStepDefId = "2", StepDefId = "step-123", IsDeleted = true },
            new SubStepDef { SubStepDefId = "3", StepDefId = "step-456", IsDeleted = false },
            new SubStepDef { SubStepDefId = "4", StepDefId = "step-123", IsDeleted = false }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<SubStepDef>>();
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<SubStepDef>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(c => c.SubStepDefs).Returns(mockSet.Object);

            var repository = new LookupDataRepository(mockContext.Object);

            // Act
            var result = repository.GetAllSubStepDefsByStepDefId(stepDefId);

            // Assert
            Assert.Equal(2, result.Count);
            Assert.All(result, x => Assert.Equal(stepDefId, x.StepDefId));
            Assert.All(result, x => Assert.False(x.IsDeleted));
        }
        [Fact]
        public void GetAllStepDefIdsByFlowDef_ReturnsOnlyNonDeletedSteps()
        {
            // Act
            var result = _repository.GetAllStepDefIdsByFlowDef("MS");

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public void GetAllStepDefsByFlowDef_ReturnsOnlyNonDeletedSteps()
        {
            // Act
            var result = _repository.GetAllStepDefsByFlowDef("MS");

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public void GetSortedStepsByStrategyFlow_ReturnsOnlyNonDeletedSteps()
        {
            // Act
            var result = _repository.GetSortedStepsByStrategyFlow("MS");

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public void GetAllBPStatusCodesIds_ReturnsAllStatusCodeIds()
        {
            // Arrange
            var data = new List<BpstatusCode>
        {
            new BpstatusCode { StatusCodeId = "SC001" },
            new BpstatusCode { StatusCodeId = "SC002" },
            new BpstatusCode { StatusCodeId = "SC003" }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<BpstatusCode>>();
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(c => c.BpstatusCodes).Returns(mockSet.Object);

            var repository = new LookupDataRepository(mockContext.Object);

            // Act
            var result = repository.GetAllBPStatusCodesIds();

            // Assert
            Assert.Equal(3, result.Count);
            Assert.Contains("SC001", result);
            Assert.Contains("SC002", result);
            Assert.Contains("SC003", result);
        }
        [Fact]
        public void GetAllBPStatusCodes_ReturnsAllStatusCodes()
        {
            // Arrange
            var data = new List<BpstatusCode>
        {
            new BpstatusCode { StatusCodeId = "SC001", StatusCode = "Open" },
            new BpstatusCode { StatusCodeId = "SC002", StatusCode = "Closed" }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<BpstatusCode>>();
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(c => c.BpstatusCodes).Returns(mockSet.Object);

            var repository = new LookupDataRepository(mockContext.Object);

            // Act
            var result = repository.GetAllBPStatusCodes();

            // Assert
            Assert.Equal(2, result.Count);
            Assert.Contains(result, x => x.StatusCodeId == "SC001");
            Assert.Contains(result, x => x.StatusCodeId == "SC002");
        }
        [Fact]
        public void GetAllTaskStatusCodes_ReturnsAllTaskStatusCodes()
        {
            // Arrange
            var data = new List<TaskStatusCode>
        {
            new TaskStatusCode { TaskStatusCodeId = "TS001", TaskStatusDesc = "Pending" },
            new TaskStatusCode { TaskStatusCodeId = "TS002", TaskStatusDesc = "Completed" }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<TaskStatusCode>>();
            mockSet.As<IQueryable<TaskStatusCode>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<TaskStatusCode>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<TaskStatusCode>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<TaskStatusCode>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(c => c.TaskStatusCodes).Returns(mockSet.Object);

            var repository = new LookupDataRepository(mockContext.Object);

            // Act
            var result = repository.GetAllTaskStatusCodes();

            // Assert
            Assert.Equal(2, result.Count);
            Assert.Contains(result, x => x.TaskStatusCodeId == "TS001");
            Assert.Contains(result, x => x.TaskStatusCodeId == "TS002");
        }
        [Fact]
        public void GetAllBPStatusCodesIdsByGroupCode_ReturnsMatchingStatusCodeIds()
        {
            // Arrange
            var groupCode = "GRP001";
            var data = new List<BpstatusCode>
        {
            new BpstatusCode { StatusCodeId = "SC001", StatusGroupCode = "GRP001" },
            new BpstatusCode { StatusCodeId = "SC002", StatusGroupCode = "GRP002" },
            new BpstatusCode { StatusCodeId = "SC003", StatusGroupCode = null },
            new BpstatusCode { StatusCodeId = "SC004", StatusGroupCode = "GRP001" }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<BpstatusCode>>();
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<BpstatusCode>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<BrokerPortalApiDBContext>();
            mockContext.Setup(c => c.BpstatusCodes).Returns(mockSet.Object);

            var repository = new LookupDataRepository(mockContext.Object);

            // Act
            var result = repository.GetAllBPStatusCodesIdsByGroupCode(groupCode);

            // Assert
            Assert.Equal(2, result.Count);
            Assert.Contains("SC001", result);
            Assert.Contains("SC004", result);
            Assert.DoesNotContain("SC002", result);
            Assert.DoesNotContain("SC003", result);
        }
    }
}
