﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class MarketTaskRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly Mock<MarketRepository> _mockRepository;
        private readonly MarketTaskRepository _repository;
        private readonly Guid _marketId;

        public MarketTaskRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.Markets.AddRange(
               new Market
               {
                   MarketId = _marketId,
                   StrategyId = Guid.Parse("11111111-1111-1111-1111-111111111111"),
                   IsDeleted = false,
                   GrpNumber = 1,
                   StepDef = new StepDef
                   {
                       StepDefId = "MS-SUBM",
                       StepDefCode = "MS-SUBM",
                       FlowDefId = "MS",
                       StepName = "MS-SUBM",
                       StepNameDisplay = "MS-SUBM",
                       IsDeleted = false,
                       StepOrder = 2

                   },
                   MarketAddlCovs = new List<MarketAddlCov> { new MarketAddlCov { IsDeleted = false } },
                   MarketTimelines = new List<MarketTimeline> { new MarketTimeline { IsDeleted = false, StepDefId = "MS-SUBM", StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" } } },
                   MarketTaskMeta = new List<MarketTaskMeta>
             {
                new MarketTaskMeta
                {
                    IsDeleted = false,
                    TaskStack = new TaskStack
                    {
                        TaskMeta = new List<TaskMeta>{ new TaskMeta() },
                        TaskSteps = new List<TaskStep>
                        {
                            new TaskStep
                            {
                                IsDeleted = false,
                                TaskAssignments = new List<TaskAssignment>
                                {
                                    new TaskAssignment { IsDeleted = false }
                                }
                            }
                        }
                    }
                }
                     }
               }
             );


            _context.SaveChanges();
            _repository = new MarketTaskRepository(_context);

        }
        [Fact]
        public void GetMarketTaskById_ReturnsCorrectMarketTasks()
        {
            // Act
            var result = _repository.GetMarketTaskById(_marketId);

            // Assert
            Assert.Equal(_marketId, result[0].MarketId);
        }
        [Fact]
        public void GetAllMarketTask_ThrowsNotImplementedException()
        {
            // Act & Assert
            Assert.Throws<NotImplementedException>(() => _repository.GetAllMarketTask());
        }
        [Fact]
        public async Task BulkMerge_CallsBulkMergeOnContext()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var marketTaskList = new List<MarketTaskMeta>
    {
        new MarketTaskMeta { MarketId = marketId }
    };
            // Act
            await _repository.BulkMerge(marketTaskList);

            // Assert
            var saved = _repository.GetMarketTaskById(marketId);
            Assert.Equal(marketId, saved[0].MarketId);

        }
        [Fact]
        public async Task BulkMerge_WhenExceptionThrown_ShouldCatchException()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var marketTaskList = new List<MarketTaskMeta>
    {
        new MarketTaskMeta { MarketId = marketId }
    };
            // Act
            await _repository.BulkMerge(null);

            // Assert
            Assert.True(true);
        }



    }
}
