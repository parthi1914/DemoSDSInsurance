﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Data.Entity;
using BrokerPortal.API.RepositoryContracts;
using BrokerPortal.API.Services;
using Microsoft.Data.Sqlite;
using BrokerPortal.API.Utilities;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class MarketRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly Mock<MarketRepository> _mockRepository;
        private readonly MarketRepository _repository;
        private readonly Guid _marketId;
        private const string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=MarketTestDb;Trusted_Connection=True;MultipleActiveResultSets=true";

        public MarketRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.Markets.AddRange(
              new Market
              {
                  MarketId = _marketId,
                  StrategyId = Guid.Parse("11111111-1111-1111-1111-111111111111"),
                  IsDeleted = false,
                  GrpNumber = 1,
                  StepDef = new StepDef
                  {
                      StepDefId = "MS-SUBM",
                      StepDefCode = "MS-SUBM",
                      FlowDefId = "MS",
                      StepName = "MS-SUBM",
                      StepNameDisplay = "MS-SUBM",
                      IsDeleted = false,
                      StepOrder = 2

                  },
                  MarketAddlCovs = new List<MarketAddlCov> { new MarketAddlCov { IsDeleted = false } },
                  MarketTimelines = new List<MarketTimeline> { new MarketTimeline { IsDeleted = false, StepDefId = "MS-SUBM", StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" } } },
                  MarketTaskMeta = new List<MarketTaskMeta>
            {
                new MarketTaskMeta
                {
                    IsDeleted = false,
                    TaskStack = new TaskStack
                    {
                        TaskMeta = new List<TaskMeta>{ new TaskMeta() },
                        TaskSteps = new List<TaskStep>
                        {
                            new TaskStep
                            {
                                IsDeleted = false,
                                TaskAssignments = new List<TaskAssignment>
                                {
                                    new TaskAssignment { IsDeleted = false }
                                }
                            }
                        }
                    }
                }
                    }
              }
            );

            _context.SaveChanges();
            _repository = new MarketRepository(_context);

        }

        [Fact]
        public void GetAllMarketByStrategy_ReturnsMarkets_WhenStrategyIdMatches()
        {
            // Arrange
            var strategyId = Guid.Parse("11111111-1111-1111-1111-111111111111");

            // Act
            var result = _repository.GetAllMarketByStrategy(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal(strategyId, result[0].StrategyId);
        }
        [Fact]
        public void GetAllMarketByStrategies_ReturnsMarkets_WhenStrategyIdsMatch()
        {
            // Arrange
            var strategyId = Guid.Parse("11111111-1111-1111-1111-111111111111");
            var strategyId2 = Guid.NewGuid();
            var strategyIdList = new List<Guid> { strategyId };


            // Act
            var result = _repository.GetAllMarketByStrategies(strategyIdList);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Count);
            Assert.All(result, m => Assert.Contains(m.StrategyId, strategyIdList));
        }
        [Fact]
        public async Task GetMarketById_ReturnsMarket_WhenMarketExists()
        {
            // Act
            var result = await _repository.GetMarketById(_marketId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(_marketId, result.MarketId);

        }
        [Fact]
        public async Task GetMarketsForUpdateByStrategy_ReturnsMarkets_WhenStrategyIdMatches()
        {
            // Arrange
            var strategyId = Guid.Parse("11111111-1111-1111-1111-111111111111");

            // Act
            var result = await _repository.GetMarketsForUpdateByStrategy(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal(strategyId, result[0].StrategyId);
        }
        [Fact]
        public async Task GetMarketForUpdateById_ReturnsMarket_WhenMarketExists()
        {
            // Act
            var result = await _repository.GetMarketForUpdateById(_marketId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(_marketId, result.MarketId);

        }
        [Fact]
        public async Task GetMarketsForStrategySyncByStrategy_ReturnsMarkets_WhenStrategyIdMatches()
        {
            // Arrange
            var strategyId = Guid.Parse("11111111-1111-1111-1111-111111111111");

            // Act
            var result = await _repository.GetMarketsForStrategySyncByStrategy(strategyId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal(strategyId, result[0].StrategyId);
        }
        [Fact]
        public async Task SaveMarket_AddsMarketToDatabase()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var market = new Market
            {
                MarketId = Guid.NewGuid(),
                StrategyId = strategyId,
                IsDeleted = false,
                GrpNumber = 1
            };

            // Act
            var result = await _repository.SaveMarket(market);

            // Assert
            Assert.NotNull(result);

            // Verify it was saved
            var savedMarket = await _context.Markets.FindAsync(market.MarketId);
            Assert.NotNull(savedMarket);
            Assert.Equal(market.StrategyId, savedMarket.StrategyId);
        }
        [Fact]
        public async Task UpdateMarket_UpdateMarketToDatabase()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var market = new Market
            {
                MarketId = Guid.NewGuid(),
                StrategyId = strategyId,
                IsDeleted = false,
                GrpNumber = 1
            };

            // Act
            var result = await _repository.SaveMarket(market);
            result.Notes = "Tests";
            var result1 = await _repository.UpdateMarket(market);
            // Assert
            Assert.NotNull(result1);

        }
        [Fact]
        public async Task TrackMarketChanges_ToDatabase()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var market = new Market
            {
                MarketId = Guid.NewGuid(),
                StrategyId = strategyId,
                IsDeleted = false,
                GrpNumber = 1
            };

            // Act
            await _repository.TrackMarketChanges(market);
            // Assert
            Assert.True(true);

        }
        [Fact]
        public async Task TrackMarketChangesWithTask_ToDatabase()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var market = new Market
            {
                MarketId = Guid.NewGuid(),
                StrategyId = strategyId,
                IsDeleted = false,
                GrpNumber = 1,
                MarketTaskMeta =new List<MarketTaskMeta> { new MarketTaskMeta
                {
                    MarketTaskId = Guid.NewGuid(),
                    MarketId = Guid.NewGuid(),
                    TaskStackId = Guid.NewGuid(),
                    CreatedBy = "admin_user",
                    CreatedDate = DateTime.UtcNow.AddDays(-10),
                    UpdatedBy = "editor_user",
                    UpdatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    Market = new Market
                    {
                        MarketId = Guid.NewGuid()
                    },
                    TaskStack = new TaskStack
                    {
                        TaskStackId = Guid.NewGuid()
                    }
                } }
            };

            // Act
            await _repository.TrackMarketChanges(market);
            // Assert
            Assert.True(true);

        }
        [Fact]
        public async Task GetStrategyIdByMarketId_ReturnsCorrectStrategyId()
        {

                // Act
                var result = await _repository.GetStrategyIdByMarketId(_marketId);

                // Assert
                Assert.NotNull(result);
         }
        [Fact]
        public async Task RemoveMarkets_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId = Guid.NewGuid(),
                        IsDeleted = false,
                        SagittaClientId = sagittaClient1.SagittaClientId
                    }
                },
                    PlanTimelines = new List<PlanTimeline>
                {
                    new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
                }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient
                    {
                        IsDeleted = false,
                        SagittaClientId = sagittaClient2.SagittaClientId
                    }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline
                    {
                        IsDeleted = false,
                        StatusCodeId = statusCode2.StatusCodeId,
                        StepDefId = stepDef.StepDefId
                    }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff
                    {
                        IsDeleted = false,
                        SagittaStaffId = sagittaStaff.SagittaStaffId
                    }
                }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new MarketRepository(context);

                // Act
                var result = await service.RemoveMarket(strategyId, securityUserId);

                // Assert
                Assert.True(result);

            }
        }
       
        private BrokerPortalApiDBContext CreateContext()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlServer(ConnectionString)
                .Options;

            var context = new BrokerPortalApiDBContext(options);
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            return context;
        }
        [Fact]
        public async Task ArchiveMarket_UpdatesMatchingTaskSteps()
        {// Arrange
            using var context = CreateContext();

            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");

            // Seed related entities
            var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                var taskStack = new TaskStack
                {
                    TaskStackId = Guid.NewGuid(),
                    TaskName = "Test Task",
                    CreatedBy = securityUser.SecurityUserId,
                    CreatedDate = DateTime.UtcNow
                };

                context.TaskStacks.Add(taskStack);
                await context.SaveChangesAsync(); // Save first to ensure FK exists

                var taskStep = new TaskStep
                {
                    TaskStepId = Guid.NewGuid(),
                    StatusCodeId=statusCode1.StatusCodeId,
                    TaskStackId = taskStack.TaskStackId, // FK now valid
                    StepDefId = stepDef.StepDefId,
                    CreatedBy = securityUser.SecurityUserId,
                    CreatedDate = DateTime.UtcNow
                };

                context.TaskSteps.Add(taskStep);
                await context.SaveChangesAsync(); // Now this will succeed

                var repository = new MarketRepository(context);

                // Act
                var marketId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";
                await repository.ArchiveMarket(marketId, securityUserId);

                // Assert
                var updatedStep =  context.TaskSteps.First();
                Assert.True(true);
            
        }
        [Fact]
        public async Task BulkMergeWithSubEntities_UpdatesMatchingTaskSteps()
        {// Arrange
            using var context = CreateContext();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");

            var repository = new MarketRepository(context);

            // Act
            var marketId = Guid.NewGuid();
            var market = new Market
            {
                MarketId = Guid.NewGuid(),
                StrategyId = Guid.NewGuid(),
                IsDeleted = false,
                GrpNumber = 1
            };
          var result=  await repository.BulkMergeWithSubEntities(new List<Market> { market});

            // Assert
            Assert.NotNull(result);

        }

    }
}

