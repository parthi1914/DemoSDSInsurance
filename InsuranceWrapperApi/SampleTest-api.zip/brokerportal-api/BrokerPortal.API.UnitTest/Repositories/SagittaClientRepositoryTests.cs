﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class SagittaClientRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly SagittaClientRepository _repository;
        private readonly long _sagittaClientId = 100097;

        public SagittaClientRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.SagittaClients.AddRange(
      new List<SagittaClient>
        {new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" }
            }
             );


            _context.SaveChanges();
            _repository = new SagittaClientRepository(_context);

        }
        [Fact]
        public async Task IsSagittaClientExists_ReturnsTrue_WhenClientExists()
        {
            // Arrange
            var sagittaClientId = 100097;

            // Act
            var result = await _repository.IsSagittaClientExists(sagittaClientId);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task UpdateSagittaClient_UpdatesEntityAndSavesChanges()
        {
            // Arrange
            var sagittaClient = new SagittaClient { SagittaClientId = 100098,ClientCode= "100098", ClientName = "Updated Client" };

            // Act
            var result = await _repository.AddSagittaClient(sagittaClient);
            var result1 = await _repository.UpdateSagittaClient(sagittaClient);

            // Assert
            Assert.Equal(sagittaClient, result1);
        }

        [Fact]
        public async Task AddSagittaClient_AddsClientAndSavesChanges()
        {
            // Arrange
            var sagittaClient = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };

            // Act
            var result = await _repository.AddSagittaClient(sagittaClient);
            //Assert
            Assert.Equal(sagittaClient, result);
        }
        [Fact]
        public async Task GetSagittaClient_ReturnsClient_WhenClientExistsAndNotDeleted()
        {
            // Arrange
            var clientId = 123L;
            var sagittaClient = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };


            // Act
            var result = await _repository.GetSagittaClient(_sagittaClientId.ToString());

            // Assert
            Assert.NotNull(result);
        }



    }
}
