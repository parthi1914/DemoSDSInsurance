﻿using Xunit;
using Moq;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
namespace BrokerPortal.API.UnitTest.Repositories
{
    public class SecurityUserRepositoryTests
    {
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<DbSet<SecurityUserProfile>> _mockUserProfileSet;
        private readonly Mock<DbSet<SecurityUserMapExternalSystem>> _mockMapSet;
        private readonly SecurityUserRepository _repository;
        private readonly BrokerPortalApiDBContext context;
        private readonly SecurityUserRepository repository;

        public SecurityUserRepositoryTests()
        {
            _mockContext = new Mock<BrokerPortalApiDBContext>();
            _mockUserProfileSet = new Mock<DbSet<SecurityUserProfile>>();
            _mockMapSet = new Mock<DbSet<SecurityUserMapExternalSystem>>();
            _repository = new SecurityUserRepository(_mockContext.Object);
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
        .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
           .Options;

            context = new BrokerPortalApiDBContext(options);
            // Seed data
            context.SecurityUserMapExternalSystems.AddRange(
      new List<SecurityUserMapExternalSystem>
        {new SecurityUserMapExternalSystem
{
    MapExternalSystemId = Guid.NewGuid(),
    SecurityUserId = "balabharathi.s@mcgriff.com",
    ExternalSystemId = "EXT_SYS_01",
    ExternalSystemUserId = "ext_user_456",
    IsActive = true,
    CreatedDate = DateTime.UtcNow.AddMonths(-2),
    CreatedBy = "admin_user",
    UpdatedDate = DateTime.UtcNow,
    UpdatedBy = "admin_user",
    SecurityUser = new SecurityUser
    {
        SecurityUserId = "balabharathi.s@mcgriff.com",
        UserEmail="balabharathi.s@mcgriff.com"
    }
}

      }
            );


            context.SaveChanges();
            repository = new SecurityUserRepository(context);
        }

        [Fact]
        public async Task GetEmployeeIdBySecurityUserId_ReturnsUserOnPremAccountName()
        {
            var userId = "balabharathi.s@mcgriff.com";
            var expectedName = "DOMAIN\\balabharathi.s@mcgriff.com";

            var data = new List<SecurityUserProfile>
        {
            new SecurityUserProfile { SecurityUserId = userId, UserOnPremAccountName = expectedName }
        }.AsQueryable();

            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            _mockContext.Setup(c => c.SecurityUserProfiles).Returns(_mockUserProfileSet.Object);

            var result = await _repository.GetEmployeeIdBySecurityUserId(userId);

            Assert.Equal(expectedName, result);
        }

        [Fact]
        public async Task GetSecurityUserMapExternalSystemUserIds_ReturnsMatchingIds()
        {
            var userId = "balabharathi.s@mcgriff.com";
            var systemId = "EXT_SYS_01";

            var result = await repository.GetSecurityUserMapExternalSystemUserIds(userId, systemId);

            Assert.Equal(1, result?.Count);
        }

        [Fact]
        public async Task GetSecurityUserMapExternalSystemUserList_ReturnsMatchingEntities()
        {
            var userId = "balabharathi.s@mcgriff.com";
            var systemId = "EXT_SYS_01";

            var result = await repository.GetSecurityUserMapExternalSystemUserList(userId, systemId);

            Assert.Equal(1, result?.Count);
        }

        [Fact]
        public async Task GetSecurityUserIdsByExternalSystemUserIds_ReturnsMatchingSecurityUserIds()
        {
            var systemId = "EXT_SYS_01";
            var externalIds = new[] { "ext_user_456" };

            var result = await repository.GetSecurityUserIdsByExternalSystemUserIds(systemId, externalIds);

            Assert.Equal(1, result?.Count);
        }


        [Fact]
        public async Task BulkSaveSecurityUserMapExternalSystemUserList_AddsAndSaves()
        {
            var list = new List<SecurityUserMapExternalSystem>
        {
            new SecurityUserMapExternalSystem { SecurityUserId = "user1", ExternalSystemId = "SYS1", ExternalSystemUserId = "ext001" }
        };

            _mockContext.Setup(c => c.SecurityUserMapExternalSystems).Returns(_mockMapSet.Object);
            _mockContext.Setup(c => c.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await _repository.BulkSaveSecurityUserMapExternalSystemUserList(list);

            _mockMapSet.Verify(m => m.AddRange(list), Times.Once);
            _mockContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
            Assert.Single(result);
        }

        [Fact]
        public async Task GetEmployeeIdBySecurityUserIdWithNull_ReturnsUserOnPremAccountName()
        {
            var userId = "balabharathi.s@mcgriff.com";
            var expectedName = "DOMAIN\\balabharathi.s@mcgriff.com";

            var data = new List<SecurityUserProfile>
        {
            new SecurityUserProfile { SecurityUserId = userId, UserOnPremAccountName = expectedName }
        }.AsQueryable();

            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockUserProfileSet.As<IQueryable<SecurityUserProfile>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            _mockContext.Setup(c => c.SecurityUserProfiles).Returns(_mockUserProfileSet.Object);

            var result = await _repository.GetEmployeeIdBySecurityUserId(null);

            Assert.Null( result);
        }


    }
}