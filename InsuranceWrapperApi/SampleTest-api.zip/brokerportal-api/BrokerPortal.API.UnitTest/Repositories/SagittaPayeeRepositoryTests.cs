﻿using Xunit;
using Moq;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using System.Data.Entity;
namespace BrokerPortal.API.UnitTest.Repositories
{
    public class SagittaPayeeRepositoryTests
    {

        private readonly BrokerPortalApiDBContext _context;
        private readonly SagittaPayeeRepository _repository;
        private readonly long _sagittaPayeeId = 100097;
        public SagittaPayeeRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.SagittaPayees.AddRange(
      new List<SagittaPayee>
        {new SagittaPayee { SagittaPayeeId="100097",PayeeCode="100097",PayeeName="TEST",CreatedBy="balabharathi.s@mcgriff.com" }
      }
            );


            _context.SaveChanges();
            _repository = new SagittaPayeeRepository(_context);
        }
        [Fact]
        public void GetSagittaPayeesByIds_ReturnsCorrectPayees()
        {
            // Arrange
            var payeeID = new string?[] { "100097" };

            // Act
            var result = _repository.GetSagittaPayeesByIds(payeeID);

            // Assert
            Assert.Equal(1, result.Count);
        }
        [Fact]
        public void BulkMerge_CallsContextBulkMergeAndReturnsInputList()
        {
            // Arrange
            var payees = new List<SagittaPayee>
        {
            new SagittaPayee { SagittaPayeeId="100098",PayeeCode="100098",PayeeName="TEST1",CreatedBy="balabharathi.s@mcgriff.com" }
        };

            // Act
            var result = _repository.BulkMerge(payees);

            // Assert
            Assert.Equal(payees, result);
        }
    }
}