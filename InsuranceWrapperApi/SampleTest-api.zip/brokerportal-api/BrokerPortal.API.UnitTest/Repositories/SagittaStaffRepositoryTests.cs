﻿using Xunit;
using Moq;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
namespace BrokerPortal.API.UnitTest.Repositories
{
    public class SagittaStaffRepositoryTests
    {
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly BrokerPortalApiDBContext context;
        private readonly Mock<DbSet<SagittaStaff>> _mockSet;
        private readonly SagittaStaffRepository _repository;
        private readonly SagittaStaffRepository repository;
        private readonly Mock<DbSet<TaskAssignment>> _mockTaskAssignmentSet;

        public SagittaStaffRepositoryTests()
        {
            _mockContext = new Mock<BrokerPortalApiDBContext>();
            _mockSet = new Mock<DbSet<SagittaStaff>>();
            _mockTaskAssignmentSet = new Mock<DbSet<TaskAssignment>>();
            _repository = new SagittaStaffRepository(_mockContext.Object);
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
         .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            context = new BrokerPortalApiDBContext(options);

            repository = new SagittaStaffRepository(context);


        }

        [Fact]
        public async Task GetSagittaStaffById_ReturnsStaff()
        {
            var staffId = "123";
            var staff = new SagittaStaff { SagittaStaffId = staffId };

            var data = new List<SagittaStaff> { staff }.AsQueryable();

            var mockSet = new Mock<DbSet<SagittaStaff>>();
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            _mockContext.Setup(c => c.SagittaStaffs).Returns(mockSet.Object);
            _mockContext.Setup(c => c.SagittaStaffs.FindAsync(staffId)).ReturnsAsync(staff);

            var result = await _repository.GetSagittaStaffById(staffId);

            Assert.NotNull(result);
            Assert.Equal(staffId, result.SagittaStaffId);
        }

        [Fact]
        public void GetSagittaStaffsByIds_ReturnsMatchingStaffs()
        {
            var staffList = new List<SagittaStaff>
        {
            new SagittaStaff { SagittaStaffId = "1" },
            new SagittaStaff { SagittaStaffId = "2" },
            new SagittaStaff { SagittaStaffId = "3" }
        }.AsQueryable();

            var mockSet = new Mock<DbSet<SagittaStaff>>();
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Provider).Returns(staffList.Provider);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Expression).Returns(staffList.Expression);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.ElementType).Returns(staffList.ElementType);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.GetEnumerator()).Returns(staffList.GetEnumerator());

            _mockContext.Setup(c => c.SagittaStaffs).Returns(mockSet.Object);

            var result = _repository.GetSagittaStaffsByIds(new[] { "1", "3" });

            Assert.Equal(2, result.Count);
            Assert.Contains(result, s => s.SagittaStaffId == "1");
            Assert.Contains(result, s => s.SagittaStaffId == "3");
        }
        [Fact]
        public async Task BulkMerge_CallsBulkMergeAndReturnsList()
        {
            var staffList = new List<SagittaStaff>
        {new SagittaStaff
{
    SagittaStaffId = "STF001",
    StaffCode = "SC123",
    StaffName = "Jane Smith",
    StaffTitle = "Senior Underwriter",
    StaffEmail = "jane.smith@example.com",
    UserId = "USR789",
    StaffEmpCode = "EMP456",
    EmployeeType = "FullTime",
    IsDatedOff = false,
    DatedOffDate = null,
    IsSagSync = true,
    LastSagSyncDate = DateTime.Parse("2025-07-06T14:30:00Z"),
    CreatedDate = DateTime.Parse("2025-01-15T09:00:00Z"),
    UpdatedDate = DateTime.Parse("2025-07-01T16:45:00Z"),
    CreatedBy = "admin_user",
    UpdatedBy = "admin_user",
    StaffNetworkId = "jsmith",
    City = "Chennai",
    CreatedByNavigation = null,
    UpdatedByNavigation = null,
    StrategyStaffs = new List<StrategyStaff>()
}

        };

            var result = await repository.BulkMerge(staffList);

            Assert.Equal(1, result.Count);
        }
        [Fact]
        public async Task SaveSagittaStaff_AddsAndSavesStaff()
        {
            var staff = new SagittaStaff { SagittaStaffId = "1" };

            _mockContext.Setup(c => c.SagittaStaffs).Returns(_mockSet.Object);
            _mockContext.Setup(c => c.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await _repository.SaveSagittaStaff(staff);

            _mockContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
            Assert.Equal("1", result.SagittaStaffId);
        }

        [Fact]
        public async Task UpdateSagittaStaff_UpdatesAndSavesStaff()
        {
            var staff = new SagittaStaff { SagittaStaffId = "1" };

            _mockContext.Setup(c => c.SagittaStaffs).Returns(_mockSet.Object);
            _mockContext.Setup(c => c.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await _repository.UpdateSagittaStaff(staff);

            _mockSet.Verify(s => s.Update(staff), Times.Once);
            _mockContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
            Assert.Equal("1", result.SagittaStaffId);
        }

        [Fact]
        public void GetSagittaStaffsByAssignedStepIds_ReturnsMatchingStaffs()
        {
            var staffList = new List<SagittaStaff>
        {
            new SagittaStaff { SagittaStaffId = "1" },
            new SagittaStaff { SagittaStaffId = "2" }
        }.AsQueryable();

            var taskStepId = Guid.NewGuid();
            var taskAssignments = new List<TaskAssignment>
        {
            new TaskAssignment { TaskAssignTo = "1", TaskStepId = taskStepId, IsDeleted = false },
            new TaskAssignment { TaskAssignTo = "2", TaskStepId = Guid.NewGuid(), IsDeleted = true }
        }.AsQueryable();

            _mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Provider).Returns(staffList.Provider);
            _mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Expression).Returns(staffList.Expression);
            _mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.ElementType).Returns(staffList.ElementType);
            _mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.GetEnumerator()).Returns(staffList.GetEnumerator());

            _mockTaskAssignmentSet.As<IQueryable<TaskAssignment>>().Setup(m => m.Provider).Returns(taskAssignments.Provider);
            _mockTaskAssignmentSet.As<IQueryable<TaskAssignment>>().Setup(m => m.Expression).Returns(taskAssignments.Expression);
            _mockTaskAssignmentSet.As<IQueryable<TaskAssignment>>().Setup(m => m.ElementType).Returns(taskAssignments.ElementType);
            _mockTaskAssignmentSet.As<IQueryable<TaskAssignment>>().Setup(m => m.GetEnumerator()).Returns(taskAssignments.GetEnumerator());

            _mockContext.Setup(c => c.SagittaStaffs).Returns(_mockSet.Object);
            _mockContext.Setup(c => c.TaskAssignments).Returns(_mockTaskAssignmentSet.Object);

            var result = _repository.GetSagittaStaffsByAssignedStepIds(new List<Guid> { taskStepId });

            Assert.Single(result);
            Assert.Equal("1", result[0].SagittaStaffId);
        }
        [Fact]
        public async Task GetSagittaStaffByIdWithNull_ReturnsStaff()
        {
            var staffId = "123";
            var staff = new SagittaStaff { SagittaStaffId = staffId };

            var data = new List<SagittaStaff> { staff }.AsQueryable();

            var mockSet = new Mock<DbSet<SagittaStaff>>();
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<SagittaStaff>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            _mockContext.Setup(c => c.SagittaStaffs).Returns(mockSet.Object);
            _mockContext.Setup(c => c.SagittaStaffs.FindAsync(staffId)).ReturnsAsync(staff);

            var result = await _repository.GetSagittaStaffById(null);

            Assert.Null(result);
            
        }

        
        

    }
}