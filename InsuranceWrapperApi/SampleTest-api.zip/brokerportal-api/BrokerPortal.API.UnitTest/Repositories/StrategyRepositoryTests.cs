﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using System.Data.Entity;
using BrokerPortal.API.Services;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.AspNetCore.Http.HttpResults;
using BrokerPortal.API.RepositoryContracts;
using System.Numerics;
using Microsoft.Data.Sqlite;
using System;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using BrokerPortal.API.Utilities;
using Microsoft.AspNetCore.Http;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using Moq;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class StrategyRepositoryTests
    {
        private readonly Guid _planId = Guid.NewGuid();
        private readonly BrokerPortalApiDBContext context;
        private readonly StrategyRepository repository;
        public StrategyRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
       .Options;

            context = new BrokerPortalApiDBContext(options);
            context.Strategies.AddRange(
new List<Strategy>
 {
            new Strategy
                { } });


            repository = new StrategyRepository(context);


        }
        [Fact]
        public async Task GetAllStrategies_ReturnsNonDeletedStrategiesWithIncludes()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(databaseName: "StrategyTestDb")
                .Options;

            using (var context = new BrokerPortalApiDBContext(options))
            {
                var plan = new Plan
                {
                    PlanId = _planId,
                    PlanName = "Test",
                    StatusCodeId = "OPEN",
                    StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST" }
                    }
                },
                    PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
                };
                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient { IsDeleted = false, SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" } }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline { IsDeleted = false, StatusCode =  new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" }, StepDef =new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode= "MS-SUBM",
                    FlowDefId="MS",
                    StepName= "MS-SUBM",
                    StepNameDisplay= "MS-SUBM",
                  IsDeleted =false

                } }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff { IsDeleted = false, SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" } }
                },
                    StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                    UpdatedByNavigation = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }

            using (var context = new BrokerPortalApiDBContext(options))
            {
                var repository = new StrategyRepository(context);

                // Act
                var result = await repository.GetAllStrategies();

                // Assert
                Assert.Single(result);
                Assert.False(result.First().IsDeleted);
                Assert.NotNull(result.First().Plan);
                Assert.All(result.First().StrategyClients, sc => Assert.False(sc.IsDeleted));
                Assert.All(result.First().StrategyTimelines, st => Assert.False(st.IsDeleted));
                Assert.All(result.First().StrategyStaffs, ss => Assert.False(ss.IsDeleted));
            }
        }
        private BrokerPortalApiDBContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString()) // Unique DB per test
                .Options;

            var context = new BrokerPortalApiDBContext(options);
            return context;
        }

        [Fact]
        public void GetStrategyHeaderById_ReturnsCorrectStrategy()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var plan = new Plan
            {
                PlanId = _planId,
                PlanName = "Test",
                StatusCodeId = "OPEN",
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST" }
                    }
                },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
            };
            context.Strategies.Add(new Strategy
            {
                StrategyId = Guid.NewGuid(),
                IsDeleted = false,
                StrategyName = "test strategy",
                Plan = plan,
                StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient { IsDeleted = false, SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" } }
                },
                StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline { IsDeleted = false, StatusCode =  new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" }, StepDef =new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode= "MS-SUBM",
                    FlowDefId="MS",
                    StepName= "MS-SUBM",
                    StepNameDisplay= "MS-SUBM",
                  IsDeleted =false

                } }
                },
                StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff { IsDeleted = false, SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" } }
                },
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                UpdatedByNavigation = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" }
            });
            context.SaveChanges();

            var repository = new StrategyRepository(context);

            // Act
            var result = repository.GetStrategyHeaderById(strategyId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStrategyById_ReturnsStrategyWithIncludes()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();


            context.Strategies.Add(strategy);
            await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            // Act
            var result = await repository.GetStrategyById(strategyId, includeMarkets: false);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStrategyForUpdate_ReturnsStrategy_WhenStrategyExists()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();


            context.Strategies.Add(strategy);
            await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            // Act
            var result = await repository.GetStrategyForUpdate(strategyId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStrategyForUpdateToSyncMarketChanges_ReturnsStrategy_WhenStrategyExists()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();


            context.Strategies.Add(strategy);
            await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            // Act
            var result = await repository.GetStrategyForUpdateToSyncMarketChanges(strategyId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStrategyForMarketChanges_ReturnsStrategy_WhenStrategyExists()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();


            context.Strategies.Add(strategy);
            await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            // Act
            var result = await repository.GetStrategyForMarketChanges(strategyId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStrategyByStrategyAndStepIds_ReturnsStrategy_WhenStrategyExists()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();

            context.Strategies.Add(strategy);
            await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            // Act
            var result = repository.GetStrategyByStrategyAndStepIds(strategyId, "MS-SUBM");

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SaveStrategy_ShouldAddAndSaveStrategy()
        {

            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();

            var repository = new StrategyRepository(context);

            // Act
            var result = await repository.SaveStrategy(strategy);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task UpdateStrategy_ShouldUpdateStrategy()
        {

            // Arrange
            var context = GetInMemoryDbContext();
            var strategyId = Guid.NewGuid();
            var strategy = getStrategyData();

            var repository = new StrategyRepository(context);

            // Act
            var result = await repository.SaveStrategy(strategy);
            result.StrategyName = "update";
            var result2 = await repository.UpdateStrategy(result);

            // Assert
            Assert.NotNull(result2);
        }
        [Fact]
        public async Task TrackStrategyChanges_ShouldCallExecuteSqlRawAsync_WhenStrategyIsValid()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var taskStackId = Guid.NewGuid();

            var strategy = getStrategyData();
            var repository = new StrategyRepository(context);
            // Act
            await repository.TrackStrategyChanges(strategy);

            // Assert
            Assert.True(true);
        }
        [Fact]
        public async Task TrackStrategyChanges_Task_ShouldCallExecuteSqlRawAsync_WhenStrategyIsValid()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var taskStackId = Guid.NewGuid();

            var strategy = getStrategyData();
            strategy.StrategyTaskMeta = new List<StrategyTaskMeta> { new StrategyTaskMeta
{
    StrategyTaskId = Guid.NewGuid(),
    StrategyId = Guid.NewGuid(),
    StrategyTimelineId = Guid.NewGuid(),
    TaskStackId = Guid.NewGuid(),
    CreatedBy = "creator_user",
    CreatedDate = DateTime.UtcNow.AddDays(-15),
    UpdatedBy = "updater_user",
    UpdatedDate = DateTime.UtcNow,
    IsDeleted = false,
    Strategy = new Strategy
    {
        StrategyId = Guid.NewGuid(),
        StrategyName = "Growth Strategy 2025"
    },
    StrategyTimeline = new StrategyTimeline
    {
        StrategyTimelineId = Guid.NewGuid(),

    },
    TaskStack = new TaskStack
    {
        TaskStackId = Guid.NewGuid(),


    }
}};
            var repository = new StrategyRepository(context);
            // Act
            await repository.TrackStrategyChanges(strategy);

            // Assert
            Assert.True(true);
        }
        [Fact]
        public async Task UpdateStrategyUpdatedBy_ShouldUpdateUpdatedByAndUpdatedDate()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;

            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
            {
                new PlanClient
                {
                    PlanClientId = Guid.NewGuid(),
                    IsDeleted = false,
                    SagittaClientId = sagittaClient1.SagittaClientId
                }
            },
                    PlanTimelines = new List<PlanTimeline>
            {
                new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
            }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
            {
                new StrategyClient
                {
                    IsDeleted = false,
                    SagittaClientId = sagittaClient2.SagittaClientId
                }
            },
                    StrategyTimelines = new List<StrategyTimeline>
            {
                new StrategyTimeline
                {
                    IsDeleted = false,
                    StatusCodeId = statusCode2.StatusCodeId,
                    StepDefId = stepDef.StepDefId
                }
            },
                    StrategyStaffs = new List<StrategyStaff>
            {
                new StrategyStaff
                {
                    IsDeleted = false,
                    SagittaStaffId = sagittaStaff.SagittaStaffId
                }
            }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }

            // Act
            using (var context = new BrokerPortalApiDBContext(options))
            {
                var service = new StrategyRepository(context);
                var strategy = context.Strategies.First();
                var userId = "balabharathi.s@mcgriff.com";

                var result = await service.UpdateStrategyUpdatedBy(strategy.StrategyId, userId);

                // Assert
                var updated = context.Strategies.First();
                Assert.NotNull(updated);
            }

            connection.Close();
        }
        [Fact]
        public async Task RemoveStrategy_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId = Guid.NewGuid(),
                        IsDeleted = false,
                        SagittaClientId = sagittaClient1.SagittaClientId
                    }
                },
                    PlanTimelines = new List<PlanTimeline>
                {
                    new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
                }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient
                    {
                        IsDeleted = false,
                        SagittaClientId = sagittaClient2.SagittaClientId
                    }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline
                    {
                        IsDeleted = false,
                        StatusCodeId = statusCode2.StatusCodeId,
                        StepDefId = stepDef.StepDefId
                    }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff
                    {
                        IsDeleted = false,
                        SagittaStaffId = sagittaStaff.SagittaStaffId
                    }
                }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new StrategyRepository(context);

                // Act
                var result = await service.RemoveStrategy(strategyId, securityUserId);

                // Assert
                Assert.True(result);

            }
        }
        [Fact]
        public async Task ArchiveStrategy_UpdatesMatchingTaskSteps()
        {
            // Arrange
            // Arrange
            string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=MarketTestDb10;Trusted_Connection=True;MultipleActiveResultSets=true";
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
        .UseSqlServer(ConnectionString)
        .Options;

            var context = new BrokerPortalApiDBContext(options);
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");

            var repository = new StrategyRepository(context);

            // Act
            var strategyId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            await repository.ArchiveStrategy(strategyId, securityUserId);

            // Assert
            Assert.True(true);

        }
        [Fact]
        public async Task ArchiveByPlan_WhenStrategiesExist_ShouldCallRemoveStrategyForEach()
        {
            // Arrange
            var planID = Guid.NewGuid();
            string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=MarketTestDb25;Trusted_Connection=True;MultipleActiveResultSets=true";
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
        .UseSqlServer(ConnectionString)
        .Options;

            var context = new BrokerPortalApiDBContext(options);
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    PlanId = planID,
                    StatusCodeId = statusCode1.StatusCodeId,
                    StrategyEffDate=DateTime.Now,
                    UpdatedBy = null
                };

                context.Strategies.Add(strategy);

                await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            // Act

            var securityUserId = "balabharathi.s@mcgriff.com";
            await repository.ArchiveStrategyByPlan(planID, securityUserId);

            // Assert
            Assert.True(true);


        }
        [Fact]
        public async Task RemoveStrategyByPlan_WhenStrategiesExist_ShouldCallRemoveStrategyForEach()
        {
            // Arrange
            var planId = Guid.NewGuid();
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = planId,
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId = Guid.NewGuid(),
                        IsDeleted = false,
                        SagittaClientId = sagittaClient1.SagittaClientId
                    }
                },
                    PlanTimelines = new List<PlanTimeline>
                {
                    new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
                }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient
                    {
                        IsDeleted = false,
                        SagittaClientId = sagittaClient2.SagittaClientId
                    }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline
                    {
                        IsDeleted = false,
                        StatusCodeId = statusCode2.StatusCodeId,
                        StepDefId = stepDef.StepDefId
                    }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff
                    {
                        IsDeleted = false,
                        SagittaStaffId = sagittaStaff.SagittaStaffId
                    }
                }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
                var repository = new StrategyRepository(context);
                var securityUserId = "balabharathi.s@mcgriff.com";
                // Act
                var result = await repository.RemoveStrategyByPlan(planId, securityUserId);
                // var result1 = await repository.ArchiveStrategyByPlan(planId, securityUserId);

                // Assert
                Assert.True(result);
            }


        }
        [Fact]
        public async Task ArchiveStrategyByPlan_WhenStrategiesExist_ShouldCallRemoveStrategyForEach()
        {
            // Arrange


            var repository = new StrategyRepository(context);
            var securityUserId = "balabharathi.s@mcgriff.com";
            // Act
            var result = await repository.ArchiveStrategyByPlan(_planId, securityUserId);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task SearchStrategies_WithAllFilterType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange
            var context = GetInMemoryDbContext();
           
            var strategy = getStrategyData();
            var strategyId = strategy.StrategyId;


            context.Strategies.Add(strategy);
            await context.SaveChangesAsync();

            var repository = new StrategyRepository(context);

            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "SC001" },
                
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.ALL,
                StrategySearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SearchStrategies_WithUSER_SPECIFICType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.USER_SPECIFIC,
                StrategySearchType.MYACCESS,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_WithUSER_SPECIFIC_ALL_Type_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.USER_SPECIFIC,
                StrategySearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_WithUSER_SPECIFIC_MYASSIGNMENT_Type_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.USER_SPECIFIC,
                StrategySearchType.MYASSIGNMENT,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_WithUSER_SPECIFIC_MYFAVORITE_Type_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.USER_SPECIFIC,
                StrategySearchType.MYFAVORITE,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_CLIENT_SPECIFICType_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                StrategySearchType.MYASSIGNMENT,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_CLIENT_SPECIFIC_ALL_Type_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                StrategySearchType.ALL,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_CLIENT_SPECIFIC_MYACCESS_Type_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                StrategySearchType.MYACCESS,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_CLIENT_SPECIFIC_MYFAVORITE_Type_CallsSearchTaskIdsByAllFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.CLIENT_SPECIFIC,
                StrategySearchType.MYFAVORITE,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SearchStrategies_WithAllFilterType_CallsSearchTaskIdsByAllFavoriteFilters_AndReturnsTaskList()
        {
            // Arrange


            var searchCriterias = new StrategySearchCriterias
            {
                strategyStatusCodes = new[] { "OPEN" }
            };
            // Act
            var result = await repository.SearchStrategies(
                SearchBaseFilterType.ALL,
                StrategySearchType.MYFAVORITE,
                searchCriterias,
                "balabharathi.s@mcgriff.com",
                new[] { "PLCC" },
                null
            );

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetStrategyIdByPlanId_ReturnsNull_WhenNotFound()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var planId = Guid.NewGuid();
            var strategy = getStrategyData();
            context.Strategies.Add(strategy);

            await context.SaveChangesAsync();


            var service = new StrategyRepository(context);

            // Act
            var result = await service.GetStrategyIdByPlanId(planId);

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task UpdateRangeStrategyTimelines_UpdatesEntitiesCorrectly()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
       .Options;
            var strategy = new Strategy
            {
                StrategyId = Guid.NewGuid(),
                IsDeleted = false,
                StrategyName = "test strategy",
                Plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = "OPEN",
                    StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
        {
            new PlanClient
            {
                PlanClientId=Guid.NewGuid(),
                 IsDeleted = false,
                SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST" }
            }
        },
                    PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
                },
                StrategyClients = new List<StrategyClient>
        {
            new StrategyClient { IsDeleted = false, SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" } }
        },
                StrategyTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline { IsDeleted = false, StatusCode =  new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" }, StepDef =new StepDef
        {
            StepDefId = "MS-SUBM",
            StepDefCode= "MS-SUBM",
            FlowDefId="MS",
            StepName= "MS-SUBM",
            StepNameDisplay= "MS-SUBM",
          IsDeleted =false

        } }
        },
                StrategyStaffs = new List<StrategyStaff>
        {
            new StrategyStaff { IsDeleted = false, SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" } }
        },
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                UpdatedByNavigation = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" }
            };
 
        var  context = new BrokerPortalApiDBContext(options);
            context.Strategies.AddRange(
new List<Strategy>
 {strategy });

            await context.SaveChangesAsync();
            var repository = new StrategyRepository(context);
            var timeline1 = new StrategyTimeline
            {
                StrategyTimelineId = Guid.NewGuid(),
                StepDefId="MS-BIND",
                UpdatedBy = null,
                Strategy =strategy,
                StepDef = new StepDef
                {
                    StepDefId = "MS-BIND",
                    StepDefCode = "MS-BIND",
                    FlowDefId = "MS",
                    StepName = "MS-BIND",
                    StepNameDisplay = "MS-BIND",
                    IsDeleted = false
                }
            };
            context.StrategyTimelines.AddRange(timeline1);
            await context.SaveChangesAsync();
            var timelinesToUpdate =  context.StrategyTimelines.ToList();
            // Act
            var result = await repository.UpdateRangeStrategyTimelines(timelinesToUpdate);

            // Assert
            Assert.NotNull(result);
            
        }

        [Fact]
        public async Task GetStrategyClientId_ReturnsNull_WhenStrategyNotFound()
        {
            // Arrange
            var context = GetInMemoryDbContext();

                var service = new StrategyRepository(context);

                // Act
                var result = await service.GetStrategyClientId(Guid.NewGuid());

                // Assert
                Assert.NotNull(result);
            
        }
        [Fact]
        public async Task GetStrategyTimelines_ReturnsNull_WhenStrategyNotFound()
        {
            // Arrange
            var context = GetInMemoryDbContext();

            var service = new StrategyRepository(context);

            // Act
            var result = await service.GetStrategyTimelines(Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task GetStrategyIdByMarketId_ReturnsNull_WhenStrategyNotFound()
        {
            // Arrange
            var context = GetInMemoryDbContext();

            var service = new StrategyRepository(context);

            // Act
            var result =  service.GetStrategyIdByMarketId(Guid.NewGuid());

            // Assert
            Assert.NotNull(result);

        }
        [Fact]
        public async Task ArchiveMarket_UpdatesMatchingTaskSteps()
        {
            // Arrange
            string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=MarketTestDb5;Trusted_Connection=True;MultipleActiveResultSets=true";
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
        .UseSqlServer(ConnectionString)
        .Options;

            var context = new BrokerPortalApiDBContext(options);
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            await context.Database.ExecuteSqlRawAsync("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'");

            var repository = new MarketRepository(context);

            // Act
            var marketId = Guid.NewGuid();
            var securityUserId = "balabharathi.s@mcgriff.com";
            await repository.ArchiveMarket(marketId, securityUserId);

            // Assert
            Assert.True(true);

        }
        private Strategy getStrategyData()
        {
            var plan = new Plan
            {
                PlanId = _planId,
                PlanName = "Test",
                StatusCodeId = "OPEN",
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
        {
            new PlanClient
            {
                PlanClientId=Guid.NewGuid(),
                 IsDeleted = false,
                SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST" }
            }
        },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
            };
            var strategy = new Strategy
            {
                StrategyId = Guid.NewGuid(),
                IsDeleted = false,
                StrategyName = "test strategy",
                Plan = plan,
                StrategyClients = new List<StrategyClient>
        {
            new StrategyClient { IsDeleted = false, SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" } }
        },
                StrategyTimelines = new List<StrategyTimeline>
        {
            new StrategyTimeline { IsDeleted = false, StatusCode =  new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" }, StepDef =new StepDef
        {
            StepDefId = "MS-SUBM",
            StepDefCode= "MS-SUBM",
            FlowDefId="MS",
            StepName= "MS-SUBM",
            StepNameDisplay= "MS-SUBM",
          IsDeleted =false

        } }
        },
                StrategyStaffs = new List<StrategyStaff>
        {
            new StrategyStaff { IsDeleted = false, SagittaStaff = new SagittaStaff { SagittaStaffId="PLCC", StaffName = "John Doe" } }
        },
                StatusCode = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                UpdatedByNavigation = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" }
            };

            return strategy;
        }
    }
}
