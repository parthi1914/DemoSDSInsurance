﻿using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.Repositories;
using BrokerPortal.API.RepositoryContracts.Domain;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokerPortal.API.ServiceContracts.Models.Plan;
using Microsoft.Data.Sqlite;

namespace BrokerPortal.API.UnitTest.Repositories
{
    public class PlanRepositoryTests
    {
        private readonly BrokerPortalApiDBContext _context;
        private readonly PlanRepository _repository;
        private readonly Guid _planId=Guid.NewGuid();

        public PlanRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _context = new BrokerPortalApiDBContext(options);

            // Seed data
            _context.Plans.AddRange(
      new List<Plan>
        {
            new Plan
            {
                PlanId=_planId,
                PlanName="Test",
                StatusCodeId="OPEN",
                StatusCode=new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100097,ClientCode="100097",ClientName="TEST" }
                    }
                },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId=Guid.NewGuid()} }
            } }
             );


            _context.SaveChanges();
            _repository = new PlanRepository(_context);

        }

        [Fact]
        public async Task GetAllPlans_ReturnsPlansWithRelatedEntities()
        {
            // Act
            var result = await _repository.GetAllPlans();

            // Assert
            Assert.Single(result); // Only one plan is not deleted
            Assert.NotNull(result[0].PlanClients);
            Assert.NotNull(result[0].PlanTimelines);
        }
        [Fact]
        public async Task GetPlanByIdReturnsPlansWithRelatedEntities()
        {
            // Act
            var result = await _repository.GetPlanById(_planId);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task FetchForUpdatePlanAndStrategiesByPlan_sPlansWithRelatedEntities()
        {
            // Act
            var result = await _repository.FetchForUpdatePlanAndStrategiesByPlan(_planId);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task SavePlan_AddsPlanAndHandlesSagittaClientsCorrectly()
        {
            // Arrange
            var plan = new Plan
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Test 2",
                StatusCodeId = "OPEN",
                StatusCode = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST 2" }
                    }
                },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
            };


            // Act
            var result = await _repository.SavePlan(plan);

            // Assert
            Assert.Equal(plan, result);
        }
        [Fact]
        public async Task SavePlan_SagittaClient_AddsPlanAndHandlesSagittaClientsCorrectly()
        {
            // Arrange
            var plan = new Plan
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Test 2",
                StatusCodeId = "OPEN",
                StatusCode = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST 2" }
                    }
                },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
            };


            // Act
            var result = await _repository.SavePlan(plan);

            // Assert
            Assert.Equal(plan, result);
        }
        [Fact]
        public async Task UpdatePlan_AddsPlanAndHandlesSagittaClientsCorrectly()
        {
            // Arrange
            var plan = new Plan
            {
                PlanId = Guid.NewGuid(),
                PlanName = "Test 2",
                StatusCodeId = "OPEN",
                StatusCode = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" },
                IsDeleted = false,
                PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId=Guid.NewGuid(),
                         IsDeleted = false,
                        SagittaClient = new SagittaClient { SagittaClientId=100098,ClientCode="100098",ClientName="TEST 2" }
                    }
                },
                PlanTimelines = new List<PlanTimeline> { new PlanTimeline { PlanTimelineId = Guid.NewGuid() } }
            };


            // Act
            var result = await _repository.SavePlan(plan);
            var result1 = await _repository.UpdatePlan(result);


            // Assert
            Assert.NotNull(result1);
        }
        [Fact]
        public async Task DoesValidStratgyStaffExistsOnPlan()
        {
            // Act
            var result =  _repository.DoesValidStratgyStaffExistsOnPlan(_planId);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task RemovePlan_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId = Guid.NewGuid(),
                        IsDeleted = false,
                        SagittaClientId = sagittaClient1.SagittaClientId
                    }
                },
                    PlanTimelines = new List<PlanTimeline>
                {
                    new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
                }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient
                    {
                        IsDeleted = false,
                        SagittaClientId = sagittaClient2.SagittaClientId
                    }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline
                    {
                        IsDeleted = false,
                        StatusCodeId = statusCode2.StatusCodeId,
                        StepDefId = stepDef.StepDefId
                    }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff
                    {
                        IsDeleted = false,
                        SagittaStaffId = sagittaStaff.SagittaStaffId
                    }
                }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new PlanRepository(context);

                // Act
                var result = await service.RemovePlan(strategyId, securityUserId);

                // Assert
                Assert.True(result);

            }
        }

        [Fact]
        public async Task ArchivePlan_ShouldMarkEntitiesAsDeleted()
        {
            // Arrange
            var connection = new SqliteConnection("Filename=:memory:");
            connection.Open();

            // Disable foreign key constraints
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "PRAGMA foreign_keys = OFF;";
                command.ExecuteNonQuery();
            }

            var options = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
                .UseSqlite(connection)
                .Options;
            using (var context = new BrokerPortalApiDBContext(options))
            {
                context.Database.EnsureCreated();

                // Seed related entities
                var statusCode1 = new BpstatusCode { StatusCodeId = "SC001", StatusCode = "OPEN", StatusName = "OPEN" };
                var statusCode2 = new BpstatusCode { StatusCodeId = "SC002", StatusCode = "OPEN", StatusName = "OPEN" };
                var sagittaClient1 = new SagittaClient { SagittaClientId = 100098, ClientCode = "100098", ClientName = "TEST" };
                var sagittaClient2 = new SagittaClient { SagittaClientId = 100097, ClientCode = "100097", ClientName = "TEST" };
                var sagittaStaff = new SagittaStaff { SagittaStaffId = "PLCC", StaffName = "John Doe" };
                var securityUser = new SecurityUser { SecurityUserId = "balabharathi.s@mcgriff.com", UserEmail = "balabharathi.s@mcgriff.com" };
                var stepDef = new StepDef
                {
                    StepDefId = "MS-SUBM",
                    StepDefCode = "MS-SUBM",
                    FlowDefId = "MS",
                    StepName = "MS-SUBM",
                    StepNameDisplay = "MS-SUBM",
                    IsDeleted = false
                };

                context.AddRange(statusCode1, statusCode2, sagittaClient1, sagittaClient2, sagittaStaff, securityUser, stepDef);
                await context.SaveChangesAsync();

                // Create and save Strategy with dependencies
                var plan = new Plan
                {
                    PlanId = Guid.NewGuid(),
                    PlanName = "Test",
                    StatusCodeId = statusCode1.StatusCodeId,
                    IsDeleted = false,
                    PlanClients = new List<PlanClient>
                {
                    new PlanClient
                    {
                        PlanClientId = Guid.NewGuid(),
                        IsDeleted = false,
                        SagittaClientId = sagittaClient1.SagittaClientId
                    }
                },
                    PlanTimelines = new List<PlanTimeline>
                {
                    new PlanTimeline { PlanTimelineId = Guid.NewGuid() }
                }
                };

                var strategy = new Strategy
                {
                    StrategyId = Guid.NewGuid(),
                    IsDeleted = false,
                    StrategyName = "test strategy",
                    Plan = plan,
                    StatusCodeId = statusCode1.StatusCodeId,
                    UpdatedBy = null,
                    StrategyClients = new List<StrategyClient>
                {
                    new StrategyClient
                    {
                        IsDeleted = false,
                        SagittaClientId = sagittaClient2.SagittaClientId
                    }
                },
                    StrategyTimelines = new List<StrategyTimeline>
                {
                    new StrategyTimeline
                    {
                        IsDeleted = false,
                        StatusCodeId = statusCode2.StatusCodeId,
                        StepDefId = stepDef.StepDefId
                    }
                },
                    StrategyStaffs = new List<StrategyStaff>
                {
                    new StrategyStaff
                    {
                        IsDeleted = false,
                        SagittaStaffId = sagittaStaff.SagittaStaffId
                    }
                }
                };

                context.Strategies.Add(strategy);
                await context.SaveChangesAsync();
            }


            using (var context = new BrokerPortalApiDBContext(options))
            {

                var strategyId = Guid.NewGuid();
                var securityUserId = "balabharathi.s@mcgriff.com";

                var service = new PlanRepository(context);

                // Act
                var result = await service.ArchivePlan(strategyId, securityUserId);

                // Assert
                Assert.True(result);

            }
        }

    }
}
