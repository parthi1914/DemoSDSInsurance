using BrokerPortal.API.Controllers;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Markets;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;

namespace BrokerPortal.API.UnitTest
{
    public class MarketsControllerTests
    {

        private readonly Mock<ILogger<MarketsController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<IMarketService> _mockMService;
        private readonly Mock<ISagittaPolicyService> _mockSagPolService;
        private readonly Mock<ISagittaPayeeService> _mockSagPayService;
        private readonly Mock<IStrategyService> _mockSService;
        private readonly MarketsController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public MarketsControllerTests()
        {
            _mockLogger = new Mock<ILogger<MarketsController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);

            _mockMService = new Mock<IMarketService>();
            _mockSagPolService = new Mock<ISagittaPolicyService>();
            _mockSagPayService = new Mock<ISagittaPayeeService>();
            _mockSService = new Mock<IStrategyService>();
            _controller = new MarketsController(_mockMService.Object, _mockSService.Object, _mockLogger.Object, _mockSagPolService.Object, _mockSagPayService.Object);

        }

        [Fact]
        public async Task GetStrategyAllMarket_ValidRequest_ReturnsOk()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            List<MarketModel> marketList = new List<MarketModel>();
            marketList = LoadMarketModel(strategyId);
            List<SagittaPolicyModel> policyList = new List<SagittaPolicyModel>();
            policyList = LoadSagPolModel();
            var strategyMarketBulkResponse = new StrategyMarketBulkResponse
            {
                Markets = marketList,
                SagittaPolicies = policyList
            };

            _mockMService.Setup(s => s.GetAllMarketByStrategy(strategyId)).Returns(marketList);
            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId)).Returns(policyList);

            // Act
            var result = await _controller.GetAllMarketByStrategy(strategyId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            StrategyMarketBulkResponse convResult = (StrategyMarketBulkResponse)okResult.Value;
            var getRes = convResult.Markets.Where(e => e.StrategyId == strategyId);
            Assert.Equal(convResult.Markets.Count(), strategyMarketBulkResponse.Markets.Count());
        }

        [Fact]
        public async Task GetById_ReturnsNotFoundResult_WhenPlanNotFound()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            List<MarketModel> marketList = new List<MarketModel>();
            List<SagittaPolicyModel> policyList = new List<SagittaPolicyModel>();
            _mockMService.Setup(s => s.GetAllMarketByStrategy(strategyId)).Returns(marketList);
            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId)).Returns(policyList);
            // Act
            var result = await _controller.GetAllMarketByStrategy(strategyId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<StrategyMarketBulkResponse>(okResult.Value);
            Assert.Equal(0, returnValue.Markets.Count());
        }

        [Fact]
        public async Task GetStrategyAllMarket_NoMarketsOrPoliciesFound_ReturnsEmptyList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            _mockMService.Setup(s => s.GetAllMarketByStrategy(strategyId)).Returns(new List<MarketModel>());
            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId)).Returns(new List<SagittaPolicyModel>());
            // Act
            var result = await _controller.GetAllMarketByStrategy(strategyId);
            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<StrategyMarketBulkResponse>(okResult.Value);
            Assert.Empty(response.Markets);
            Assert.Empty(response.SagittaPolicies);
        }

        [Fact]
        public async Task GetMarket_ValidRequest_ReturnsOk()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var marketResponse = new MarketModel { MarketId = marketId };
            _mockMService.Setup(s => s.GetMarketById(marketId)).ReturnsAsync(marketResponse);

            // Act
            var result = await _controller.GetMarketById(marketId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(marketResponse, okResult.Value);
        }

        [Fact]
        public async Task GetMarket_InvalidMarketId_ReturnsBadRequest()
        {
            // Arrange
            var marketId = Guid.Empty;

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetMarketById(marketId));
        }

        [Fact]
        public async Task GetStrategyMarket_NoMarketFound_ReturnsEmptyList()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            _mockMService.Setup(s => s.GetMarketById(marketId)).ReturnsAsync((MarketModel)null);

            // Act
            var result = await _controller.GetMarketById(marketId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Empty((List<MarketModel>)okResult.Value);
        }

        //[Fact]
        //public async Task SaveStrategyMarket_ReturnsOkResult_WhenModelStateIsValid()
        //{
        //    // Arrange
        //    var strategyId = Guid.NewGuid();
        //    var marketId = Guid.NewGuid();

        //   List<MarketRequest> marketRequest =  new List<MarketRequest> { 
        //        new MarketRequest
        //    {
        //        MarketId = marketId,
        //        SubStepDefName = "testdefname",
        //        SagittaPolicyId = 1212121,

        //        MarketAddlCoverages = new List<MarketAddlCovRequest>
        //            { new MarketAddlCovRequest
        //            { MarketAddlCovId =Guid.NewGuid(),
        //              CovId = 1 },
        //              new MarketAddlCovRequest
        //            { MarketAddlCovId =Guid.NewGuid(),
        //              CovId = 1 }
        //            }
        //        } };
        //    MarketRequest marRequest = 
        //        new MarketRequest
        //    {
        //        MarketId = marketId,
        //        SubStepDefName = "testdefname",
        //        SagittaPolicyId = 1212121,

        //        MarketAddlCoverages = new List<MarketAddlCovRequest>
        //            { new MarketAddlCovRequest
        //            { MarketAddlCovId =Guid.NewGuid(),
        //              CovId = 1 },
        //              new MarketAddlCovRequest
        //            { MarketAddlCovId =Guid.NewGuid(),
        //              CovId = 1 }
        //            }
        //         };
        //    var securityUser = new SecurityUserModel
        //    { SecurityUserId = "test@test.com" };
        //    StrategyMarketRequest strategymarReq = new StrategyMarketRequest
        //    {
        //        Markets = marketRequest,
        //        SecurityUser = securityUser
        //    };



        //    MarketModel markModel = new MarketModel
        //    {
        //        MarketId = marketId,
        //        StrategyId = strategyId,
        //        MarketAddlCovs = new List<MarketAddlCovModel>
        //        { new MarketAddlCovModel
        //        { MarketAddlCovId = Guid.NewGuid(),
        //            MarketId = marketId },
        //            new MarketAddlCovModel
        //            { MarketAddlCovId = Guid.NewGuid(),
        //                MarketId = marketId }
        //        }
        //    };

        //    _mockMService.Setup(s => s.SaveMarket(strategyId, securityUser.SecurityUserId, marRequest))
        //                        .ReturnsAsync(markModel);

        //    // Act
        //    var result = await _controller.SaveMarket(strategyId, strategymarReq);

        //    // Assert
        //    var okResult = Assert.IsType<OkObjectResult>(result);
        //    Assert.Equal(200, okResult.StatusCode);

        //}

        //[Fact]
        //public async Task SaveStrategyMarket_ThrowsBadRequestException_WhenModelStateIsInvalid()
        //{
        //    // Arrange
        //    var strategyId = Guid.NewGuid();
        //    var marketSaveRequest = new StrategyMarketRequest();
        //    _controller.ModelState.AddModelError("Error", "Invalid model state");

        //    // Act & Assert
        //    await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveMarket(strategyId, marketSaveRequest));
        //}

        //[Fact]
        //public async Task UpdateSingleMarket_ReturnsOkResult_WhenModelStateIsValid()
        //{
        //    // Arrange
        //    var marketId = Guid.NewGuid();
        //    var strategyId = Guid.NewGuid();


        //    var marketRequest = new MarketRequest
        //    {
        //        MarketId = marketId,
        //        SubStepDefName = "testdefname",
        //        SagittaPolicyId = 1212121,

        //        MarketAddlCoverages = new List<MarketAddlCovRequest>
        //            { new MarketAddlCovRequest
        //            { MarketAddlCovId =Guid.NewGuid(),
        //              CovId = 1 },
        //              new MarketAddlCovRequest
        //            { MarketAddlCovId =Guid.NewGuid(),
        //              CovId = 1 }
        //            }
        //    };




        //    SecurityUserModel securityUser = new SecurityUserModel
        //    { SecurityUserId = "test@test.com" };

        //    var marketSaveRequest = new StrategyMarketRequest
        //    {
        //        Markets = new List<MarketRequest> {

        //        new MarketRequest
        //        {
        //            MarketId = marketId,
        //            SubStepDefName = "testdefname",
        //            SagittaPolicyId = 1212121,

        //            MarketAddlCoverages = new List<MarketAddlCovRequest>
        //                { new MarketAddlCovRequest
        //                { MarketAddlCovId =Guid.NewGuid(),
        //                  CovId = 1 },
        //                  new MarketAddlCovRequest
        //                { MarketAddlCovId =Guid.NewGuid(),
        //                  CovId = 1 }
        //                }
        //        }
               
        //    },
        //        SecurityUser = new SecurityUserModel
        //        { SecurityUserId = "test@test.com" }
        //    };


        //    MarketModel markModel = new MarketModel
        //    {
        //        MarketId = marketId,
        //        StrategyId = strategyId,
        //        MarketAddlCovs = new List<MarketAddlCovModel>
        //            { new MarketAddlCovModel
        //            { MarketAddlCovId = Guid.NewGuid(),
        //                MarketId = marketId },
        //                new MarketAddlCovModel
        //                { MarketAddlCovId = Guid.NewGuid(),
        //                    MarketId = marketId }
        //            }
        //    };


        //    _mockMService.Setup(s => s.SaveMarket(strategyId, securityUser.SecurityUserId, marketRequest))
        //                       .ReturnsAsync(markModel);
        //    _mockMService.Setup(s => s.UpdateMarket(marketId, securityUser.SecurityUserId, marketRequest))
        //                .ReturnsAsync(markModel);

        //    // Act
        //    var result = await _controller.UpdateMarket(marketId, marketSaveRequest);

        //    // Assert
        //    var okResult = Assert.IsType<OkObjectResult>(result);
        //    Assert.Equal(200, okResult.StatusCode);

        //}

        //[Fact]
        //public async Task UpdateSingleMarket_ThrowsBadRequestException_WhenModelStateIsInvalid()
        //{
        //    // Arrange
        //    var marketId = Guid.NewGuid();
        //    var updateStrategyMarket = new StrategyMarketRequest();
        //    _controller.ModelState.AddModelError("Error", "Invalid model state");

        //    // Act & Assert
        //    await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateMarket(marketId, updateStrategyMarket));
        //}

        //[Fact]
        //public async Task UpdateSingleMarket_ThrowsBadRequestException_WhenMarketIdIsEmpty()
        //{
        //    // Arrange
        //    var marketId = Guid.Empty;
        //    var updateStrategyMarket = new StrategyMarketRequest();

        //    // Act & Assert
        //    await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateMarket(marketId, updateStrategyMarket));
        //}

        [Fact]
        public async Task DeleteSingleMarket_ReturnsOkResult_WhenModelStateIsValid()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var strategyId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "test@test.com" };
            _mockMService.Setup(s => s.RemoveMarket(marketId, securityUser.SecurityUserId))
                        .ReturnsAsync(true);
            _mockMService.Setup(s => s.GetStrategyIdByMarketId(marketId))
                       .ReturnsAsync(strategyId);

            // Act
            var result = await _controller.RemoveMarket(marketId, securityUser);

            // Assert
            var okResult = Assert.IsType<OkResult>(result);
            Assert.Equal(200, okResult.StatusCode);
            _mockMService.Verify(s => s.RemoveMarket(marketId, securityUser.SecurityUserId), Times.Once);
        }

        [Fact]
        public async Task DeleteSingleMarket_ThrowsBadRequestException_WhenModelStateIsInvalid()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "test@test.com" };
            _controller.ModelState.AddModelError("Error", "Invalid model state");

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemoveMarket(marketId, securityUser));
        }

        [Fact]
        public async Task DeleteSingleMarket_ThrowsBadRequestException_WhenMarketIdIsEmpty()
        {
            // Arrange
            var marketId = Guid.Empty;
            var securityUser = new SecurityUserModel { SecurityUserId = "testUserId" };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemoveMarket(marketId, securityUser));
        }

        [Fact]
        public async Task DeleteSingleMarket_ThrowsBadRequestException_WhenSecurityUserIdIsEmpty()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = string.Empty };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemoveMarket(marketId, securityUser));
        }

        [Fact]
        public async Task GetStrategyAllMarketPolicies_ReturnsOkResult_WithPolicyList()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var policyList = new List<SagittaPolicyModel>
        {
            new SagittaPolicyModel { SagittaPolicyId = 1234567, SagittaClientId = 2233445 },

            new SagittaPolicyModel { SagittaPolicyId = 1234568, SagittaClientId = 2233446 }
        };
            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId))
                                     .Returns(policyList);

            // Act
            var result = await _controller.GetStrategyAllMarketPolicies(strategyId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<SagittaPolicyModel>>(okResult.Value);
            Assert.Equal(2, returnValue.Count);

        }

        [Fact]
        public async Task GetStrategyAllMarketPolicies_ReturnsOkResult_WithEmptyList_WhenNoPoliciesFound()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var policyList = new List<SagittaPolicyModel>();
            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId))
                                     .Returns(policyList);

            // Act
            var result = await _controller.GetStrategyAllMarketPolicies(strategyId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<SagittaPolicyModel>>(okResult.Value);
            Assert.Empty(returnValue);
            _mockSagPolService.Verify(s => s.GetSagittaPoliciesByStrategyId(strategyId), Times.Once);
        }

        [Fact]
        public async Task StrategyMarketBulkRequests_ReturnsOkResult_WithValidRequest()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketBulkRequest = new StrategyMarketBulkRequest
            {
                SecurityUser = new SecurityUserModel { SecurityUserId = "testUserId" },
                Markets = new List<MarketRequest> { new MarketRequest() },
                SagittaPolicies = new List<SagittaPolicyModelRequest> { new SagittaPolicyModelRequest() }
            };
            var marketModelResponse = new List<MarketModel> { new MarketModel() };
            var sagittaPolicyModelResponseList = new List<SagittaPolicyModel> { new SagittaPolicyModel() };
            List<SagittaPayeeModel> sagittaPayeelist = new List<SagittaPayeeModel>();

            List<SagittaPolicyModel> sagittapolicyList = new List<SagittaPolicyModel>
            {
            new SagittaPolicyModel()
            };


            _mockMService.Setup(s => s.BulkMergeMarkets(strategyId, marketBulkRequest.SecurityUser.SecurityUserId, It.IsAny<List<MarketRequest>>()))
                        .ReturnsAsync(marketModelResponse);
            _mockSagPolService.Setup(s => s.BulkMergeSagittaPolicies(marketBulkRequest.SecurityUser.SecurityUserId, It.IsAny<List<SagittaPolicyModelRequest>>()))
                                     .Returns(sagittaPolicyModelResponseList);

            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId)).Returns(sagittapolicyList);
            _mockSagPayService.Setup(s => s.BulkMergeSagittaPayees(marketBulkRequest.SecurityUser.SecurityUserId, It.IsAny<List<SagittaPayeeRequest>>()))
                                    .Returns(sagittaPayeelist);

            // Act
            var result = await _controller.BulkMergeMarkets(strategyId, marketBulkRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<StrategyMarketBulkResponse>(okResult.Value);
            Assert.NotNull(returnValue.Markets);
            Assert.NotNull(returnValue.SagittaPolicies);

        }

        [Fact]
        public async Task StrategyMarketBulkRequests_ThrowsBadRequestException_WhenModelStateIsInvalid()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var marketBulkRequest = new StrategyMarketBulkRequest
            {
                SecurityUser = new SecurityUserModel { SecurityUserId = "testUserId" },
                Markets = new List<MarketRequest> { new MarketRequest() },
                SagittaPolicies = new List<SagittaPolicyModelRequest> { new SagittaPolicyModelRequest() }
            };
            _controller.ModelState.AddModelError("Error", "Invalid model state");

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.BulkMergeMarkets(strategyId, marketBulkRequest));
        }

        //[Fact]
        //public async Task StrategyMarketBulkRequests_ThrowsBadRequestException_WhenStrategyIdIsEmpty()
        //{
        //    // Arrange
        //    var strategyId = Guid.Empty;
        //    var marketBulkRequest = new StrategyMarketBulkRequest
        //    {
        //        SecurityUser = new SecurityUserModel { SecurityUserId = "testUserId" },
        //        Markets = new List<MarketModelRequest> { new MarketModelRequest() },
        //        SagittaPolicies = new List<SagittaPolicyModelRequest> { new SagittaPolicyModelRequest() }
        //    };

        //    // Act & Assert
        //    await Assert.ThrowsAsync<BadRequestException>(() => _controller.BulkMergeMarkets(strategyId, marketBulkRequest));
        //}
        [Fact]
        public async Task ArchiveMarket_ValidRequest_ReturnsOk()
        {
            // Arrange
            var marketId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "user123" };
            var strategyId = Guid.NewGuid();

            var mockService = new Mock<IMarketService>();
            var mockStrategyService = new Mock<IStrategyService>();
            var mockLogger = new Mock<ILogger<MarketsController>>();

            mockService.Setup(s => s.GetStrategyIdByMarketId(marketId)).ReturnsAsync(strategyId);
            mockService.Setup(s => s.ArchiveMarket(marketId, securityUser.SecurityUserId)).ReturnsAsync(true);

            // Act
            var result = await _controller.ArchiveMarket(marketId, securityUser);

            // Assert
            Assert.NotNull(result);
        }


        [Fact]
        public async Task MergeMarket_ValidRequest_ReturnsOkWithStrategyMarketResponse()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var securityUserId = "user-123";

            var marketRequest = new MarketRequest
            {
                SagittaPolicyId = 1234
            };

            var sagittaPolicyRequest = new SagittaPolicyModelRequest
            {
                SagittaPolicyId = 5432
            };

            var strategyMarketRequest = new StrategyMarketRequest
            {
                SecurityUser = new SecurityUserModel { SecurityUserId = securityUserId },
                Market = marketRequest,
                SagittaPolicies = new List<SagittaPolicyModelRequest> { sagittaPolicyRequest }
            };

            var mergedMarkets =new MarketModel() ;
            var strategyModel = new StrategyModel();
            var sagittaPolicies = new List<SagittaPolicyModel> { new SagittaPolicyModel() };

            _mockMService.Setup(s => s.MergeMarket(strategyId, securityUserId, marketRequest))
                .ReturnsAsync(mergedMarkets);

            _mockSService.Setup(s => s.SyncStrategyForMarkets(strategyId, securityUserId))
                     .ReturnsAsync(true); //

            _mockSService.Setup(s => s.GetStrategyById(strategyId, true))
                .ReturnsAsync(strategyModel);

            _mockSagPolService.Setup(s => s.GetSagittaPoliciesByStrategyId(strategyId))
                .Returns(sagittaPolicies);

            _mockSagPolService.Setup(s => s.MergeSagittaPolicy(securityUserId, sagittaPolicyRequest))
                .Returns(Task.CompletedTask);

            _mockSagPayService.Setup(s => s.MergeSagittaPayee(securityUserId, It.IsAny<SagittaPayeeRequest>()))
                .Verifiable();

            // Act
            var result = await _controller.MergeMarket(strategyId, strategyMarketRequest);

            // Assert
            //var okResult = result as OkObjectResult;

            //var response = okResult.Value as StrategyMarketResponse;

            //_mockSService.Verify(s => s.MergeMarket(strategyId, securityUserId, marketRequest), Times.Once);
            //_mockSService.Verify(s => s.SyncStrategyForMarkets(strategyId, securityUserId), Times.Once);
            //_mockSService.Verify(s => s.GetStrategyById(strategyId, true), Times.Once);
            //_mockSagPolService.Verify(s => s.GetSagittaPoliciesByStrategyId(strategyId), Times.Once);
            //_mockSagPolService.Verify(s => s.MergeSagittaPolicy(securityUserId, sagittaPolicyRequest), Times.Once);
            //_mockSagPayService.Verify(s => s.MergeSagittaPayee(securityUserId, It.IsAny<SagittaPayeeRequest>()), Times.Once);



            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            //Assert.Equal(expectedResult, okResult.Value);


        }

        private List<SagittaPolicyModel> LoadSagPolModel()
        {
            List<SagittaPolicyModel> sagpolicyMod = new List<SagittaPolicyModel>
            {
                new SagittaPolicyModel
                {
                    SagittaPolicyId = 1232323,
                    SagittaClientId = 1232234
                },
                new SagittaPolicyModel
                {
                    SagittaPolicyId = 1232444,
                    SagittaClientId = 1232555
                }
            };
            return sagpolicyMod;
        }

        private List<MarketModel> LoadMarketModel(Guid strategyId)
        {
            Guid marketId1 = Guid.NewGuid();
            Guid marketId2 = Guid.NewGuid();
            List<MarketModel> marketMod = new List<MarketModel>
            {
            new MarketModel
            {
                MarketId = marketId1,
                StrategyId =strategyId,
                MarketAddlCovs = new List<MarketAddlCovModel>
                {
                new MarketAddlCovModel
                {
                MarketAddlCovId=Guid.NewGuid(),
                MarketId =marketId1,
                },
                 new MarketAddlCovModel
                {
                MarketAddlCovId=Guid.NewGuid(),
                MarketId =marketId1
                },
               }
            },
            new MarketModel
            {
                MarketId = marketId2,
                StrategyId = strategyId,
                MarketAddlCovs = new List<MarketAddlCovModel>
                {
                new MarketAddlCovModel
                {
                MarketAddlCovId=Guid.NewGuid(),
                MarketId = marketId2
                },
                 new MarketAddlCovModel
                {
                MarketAddlCovId=Guid.NewGuid(),
                MarketId = marketId2
                },
               }
            }
            };
            return marketMod;
        }


    }
}