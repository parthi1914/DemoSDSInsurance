﻿using BrokerPortal.API.Controllers;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace BrokerPortal.API.UnitTest
{
    public class StrategyStaffsControllerTest
    {
        private readonly Mock<IStrategyStaffService> _mockService;
        private readonly Mock<IStrategyService> _mockStrategyService;
        private readonly Mock<ILogger<StrategyStaffsController>> _mockLogger;
        private readonly StrategyStaffsController _controller;
        private readonly Mock<ISagittaStaffService> _mockSagittaStaffService;
        private readonly Mock<ISagittaClientService> _mockSagittaClientService;
        private readonly Mock<ITaskStackService> _mockTaskStackService;
        private readonly Mock<BrokerPortalApiDBContext> _mockDBContext;
        private readonly Mock<IConfiguration> _mockConfig;
        private readonly Mock<HttpRequest> _mockHttpRequest;
        private readonly Mock<HttpContext> _mockHttpContext;


        public StrategyStaffsControllerTest()
        {
            _mockService = new Mock<IStrategyStaffService>();
            _mockLogger = new Mock<ILogger<StrategyStaffsController>>();
            _mockStrategyService = new Mock<IStrategyService>();
            _mockSagittaStaffService = new Mock<ISagittaStaffService>();
            _mockSagittaClientService = new Mock<ISagittaClientService>();
            _mockSagittaClientService = new Mock<ISagittaClientService>();
            _mockTaskStackService = new Mock<ITaskStackService>();
            _mockDBContext = new Mock<BrokerPortalApiDBContext>();
            _mockConfig = new Mock<IConfiguration>();
            _mockHttpRequest = new Mock<HttpRequest>();
            _mockHttpContext = new Mock<HttpContext>();


            Mock<IConfigurationSection> mockSection = new Mock<IConfigurationSection>();
            mockSection.Setup(x => x.Value).Returns("parthiban.kaliaperumal@tihinsurance.com");

            _mockConfig.Setup(x => x.GetSection("SecurityUser")).Returns(mockSection.Object);
            _controller = new StrategyStaffsController(_mockService.Object, _mockStrategyService.Object, _mockSagittaStaffService.Object,
                _mockSagittaClientService.Object, _mockTaskStackService.Object, _mockLogger.Object,
                 _mockDBContext.Object, _mockConfig.Object);



        }

        [Fact]
        public async Task GetStrategyStaffs_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var headers = new HeaderDictionary { { "Authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTIzNDU2Nzg5LCJuYW1lIjoiSm9zZXBoIn0.OpOSSw7e485LOP5PrzScxHb7SR6sAOMRckfFwi4rp7o" } };
            _mockHttpRequest.Setup(r => r.Headers).Returns(headers);
            _mockHttpContext.Setup(ctx => ctx.Request).Returns(_mockHttpRequest.Object);

            var expectedResponse = await LoadStrategyStaffModel();
            _mockService.Setup(s => s.GetStrategyStaffs(It.IsAny<Guid?>())).ReturnsAsync(expectedResponse);
            _controller.ControllerContext = new ControllerContext();
            _controller.ControllerContext.HttpContext = _mockHttpContext.Object;
            //ACT
            var result = await _controller.GetStrategyStaffs(expectedResponse.SingleOrDefault().StrategyId);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }

        [Fact]
        public async Task GetStrategyStaffsWithNull_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var headers = new HeaderDictionary { { "Authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTIzNDU2Nzg5LCJuYW1lIjoiSm9zZXBoIn0.OpOSSw7e485LOP5PrzScxHb7SR6sAOMRckfFwi4rp7o" } };
            _mockHttpRequest.Setup(r => r.Headers).Returns(headers);
            _mockHttpContext.Setup(ctx => ctx.Request).Returns(_mockHttpRequest.Object);

            var expectedResponse = await LoadStrategyStaffModel();

            _mockService.Setup(s => s.GetStrategyStaffs(It.IsAny<Guid?>()))
                        .ReturnsAsync(new List<StrategyStaffModel>());
            _mockSagittaStaffService.Setup(s => s.GetSagittaStaffIdsBySecurityUserId(It.IsAny<string?>()))
                        .ReturnsAsync(new List<string> { "PLCC"});

            _controller.ControllerContext = new ControllerContext();
            _controller.ControllerContext.HttpContext = _mockHttpContext.Object;
            //ACT
            var result = await _controller.GetStrategyStaffs(expectedResponse.SingleOrDefault().StrategyId);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }


        [Fact]
        public async Task BulkMergeStrategyStaffs_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var bulkRequest = await LoadStrategyStaffsRequest();
            var expectedResponse = LoadStrategyStaffsResponse(bulkRequest.StrategyId.Value);
            _mockService.Setup(s => s.BulkMergeStrategyStaffs(It.IsAny<Guid?>(), It.IsAny<string?>(), It.IsAny<List<StaffRequest>>())).Returns(expectedResponse);

            //ACT
            var result = await _controller.BulkMergeStrategyStaffs(bulkRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }
        [Fact]
        public async Task BulkMergeStrategyStaffs_StaffDetails_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var bulkRequest = await LoadStrategyStaffsRequest();
            bulkRequest.SagittaStaffs=new List<StaffRequest>{ new StaffRequest
            {
                StrategyStaffId = Guid.NewGuid(),
                SagittaStaffId = "SAG12345",
                IsMae = true,
                IsAccessible = true,
                IsDeleted = false,
                StaffDetails = new SagittaStaffRequest
                {
                    SagittaStaffId = "SAG12345",
                    StaffCode = "STF001",
                    StaffName = "John Doe",
                    EmployeeType = "Full-Time",
                    UserId = "jdoe",
                    StaffEmpCode = "EMP123",
                    StaffNetworkId = "NET456",
                    StaffTitle = "Manager",
                    StaffEmail = "john.doe@example.com",
                    SecurityRole = "Admin",
                    DivCode = "DIV01",
                    DeptCode = "DPT01",
                    Address1 = "123 Main St",
                    Address2 = "Suite 100",
                    City = "Chennai",
                    State = "TN",
                    Zipcode = "600001",
                    Homephone = "044-1234567",
                    MobilePhone = "9876543210",
                    Npn = "NPN789",
                    IsDatedOff = false,
                    DatedOffDate = null
                },
                StrategyStaffAssignments = new List<StrategyStaffAssignmentRequest>
    {
new StrategyStaffAssignmentRequest
        {
            StrategyStaffId = Guid.NewGuid(),
            SagittaStaffId = "SAG12345",
            StepDefId = "STEP001",
            IsDeleted = false
        },


    } }
            };

            var expectedResponse = LoadStrategyStaffsResponse(bulkRequest.StrategyId.Value);
            _mockService.Setup(s => s.BulkMergeStrategyStaffs(It.IsAny<Guid?>(), It.IsAny<string?>(), It.IsAny<List<StaffRequest>>())).Returns(expectedResponse);

            //ACT
            var result = await _controller.BulkMergeStrategyStaffs(bulkRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }

        [Fact]
        public async Task UpdateStrategyStaffs_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var bulkRequest = await LoadStrategyStaffsRequest();
            Guid? strategyStaffID = Guid.NewGuid();
            var expectedResponse = LoadStrategyStaffs(bulkRequest.StrategyId.Value);
            var user = new SecurityUserModel() { SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com" };
            _mockService.Setup(s => s.DeleteStrategyStaff(user.SecurityUserId, strategyStaffID.Value)).ReturnsAsync(true);
            //ACT
            var straetgyStaffId = Guid.NewGuid();
            var strategyStaffRequest = await LoadStrategyStaffRequest();
            var result = await _controller.UpdateStrategyStaff(straetgyStaffId, strategyStaffRequest);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }
        [Fact]
        public async Task UpdateStrategyStaffs_ValidStaff_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var bulkRequest = await LoadStrategyStaffsRequest();
            Guid? strategyStaffID = Guid.NewGuid();
            var expectedResponse = LoadStrategyStaffs(bulkRequest.StrategyId.Value);
            var user = new SecurityUserModel() { SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com" };
            _mockService.Setup(s => s.DeleteStrategyStaff(user.SecurityUserId, strategyStaffID.Value)).ReturnsAsync(true);
            //ACT
            var straetgyStaffId = Guid.NewGuid();
            var strategyStaffRequest = await LoadStrategyStaffRequest();
            _controller.ModelState.AddModelError("userId", "Invalid userId");

            //ASSERT
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateStrategyStaff(straetgyStaffId, strategyStaffRequest));
        }
        [Fact]
        public async Task UpdateStrategyStaffs_InValidUser_ValidStrategyId_ReturnsOk()
        {
            //ARRANGE
            var bulkRequest = await LoadStrategyStaffsRequest();
            Guid? strategyStaffID = Guid.NewGuid();
            var expectedResponse = LoadStrategyStaffs(bulkRequest.StrategyId.Value);
            var user = new SecurityUserModel() { SecurityUserId = "" };
            _mockService.Setup(s => s.DeleteStrategyStaff(user.SecurityUserId, strategyStaffID.Value)).ReturnsAsync(true);
            //ACT
            var straetgyStaffId = Guid.NewGuid();
            var strategyStaffRequest = await LoadStrategyStaffRequest();
            _controller.ModelState.AddModelError("userId", "Invalid userId");

            //ASSERT
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateStrategyStaff(straetgyStaffId, strategyStaffRequest));
        }

        [Fact]
        public async Task DeleteStrategyStaff_ReturnsOk_WhenValid()
        {
            //ARRANGE
            Guid? strategyStaffID = Guid.NewGuid();
            var user = new SecurityUserModel() { SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com" };
            _mockService.Setup(s => s.DeleteStrategyStaff(user.SecurityUserId,strategyStaffID.Value)).ReturnsAsync(true);

            //ACT
            var result = await _controller.RemoveStrategyStaff(strategyStaffID.Value,user);

            //ASSERT
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);
        }


        private Task<Guid?> GetStrategyStaffID()
        {
            Guid? strategyStaffID = Guid.NewGuid();
            return Task.FromResult(strategyStaffID);
        }


        private Task<List<StrategyStaffModel>> LoadStrategyStaffModel()
        {
            List<StrategyStaffModel> strategyStaffModels = new List<StrategyStaffModel>();
            StrategyStaffModel strategyStaffModel = new StrategyStaffModel();
            strategyStaffModel.StrategyId = Guid.NewGuid();
            strategyStaffModel.StrategyStaffId = Guid.NewGuid();
            strategyStaffModel.IsAccessible = true;

            strategyStaffModels.Add(strategyStaffModel);
            return Task.FromResult(strategyStaffModels);

        }

        private Task<StrategyStaffsRequest> LoadStrategyStaffsRequest()
        {
            StrategyStaffsRequest strategyStaffsRequest = new StrategyStaffsRequest();
            strategyStaffsRequest.StrategyId = Guid.NewGuid();
            strategyStaffsRequest.SecurityUsers.SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com";


            StrategyTimelinesRequest strategyTimelinesRequest = new StrategyTimelinesRequest();
            strategyTimelinesRequest.StrategyId = strategyStaffsRequest.StrategyId.Value;
            strategyTimelinesRequest.StepDefId = "MS-SUBM";
            strategyTimelinesRequest.StrategyTimelineId = Guid.NewGuid();

            StaffRequest staffRequest = new StaffRequest();
            staffRequest.StrategyStaffId = Guid.NewGuid();
            staffRequest.IsAccessible = true;

            strategyStaffsRequest.StrategyTimelines.Add(strategyTimelinesRequest);
            strategyStaffsRequest.SagittaStaffs = new List<StaffRequest>();
            strategyStaffsRequest.SagittaStaffs.Add(staffRequest);
            return Task.FromResult(strategyStaffsRequest);

        }


        //private StrategyStaffsResponse LoadStrategyStaffsResponse(Guid strategyId)
        //{
        //    var response = new StrategyStaffsResponse() 
        //                            { StrategyId = strategyId,
        //                             SagittaStaffs =new List<StrategyStaffModel> { new StrategyStaffModel { SagittaStaffId = "101", CreatedDate =DateTime.Now } }
        //                            };
        //    return response;
        //}

        private Task<List<StrategyStaffModel>> LoadStrategyStaffsResponse(Guid strategyId)
        {
            List<StrategyStaffModel> strategyStaffModels = new List<StrategyStaffModel>();
            var StrategyStaffModel = new StrategyStaffModel()
            {
                StrategyId = strategyId,
                CreatedDate = DateTime.Now,
                SagittaStaffId = "101",
                IsMae = true
            };

            strategyStaffModels.Add(StrategyStaffModel);

            return Task.FromResult(strategyStaffModels);
        }

        private Task<StrategyStaffModel> LoadStrategyStaffs(Guid strategyId)
        {
            var StrategyStaffModel = new StrategyStaffModel()
            {
                StrategyId = strategyId,
                CreatedDate = DateTime.Now,
                SagittaStaffId = "101",
                IsMae = true
            };

            return Task.FromResult(StrategyStaffModel);
        }

        private Task<StrategyStaffRequest> LoadStrategyStaffRequest()
        {
            StrategyStaffRequest strategyStaffRequest = new StrategyStaffRequest();
            strategyStaffRequest.StrategyStaff = new StaffRequest
            {
                StrategyStaffId = Guid.NewGuid(),
                IsAccessible = true,
                SagittaStaffId = "101"
            };
            strategyStaffRequest.SecurityUser.SecurityUserId = "parthiban.kaliaperumal@tihinsurance.com";


            return Task.FromResult(strategyStaffRequest);

        }


    }
}
