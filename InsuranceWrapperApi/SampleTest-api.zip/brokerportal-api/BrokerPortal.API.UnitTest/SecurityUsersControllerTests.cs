﻿using BrokerPortal.API.Controllers;
using BrokerPortal.API.Controllers.Aggregate;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.SagittaRepl;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokerPortal.API.UnitTest
{
    public class SecurityUsersControllerTests
    {
        private readonly Mock<ILogger<SecurityUsersController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<ISecurityUserService> _mockSService;
        private readonly Mock<ISagittaStaffService> _mockSSService;
        private readonly SecurityUsersController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;
        public SecurityUsersControllerTests()
        {
            _mockLogger = new Mock<ILogger<SecurityUsersController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
            _mockSService = new Mock<ISecurityUserService>();
            _mockSSService = new Mock<ISagittaStaffService>();
            _controller = new SecurityUsersController(_mockLogger.Object, _mockSService.Object,_mockSSService.Object,null);

        }

        [Fact]
        public async Task MapOrSyncSecurityUserToExternalUsers_ReturnsOk_WhenValid()
        {
            // Arrange
            string securityUserId = "user123";
            string externalSystemId = "SAGITTA";
            string employeeId = "emp123";
            var replResponse = new List<SagittaReplStaffModel> { new() { StaffId = "staff1" } };
            var staffModels = new List<SagittaStaffModel> { new() };

            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };

            _mockSService.Setup(s => s.GetEmployeeIdBySecurityUserId(securityUserId)).ReturnsAsync(employeeId);
            _mockSSService.Setup(s => s.GetMappedSagittaStaffsFromReplBySecurityUserEmployeeId(It.IsAny<string>(), securityUserId, employeeId)).ReturnsAsync(replResponse);
            _mockSSService.Setup(s => s.BulkMergeSagittaStaffsFromReplResponse(securityUserId, replResponse)).ReturnsAsync(staffModels);
            _mockSService.Setup(s => s.BulkMergeUserMapExternalSystem(securityUserId, externalSystemId, It.IsAny<List<string>>())).ReturnsAsync(true);

            // Act
            var result = await _controller.MapOrSyncSecurityUserToExternalUsers(securityUserId, externalSystemId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("SUCCESS", okResult.Value);
        }

    }
}
