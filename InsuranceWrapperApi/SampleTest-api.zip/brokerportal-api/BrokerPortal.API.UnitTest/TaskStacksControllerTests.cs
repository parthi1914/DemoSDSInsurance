using BrokerPortal.API.Controllers;
using BrokerPortal.API.Repositories.DBContext;
using BrokerPortal.API.RepositoryContracts.Domain;
using BrokerPortal.API.ServiceContracts;
using BrokerPortal.API.ServiceContracts.Models;
using BrokerPortal.API.ServiceContracts.Models.Favourite;
using BrokerPortal.API.ServiceContracts.Models.Sagitta;
using BrokerPortal.API.ServiceContracts.Models.Strategy;
using BrokerPortal.API.ServiceContracts.Models.TaskStacks;
using Microsoft.Net.Http.Headers;
using BrokerPortal.API.Utilities;
using BrokerPortal.API.Utilities.GlobalException;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.AspNetCore.Http;

namespace BrokerPortal.API.UnitTest
{
    public class TaskStacksControllerTests
    {

        private readonly Mock<ILogger<TaskStacksController>> _mockLogger;
        private readonly Mock<BrokerPortalApiDBContext> _mockContext;
        private readonly Mock<ITaskStackService> _mockTService;
        private readonly Mock<ISagittaStaffService> _mockSService;
        private readonly Mock<ISagittaClientService> _mockCService;
        private readonly TaskStacksController _controller;
        private readonly DbContextOptions<BrokerPortalApiDBContext> _dbContextOptions;
        private readonly BrokerPortalApiDBContext _context;

        public TaskStacksControllerTests()
        {
            _mockLogger = new Mock<ILogger<TaskStacksController>>();
            _dbContextOptions = new DbContextOptionsBuilder<BrokerPortalApiDBContext>()
          .UseInMemoryDatabase(databaseName: "TestDatabase")
           .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
           .Options;
            _context = new BrokerPortalApiDBContext(_dbContextOptions);
            _mockTService = new Mock<ITaskStackService>();
            _mockSService = new Mock<ISagittaStaffService>();
            _mockCService = new Mock<ISagittaClientService>();
            _controller = new TaskStacksController(_mockTService.Object, _mockSService.Object,_mockCService.Object, _mockLogger.Object);

        }

        [Fact]
        public async Task GetAllTaskStacks_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        {
            // Arrange
            var taskStacks = new List<TaskStackModel> { new TaskStackModel() };
            _mockTService.Setup(service => service.GetAllTaskStacks())
                        .ReturnsAsync(taskStacks);

            // Act
            var result = await _controller.GetAllTaskStacks();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.NotEmpty(returnValue);

        }

        [Fact]
        public async Task GetAllTaskStacks_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            _mockTService.Setup(service => service.GetAllTaskStacks())
                        .ReturnsAsync(new List<TaskStackModel>());

            // Act
            var result = await _controller.GetAllTaskStacks();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.Empty(returnValue);

        }


        [Fact]
        public async Task GetAllTaskStacks_ReturnsNotFound_WhenServiceReturnsNull()
        {
            // Arrange
            List<TaskStackModel> taskList = null;
            _mockTService.Setup(s => s.GetAllTaskStacks()).ReturnsAsync(taskList);

            // Act
            var result = await _controller.GetAllTaskStacks();

            // Assert
            var notFoundResult = Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task GetTaskStackById_ThrowsBadRequestException_WhenTaskStackIdIsEmpty()
        {
            // Arrange
            var taskStackId = Guid.Empty;

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.GetTaskStackById(taskStackId));
        }

        [Fact]
        public async Task GetTaskStackById_ReturnsOk_WithResult_WhenResultIsNotNull()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var taskStackModel = new TaskStackModel();
            _mockTService.Setup(service => service.GetTaskStackById(taskStackId))
                        .ReturnsAsync(taskStackModel);

            // Act
            var result = await _controller.GetTaskStackById(taskStackId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(taskStackModel, okResult.Value);

        }

        [Fact]
        public async Task GetTaskStackById_ReturnsOk_WithEmptyList_WhenResultIsNull()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            _mockTService.Setup(service => service.GetTaskStackById(taskStackId))
                        .ReturnsAsync((TaskStackModel)null);

            // Act
            var result = await _controller.GetTaskStackById(taskStackId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.Empty(returnValue);

        }

        [Fact]
        public async Task SaveTaskStack_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("taskRequest", "Invalid task request");
            var taskRequest = new TaskStackRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveTaskStack(taskRequest));
        }

        [Fact]
        public async Task SaveTaskStack_ReturnsOk_WithResponse()
        {
            // Arrange
            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };
            var taskRequest = new TaskStackRequest
            {
                TaskInfo = new TaskStackRequestInfo
                {
                    TaskStackId = Guid.NewGuid(),
                    StepDefId = "MP-BIND",
                    TaskMeta=new TaskMetaRequest
                    {
                        SagittaClientId=123,
                    },
                    TaskAssignTo = ["PLCC"],
                    //TaskName = "TestTask"
                },
                SecurityUser = new SecurityUserModel { SecurityUserId = "test@test.com" }
            };
            var taskResponse = new TaskStackModel
            {
                TaskStackId = taskRequest.TaskInfo.TaskStackId ?? default,
                //StepDefId = "MP-BIND",
                //StepName = "Bind"
            };
            _mockTService.Setup(service => service.SaveTaskStack(taskRequest.SecurityUser.SecurityUserId, taskRequest.TaskInfo))
                .ReturnsAsync(taskResponse);

            // Act
            var result = await _controller.SaveTaskStack(taskRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(taskResponse, okResult.Value);

        }
        [Fact]
        public async Task SaveStrategy_ReturnsBadRequest_WhenServiceThrowsException()
        {
            // Arrange
            var taskRequest = new TaskStackRequest();
            _mockTService.Setup(s => s.SaveTaskStack(taskRequest.SecurityUser.SecurityUserId, taskRequest.TaskInfo)).ThrowsAsync(new BadRequestException("Service error"));

            // Act
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SaveTaskStack(taskRequest));

        }

        [Fact]
        public async Task Put_ReturnsBadRequest_WhenTaskRequestIsNull()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            TaskStackRequest taskRequest = null;
            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };

            // Act
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateTaskStack(taskStackId, taskRequest));
        }

        [Fact]
        public async Task Put_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("taskRequest", "Invalid task request");
            var taskRequest = new TaskStackRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateTaskStack(Guid.NewGuid(), taskRequest));
        }

        [Fact]
        public async Task Put_ReturnsBadRequest_WhenTaskStackIdIsEmpty()
        {
            // Arrange
            var taskRequest = new TaskStackRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.UpdateTaskStack(Guid.Empty, taskRequest));
        }

        [Fact]
        public async Task Put_ReturnsOk_WithResponse()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();

            var context = new DefaultHttpContext();
            context.Request.Headers[HeaderNames.Authorization] = "Bearer test-token";
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = context
            };
            var taskRequest = new TaskStackRequest
            {
                TaskInfo = new TaskStackRequestInfo
                {

                    StepDefId = "MP-BIND",
                    TaskMeta = new TaskMetaRequest
                    {
                        SagittaClientId = 123,
                    },
                    TaskAssignTo = ["PLCC"],
                    //StepName = "Bind",
                    //TaskName = "TestTask"
                },
                SecurityUser = new SecurityUserModel { SecurityUserId = "test@test.com" }
            };
            TaskStackModel taskResponse = new TaskStackModel
            {
                TaskStackId = taskStackId,
                //StepDefId = "MP-BIND",
                //StepName = "Bind"
            };
            _mockTService.Setup(service => service.UpdateTaskStack(taskRequest.SecurityUser.SecurityUserId, taskStackId, taskRequest.TaskInfo))
                        .ReturnsAsync(taskResponse);

            // Act
            var result = await _controller.UpdateTaskStack(taskStackId, taskRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(taskResponse, okResult.Value);

        }

        [Fact]
        public async Task DeleteTask_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("securityUser", "Invalid security user");
            var securityUser = new SecurityUserModel();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller .RemoveTaskStack(Guid.NewGuid(), securityUser));
        }

        [Fact]
        public async Task DeleteTask_ReturnsBadRequest_WhenTaskStackIdIsEmpty()
        {
            // Arrange
            var securityUser = new SecurityUserModel { SecurityUserId = "user@test.com" };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemoveTaskStack(Guid.Empty, securityUser));
        }

        [Fact]
        public async Task DeleteTask_ReturnsBadRequest_WhenSecurityUserIdIsEmpty()
        {
            // Arrange
            var securityUser = new SecurityUserModel { SecurityUserId = string.Empty };

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.RemoveTaskStack(Guid.NewGuid(), securityUser));
        }

        [Fact]
        public async Task DeleteTask_ReturnsOk_WithResponse()
        {
            // Arrange
            var taskStackId = Guid.NewGuid();
            var securityUser = new SecurityUserModel { SecurityUserId = "user@test.com" };
            var response = true; // Assuming the response is a boolean indicating success
            _mockTService.Setup(service => service.RemoveTaskStack(taskStackId, securityUser.SecurityUserId))
                        .ReturnsAsync(response);

            // Act
            var result = await _controller.RemoveTaskStack(taskStackId, securityUser);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(response, okResult.Value);
          
        }



      
        [Fact]
        public async Task SearchTaskStacks_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("searchRequest", "Invalid search request");
            var searchRequest = new TaskSearchRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchTaskStacks(searchRequest));
        }

        [Fact]
        public async Task SearchTaskStacks_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            TaskSearchRequest searchRequest = new TaskSearchRequest
            {
                SearchType = "ALL",
                SearchCriterias = new TaskSearchCriterias
                {
                    //stepDefCodes = ["ALL"],
                    TaskStatusCodes = [
                                  "ALL"
                                 ]
                },
                SecurityUser = new SecurityUserModel
                {
                    SecurityUserId = "test@test.com",
                    SecurityUserEmail = "user@system.com"
                }
            };
            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType);
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;
            SecurityUserModel securityUser = searchRequest.SecurityUser;
            _mockTService.Setup(service => service.SearchTaskStacks(
               SearchBaseFilterType.ALL, TaskSearchType.ALL, searchCriterias,
                securityUser.SecurityUserId,
                null,null))
                .ReturnsAsync(new List<TaskStackModel>());

            // Act
            var result = await _controller.SearchTaskStacks(searchRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.Empty(returnValue);
           
        }


        [Fact]
        public async Task SearchTaskStacksByUser_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("searchRequest", "Invalid search request");
            var searchRequest = new TaskSearchRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchTaskStacksByUser("validUserId", searchRequest));
        }

        //[Fact]
        //public async Task SearchTaskStacksByUser_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        //{
        //    // Arrange
        //    var userId = "test@test.com";
        //    TaskSearchRequest searchRequest = new TaskSearchRequest
        //    {
        //        SearchType = "ALL",
        //        SearchCriterias = new TaskSearchCriterias
        //        {
        //        stepDefCodes= ["ALL"],
        //        TaskStatusCodes= [
        //                         "ALL"
        //                        ]
        //        },
        //        SecurityUser  = new SecurityUserModel
        //        {
        //            SecurityUserId= "test@test.com",
        //            SecurityUserEmail= "user@system.com"
        //         }
        //    };
        //    TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType);
        //    TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;
        //    SecurityUserModel securityUser = searchRequest.SecurityUser;
        //    var taskList = new List<TaskSearchModel> {
        //        new TaskSearchModel {
        //            TaskStackId = Guid.NewGuid()

        //    },
        //         new TaskSearchModel {
        //            TaskStackId = Guid.NewGuid()

        //    }

        //    };
        //    _mockTService.Setup(service => service.SearchTaskStacks(SearchBaseFilterType.ALL, TaskSearchType.ALL, searchCriterias,
        //        securityUser.SecurityUserId,
        //        null))
        //        .ReturnsAsync(taskList);

        //    // Act
        //    var result = await _controller.SearchTaskStacksByUser(userId, searchRequest);

        //    // Assert
        //    var okResult = Assert.IsType<OkObjectResult>(result);
        //    var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
        //    Assert.NotEmpty(returnValue);
           
        //}

        [Fact]
        public async Task SearchTaskStacksByUser_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            var userId = "test@test.com";
            TaskSearchRequest searchRequest = new TaskSearchRequest
            {
                SearchType = "ALL",
                SearchCriterias = new TaskSearchCriterias
                {
                //stepDefCodes= [
                               //  "ALL"
                               //],
                TaskStatusCodes= [
                                 "ALL"
                                ]
                },
                SecurityUser = new SecurityUserModel
                {
                    SecurityUserId= "test@test.com",
                    SecurityUserEmail= "user@system.com"
                 }
            };
            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType);
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;
            SecurityUserModel securityUser = searchRequest.SecurityUser;
           
            _mockTService.Setup(service => service.SearchTaskStacks(SearchBaseFilterType.ALL, TaskSearchType.ALL, searchCriterias,
                securityUser.SecurityUserId,
                null,null))
                .ReturnsAsync(new List<TaskStackModel>());

            // Act
            var result = await _controller.SearchTaskStacksByUser(userId, searchRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.Empty(returnValue);
           
        }

        


        [Fact]
        public async Task SearchTaskStacksByClient_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("searchRequest", "Invalid search request");
            var searchRequest = new TaskSearchRequest();

            // Act & Assert
            await Assert.ThrowsAsync<BadRequestException>(() => _controller.SearchTaskStacksByClient("validClientId", searchRequest));
        }

        //[Fact]
        //public async Task SearchTaskStacksByClient_ReturnsOk_WithResults_WhenResultsAreNotEmpty()
        //{
        //    // Arrange
        //    var sagittaclientid = "validClientId";
        //    TaskSearchRequest searchRequest = new TaskSearchRequest
        //    {
        //        SearchType = "ALL",
        //        SearchCriterias = new TaskSearchCriterias
        //        {
        //        stepDefCodes= [
        //                         "ALL"
        //                       ],
        //        TaskStatusCodes= [
        //                         "ALL"
        //                        ]
        //        },
        //        SecurityUser = new SecurityUserModel
        //        {
        //            SecurityUserId= "test@test.com",
        //            SecurityUserEmail= "user@system.com"
        //         }
        //    };
        //    TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType);
        //    TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;
        //    SecurityUserModel securityUser = searchRequest.SecurityUser;
        //    var taskList = new List<TaskSearchModel> { 
        //        new TaskSearchModel {
        //            TaskStackId = Guid.NewGuid()

        //    },
        //         new TaskSearchModel {
        //            TaskStackId = Guid.NewGuid()

        //    }

        //    };
        //    _mockTService.Setup(service => service.SearchTaskStacks(SearchBaseFilterType.ALL,TaskSearchType.ALL, searchCriterias,
        //        securityUser.SecurityUserId,
        //        sagittaclientid))
        //        .ReturnsAsync(taskList);

        //    // Act
        //    var result = await _controller.SearchTaskStacksByClient(sagittaclientid, searchRequest);

        //    // Assert
        //    var okResult = Assert.IsType<OkObjectResult>(result);
        //    var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
        //    Assert.NotEmpty(returnValue);

        //}

        [Fact]
        public async Task SearchTaskStacksByClient_ReturnsOk_WithEmptyList_WhenResultsAreEmpty()
        {
            // Arrange
            var sagittaclientid = "100097";

            TaskSearchRequest searchRequest = new TaskSearchRequest
            {
                SearchType = "ALL",
                SearchCriterias = new TaskSearchCriterias {
                //stepDefCodes= [
                //                 "ALL"
                //               ],
                TaskStatusCodes= [
                                 "ALL"
                                ]
                },
                SecurityUser = new SecurityUserModel
                {
                    SecurityUserId= "test@test.com",
                    SecurityUserEmail= "user@system.com"
                 }
            };
            TaskSearchType searchType = Enum.Parse<TaskSearchType>(searchRequest.SearchType);
            TaskSearchCriterias searchCriterias = searchRequest.SearchCriterias;
            SecurityUserModel securityUser = searchRequest.SecurityUser;
           
            _mockTService.Setup(service => service.SearchTaskStacks(SearchBaseFilterType.ALL, TaskSearchType.ALL, searchCriterias,
                securityUser.SecurityUserId,
                Convert.ToInt64(sagittaclientid),null))
                .ReturnsAsync(new List<TaskStackModel>());

            // Act
            var result = await _controller.SearchTaskStacksByClient(sagittaclientid, searchRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.Empty(returnValue);

        }


        [Fact]
        public async Task SearchTaskStacksByStrategy_ReturnsOk_WithResults()
        {
            // Arrange
            var strategyId = Guid.NewGuid();
            var searchRequest = new TaskSearchRequest
            {
                SecurityUser = new SecurityUserModel { SecurityUserId = "test@example.com" },
                SearchType = "ALL",
                SearchCriterias = new TaskSearchCriterias()
            };

            var expectedResults = new List<TaskStackModel> { new TaskStackModel() };

            _mockTService.Setup(s => s.SearchTaskStacks(
            SearchBaseFilterType.STRATEGY_SPECIFIC,
            It.IsAny<TaskSearchType>(),
            searchRequest.SearchCriterias,
            "test@example.com",
            null,
            strategyId)).ReturnsAsync(expectedResults);

            // Act
            var result = await _controller.SearchTaskStacksByStrategy(strategyId, searchRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<List<TaskStackModel>>(okResult.Value);
            Assert.Single(returnValue);
        }








    }
}